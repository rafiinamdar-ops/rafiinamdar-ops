/*
Missing Index Details from SQLQuery32.sql - sql-ent-37.AppSenseManagementServer_MS (CORP\s9012592 (160))
The Query Processor estimates that implementing the following index could improve the query cost by 98.4947%.
*/

/*
USE [AppSenseManagementServer_MS]
GO
CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>]
ON [dbo].[Machines] ([GroupFK])
INCLUDE ([MachinePK])
GO
*/

/*
Missing Index Details from SQLQuery32.sql - sql-ent-37.AppSenseManagementServer_MS (CORP\s9012592 (160))
The Query Processor estimates that implementing the following index could improve the query cost by 98.8513%.
*/

/*
USE [AppSenseManagementServer_MS]
GO
CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>]
ON [dbo].[Machines] ([GroupFK])

GO
*/
/*
Missing Index Details from SQLQuery38.sql - sql-ent-37.AppSenseManagementServer_MS (CORP\s9012592 (178))
The Query Processor estimates that implementing the following index could improve the query cost by 98.4843%.
*/

/*
USE [AppSenseManagementServer_MS]
GO
CREATE NONCLUSTERED INDEX [<Name of Missing Index, sysname,>]
ON [dbo].[Machines] ([GroupFK])
INCLUDE ([MachinePK])
GO
*/
