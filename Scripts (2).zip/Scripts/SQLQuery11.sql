USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_StartBackupDD]    Script Date: 11/24/2016 11:06:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO



ALTER   Procedure [dbo].[proc_StartBackupDD] @sBackupType varchar(4)
as
DECLARE @bksize as bigint
DECLARE dblist CURSOR READ_ONLY FOR 
SELECT distinct sysdb.NAME 
   FROM master.dbo.sysdatabases sysdb
   Where sysdb.name not in (select * from BACKUP_EXCLUSION_LIST)
   and sysdb.name not in ('master', 'msdb')
   and sysdb.name in (select name from sys.databases where state_desc='online')
   order by sysdb.Name
DECLARE @name nvarchar(128)
OPEN dblist
FETCH NEXT FROM dblist INTO @name
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN

		SET @bksize=(SELECT TOP 1
						CAST(s.backup_size / 1000000 AS bigINT)
						FROM msdb.dbo.backupset s
						INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
						WHERE s.database_name =  @name and s.[type]='D' -- Remove this line for all the database
						ORDER BY backup_start_date DESC, backup_finish_date)
			If @bksize >30000
					exec sqldba..proc_BackupDDWS @sBackupType, @name
			Else
					exec sqldba..proc_BackupDD @sBackupType, @name
		END
	FETCH NEXT FROM dblist INTO @name
END
CLOSE dblist
DEALLOCATE dblist
/* Backup master and msdb databases last so all other backups are in msdb*/
exec sqldba..proc_BackupDD 'db', 'master'
exec sqldba..proc_BackupDD 'db', 'msdb'





GO


