USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_VerifyAllDBs_First]    Script Date: 12/22/2016 5:19:53 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO




Alter Procedure [dbo].[proc_VerifyAllDBs_First]
as
/* Procedure to verify all DBs on server by running xp_sqlmaint with        */
/* 	-CkDB parameter                        			                      */
/* Written by: 		Murray DeVore					                            */
/* Date Written:	10/30/2003					                                  */
/* Revision Log					                                              */
/* Revised By   Mahammadrafik Inamdar   Date 2/23/2014    
				Comments  Updated proc_VerifyAllDBs to stop using deprecated 'xp_sqlmaint commands and use DBCC CHECKDB */
/* -------------   ----------   -----------------------------------------------------------------------------------------------*/
declare @sParamString varchar(100)
Declare @currentdate datetime
Declare @EndTime datetime
Declare @HalfTotalDuartion int
DECLARE @LastVerifyRun int
DECLARE @SumDuration int
DECLARE @Veriflag int
DECLARE @currnetrunvalue int

SET @Veriflag=0
SET @SumDuration=0
SET @LastVerifyRun=(SELECT [VarValue] FROM [sqldba].[dbo].[VARIABLE] Where [VarName]='VerifyRunValue')
IF @LastVerifyRun=3
SET @currnetrunvalue=1
ELSE 
	@currnetrunvalue=@LastVerifyRun+1

----PRINT  @LastVerifyRun
--IF  @LastVerifyRun =3
--BEGIN
SET @HalfTotalDuartion=( SELECT Sum((Datediff(minute,Startdate,Endtime))) as TotalDuration
					FROM [sqldba].[dbo].[DBVerify_Stats] A 
					WHERE EndTime in 
					(Select Max(EndTime) from [sqldba].[dbo].[DBVerify_Stats] B
					where B.[DBName] = A.[DBName]))/3
SELECT @HalfTotalDuartion
--UPDATE [sqldba].[dbo].[VARIABLE]
--SET  [VarValue]=@HalfTotalDuartion
--WHERE [VarName]='VerifyDuration'
--END
INSERT INTO sqldba.[dbo].[VerifyDBTable] (DBName) SELECT Name from sys.databases 
											where NAME not in ('tempdb')
											and name not in (select * from BACKUP_EXCLUSION_LIST)								
						and  Name not in (SELECT DBName from sqldba.[dbo].[VerifyDBTable])
DECLARE dblist CURSOR READ_ONLY FOR 
   SELECT t.dbname
FROM (
      SELECT DBName, MAX(EndTime) as MaxTime
      FROM [sqldba].[dbo].[DBVerify_Stats] 
      GROUP BY DBname
) r
INNER JOIN [sqldba].[dbo].[DBVerify_Stats]  t
ON t.dbname = r.dbname AND t.EndTime = r.MaxTime
ORDER BY datediff(minute,t.startdate, r.MaxTime)  Desc

DECLARE @name nvarchar(128)
OPEN dblist
FETCH NEXT FROM dblist INTO @name
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
      /* Validate Database Integrity */
	  SET @Veriflag=(SELECT veriflag from SQLDBA.[dbo].[VerifyDBTable] Where DBname=@name)
	  IF @SumDuration<=@HalfTotalDuartion and @Veriflag=0
	  BEGIN
	  SET @currentdate=(select getdate())
	  INSERT INTO SQLDBA.[dbo].[DBVerify_Stats]
           ([DBName]
           ,[StartDate])           
     VALUES
           (@name
           ,@currentdate)
		print 'DBCC CHECKDB '+@name
		DBCC CHECKDB(@name) with no_infomsgs  
		
		SET @EndTime=(SELECT getdate())
		UPDATE SQLDBA.[dbo].[DBVerify_Stats]
		SET EndTime=@EndTime
		WHERE [DBName]=@name and [StartDate]=@currentdate
		UPDATE SQLDBA.[dbo].[VerifyDBTable]
		SET veriflag=1,runvalue=@currnetrunvalue
		Where DBname=@name
		SET @SumDuration=@SumDuration+(SELECT datediff(minute,@currentdate,@EndTime))

		SELECT @SumDuration as Duration
	 END
	 ELSE
	 UPDATE SQLDBA.[dbo].[VerifyDBTable]
	 SET veriflag=0
	 Where DBname=@name
	END

	FETCH NEXT FROM dblist INTO @name
END
CLOSE dblist
DEALLOCATE dblist


--EXEC msdb.dbo.sp_start_job @job_name = 'SQLDBA_Update_Stats'
IF  @LastVerifyRun =3
BEGIN
UPDATE [sqldba].[dbo].[VARIABLE] 
SET [VarValue]=1
Where [VarName]='VerifyRunValue'
UPDATE SQLDBA.[dbo].[VerifyDBTable]
SET veriflag=0
END
ELSE
UPDATE [sqldba].[dbo].[VARIABLE] 
SET [VarValue]=@LastVerifyRun+1
Where [VarName]='VerifyRunValue'







GO


