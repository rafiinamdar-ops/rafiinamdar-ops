Declare @servername varchar(100)
Declare @sql varchar(500)
SET @servername='"HPN-ICT-70"'
SET @sql ='wmic /node:'+@servername+' logicaldisk get size,freespace,caption /FORMAT:CSV'
print @sql
CREATE TABLE #WMIC (
    
    CmdOutput VARCHAR(1000),
	EventDate datetime 
)
ALTER TABLE [#WMIC] ADD  CONSTRAINT [WMIC_Eventdate]  DEFAULT (getdate()) FOR [Eventdate]
INSERT INTO #WMIC (CmdOutput) EXEcute master..xp_cmdshell @sql
--EXECUTE xp_cmdshell 'wmic /node:"hpn-ict-70","SQL-RDU-74" logicaldisk get size,freespace,caption /FORMAT:CSV' 
	 select * from #WMIC  where [CmdOutput] like '%'+@servername+'%'
 DROP TABLE #WMIC 