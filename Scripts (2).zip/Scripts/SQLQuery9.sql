USE [msdb]
GO

SELECT [id]
      ,[name]
      ,[enabled]
      ,[email_address]
      ,[last_email_date]
      ,[last_email_time]
      ,[pager_address]
      ,[last_pager_date]
      ,[last_pager_time]
      ,[weekday_pager_start_time]
      ,[weekday_pager_end_time]
      ,[saturday_pager_start_time]
      ,[saturday_pager_end_time]
      ,[sunday_pager_start_time]
      ,[sunday_pager_end_time]
      ,[pager_days]
      ,[netsend_address]
      ,[last_netsend_date]
      ,[last_netsend_time]
      ,[category_id]
      
  FROM [dbo].[sysoperators] where  [email_address]  like '%hp.com%'
GO


