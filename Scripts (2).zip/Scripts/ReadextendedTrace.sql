SET NUMERIC_ROUNDABORT OFF
SELECT
n.value('(@name)[1]', 'varchar(50)') AS event_name,
n.value('(/event/data[@name="wait_type"]/value)[1]', 'int') AS [wait_type]
,n.value('(/event/data[@name="wait_type"]/text)[1]', 'varchar(max)') AS [wait_typeT]
,n.value('(/event/action[@name="database_name"]/value)[1]', 'varchar(max)') AS [database_name]
--n.value('(/event/action[@name="server_principal_name"]/value)[1]', 'varchar(max)') AS [LoginName],
--n.value('(/event/action[@name="client_app_name"]/value)[1]', 'varchar(max)') AS [client_app_namee],
,n.value('(/event/action[@name="sql_text"]/value)[1]', 'varchar(max)') AS [sql_text]
INTO
 #Temp
FROM
   (
         select CAST(event_data as XML) AS event_data
		
		 from sys.fn_xe_file_target_read_file
        (
        'J:\*.xel', 
        'J:\*.xem', 
		null, 
		null
        )

    ) 
	--as xmlr(xdata) 
	 as tab
		CROSS APPLY event_data.nodes('event') as q(n)

SELECT * FROM #Temp --WHERE LoginName <>'CORP\s9012592'

DROP TABLE #Temp
	

			SELECT * FROM 
sys.fn_xe_file_target_read_file('J:\*.xel', 'J:\*.xem', null, null) where object_name ='wait_info'

	




