-- Find the database file space usage
-- no harm in running on production server
use SCAT ;
SELECT 
	[Time] = CURRENT_TIMESTAMP ,DbName=DB_NAME(), file_id
	,[Status]=state_desc
	,LogicalFileName=name
	,FileSizeAllocated_MB= CONVERT(DECIMAL(8,2),size/128.0)
	,[File_UsedSpace_MB] = CONVERT(DECIMAL(8,2),FILEPROPERTY(name, 'spaceused')/128.0)
	,Maxsize_MB= CASE
    WHEN  max_size < 0 THEN 'UNLIMITED'
	WHEN  max_size = 0 THEN 'NO GROWTH, FILE SIZE IS FIXED'
	WHEN  max_size > 0 THEN CONVERT(VARCHAR(15),max_size/128)
	END
	,FileGrowth = CASE
		WHEN growth = 0 THEN 'No Autogrow option Set'
		WHEN growth > 0 AND is_percent_growth = 0 
		THEN CONVERT(VARCHAR(15),CONVERT(DECIMAL(10,2),growth/128.0)) + ' MB'
		WHEN growth > 0 AND is_percent_growth = 1 THEN CONVERT(VARCHAR(15),growth) + ' %'
	END
	,[ReadOnly] = CASE 
		WHEN is_read_only = 1 THEN 'READ ONLY'
		WHEN is_read_only = 0 THEN 'READ WRITE'
	END
FROM sys.database_files
WHERE file_id = 2
waitfor delay '00:02:00' -- pass 2 mins time
use msdb;
SELECT 
	[Time] = CURRENT_TIMESTAMP ,DbName=DB_NAME(), file_id
	,[Status]=state_desc
	,LogicalFileName=name
	,FileSizeAllocated_MB= CONVERT(DECIMAL(8,2),size/128.0)
	,[File_UsedSpace_MB] = CONVERT(DECIMAL(8,2),FILEPROPERTY(name, 'spaceused')/128.0)
	,Maxsize_MB= CASE
    WHEN  max_size < 0 THEN 'UNLIMITED'
	WHEN  max_size = 0 THEN 'NO GROWTH, FILE SIZE IS FIXED'
	WHEN  max_size > 0 THEN CONVERT(VARCHAR(15),max_size/128)
	END
	,FileGrowth = CASE
		WHEN growth = 0 THEN 'No Autogrow option Set'
		WHEN growth > 0 AND is_percent_growth = 0 
		THEN CONVERT(VARCHAR(15),CONVERT(DECIMAL(10,2),growth/128.0)) + ' MB'
		WHEN growth > 0 AND is_percent_growth = 1 THEN CONVERT(VARCHAR(15),growth) + ' %'
	END
	,[ReadOnly] = CASE 
		WHEN is_read_only = 1 THEN 'READ ONLY'
		WHEN is_read_only = 0 THEN 'READ WRITE'
	END
FROM sys.database_files
WHERE file_id = 2