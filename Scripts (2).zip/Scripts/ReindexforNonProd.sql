USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_IndexMaint]    Script Date: 3/23/2017 5:47:17 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO



ALTER PROC [dbo].[proc_IndexMaint] @dbname nvarchar(130) = NULL
AS
SET NOCOUNT ON;
DECLARE @dbid int;

DECLARE @sql varchar(max);

IF @dbname IS NULL
	BEGIN
		DECLARE db CURSOR FAST_FORWARD FOR SELECT database_id, [name] FROM master.sys.databases 
		where [name] not in ('model','tempdb','ReportServerTempDB','ReportServer_2008TempDB') and state_desc not in ('OFFLINE')
	END
ELSE
	BEGIN
		DECLARE db CURSOR FAST_FORWARD FOR SELECT database_id, [name] FROM master.sys.databases 
		where [name] = @dbname
	END

OPEN db;

/* Get database(s) to be processed */
FETCH NEXT FROM db INTO @dbid, @dbname
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
		set @sql = "USE ["+@dbname+"]
		set nocount on
		set quoted_identifier on
		DECLARE @objectid int;
		DECLARE @indexid int;
		DECLARE @partitioncount bigint;
		DECLARE @schemaname nvarchar(130); 
		DECLARE @objectname nvarchar(130); 
		DECLARE @indexname nvarchar(130); 
		DECLARE @partitionnum bigint;
		DECLARE @partitions bigint;
		DECLARE @frag float;
		DECLARE @command nvarchar(4000); 
		DECLARE @dbid int;
		DECLARE @dbname nvarchar(130);
		set @dbid = DB_ID();
		set @dbname = db_name()
		select db_name(@dbid), @dbid

		-- Conditionally select tables and indexes from the sys.dm_db_index_physical_stats function 
		-- and convert object and index IDs to names.
		
		SELECT
			object_id AS objectid,
			index_id AS indexid,
			partition_number AS partitionnum,
			avg_fragmentation_in_percent AS frag
		INTO #work_to_do
		FROM sys.dm_db_index_physical_stats (@dbid, NULL, NULL , NULL, 'LIMITED')
		WHERE avg_fragmentation_in_percent > 10.0 AND index_id > 0;
		
		-- if there are indexes to be processed, backup the transaction log
		if (select count(*) from #work_to_do) > 0
			BEGIN
				--exec sqldba.dbo.proc_BackupDD 'tlog',@dbname 
				select getdate()
			END


		-- Declare the cursor for the list of partitions to be processed.
		DECLARE partitions CURSOR FOR SELECT * FROM #work_to_do;

		-- Open the cursor.
		OPEN partitions;

		-- Loop through the partitions.
		WHILE (1=1)
			BEGIN;
				FETCH NEXT
				   FROM partitions
				   INTO @objectid, @indexid, @partitionnum, @frag;
				IF @@FETCH_STATUS < 0 BREAK;
				SELECT @objectname = QUOTENAME(o.name), @schemaname = QUOTENAME(s.name)
				FROM sys.objects AS o
				JOIN sys.schemas as s ON s.schema_id = o.schema_id
				WHERE o.object_id = @objectid;
				SELECT @indexname = QUOTENAME(name)
				FROM sys.indexes
				WHERE  object_id = @objectid AND index_id = @indexid;
				SELECT @partitioncount = count (*)
				FROM sys.partitions
				WHERE object_id = @objectid AND index_id = @indexid;

		-- 30 is an arbitrary decision point at which to switch between reorganizing and rebuilding.
				IF @frag < 30.0
					SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REORGANIZE';
				IF @frag >= 30.0
					SET @command = N'ALTER INDEX ' + @indexname + N' ON ' + @schemaname + N'.' + @objectname + N' REBUILD';
				IF @partitioncount > 1
					SET @command = @command + N' PARTITION=' + CAST(@partitionnum AS nvarchar(10));
				EXEC (@command);
				PRINT N'Executed: ' + @command + ' - frag % --> '+cast(@frag as varchar);
			END;

		-- Close and deallocate the cursor.
		CLOSE partitions;
		DEALLOCATE partitions;

		-- if indexes were processed, backup the transaction log
		if (select count(*) from #work_to_do) > 0
			BEGIN
				--exec sqldba.dbo.proc_BackupDD 'tlog',@dbname 
				select getdate()
			END

		-- Drop the temporary table.
		DROP TABLE #work_to_do;"

		--print @sql
		exec (@sql)
	END
	FETCH NEXT FROM db INTO @dbid, @dbname
END

CLOSE db
DEALLOCATE db





GO


