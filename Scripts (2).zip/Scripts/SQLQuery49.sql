SELECT
      --(SUM(backup_size) + SUM(1536)) / 1024 / 1024 As MBs,
      (SUM(backup_size) + SUM(1536)) /1024 / 1024 / 1024 As GBs
FROM
      backupset
INNER JOIN
(
      SELECT
            database_name,
            MAX(backup_start_date) as LastFullBackupDate
      FROM
            backupset
      WHERE
            media_set_id IN (SELECT media_set_id FROM backupmediafamily WHERE device_type = 7) AND
            type = 'D' and database_name='scat'
      GROUP BY
            database_name
) AS GetLastDate
ON
      backupset.database_name = GetLastDate.database_name AND
      backupset.backup_start_date = GetLastDate.LastFullBackupDate


	  exec sqldba ..proc_BackupDD 'db','scat'

	  SELECT db_name(database_id) as dbname,CONVERT(DECIMAL(10,2),((size * 8.00) / 1024.00 / 1024.00)) As UsedSpace
FROM master.sys.master_files where db_name(database_id)='scat'

select * from sys.sysservers where srvid =0