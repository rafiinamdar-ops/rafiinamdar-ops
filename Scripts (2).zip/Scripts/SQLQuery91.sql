sp_who2 active

SELECT cp.plan_handle, st.[text]
FROM sys.dm_exec_cached_plans AS cp 
CROSS APPLY sys.dm_exec_sql_text(plan_handle) AS st
WHERE [text] LIKE N'% SELECT (CASE [Projects].[Status_Code]  %';

select * from sys.dm_exec_cached_plans

select * from sysprocesses where hostname like '%hpn-ict-70%'

DBCC FREEPROCCACHE (0x01002C00A1C4F52300119EA20100000000000000)
DBCC FREEPROCCACHE (0x01002C008289B81A007442610100000000000000)

DBCC FLUSHPROCINDB (44)

select * from sys.databases

select session_id,granted_query_memory
from sys.dm_exec_requests

SELECT t.text, cp.objtype,qp.query_plan
FROM sys.dm_exec_cached_plans AS cp
JOIN sys.dm_exec_query_stats AS qs ON cp.plan_handle = qs.plan_handle
CROSS APPLY sys.dm_exec_query_plan(cp.plan_handle) AS qp
CROSS APPLY sys.dm_exec_sql_text(qs.sql_handle) AS t
WHERE qp.query_plan.exist('declare namespace n="http://schemas.microsoft.com/sqlserver/2004/07/showplan"; //n:MemoryFractions') = 1