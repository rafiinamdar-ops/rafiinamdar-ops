Declare @servername varchar(100)
Declare @sql varchar(500)
SET @servername='"sql-rdu-74","sql-ent-82","sql-ent-85"'
SET @sql ='wmic /node:'+@servername+' logicaldisk get size,freespace,caption /FORMAT:CSV'
print @sql
CREATE TABLE #WMIC (
    
    CmdOutput VARCHAR(1000),
	EventDate datetime 
)
ALTER TABLE [#WMIC] ADD  CONSTRAINT [WMIC_Eventdate]  DEFAULT (getdate()) FOR [Eventdate]
INSERT INTO #WMIC (CmdOutput) EXEcute master..xp_cmdshell @sql
--EXECUTE xp_cmdshell 'wmic /node:"hpn-ict-70","SQL-RDU-74" logicaldisk get size,freespace,caption /FORMAT:CSV' 
	select distinct EventDate, S.a.value('(/H/r)[1]','varchar(100)') AS SErver,S.a.value('(/H/r)[2]','varchar(100)') AS Driver,S.a.value('(/H/r)[3]','varchar(100)') FreeSpace,S.a.value('(/H/r)[4]','varchar(100)') Capacity   
	from (select EventDate, CAST(N'<H><r>'+ replace([CmdOutput],',','</r><r>') +'</r></H>' as XML) as x from #WMIC  where [CmdOutput] NOT LIKE 'Node,Caption,FreeSpace,Size%'
	AND ISNULL([CmdOutput],CHAR(13))<>CHAR(13)) A
	CROSS APPLy A.x.nodes('/H/r')S(a)
 DROP TABLE #WMIC 
 /*
 SELECT�EmployeeID,
LTRIM(RTRIM(m.n.value('.[1]','varchar(8000)')))�AS�Certs
FROM
(
SELECT�EmployeeID,CAST('<XMLRoot><RowData>'�+�REPLACE(Certs,',','</RowData><RowData>') +�'</RowData></XMLRoot>'�AS�XML)�AS�x
FROM���@t
)t
CROSS�APPLY x.nodes('/XMLRoot/RowData')m(n) 
 
 */