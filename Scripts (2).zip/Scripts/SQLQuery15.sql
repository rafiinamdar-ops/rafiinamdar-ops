
-- Get Backup History for required database
SELECT TOP 1
s.database_name,
CAST(CAST(s.backup_size / 1000000 AS INT) AS VARCHAR(14)) + ' ' + 'MB' AS bkSize
FROM msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
WHERE s.database_name = 'cdw787' and s.[type]='D' -- Remove this line for all the database
ORDER BY backup_start_date DESC, backup_finish_date
GO

sp_who2 active