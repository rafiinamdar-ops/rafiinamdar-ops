use sqldba
go
If exists (Select name from sys.objects where name = 'DBGrowthRate' and Type = 'U')
Drop Table dbo.DBGrowthRate
Create Table dbo.DBGrowthRate (DBGrowthID int identity(1,1), DBName varchar(256),type_desc varchar(120),Lfname varchar(256),
 physical_name varchar(520),  DBID int,
NumPages bigint, OrigSize_In_MB decimal(32,2), CurSize_In_MB decimal(32,2), GrowthAmt varchar(100), 
MetricDate datetime)
--Drop table #TempDBSize
--Drop table #Test
Select sd.name as DBName,mf.type_desc as type_desc, mf.name as FileName,mf.physical_name as FilePath,mf.database_id, file_id, size
into #TempDBSize
from sys.databases sd
join sys.master_files mf
on sd.database_ID = mf.database_ID
--where mf.type_desc not in ('LOG')
Order by mf.database_id, sd.name

Insert into DBGrowthRate (DBName,type_desc,lfname,physical_name, DBID, NumPages, OrigSize_In_MB, CurSize_In_MB, GrowthAmt, MetricDate)
(Select tds.DBName,tds.type_desc,tds.Filename,tds.Filepath, tds.database_ID, Sum(tds.Size) as NumPages, 
Convert(decimal(18,2),(((Sum(Convert(decimal(18,2),tds.Size)) * 8000)/1024)/1024)) as OrigSize,
Convert(decimal(18,2),(((Sum(Convert(decimal(18,2),tds.Size)) * 8000)/1024)/1024)) as CurSize,
'0.00 MB' as GrowthAmt, GetDate() as MetricDate
from #TempDBSize tds
where tds.database_ID not in (Select Distinct DBID from DBGrowthRate where DBName = tds.database_ID)
Group by tds.database_ID, tds.DBName,tds.type_desc,tds.Filename,tds.Filepath)
Drop table #TempDBSize
Select *
from DBGrowthRate