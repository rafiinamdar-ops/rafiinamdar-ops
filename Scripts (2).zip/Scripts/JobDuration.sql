SELECT
    j.name,
    h.run_status,
    durationHHMMSS = STUFF(STUFF(REPLACE(STR(h.run_duration,7,0),
        ' ','0'),4,0,':'),7,0,':'),
    [start_date] = CONVERT(DATETIME, RTRIM(run_date) + ' '
        + STUFF(STUFF(REPLACE(STR(RTRIM(h.run_time),6,0),
        ' ','0'),3,0,':'),6,0,':'))
FROM
    msdb.dbo.sysjobs AS j
INNER JOIN
    (
        SELECT job_id, instance_id = MAX(instance_id)
            FROM msdb.dbo.sysjobhistory
            GROUP BY job_id
    ) AS l
    ON j.job_id = l.job_id
INNER JOIN
    msdb.dbo.sysjobhistory AS h
    ON h.job_id = l.job_id
    AND h.instance_id = l.instance_id
	Where j.name like '%SQLDBA_BackupDD_DB%'
ORDER BY
    
    [start_date] DESC,CONVERT(INT, h.run_duration) DESC;

	------------------Check job status
	 IF OBJECT_ID('tempdb.dbo.#RunningJobs') IS NOT NULL
      DROP TABLE #RunningJobs
CREATE TABLE #RunningJobs (  
Job_ID UNIQUEIDENTIFIER,  
Last_Run_Date INT,  
Last_Run_Time INT,  
Next_Run_Date INT,  
Next_Run_Time INT,  
Next_Run_Schedule_ID INT,  
Requested_To_Run INT,  
Request_Source INT,  
Request_Source_ID VARCHAR(100),  
Running INT,  
Current_Step INT,  
Current_Retry_Attempt INT,  
State INT )    
     
INSERT INTO #RunningJobs EXEC master.dbo.xp_sqlagent_enum_jobs 1,garbage  
 
SELECT    
  name AS [Job Name]
 ,CASE WHEN next_run_date=0 THEN '[Not scheduled]' ELSE
   CONVERT(VARCHAR,DATEADD(S,(next_run_time/10000)*60*60 /* hours */ 
  +((next_run_time - (next_run_time/10000) * 10000)/100) * 60 /* mins */ 
  + (next_run_time - (next_run_time/100) * 100)  /* secs */, 
  CONVERT(DATETIME,RTRIM(next_run_date),112)),100) END AS [Start Time]
FROM     #RunningJobs JSR 
JOIN     msdb.dbo.sysjobs 
ON       JSR.Job_ID=sysjobs.job_id 
WHERE    Running=1 -- i.e. still running 
ORDER BY name,next_run_date,next_run_time  

SELECT TOP 100
s.database_name,
m.physical_device_name,
CAST(CAST(s.backup_size / 1000000 AS INT) AS VARCHAR(14)) + ' ' + 'MB' AS bkSize,
CAST(DATEDIFF(second, s.backup_start_date,
s.backup_finish_date) AS VARCHAR(4)) + ' ' + 'Seconds' TimeTaken,
s.backup_start_date,
CAST(s.first_lsn AS VARCHAR(50)) AS first_lsn,
CAST(s.last_lsn AS VARCHAR(50)) AS last_lsn,
CASE s.[type] WHEN 'D' THEN 'Full'
WHEN 'I' THEN 'Differential'
WHEN 'L' THEN 'Transaction Log'
END AS BackupType,
s.server_name,
s.recovery_model
FROM msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
WHERE s.[type]='L' --and CAST(s.backup_size / 1000000 AS INT)>30000  and s.database_name= 'WSS_Content_ITInfrastructure'---- Remove this line for all the database
ORDER BY backup_start_date DESC, backup_finish_date Desc
GO