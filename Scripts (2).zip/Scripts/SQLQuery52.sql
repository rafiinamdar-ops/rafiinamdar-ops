USE [sqldba]
GO

SELECT [SERVER_NAME]
      ,[START_DATETIME]
      ,[LINE_NO]
      ,[BEGIN_DATETIME]
      ,[END_DATETIME]
      ,[MSG_LINE]
  FROM [dbo].[DDDelete_History]
  ORDER BY [START_DATETIME] DESC
GO


