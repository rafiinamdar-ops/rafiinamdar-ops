USE [AppSenseManagementServer_MS]
GO

    DECLARE @value INT
    DECLARE @machines INT
	DECLARE @groupKey AS UNIQUEIDENTIFIER='7E140016-A8C9-4016-9B5E-9CE8BD55426A'
    
    SET @machines = (SELECT COUNT(*) FROM Machines WHERE GroupFK = @groupKey)
    IF (@machines = 0)
        SET @value = 100
    ELSE
        SET @value = (SELECT AVG(Deployed) FROM MachinesViewConsole WHERE GroupKey = @groupKey)
        
    IF (@value IS NULL)
        SET @value = 0

    SELECT @value




