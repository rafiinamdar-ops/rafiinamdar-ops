sp_who2 active

select * from MachinesViewConsole

SELECT
n.value('(@name)[1]', 'varchar(50)') AS event_name
--,n.value('(/event/action[@name="collect_system_time"]/value)[1]', 'datetime') AS [EventDate],
--n.value('(/event/action[@name="server_instance_name"]/value)[1]', 'varchar(max)') AS [server_instance_name],
--n.value('(/event/action[@name="server_principal_name"]/value)[1]', 'varchar(max)') AS [LoginName],
--n.value('(/event/action[@name="client_app_name"]/value)[1]', 'varchar(max)') AS [client_app_namee],
--n.value('(/event/action[@name="sql_text"]/value)[1]', 'varchar(max)') AS [sql_text]
FROM
   (
         select CAST(event_data as XML) AS event_data
		
		 from sys.fn_xe_file_target_read_file
        (
        'J:\*.xel', 
        'J:\*.xem', 
		null, 
		null
        )

    ) 
	--as xmlr(xdata) 
	 as tab
		CROSS APPLY event_data.nodes('event') as q(n)

		SELECT * FROM 
sys.fn_xe_file_target_read_file('J:\*.xel', 'J:\*.xem', null, null);

SELECT scheduler_id, current_tasks_count, runnable_tasks_count, work_queue_count, pending_disk_io_count
FROM sys.dm_os_schedulers
WHERE scheduler_id < 255

