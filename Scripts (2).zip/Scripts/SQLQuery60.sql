Select sd.name as DBName, mf.type_desc as type_desc,mf.name as FileName,mf.physical_name as FilePath, mf.database_id, file_id, size
into #TempDBSize2
from sys.databases sd
join sys.master_files mf
on sd.database_ID = mf.database_ID
Order by mf.database_id, sd.name
If Exists (Select Distinct DBName from #TempDBSize2 
where DBName in (Select Distinct DBName from DBGrowthRate))
and Convert(varchar(24),GetDate(),109) > (Select Distinct Convert(varchar(24),Max(MetricDate),109) as MetricDate
from DBGrowthRate)
Begin
Insert into dbo.DBGrowthRate (DBName,type_desc,Lfname,physical_name, DBID, NumPages, OrigSize_In_MB, CurSize_In_MB, GrowthAmt, MetricDate)
(Select tds.DBName,tds.type_desc,tds.FileName,tds.FilePath, tds.database_ID, Sum(tds.Size) as NumPages, 
dgr.CurSize_In_MB as OrigSize,
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8000)/1024)/1024)) as CurSize,
Convert(varchar(100),(Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8000)/1024)/1024))
- dgr.CurSize_In_MB)) + ' MB' as GrowthAmt, GetDate() as MetricDate
from #TempDBSize2 tds
join DBGrowthRate dgr
on tds.database_ID = dgr.DBID
Where DBGrowthID = (Select Distinct Max(DBGrowthID) from DBGrowthRate
where DBID = dgr.DBID)
Group by tds.database_ID, tds.DBName,tds.type_desc,tds.FileName,tds.FilePath,  dgr.CurSize_In_MB)
End
Else
IF Not Exists (Select Distinct DBName from #TempDBSize2 
where DBName in (Select Distinct DBName from DBGrowthRate))
Begin
Insert into dbo.DBGrowthRate (DBName,type_desc,Lfname,physical_name, DBID, NumPages, OrigSize_In_MB, CurSize_In_MB, GrowthAmt, MetricDate)
(Select tds.DBName,tds.type_desc,tds.FileName,tds.FilePath, tds.database_ID, Sum(tds.Size) as NumPages, 
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8000)/1024)/1024)) as OrigSize,
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8000)/1024)/1024)) as CurSize,
'0.00 MB' as GrowthAmt, GetDate() as MetricDate
from #TempDBSize2 tds
where tds.database_ID not in (Select Distinct DBID from DBGrowthRate 
where DBName = tds.database_ID)
Group by tds.database_ID, tds.DBName,tds.type_desc,tds.FileName,tds.FilePath)
End
--declare @mdate datetime
--Select @mdate=MAX(MetricDate)
--from DBGrowthRate
--PRINT @mdate
--select * from DBGrowthRate WHERE MetricDate>=@mdate and dbname='AAF'
--order by MetricDate desc 
--where MetricDate=Max(MetricDate)
--group by MetricDate
--Verifies values were entered
Drop table #TempDBSize2
select * from DBGrowthRate