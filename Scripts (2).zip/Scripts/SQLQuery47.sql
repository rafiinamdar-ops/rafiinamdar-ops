SELECT DatabaseName = bs.database_name
    , BackupStartDate = bs.backup_start_date
    , CompressedBackupSize = ((bs.compressed_backup_size)/1024/1024/1024)/10
    , ExpirationDate = bs.expiration_date
    , BackupSetName = bs.name
    , RecoveryModel = bs.recovery_model
    , ServerName = bs.server_name
    , BackupType = CASE bs.type 
        WHEN 'D' THEN 'Database' 
        WHEN 'L' THEN 'Log' 
        ELSE '[unknown]' END
    , LogicalDeviceName = bmf.logical_device_name
    , PhysicalDeviceName = bmf.physical_device_name
FROM msdb.dbo.backupset bs
    INNER JOIN msdb.dbo.backupmediafamily bmf 
        ON [bs].[media_set_id] = [bmf].[media_set_id]
WHERE  bs.backup_start_date between '2017-03-12 05:32:43.000' and '2017-03-22 05:32:43.000' and bs.database_name ='SCAT'
 and bs.type = 'D'
--(bs.database_name = @DBName
--    OR @DBName IS NULL)
--    AND 
--ORDER BY bs.backup_start_date DESC;

--use scat
--go
--sp_spaceused
--go