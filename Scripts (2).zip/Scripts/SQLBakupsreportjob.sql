USE [msdb]
GO

/****** Object:  Job [BackupReports]    Script Date: 1/5/2017 12:09:29 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 1/5/2017 12:09:29 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'BackupReports', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'CORP\p9012592', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PopulateBackupTable]    Script Date: 1/5/2017 12:09:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PopulateBackupTable', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'PowerShell', 
		@command=N'<###################################################################
# 																	
# Author       : Rafik										
# Date         : 12 Dec 2013									
# Version      : 1.0												
# Desctiption  : This Script will retrieve Database backup details
#				 from the SQL server .
#																	
####################################################################>

#Change value of following variables as needed
$ServerList = Get-Content "J:\dbascript\ServerList.txt"


[System.Reflection.Assembly]::LoadWithPartialName(''Microsoft.SqlServer.SMO'') | out-null

# Open Connection
$conn = New-Object System.Data.SqlClient.SqlConnection
$connectionString = "server=$DatabaseServerName;database=$DatabaseName;trusted_connection=true;"
$conn.ConnectionString = $connectionString
$conn.Open()


# Create the Command object to execute the queries
$cmd = New-Object System.Data.SqlClient.SqlCommand
$cmd.Connection = $conn
$cmd.CommandType = [System.Data.CommandType]::Text

$dquery="truncate table [SQLDBA].[dbo].[TLOG_DatabaseBackup] "
     
    #$dquery
     # Setup Command
           $cmd.CommandText = $dquery

        # Execute Command to insert data for this $drive
        $result = $cmd.ExecuteNonQuery() 


ForEach ($ServerName in $ServerList)
{
	 $srvname=$ServerName
    if (($srvname -eq "sql-fac-01.facict.spiritaero.com\dev") -or ($srvname -eq "sql-fac-01.facict.spiritaero.com") -or ($srvname -eq "sql-fac-02.facict.spiritaero.com\dev") -or ($srvname -eq "sql-fac-02.facict.spiritaero.com") )
    {
   try {
   
#$dbname="Test"
$mySrvConn = new-object Microsoft.SqlServer.Management.Common.ServerConnection
$mySrvConn.ServerInstance=$srvname
$mySrvConn.LoginSecure = $false
$mySrvConn.Login = "SQLDBARead"
$mySrvConn.Password = "SQLDBARead"



$srv = new-object Microsoft.SqlServer.Management.SMO.Server($mySrvConn)
Foreach($Database in $srv.Databases)
	{
             
     # $QueryResults=Get-SQLQuery $ServerName $Database $Query
      #if (!$QueryResults){
           $query="INSERT INTO [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] ([SERVERNAME],[DatabaseName],[State_Desc],[RecoveryModel],[LastFullBackupDate],[LastDifferentialBackupDate],[LastLogBackupDate]) VALUES (''"
        $query=$query + $ServerName+"'',''"+$Database.Name
        $query=$query +"'',''"+$Database.Status
        $query=$query +"'',''"+$Database.RecoveryModel
         $query=$query  +"'',''"+$Database.LastBackupDate
         $query=$query  +"'',''"+$Database.LastDifferentialBackupDate
         $query=$query  +"'',''"+$Database.LastLogBackupDate+ "'')"

       # }

        # Uncomment next line to display query for checking
        #$query 
        
           # Setup Command
            $cmd.CommandText = $query

        # Execute Command to insert data for this $drive
        $result = $cmd.ExecuteNonQuery() 
          
          
        
	}
    
}

catch { 
    $err = $Error[0].Exception ; 
    #write-host "Error caught: "  $err.Message ; 
          $query="INSERT INTO [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] ([SERVERNAME],[DatabaseName]) VALUES (''"
        $query=$query + $ServerName+"'',''"+ $err.Message +"'')"

       # }

        # Uncomment next line to display query for checking
        #$query 
        
           # Setup Command
            $cmd.CommandText = $query
        #$query
        # Execute Command to insert data for this $drive
        $result = $cmd.ExecuteNonQuery() 
    continue ; 
}}
    ELSE {
    
try {
    $SQLServer = New-Object (''Microsoft.SqlServer.Management.Smo.Server'') $ServerName 
    
	Foreach($Database in $SQLServer.Databases)
	{
             
     # $QueryResults=Get-SQLQuery $ServerName $Database $Query
      #if (!$QueryResults){
           $query="INSERT INTO [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] ([SERVERNAME],[DatabaseName],[State_Desc],[RecoveryModel],[LastFullBackupDate],[LastDifferentialBackupDate],[LastLogBackupDate]) VALUES (''"
        $query=$query + $ServerName+"'',''"+$Database.Name
        $query=$query +"'',''"+$Database.Status
        $query=$query +"'',''"+$Database.RecoveryModel
         $query=$query  +"'',''"+$Database.LastBackupDate
         $query=$query  +"'',''"+$Database.LastDifferentialBackupDate
         $query=$query  +"'',''"+$Database.LastLogBackupDate+ "'')"

       # }

        # Uncomment next line to display query for checking
        #$query 
        
           # Setup Command
            $cmd.CommandText = $query
        #$query
        # Execute Command to insert data for this $drive
        $result = $cmd.ExecuteNonQuery() 
          
          
       
	}
    }

catch { 
    $err = $Error[0].Exception ; 
    #write-host "Error caught: "  $err.Message ;
      $query="INSERT INTO [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] ([SERVERNAME],[DatabaseName]) VALUES (''"
        $query=$query + $ServerName+"'',''"+ $err.Message +"'')"

       # }

        # Uncomment next line to display query for checking
        #$query 
        
           # Setup Command
            $cmd.CommandText = $query
        #$query
        # Execute Command to insert data for this $drive
        $result = $cmd.ExecuteNonQuery() 
    continue ; 
}
} 
}

            $uquery="update [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] set [LastFullBackupDate]=Null  WHERE [LastFullBackupDate]=''01/01/0001 00:00:00''"
	        $uquery= $uquery+" update [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] set [LastDifferentialBackupDate]=Null  WHERE [LastDifferentialBackupDate]=''01/01/0001 00:00:00''"
	         $uquery= $uquery+" update [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] set [LastLogBackupDate]=Null  WHERE [LastLogBackupDate]=''01/01/0001 00:00:00'' "
               $uquery= $uquery+" delete [sql-rdu-74].[SQLDBA].[dbo].[TLOG_DatabaseBackup] where DatabaseName in (''model'',''tempdb'')"
               
             # Setup Command
                $cmd.CommandText = $uquery

        # Execute Command to insert data for this $drive
                $result = $cmd.ExecuteNonQuery()  
$conn.Close()', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run Report SQl Backup report]    Script Date: 1/5/2017 12:09:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Report SQl Backup report', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'rs -i "J:\DBAScript\BackupReports\BackupReports\Render Report.rss" -s http://sql-rdu-74/ReportServer -e Exec2005', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [CompleteReportSendFile]    Script Date: 1/5/2017 12:09:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'CompleteReportSendFile', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @cmd varchar(100)
declare @datetime datetime
Select @datetime=getdate()
--print @datetime
SELECT @cmd = ''SQL Backup Reports was executed at '' + CONVERT(varchar, DATEPART(yyyy, @datetime)) 
+ ''/'' + CONVERT(varchar, DATEPART(mm, @datetime)) 
+''/'' + CONVERT(varchar, DATEPART(dd,@datetime))+'' '' + CONVERT(varchar, DATEPART(hh,@datetime))
+'':'' + CONVERT(varchar, DATEPART(m ,@datetime))
+'':'' + CONVERT(varchar, DATEPART(ss,@datetime))
 --print @cmd
EXEC msdb.dbo.sp_send_dbmail
    @recipients = ''Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;fredric.w.shope@spiritaero.com'',
    @body =  ''The report is attached:'',
    @subject = @cmd,
    @file_attachments= ''J:\DBAScript\BackupReports\BackupReports\SQL Database Backup.xls'' ;
', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Missing DB Backup Reports]    Script Date: 1/5/2017 12:09:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Missing DB Backup Reports', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=2, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'rs -i "J:\DBAScript\BackupReports\BackupReports\Missing Render Report.rss" -s http://sql-rdu-74/ReportServer -e Exec2005', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=8
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [SendMissingdBbackup File]    Script Date: 1/5/2017 12:09:29 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'SendMissingdBbackup File', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @cmd varchar(100)
declare @datetime datetime
Select @datetime=getdate()
--print @datetime
SELECT @cmd = ''Missing SQL Databases Backup Reports was executed at '' + CONVERT(varchar, DATEPART(yyyy, @datetime)) 
+ ''/'' + CONVERT(varchar, DATEPART(mm, @datetime)) 
+''/'' + CONVERT(varchar, DATEPART(dd,@datetime))+'' '' + CONVERT(varchar, DATEPART(hh,@datetime))
+'':'' + CONVERT(varchar, DATEPART(m ,@datetime))
+'':'' + CONVERT(varchar, DATEPART(ss,@datetime))
 --print @cmd
EXEC msdb.dbo.sp_send_dbmail
    @recipients = ''Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;fredric.w.shope@spiritaero.com'',
    @body =  ''The report is attached:'',
    @subject = @cmd,
    @file_attachments= ''J:\DBAScript\BackupReports\BackupReports\Missing SQL Database Backup.xls'' ;', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_Backup', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=30, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140113, 
		@active_end_date=99991231, 
		@active_start_time=223000, 
		@active_end_time=235959, 
		@schedule_uid=N'b6268de5-005f-46f2-ab7a-ebb10e75cbf4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Sunday_Schedule', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20141005, 
		@active_end_date=99991231, 
		@active_start_time=190000, 
		@active_end_time=235959, 
		@schedule_uid=N'2b0cbec0-b4a5-4790-b267-7cbc237cc07a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

