use SQLDBA 
go
select [SERVERNAME]
			,Drive 
			,cast(cast(dbo.udf_GetNumeric(capacity)  as float)/1024/1024/1024 as DECIMAL(18,2)) AS TotalSize
			,(cast(cast(dbo.udf_GetNumeric(capacity)  as float)/1024/1024/1024 as DECIMAL(18,2))
			-cast(cast(rtrim(ltrim([FreeSpace])) as float)/1024/1024/1024 as DECIMAL(18,2))) AS UsedSpace
           ,cast(cast(rtrim(ltrim([FreeSpace])) as float)/1024/1024/1024 as DECIMAL(18,2)) As FreeSpace
           ,cast(((cast(cast(rtrim(ltrim([FreeSpace])) as float)/1024/1024/1024 as DECIMAL(18,2))/
           cast(cast(dbo.udf_GetNumeric(capacity)  as float)/1024/1024/1024 as DECIMAL(18,2)))*100) as decimal(18,2)) AS PercentFree
		  ,[CheckDate] --iNTO dbo.TEMPTEST
	 from [sqldba].[dbo].[IDiskSpaceUtilization]  where  cast(cast(dbo.udf_GetNumeric(capacity)  as float)/1024/1024/1024 as DECIMAL(18,2))>0