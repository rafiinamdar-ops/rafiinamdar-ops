SELECT @@SERVERNAME as ServerName,name As DatabaseName,recovery_model_desc 
AS Recovery_Model,GETDATE() as CheckDate from sys.databases


EXEC msdb.dbo.sp_delete_jobserver @job_name = 'SQLDBA_BackupDD_DB', 
@server_name = N'sql-rdu-75'
GO
EXEC msdb.dbo.sp_delete_jobserver @job_name = 'SQLDBA_BackupDD_Diff', 
@server_name = N'sql-rdu-75'
GO
EXEC msdb.dbo.sp_delete_jobserver @job_name = 
'SQLDBA_BackupDD_TLogs_NonProd', @server_name = N'sql-rdu-75'
GO