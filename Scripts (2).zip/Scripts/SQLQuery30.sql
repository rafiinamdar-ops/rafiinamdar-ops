CREATE  TABLE extent_info (   file_id BIGINT,page_id BIGINT,pg_alloc TINYINT,ext_size SMALLINT,obj_id BIGINT,index_id TINYINT,
partition_number smallint,partition_id BIGINT,iam_chain_type varchar(50), pfs_bytes VARBINARY(4000))

CREATE proc extentinfo  AS  DBCC EXTENTINFO(0)

INSERT extent_info  EXEC extentinfo

SELECT [file_id],   object_name(obj_id),index_id,ext_size,'actual extent count' = COUNT(*)
,'actual page count' = sum(pg_alloc),'possible extent count' = CEILING(SUM(pg_alloc)*1.0/ext_size)
, 'possible extents over actual extents' =   (CEILING(SUM(pg_alloc)*1.00/ext_size)*100.00) / COUNT(*)   
FROM extent_info   --WHERE ext_size <> 1   AND index_id = 255  -- TEXT or IMAGE column 
--where (CEILING(SUM(pg_alloc)*1.00/ext_size)*100.00) / COUNT(*) <75
 GROUP BY [file_id],obj_id, index_id, ext_size   
 HAVING COUNT(*)-CEILING(SUM(pg_alloc)*1.0/ext_size) > 0   ORDER BY obj_id, index_id, [file_id]
