SELECT top 2000 EventClass, Events.Name As EventClassName, TextData,ApplicationName,LoginName, 
Duration, StartTime, EndTime, Reads, Writes,ObjectName,RowCounts 
FROM fn_trace_gettable('F:\Rafik\Ektron\Ektronsync.trc', default) Trace
INNER JOIN sys.trace_events Events
ON Trace.EventClass = Events.trace_event_id
where TextData is not null
order by StartTime desc