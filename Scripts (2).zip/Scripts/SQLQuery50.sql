if    (select count(*) from sys.sysservers where srvid =0 and srvname in ('SQL-ENT-83',
'SQL-RDU-74',
'SQL-ENT-82',
'SQL-ENT-84',
'SQL-RDU-75',
'SQL-ENT-72',
'SQL-ENT-91',
'SQL-ENT-86',
'EVM-ENT-72',
'SQL-ENT-85',
'SQL-ENT-92',
'SQL-ENT-95'
))>0
SELECT CONVERT(DECIMAL(10,2),(SUM(size * 8.00) / 1024.00 / 1024.00)) As UsedSpace
FROM master.sys.master_files

