/*
Usage : This table is used to load escapes from Prestwick
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_escape_prestwick'
)

CREATE TABLE [datamart].[fact_escape_prestwick](
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[ca_count] [int] NULL,
	[date_written] [date] NULL,
	[escape_amount_actual] [float] NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](255) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime] NOT NULL,
	[feature_descrepancy] [varchar](300) NULL,
	[modified_by] [varchar](50) NULL DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL DEFAULT (getdate()),
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL
) 

GO



