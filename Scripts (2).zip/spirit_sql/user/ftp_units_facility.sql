/*
Usage : To find source data for quality attribute for units

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_units_facility'
)


CREATE TABLE staging.ftp_units_facility
(
location nvarchar(100) null
,program nvarchar(150) null
,weekenddate datetime null
,units float null
)

GO

