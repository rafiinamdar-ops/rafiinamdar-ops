
IF EXISTS (
SELECT name 
from sys.procedures 
where name ='proc_sendmailreminder_missingfiles'
)
DROP PROC datamart.proc_sendmailreminder_missingfiles
GO


CREATE Procedure [datamart].[proc_sendmailreminder_missingfiles]
As 
BEGIN
/*
Usage : To find missing input file AND send notification to respactive biz users.

Creator/Editor #Date #Comments
Praveen C # 2017-11-22 # Initial creation
Praveen C # 2018-01-31 # Modified the logic to exclude already processed files for current week from sending mail 
*/

SET NOCOUNT ON;

DECLARE @errorprocedure VARCHAR(50), --used to store procedure name
@errorline INT, -- used to call RAISEERROR
@errornumber INT, -- used to call RAISEERROR
@errorseverity INT, -- used to call RAISEERROR
@errorstate INT,  -- used to call RAISEERROR
@errormessage VARCHAR(2048)  -- used to call RAISEERROR

Declare @SeqNo int = 1, @NoOfRows int

Declare @File_Code varchar(100)
,@msg_unavailable varchar(MAX)
,@msg_subject varchar(100)
,@mailgroup_user varchar(MAX)
,@mailgroup_dev varchar(MAX)
,@file_description varchar(150)

BEGIN TRY;

Declare @LogDate datetime , @start_date date
SELECT @LogDate = MAX(logdate) 
From datamart.fact_file_exist_log

Select @start_date = MAX(week_start_date)
From datamart.vw_dim_calendar 
Where week_start_date <= @LogDate

-- Update the file_code into log files
;WITH msgCTE AS
(
SELECT @LogDate logdate
,file_code
,file_location+CHAR(92)+file_name file_name
from datamart.dim_mail_messages
)
Update L Set L.file_code = Msg.file_code
From msgCTE Msg
Inner Join datamart.fact_file_exist_log L 
 On L.file_name Like msg.file_name 
 AND L.logdate = @LogDate
Where L.file_code = ''

-- Insert missing log files with status 'NO'
;WITH msgCTE AS
(
SELECT @LogDate logdate
,file_code
,file_location+CHAR(92)+file_name file_name
from datamart.dim_mail_messages
)
, cte_exising_files AS
(
SELECT DISTINCT file_code 
from datamart.fact_file_exist_log l
Where logdate >= @start_date
AND existence = 'Yes'
)

Insert Into datamart.fact_file_exist_log
SELECT Msg.logdate, Msg.file_code, Msg.file_name, 'No', 0 
From msgCTE Msg
Left  Join datamart.fact_file_exist_log L 
 On L.file_name Like msg.file_name 
 AND L.logdate = @LogDate
WHERE L.existence is Null
AND Msg.file_code NOT IN (Select file_code from cte_exising_files)

-- Send mail to biz users or dev
DECLARE db_cursor CURSOR FOR  
SELECT Msg.file_code
,Msg.msg_unavailable
,Msg.mailgroup_user
,Msg.mailgroup_dev
,Msg.msg_subject
From datamart.dim_mail_messages Msg
Inner Join datamart.fact_file_exist_log L 
On L.file_name Like file_location+CHAR(92)+Msg.file_name 
AND L.logdate = @LogDate 
AND L.existence = 'No'
AND L.mail_sent = 0

OPEN db_cursor   
FETCH NEXT FROM db_cursor 
INTO @File_Code, @msg_unavailable, @mailgroup_user, @mailgroup_dev,@msg_subject

WHILE @@FETCH_STATUS = 0   
BEGIN   

If (@mailgroup_user IS NOT Null)
Begin
EXEC msdb.dbo.sp_send_dbmail @profile_name='Spirit_Digi'
,@recipients=@mailgroup_user
,@copy_recipients=@mailgroup_dev
,@subject=@msg_subject
,@body=@msg_unavailable

UPDATE datamart.fact_file_exist_log SET mail_sent =1
WHERE logdate = @logdate 
 AND file_code = @file_code
 
End
FETCH NEXT FROM db_cursor 
INTO @File_Code, @msg_unavailable, @mailgroup_user, @mailgroup_dev,@msg_subject
END   

CLOSE db_cursor   
DEALLOCATE db_cursor

END TRY
BEGIN CATCH;

SELECT @errorprocedure='[datamart].[proc_sendmailreminder_missingfiles]',
@errorline=ERROR_LINE(),
@errornumber=ERROR_NUMBER(),
@errorseverity=ERROR_SEVERITY(),
@errorstate=ERROR_STATE(),
@errormessage=ERROR_MESSAGE();

EXECUTE datamart.proc_log_error   
@errorprocedure=@errorprocedure,
@errorline=@errorline,
@errornumber=@errornumber,
@errormessage=@errormessage,
@errorseverity=@errorseverity,
@errorstate=@errorstate

RETURN -1;
END CATCH;
RETURN 0;
End

GO
