/*
Usage : This table is used to provide the alias mapping information

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_alias_mapping'
)

CREATE TABLE datamart.dim_alias_mapping
(
	alias_name varchar(30),
	actual_name varchar(30),
	category varchar(30),
	pk_id int IDENTITY(1,1),
	
 CONSTRAINT uk_alias_name_category UNIQUE NONCLUSTERED 
(
	alias_name ASC,
	category ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO




