-- This script will handle upgrade of Stored procedures/extended procedures for Web Assistant

-- Upgrade is handled by Resource DB.