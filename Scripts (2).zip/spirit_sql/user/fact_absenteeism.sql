/*
Usage : This datamart table is used to populate the data for headcount metric for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_absenteeism'
)
CREATE TABLE datamart.fact_absenteeism
(
	cost_center nvarchar(255),
	working_level nvarchar(255),
	shifts nvarchar(255),
	period nvarchar(50),
	abs_p float,
	
	abs_up float,
	abs_fmla nvarchar(255),
	countofpaycode int,
	total_abs_hours float,
	std_hours_per_week float,
	
	std_abs_pcg float,
	loaddate datetime,
	business_unit nvarchar(510),
	location nvarchar(50) 
) 

GO


