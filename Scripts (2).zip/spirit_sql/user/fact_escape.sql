/*
Usage : This table is used to load escapes actuals data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_escape'
)

CREATE TABLE [datamart].[fact_escape](
	[program_nm] [varchar](30) NULL,
	[value_chain_cd] [varchar](50) NULL,
	[responsible_mgmt_code] [varchar](200) NULL,
	[feature_description] [varchar](100) NULL,
	[discrepancy_description] [varchar](100) NULL,
	[feature_code] [varchar](50) NULL,
	[ca_count] [int] NULL,
	[ncr_part_no] [varchar](50) NULL,
	[ca_ser_no] [varchar](50) NULL,
	[sum_ncr_cost_amt] [float] NULL,
	[discrepancy_code] [varchar](50) NULL,
	[unit_no] [float] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL CONSTRAINT [DF__fact_esca__modif__7D439ABD]  DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL CONSTRAINT [DF__fact_esca__modif__7E37BEF6]  DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL
)

GO



