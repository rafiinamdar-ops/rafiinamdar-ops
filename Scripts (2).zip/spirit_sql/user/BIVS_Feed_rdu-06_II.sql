/****** Script for SelectTopNRows command from SSMS  ******/
INSERT INTO [sql-ent-83].[BIVS].[dbo].[BIVSR]
			([SITE_SUPPL_CD]
      ,[SUPPL_INV_NO]
      ,[PO_NO]
      ,[PO_LN_IT_NO]
      ,[INV_RCVD_DT]
      ,[CHK_NO]
      ,[PAY_DT]
      ,[PT_NO]
      ,[QTY]
      ,[UN_PRC]
      ,[TOT_IT_AMT]
      ,[SUPPL_INV_NO_TRIM]
      ,[PO_NO_NO_DASH]
      ,[PO_NO_SHORT]
      ,[IMPORT_FILE_NAME])
   SELECT [SITE_SUPPL_CD]
      ,[SUPPL_INV_NO]
      ,[PO_NO]
      ,[PO_LN_IT_NO]
      ,[INV_RCVD_DT]
      ,[CHK_NO]
      ,[PAY_DT]
      ,[PT_NO]
      ,[QTY]
      ,[UN_PRC]
      ,[TOT_IT_AMT]
      ,[SUPPL_INV_NO_TRIM]
      ,[PO_NO_NO_DASH]
      ,[PO_NO_SHORT]
      ,[IMPORT_FILE_NAME]
  FROM [sql-ent-83].[BIVS].[dbo].[BIVSR]_OLD] 
  
  where len(ltrim(rtrim([PO_NO])))>13

  --TRUNCATE TABLE [dbo].[BIVSR]

 -- 600-A76-00073 614-010069210

 SELECT LEN('600-A76-00073') - LEN(REPLACE('600-A76-00073','-',''))
  
  SELECT LEN('614-010069210') - LEN(REPLACE('614-010069210','-',''))

  SELECT LEN('600-A76-00073') as len1, LEN(REPLACE('600-A76-00073','-','')) as len2
  SELECT SUBSTRING ('600-A76-00073',LEN(REPLACE('614-010069210','-','')),3)
  SELECT CHARINDEX ('-','600-A76-00073',4 )

  SELECT REPLACE('614-010069210',SUBSTRING ('600-A76-00073',CHARINDEX ('-','600-A76-00073'),4 ),'')


  --  SELECT [SITE_SUPPL_CD]
  --    ,[SUPPL_INV_NO]
  --    ,[PO_NO]
  --    ,[PO_LN_IT_NO]
  --    ,[INV_RCVD_DT]
  --    ,[CHK_NO]
  --    ,[PAY_DT]
  --    ,[PT_NO]
  --    ,[QTY]
  --    ,[UN_PRC]
  --    ,[TOT_IT_AMT]
  --    ,[SUPPL_INV_NO_TRIM]
  --    ,[PO_NO_NO_DASH]
  --    ,[PO_NO_SHORT]
  --    ,[IMPORT_FILE_NAME]
  --FROM [sql-rdu-06].[BIVS].[dbo].[BIVS]
