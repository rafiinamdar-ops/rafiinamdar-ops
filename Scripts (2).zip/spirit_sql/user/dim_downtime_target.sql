/*
Usage : To find downtime target for facilities

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-04 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_downtime_target'
)

CREATE TABLE datamart.dim_downtime_target
(
spirit_year int
,location varchar(100)
,business_unit varchar(100)
,asset_priority int
,total_downtime_previous_year float

,improvement_pcg float
,downtime_target float
)

GO

