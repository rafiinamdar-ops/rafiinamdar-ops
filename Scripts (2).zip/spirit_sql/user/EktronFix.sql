use EktronProdAuth
go

select * from page_to_objectTracking where page_id  = 27917287417 and object_id = 27917291869

use EktronProdStaging 
go
select * from page_to_object_Tracking  where page_id  = 27917287417 and object_id = 27917291869
select * from page_to_object  where page_id  = 27917287417 and object_id = 27917291869

update page_to_object_Tracking
set sync_row_is_tombstone = 1
where page_id  = 27917287417 and object_id = 27917291869

exec sqldba ..proc_BackupDD 'tlog','EktronProdAuth'

exec sqldba ..proc_BackupDD 'tlog','EktronProdStaging'
