
IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_facility_weekly_variance')
DROP PROC datamart.proc_generate_facility_weekly_variance
GO

CREATE PROC datamart.proc_generate_facility_weekly_variance
AS
BEGIN

/*
Usage : To populate Facility Weekly Varinace report in the same reporting format

Creator/Editor #Date #Comments
Pratheesh N # 2017-09-22 # Initial creation
*/

SET NOCOUNT ON;

--BEGIN TRAN datamart_facility

DECLARE 
@errorprocedure VARCHAR(50) --used to store procedure name
,@errorline INT --used to call RAISEERROR
,@errornumber INT --used to call RAISEERROR
,@errorseverity INT --used to call RAISEERROR
,@errorstate INT  --used to call RAISEERROR
,@errormessage VARCHAR(2048);  --used to call RAISEERROR

--BEGIN TRY;

TRUNCATE TABLE reporting.facility_weekly_variance

--Starts Insert of template data
;
WITH cte1 as
(
SELECT distinct spirit_year,spirit_week
FROM reporting.facility_summary

WHERE spirit_year > 2016
)
,

cte2 as
(
SELECT distinct location,business_unit
FROM reporting.facility_summary
)

INSERT INTO reporting.facility_weekly_variance
(
spirit_year
,spirit_week
,business_unit
,location
)

SELECT
spirit_year
,spirit_week
,business_unit
,location

FROM cte1, cte2
;
--Ends Insert of template data


--Starts Update of quality summary # All except $ per unit
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,SUM(scrap_amount_actual) as weekly_scrap_actual

,SUM(rr_amount_actual) as weekly_rr_actual
,MAX(scrap_amount_target) as scrap_target_per_unit
,MAX(rr_amount_target) as rr_target_per_unit

FROM reporting.facility_summary

WHERE attribute = 'quality'

GROUP BY
spirit_year
,spirit_week
,location
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,SUM(c2.weekly_scrap_actual) as ytd_scrap_actual
,SUM(c2.weekly_rr_actual) as ytd_rr_actual

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.weekly_scrap_actual
,c1.weekly_rr_actual

,c1.scrap_target_per_unit
,c1.rr_target_per_unit
,c2.ytd_scrap_actual
,c2.ytd_rr_actual

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
)

UPDATE reporting.facility_weekly_variance
SET weekly_scrap_actual = isnull(cte3.weekly_scrap_actual,0)
 ,weekly_rr_actual = isnull(cte3.weekly_rr_actual,0)
 ,scrap_target_per_unit = isnull(cte3.scrap_target_per_unit,0)
 ,rr_target_per_unit = isnull(cte3.rr_target_per_unit,0)

FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit is null
   
--Ends Update of quality summary # All except $ per unit

--Starts Update of quality summary # $ per unit
;
WITH cte1 as
(
SELECT
t1.spirit_year
,t1.spirit_week
,t1.location
,t1.program
,t1.month_no

,SUM(t1.rr_amount_actual) as weekly_rr
,SUM(t1.scrap_amount_actual) as weekly_scrap

FROM reporting.facility_summary t1

WHERE t1.attribute = 'quality'
  
GROUP BY
t1.spirit_year
,t1.spirit_week
,t1.location
,t1.program

,t1.month_no
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.month_no
,c1.location
,c1.program

,SUM(c2.weekly_rr) as mtd_rr
,SUM(c2.weekly_scrap) as mtd_scrap

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.program = c2. program
 AND c1.spirit_year = c2.spirit_year
 AND c1.month_no = c2.month_no
 AND c1.spirit_week >= c2.spirit_week
 
GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.month_no
,c1.location
,c1.program
)

,
cte3 as
(
SELECT
t1.location
,t1.program
,t1.spirit_year
,t1.month_no
,SUM(t1.scrap_amount_actual) / NULLIF(SUM(t1.unit),0) monthly_scrap_per_unit

,SUM(t1.rr_amount_actual) / NULLIF(SUM(t1.unit),0) monthly_rr_per_unit
,SUM(t1.unit) monthly_unit

FROM reporting.facility_summary t1

WHERE t1.attribute = 'quality'

GROUP BY 
t1.location
,t1.program
,t1.spirit_year
,t1.month_no
)

,
cte4 as
(
SELECT
c2.spirit_year
,c2.spirit_week
,c2.month_no
,c2.location
,c2.program

,c2.mtd_rr / NULLIF(c3.monthly_unit,0) mtd_rr_per_unit
,c2.mtd_scrap / NULLIF(c3.monthly_unit,0) mtd_scrap_per_unit

FROM cte2 c2

INNER JOIN cte3 c3
 ON c2.spirit_year = c3.spirit_year
 AND c2.month_no = c3.month_no
 AND c2.location = c3.location
 AND c2.program = c3.program
)

,
cte5 as
(
SELECT
c3.location
,c3.spirit_year
,c3.month_no
,SUM(c3.monthly_scrap_per_unit) as monthly_scrap_per_unit

,SUM(c3.monthly_rr_per_unit) as monthly_rr_per_unit

FROM cte3 c3

GROUP BY
c3.location
,c3.spirit_year
,c3.month_no
)

,
cte6 as
(
SELECT
c4.location
,c4.spirit_year
,c4.spirit_week
,c4.month_no
,SUM(c4.mtd_rr_per_unit) as mtd_rr_per_unit

,SUM(c4.mtd_scrap_per_unit) as mtd_scrap_per_unit
,ROW_NUMBER () OVER (partition by c4.location,c4.spirit_year,c4.spirit_week  order by c4.month_no desc) as rno

FROM cte4 c4

GROUP BY
c4.location
,c4.spirit_year
,c4.spirit_week
,c4.month_no
)

,

cte7 as
(
SELECT 
c6.location
,c6.spirit_year
,c6.spirit_week
,c6.month_no
,c6.mtd_rr_per_unit

,c6.mtd_scrap_per_unit
,SUM(c5.monthly_rr_per_unit) as ytd_rr_per_unit
,SUM(c5.monthly_scrap_per_unit) as ytd_scrap_per_unit

FROM cte6 c6

LEFT OUTER JOIN cte5 c5
 ON c6.location = c5.location
 AND c6.spirit_year = c5.spirit_year
 AND c6.month_no > c5.month_no

WHERE c6.rno = 1

GROUP BY
c6.location
,c6.spirit_year
,c6.spirit_week
,c6.month_no
,c6.mtd_rr_per_unit

,c6.mtd_scrap_per_unit
)

UPDATE reporting.facility_weekly_variance
SET ytd_scrap_avg_per_unit = (isnull(cte7.mtd_scrap_per_unit,0) + isnull(cte7.ytd_scrap_per_unit,0)) / nullif(cte7.month_no,0)
 ,ytd_rr_avg_per_unit = (isnull(cte7.mtd_rr_per_unit,0) + isnull(cte7.ytd_rr_per_unit,0)) / nullif(cte7.month_no,0)

FROM cte7

WHERE reporting.facility_weekly_variance.spirit_year = cte7.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte7.spirit_week
 AND reporting.facility_weekly_variance.location = cte7.location
 AND reporting.facility_weekly_variance.business_unit is null

--Ends Update of quality summary # $ per unit


--Starts Update of utilization summary
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(manpower_available) as weekly_available

,SUM(manpower_clocked) as weekly_clocked
,SUM(manpower_clocked_noa) as weekly_noa

FROM reporting.facility_summary

WHERE attribute = 'utilization'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_noa) as ytd_noa

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.weekly_available
,c1.weekly_clocked

,c1.weekly_noa
,c2.ytd_noa

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit
)

UPDATE reporting.facility_weekly_variance
SET weekly_available = isnull(cte3.weekly_available,0)
 ,weekly_clocked = isnull(cte3.weekly_clocked,0) - isnull(cte3.weekly_noa,0)
 ,weekly_noa = isnull(cte3.weekly_noa,0)
 ,ytd_noa = isnull(cte3.ytd_noa,0)
 ,effective_hours = ((isnull(cte3.weekly_clocked,0) - isnull(cte3.weekly_noa,0)) / nullif(cte3.weekly_available,0)) --* 100

FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit = cte3.business_unit
 
--Ends Update of utilization summary


--Starts Update of overtime summary
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(actual_regular_hours) as weekly_actual_regular_hours

,SUM(actual_over_time_hours) as weekly_actual_over_time_hours
,SUM(forecast_regular_hours) as weekly_forecast_regular_hours
,SUM(forecast_over_time_hours) as weekly_forecast_over_time_hours

FROM reporting.facility_summary

WHERE attribute = 'overtime'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_actual_regular_hours) as ytd_actual_regular_hours

,SUM(c2.weekly_actual_over_time_hours) as ytd_actual_over_time_hours
,SUM(c2.weekly_forecast_regular_hours) as ytd_forecast_regular_hours
,SUM(c2.weekly_forecast_over_time_hours) as ytd_forecast_over_time_hours

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.weekly_actual_regular_hours

,c1.weekly_actual_over_time_hours
,c1.weekly_forecast_regular_hours
,c1.weekly_forecast_over_time_hours
,c2.ytd_actual_regular_hours
,c2.ytd_actual_over_time_hours

,c2.ytd_forecast_regular_hours
,c2.ytd_forecast_over_time_hours

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit
)

UPDATE reporting.facility_weekly_variance
SET weekly_actual_pcg = isnull((cte3.weekly_actual_over_time_hours/nullif(cte3.weekly_actual_regular_hours,0)),0)
 ,weekly_planned_pcg = isnull((cte3.weekly_forecast_over_time_hours/nullif(cte3.weekly_forecast_regular_hours,0)),0)
 ,ytd_actual_pcg = isnull((cte3.ytd_actual_over_time_hours/nullif(cte3.ytd_actual_regular_hours,0)),0)
 ,planned_ot_pcg = isnull((cte3.ytd_forecast_over_time_hours/nullif(cte3.ytd_forecast_regular_hours,0)),0)
 
FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit = cte3.business_unit
 
--Ends Update of overtime summary


--Starts Update of headcount summary
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(headcount_actuals) as weekly_headcount_actuals

,MAX(abs_std_pcg) as abs_std_pcg
,SUM(total_abs_hours) as weekly_total_abs_hours
,SUM(std_hours_per_week) as weekly_std_hours_per_week

FROM reporting.facility_summary

WHERE attribute = 'headcount'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_total_abs_hours) as ytd_total_abs_hours

,SUM(c2.weekly_std_hours_per_week) as ytd_std_hours_per_week

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.weekly_headcount_actuals

,c1.abs_std_pcg
,c1.weekly_total_abs_hours
,c1.weekly_std_hours_per_week
,c2.ytd_total_abs_hours
,c2.ytd_std_hours_per_week

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit
)

UPDATE reporting.facility_weekly_variance
SET assigned_actuals = isnull(cte3.weekly_headcount_actuals,0)
 ,abs_std_pcg = isnull(cte3.abs_std_pcg,0)
 ,week_abs_pcg_actual = isnull((cte3.weekly_total_abs_hours/nullif(cte3.weekly_std_hours_per_week,0)),0)
 ,ytd_abs_pcg_actual = isnull((cte3.ytd_total_abs_hours/nullif(cte3.ytd_std_hours_per_week,0)),0)
 
FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit = cte3.business_unit
 
--Ends Update of headcount summary


--Starts Update of downtime summary

;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(case when criticality = 'Critical 1-3' then asset_count else 0 end) as asset_count_critical_1_3

,SUM(case when criticality = 'Critical 4' then asset_count else 0 end) as asset_count_critical_4
,SUM(case when criticality = 'Critical 5' then asset_count else 0 end) as asset_count_critical_5
,SUM(case when criticality = 'Critical 1-3' then downtime_actual else 0 end) as weekly_downtime_actual_critical_1_3
,SUM(case when criticality = 'Critical 4' then downtime_actual else 0 end) as weekly_downtime_actual_critical_4
,SUM(case when criticality = 'Critical 5' then downtime_actual else 0 end) as weekly_downtime_actual_critical_5

,SUM(case when criticality = 'Critical 5' then downtime_target else 0 end) as weekly_downtime_target_critical_5

FROM reporting.facility_summary

WHERE attribute = 'downtime'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_downtime_actual_critical_1_3) as ytd_downtime_actual_critical_1_3

,SUM(c2.weekly_downtime_actual_critical_4) as ytd_downtime_actual_critical_4
,SUM(c2.weekly_downtime_actual_critical_5) as ytd_downtime_actual_critical_5

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c2.weekly_downtime_actual_critical_1_3 as prior_weekly_downtime_actual_critical_1_3

,c2.weekly_downtime_actual_critical_4 as prior_weekly_downtime_actual_critical_4
,c2.weekly_downtime_actual_critical_5 as prior_weekly_downtime_actual_critical_5

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week + 1
)


,
cte4 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.asset_count_critical_1_3

,c1.asset_count_critical_4
,c1.asset_count_critical_5
,c1.weekly_downtime_actual_critical_1_3
,c1.weekly_downtime_actual_critical_4
,c1.weekly_downtime_actual_critical_5

,c1.weekly_downtime_target_critical_5
,c2.ytd_downtime_actual_critical_1_3
,c2.ytd_downtime_actual_critical_4
,c2.ytd_downtime_actual_critical_5
,c3.prior_weekly_downtime_actual_critical_1_3

,c3.prior_weekly_downtime_actual_critical_4
,c3.prior_weekly_downtime_actual_critical_5

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit

LEFT OUTER JOIN cte3 c3
 ON c1.spirit_year = c3.spirit_year
 AND c1.spirit_week = c3.spirit_week
 AND c1.location = c3.location
 AND c1.business_unit = c3.business_unit 
 
)

UPDATE reporting.facility_weekly_variance
SET crit_1_3_asset = isnull(cte4.asset_count_critical_1_3,0)
 ,crit_1_3_weekly_dt_actuals_per_hrs = isnull(cte4.weekly_downtime_actual_critical_1_3,0)
 ,crit_1_3_prior_week_dt_actuals_per_hrs = isnull(cte4.prior_weekly_downtime_actual_critical_1_3,0)
 ,crit_1_3_ytd_dt_actuals_per_hrs = isnull(cte4.ytd_downtime_actual_critical_1_3,0)
 
 ,crit_4_assets = isnull(cte4.asset_count_critical_4,0)
 ,crit_4_weekly_dt_actuals_per_hrs = isnull(cte4.weekly_downtime_actual_critical_4,0)
 ,crit_4_prior_week_dt_actuals_per_hrs = isnull(cte4.prior_weekly_downtime_actual_critical_4,0)
 ,crit_4_ytd_dt_actuals_per_hrs = isnull(cte4.ytd_downtime_actual_critical_4,0)
 
 ,crit_5_assets = isnull(cte4.asset_count_critical_5,0)
 ,crit_5_weekly_dt_actuals_per_hrs = isnull(cte4.weekly_downtime_actual_critical_5,0)
 ,crit_5_prior_weekly_dt_actuals_per_hrs = isnull(cte4.prior_weekly_downtime_actual_critical_5,0)
 ,crit_5_ytd_dt_actuals_per_hrs = isnull(cte4.ytd_downtime_actual_critical_5,0)
 ,crit_5_weekly_dt_tgt_hrs = isnull(cte4.weekly_downtime_target_critical_5,0)
  
FROM cte4

WHERE reporting.facility_weekly_variance.spirit_year = cte4.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte4.spirit_week
 AND reporting.facility_weekly_variance.location = cte4.location
 AND reporting.facility_weekly_variance.business_unit = cte4.business_unit
 
--Ends Update of downtime summary

--Starts Update of nulls with 0

UPDATE reporting.facility_weekly_variance

SET weekly_scrap_actual = isnull(weekly_scrap_actual,0)
 ,weekly_rr_actual = isnull(weekly_rr_actual,0)
 ,scrap_target_per_unit = isnull(scrap_target_per_unit,0)
 ,rr_target_per_unit = isnull(rr_target_per_unit,0)
 ,ytd_scrap_avg_per_unit = isnull(ytd_scrap_avg_per_unit,0)
 
 ,ytd_rr_avg_per_unit = isnull(ytd_rr_avg_per_unit,0)
 ,weekly_available = isnull(weekly_available,0)
 ,weekly_clocked = isnull(weekly_clocked,0)
 ,weekly_noa = isnull(weekly_noa,0)
 ,ytd_noa = isnull(ytd_noa,0)
 
 ,effective_hours = isnull(effective_hours,0)
 ,weekly_actual_pcg = isnull(weekly_actual_pcg,0)
 ,weekly_planned_pcg = isnull(weekly_planned_pcg,0)
 ,ytd_actual_pcg = isnull(ytd_actual_pcg,0)
 ,planned_ot_pcg = isnull(planned_ot_pcg,0)

 ,assigned_actuals = isnull(assigned_actuals,0)
 ,abs_std_pcg = isnull(abs_std_pcg,0)
 ,week_abs_pcg_actual = isnull(week_abs_pcg_actual,0)
 ,ytd_abs_pcg_actual = isnull(ytd_abs_pcg_actual,0)
 ,crit_1_3_asset = isnull(crit_1_3_asset,0)
 
 ,crit_1_3_weekly_dt_actuals_per_hrs = isnull(crit_1_3_weekly_dt_actuals_per_hrs,0)
 ,crit_1_3_prior_week_dt_actuals_per_hrs = isnull(crit_1_3_prior_week_dt_actuals_per_hrs,0)
 ,crit_1_3_ytd_dt_actuals_per_hrs = isnull(crit_1_3_ytd_dt_actuals_per_hrs,0)
 ,crit_4_assets = isnull(crit_4_assets,0)
 ,crit_4_weekly_dt_actuals_per_hrs = isnull(crit_4_weekly_dt_actuals_per_hrs,0)
 
 ,crit_4_prior_week_dt_actuals_per_hrs = isnull(crit_4_prior_week_dt_actuals_per_hrs,0)
 ,crit_4_ytd_dt_actuals_per_hrs = isnull(crit_4_ytd_dt_actuals_per_hrs,0)
 ,crit_5_assets = isnull(crit_5_assets,0)
 ,crit_5_weekly_dt_tgt_hrs = isnull(crit_5_weekly_dt_tgt_hrs,0)
 ,crit_5_weekly_dt_actuals_per_hrs = isnull(crit_5_weekly_dt_actuals_per_hrs,0)
 
 ,crit_5_prior_weekly_dt_actuals_per_hrs = isnull(crit_5_prior_weekly_dt_actuals_per_hrs,0)
 ,crit_5_ytd_dt_actuals_per_hrs = isnull(crit_5_ytd_dt_actuals_per_hrs,0)
 
update SpiritDigi_Test.reporting.refresh_log
set reporting_period = week_str
,last_refresh_date_time = getdate() 
,week_no = spirit_week

from datamart.vw_dim_calendar
where is_current_week = 1

and report_name = 'Facility'

--Ends Update of nulls with 0

--COMMIT TRAN datamart_facility;

--END TRY

--BEGIN CATCH;

--PRINT 'Unexpected error occurred!'
--ROLLBACK TRAN datamart_facility
--RETURN 1


/* SELECT  
	@errorprocedure='[datamart].[proc_generate_facility_weekly_program_metrics]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
----RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0; */



END

GO
