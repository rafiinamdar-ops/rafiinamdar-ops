/*
**  repl_hotfix_uninstall.SQL
**  Patch uninstall script for replication components.
*/
