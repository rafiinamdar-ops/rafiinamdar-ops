
IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_facility_overtime')
 DROP PROC datamart.proc_cleansing_facility_overtime
GO

CREATE PROC datamart.proc_cleansing_facility_overtime
as

/*
Usage : Cleansing overtime data for factilities & fabrication from Staging & Loading to Datamart

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-05 # Initial Creation
*/

BEGIN

SET NOCOUNT ON;
DECLARE @spirit_year int;

SELECT @spirit_year = MAX(spirit_year)
FROM datamart.vw_dim_calendar
WHERE is_current_week = 1
--week_end_date < getdate() 

IF -- delete data for the current year if we have some data in the staging table
(
SELECT count(week_no) as cnt
FROM staging.ftp_direct_labor_safety
) > 10

DELETE FROM datamart.fact_direct_labor_safety
WHERE spirit_year = @spirit_year

--Starts cleansing of Overtime # Updating cost_center for merged rows (only for week_no = 1)

;
WITH cte1 as
(
SELECT
srno
,cost_center
,sheet_name

FROM staging.ftp_direct_labor_safety

WHERE cost_center is not null
 AND week_no = 1
)

,
cte2 as
(
SELECT
t1.srno
,t1.sheet_name
,max(c1.srno) as srno_cc

FROM staging.ftp_direct_labor_safety t1
INNER JOIN cte1 c1 
 ON t1.sheet_name = c1.sheet_name

WHERE t1.cost_center is null
 AND t1.week_no = 1
 AND t1.srno > c1.srno
 
GROUP BY
t1.srno
,t1.sheet_name
)

,
cte3 as
(
SELECT
c2.srno as sn
,c2.sheet_name as ss
,c1.cost_center as cc

FROM cte2 c2
INNER JOIN cte1 c1 
 ON c2.srno_cc = c1.srno
 AND c2.sheet_name = c1.sheet_name
)
 
UPDATE staging.ftp_direct_labor_safety
SET cost_center = cc

FROM cte3
WHERE srno = sn
 AND sheet_name = ss

--Ends cleansing of Overtime # Updating cost_center for merged rows (only for week_no = 1)
 
--Starts cleansing of Overtime # Updating metric_name for null rows (week_no 2 onwards)
;
WITH cte1 as
(
SELECT
srno as sn
,sheet_name as ss
,cost_center as cc
,metric_name as mn
,row_number () over (partition by sheet_name,week_no order by srno) as wsn

FROM staging.ftp_direct_labor_safety
WHERE week_no = 1
)

,
cte2 as
(
SELECT
srno
,sheet_name
,cost_center
,metric_name
,row_number () over (partition by sheet_name,week_no order by srno) as week_wise_srno

FROM staging.ftp_direct_labor_safety
WHERE week_no > 1
)

UPDATE cte2
SET cost_center = cc
 ,metric_name = mn

FROM cte1
WHERE sheet_name = ss
 AND week_wise_srno = wsn

--Ends cleansing of Overtime # Updating metric_name for null rows (week_no 2 onwards)


--Starts cleansing of Overtime # Inserting into datamart table
;
WITH cte_location as
(
SELECT DISTINCT
sheet_name
,location

FROM datamart.dim_cellrange_dynamic_excel_cols
)

INSERT INTO datamart.fact_direct_labor_safety
(
sheet_name
,location
,spirit_year
,spirit_week
,cost_center

,metric_name
,actuals
,planned
)

SELECT
t1.sheet_name
,c1.location
,@spirit_year
,t1.week_no
,coalesce(t2.actual_name, rtrim(ltrim(t1.cost_center))) as cost_center

,rtrim(ltrim(t1.metric_name)) as metric_name
,t1.actuals
,t1.planned

FROM staging.ftp_direct_labor_safety t1

LEFT OUTER JOIN cte_location c1 
 ON t1.sheet_name = c1.sheet_name

LEFT OUTER JOIN datamart.dim_alias_mapping t2 
 ON rtrim(ltrim(t1.cost_center)) = t2.alias_name
 AND t2.category = 'cost_center'

--Ends cleansing of Overtime # Inserting into datamart table

END

GO
