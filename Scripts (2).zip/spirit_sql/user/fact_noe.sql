/*
Usage : This table is used to load noe data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_noe'
)

CREATE TABLE [datamart].[fact_noe](
	[ecd] [varchar](30) NULL,
	[date_written] [date] NULL,
	[date_closed] [date] NULL,
	[noe_sdr_nar_nod] [varchar](20) NULL,
	[status] [varchar](50) NULL,
	[bu_supplier] [varchar](100) NULL,
	[customer] [varchar](30) NULL,
	[owner] [varchar](30) NULL,
	[models] [varchar](50) NULL,
	[assigned_to] [varchar](100) NULL,
	[description_of_condition] [varchar](300) NULL,
	[comments_disposition] [varchar](300) NULL,
	[rcca_summary] [varchar](max) NULL,
	[previous_occurrence] [varchar](30) NULL,
	[units_affected] [varchar](max) NULL,
	[rcca_initiated] [varchar](20) NULL,
	[rcca_completed] [varchar](20) NULL,
	[safety_of_flight] [varchar](20) NULL,
	[cust_ref] [varchar](20) NULL,
	[Z7] [varchar](max) NULL,
	[aftermarke_groups_affected] [varchar](30) NULL,
	[qn_number] [varchar](300) NULL,
	[qn_initiation_date] [datetime] NULL,
	[vendor_code] [varchar](20) NULL,
	[pns] [varchar](300) NULL,
	[disposition] [varchar](30) NULL,
	[can] [varchar](200) NULL,
	[can_initiated] [varchar](20) NULL,
	[can_action_plans_sent] [varchar](20) NULL,
	[can_closed] [varchar](30) NULL,
	[ecd_of_ca] [varchar](20) NULL,
	[z7_close_with_executive_summary] [varchar](30) NULL,
	[customer_closure_notice_received] [varchar](30) NULL,
	[path] [varchar](30) NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL,
	[modified_date] [datetime] NULL,
	[noe_sdr] [varchar](300) NULL,
	[tracking] [varchar](20) NULL,
	[item_type] [varchar](20) NULL,
	[boeing_mrb_appendix_C_authority_used] [varchar](200) NULL
)


GO


