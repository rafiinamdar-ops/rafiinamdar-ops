USE [msdb]
GO

/****** Object:  Job [SQLDBA_BackupDD_TLogs_NonProd]    Script Date: 8/19/2015 7:28:24 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Multi-Server)]]]    Script Date: 8/19/2015 7:28:24 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Multi-Server)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'MULTI-SERVER', @name=N'[Uncategorized (Multi-Server)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLDBA_BackupDD_TLogs_NonProd', 
		@enabled=1, 
		@notify_level_eventlog=2, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=2, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Multi-Server)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQL Server DBA', 
		@notify_page_operator_name=N'SQL Server DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check for Backups running]    Script Date: 8/19/2015 7:28:24 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check for Backups running', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec sqldba.dbo.proc_Job_Watcher ''SQLDBA_BackupDD_DB_Local'', 0, 1', 
		@database_name=N'SQLDBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check for Diff Backups running]    Script Date: 8/19/2015 7:28:24 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check for Diff Backups running', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec sqldba.dbo.proc_Job_Watcher ''SQLDBA_BackupDD_Diff_Local'', 0, 1', 
		@database_name=N'SQLDBA', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run proc_StartBackup]    Script Date: 8/19/2015 7:28:24 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run proc_StartBackup', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec sqldba..proc_StartBackupDD  ''tlog''', 
		@database_name=N'master', 
		@output_file_name=N'C:\TEMP\04mssql_BackupTLog.log', 
		@flags=6
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Rename log files]    Script Date: 8/19/2015 7:28:24 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Rename log files', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @fn as varchar(50)
declare @cmd as varchar(100)

set @fn = (select cast(datepart(yyyy,getdate()) as varchar(4))
   + case when Len(cast(datepart(mm,getdate()) as varchar(2))) = 1 
          then ''0'' + cast(datepart(mm,getdate()) as varchar(2))
          else cast(datepart(mm,getdate()) as varchar(2))
     end
   + case when Len(cast(datepart(dd,getdate()) as varchar(2))) = 1
          then ''0'' + cast(datepart(dd,getdate()) as varchar(2))
          else cast(datepart(dd,getdate()) as varchar(2))
     end
   + case when Len(cast(datepart(hh,getdate()) as varchar(2))) = 1
          then ''0'' + cast(datepart(hh,getdate()) as varchar(2))
          else cast(datepart(hh,getdate()) as varchar(2))
     end
   + case when Len(cast(datepart(mi,getdate()) as varchar(2))) = 1
          then ''0'' + cast(datepart(mi,getdate()) as varchar(2))
          else cast(datepart(mi,getdate()) as varchar(2))
     end
   + case when Len(cast(datepart(ss,getdate()) as varchar(2))) = 1
          then ''0'' + cast(datepart(ss,getdate()) as varchar(2))
          else cast(datepart(ss,getdate()) as varchar(2))
     end)
/* Rename Transaction Log Log File */
set @cmd = ''ren C:\TEMP\04mssql_BackupTLog.log TLog_''+@fn+''.log''
exec xp_cmdshell @cmd
/* Rename Netbackup Log File */
set @cmd = ''ren C:\Temp\mssql_NetBackupLog.Log NB_''+@fn+''.log''
exec xp_cmdshell @cmd', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Clean up backup history]    Script Date: 8/19/2015 7:28:24 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Clean up backup history', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=1, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'declare @oldest_date datetime
declare @datepart nvarchar (2)
declare @sql nvarchar (300)
declare @time int

set @datepart = (select case when charindex(''m'',varvalue) > 1 then ''mm''
     when charindex(''w'',varvalue) > 1 then ''ww''
     end
from sqldba.dbo.variable 
where varname = ''NetBackupRetention'')

if @datepart = ''mm'' 
   BEGIN
      set @time = (select 0 - left(varvalue,charindex(''m'',varvalue)-1)from sqldba.dbo.variable where varname = ''NetBackupRetention'')
      set @oldest_date = (select dateadd(mm,@time,(select convert(datetime, convert(varchar,datepart(mm,GetDate())) 
         + ''/'' + convert(varchar,datepart(dd,GetDate()))
         + ''/'' + convert(varchar,datepart(yyyy,GetDate()))))))
   END
else if @datepart = ''ww'' 
   BEGIN
      set @time = (select 0 - left(varvalue,charindex(''w'',varvalue)-1)from sqldba.dbo.variable where varname = ''NetBackupRetention'')
      set @oldest_date = (select dateadd(ww,@time,(select convert(datetime, convert(varchar,datepart(mm,GetDate())) 
         + ''/'' + convert(varchar,datepart(dd,GetDate()))
         + ''/'' + convert(varchar,datepart(yyyy,GetDate()))))))
   END
exec sp_delete_backuphistory @oldest_date
--print @oldest_date', 
		@database_name=N'msdb', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Transaction Log Backup Saturday 4 hour', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=64, 
		@freq_subday_type=8, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20090725, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=180001, 
		@schedule_uid=N'fb08376f-4e78-4008-8054-5db13fac1a53'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Transaction Log Backup Sunday 4 hour', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=4, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20090910, 
		@active_end_date=99991231, 
		@active_start_time=100000, 
		@active_end_time=180100, 
		@schedule_uid=N'344e30f6-bd32-4767-8846-b22d25baf741'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Transaction Log Backup Weekday 3 Hour', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=62, 
		@freq_subday_type=8, 
		@freq_subday_interval=3, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20150820, 
		@active_end_date=99991231, 
		@active_start_time=60000, 
		@active_end_time=180059, 
		@schedule_uid=N'858ffde2-528a-46c2-88e4-dc7bcaa10c23'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'SQL-RDU-74'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO


