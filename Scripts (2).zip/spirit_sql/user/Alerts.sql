USE [msdb]
GO

/****** Object:  Alert [825 - Read-Retry Required]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'825 - Read-Retry Required', 
		@message_id=825, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [AG Data Movement - Resumed]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'AG Data Movement - Resumed', 
		@message_id=35265, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [AG Data Movement - Suspended]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'AG Data Movement - Suspended', 
		@message_id=35264, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [AG Role Change]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'AG Role Change', 
		@message_id=1480, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'bc35bbea-1d75-4f76-9f47-318cde78a15e'
GO

/****** Object:  Alert [DB Integrity Error Sev. 23]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'DB Integrity Error Sev. 23', 
		@message_id=0, 
		@severity=23, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [DB Process Error Sev. 21]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'DB Process Error Sev. 21', 
		@message_id=0, 
		@severity=21, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Disk Full]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Disk Full', 
		@message_id=1105, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Fatal Error Sev. 25]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Fatal Error Sev. 25', 
		@message_id=0, 
		@severity=25, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [H/W Error Sev. 24]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'H/W Error Sev. 24', 
		@message_id=0, 
		@severity=24, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Log shipping Primary Server Alert.]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Log shipping Primary Server Alert.', 
		@message_id=14420, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=5, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Log shipping Secondary Server Alert.]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Log shipping Secondary Server Alert.', 
		@message_id=14421, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=5, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Process Error Sev. 20]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Process Error Sev. 20', 
		@message_id=0, 
		@severity=20, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Resource Limit Reached Sev. 19]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Resource Limit Reached Sev. 19', 
		@message_id=0, 
		@severity=19, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [TB Integrity Error Sev. 22]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'TB Integrity Error Sev. 22', 
		@message_id=0, 
		@severity=22, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [Trans Log Full]    Script Date: 2/22/2018 7:26:30 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'Trans Log Full', 
		@message_id=9002, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=600, 
		@include_event_description_in=3, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

