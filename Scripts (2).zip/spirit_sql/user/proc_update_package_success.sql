/*
Usage : This SP is used to load stored procedure log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_update_package_success')
 DROP PROC [datamart].[proc_update_package_success]
GO


CREATE PROC [datamart].[proc_update_package_success]
(
@package_name VARCHAR(100),
@process_number  UNIQUEIDENTIFIER,
@package_status VARCHAR(20)

)
AS
BEGIN


/***********************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Inserting LOG on package execution  
************************************************************************************************************/

SET NOCOUNT ON;
UPDATE datamart.log_package
SET [package_end_time]=GETDATE(),
package_status=@package_status
WHERE [package_name]=@package_name
AND process_number=@process_number
END




GO


