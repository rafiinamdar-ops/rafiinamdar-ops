use master
go
ALTER SERVER ROLE [dbcreator] ADD MEMBER [corp\svcnicelabel]
GO

GRANT ALTER ANY LOGIN TO [corp\svcnicelabel]
GO
GRANT ALTER ANY LOGIN TO [corp\svcnicelabel]
GO

GRANT CONNECT SQL TO [corp\svcnicelabel] WITH GRANT OPTION 
GO
GRANT CREATE ANY DATABASE TO [corp\svcnicelabel] WITH GRANT OPTION 
GO
GRANT CONTROL SERVER TO [corp\svcnicelabel];
Go
use msdb
go
Grant EXEC on msdb..sp_send_dbmail to [corp\svcnicelabel]
go
Grant EXEC on msdb.dbo.sp_delete_database_backuphistory to [corp\svcnicelabel]
GO