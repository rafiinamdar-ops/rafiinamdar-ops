/*
Usage : This datamart table is used to populate the data for quality attribuet of units for facility 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_units_facility'
)

CREATE TABLE datamart.fact_units_facility
(
	location nvarchar(255),
	program nvarchar(255),
	weekenddate date,
	units float 
) 

GO


