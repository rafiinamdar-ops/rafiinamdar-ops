/*
Usage : To find source data for quality attribute from oracl source 

Creator/Editor #Date #Comments
Prakhar  # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ora_srr_facility'
)

CREATE TABLE staging.ora_srr_facility
(
nc_key varchar(50)
,dtwritten datetime
,model_ist3 varchar(50)
,unit float
,defect_qty float

,defect_dollars float
,scrap_dollars float
,admin_cost float
,mgcode varchar(50)
,featdef_cd varchar(50)

,feat_descrip varchar(100)
,desc_description varchar(100)
,ncr_type varchar(20)
,value_chain varchar(20)
,parts varchar(40)

,origshop varchar(12)
,reasoncd varchar(3) 
,code_set_id varchar(50)
)

GO


