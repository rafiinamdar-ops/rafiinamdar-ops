USE [SQLDBA]
GO

/****** Object:  StoredProcedure [dbo].[proc_ExpireDD_Backups]    Script Date: 4/17/2017 3:06:41 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO










ALTER PROCEDURE [dbo].[proc_ExpireDD_Backups]  
as


declare @return_line varchar(1000) 
declare @rc int
declare @sOption as varchar(50)
declare @sql as nvarchar(2000)
declare @cmd as varchar(2000)

declare @saveerror int 
declare @orecipients nvarchar(max)
Set @orecipients = 'Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;Spirit_HP_NEN_SQL_ITAR@groups.ext.hpe.com;SQLServerDBAs@spiritaero.com' 
declare @msgtext nvarchar(max)
declare @osubject nvarchar(255) 
declare @gooddelete as int
declare @linectr as int 
declare @start_datetime datetime
declare @end_datetime   datetime 
declare @DDDeletemsg  varchar(50)
Set @DDDeletemsg = 'save sets were deleted successfully.'  
declare @delmsg_len     int 
set @delmsg_len =LEN(@DDDeletemsg)
declare @delmsg_start   int 
declare @comma_start    int 
declare @numlen         int 
declare @del_cnt_char   varchar(20)
set @del_cnt_char = '999999' 
declare @del_cnt_int    int  

 
declare @DDaparm5     varchar(50)   
Set @DDaparm5 = 'NSR_DFA_SI_DEVICE_PATH=/MSSQL'

DECLARE @cmd_output_tbl table (output varchar(1000))  
DECLARE READ_OUTPUT_CURSOR CURSOR for 
  select output from @cmd_output_tbl 

set @osubject = 'UNSUCCESSFUL DATA DOMAIN EXPIRY DELETE on server ' + @@SERVERNAME  
set @msgtext = 'Unexpected error encountered during Expiry tool run ' + '
    ' + 'Server = ' + @@SERVERNAME

set @start_datetime = getdate() 
   
 
-- print 'DDserver = ' + @DDserver



--print 'END of DD variables'                
 
    
delete from @cmd_output_tbl 
set @cmd = 'ddbmexptool.exe -k -n mssql -z "C:\Admin\ddconfig.cfg" -Y' 
-- print ' cmd variable = ' + @cmd 
-- set @cmd = 'exec master.xp_cmdshell ' + 'ddbmsqlsv.exe ' + @DDfullparm   /* + ' > ' + @DDFilename   */ 

-- print 'BEFORE EXPIRY COMMAND ISSUED' 
-- exec @rc = master..xp_cmdshell @cmd 
-- print 'return code = ' + cast(@rc as varchar(10))
-- print 'AFTER EXPIRY COMMAND ISSUED'

-- print 'cmd rc = ' + @rc 
-- exec master..xp_cmdshell @cmd 
-- print ' cmd variable = ' + @cmd 

insert into @cmd_output_tbl  exec master..xp_cmdshell @cmd  
-- set @rc = (select COUNT(*)from @cmd_output_tbl) 
-- print 'Rows returned from backup command = ' + cast(@rc as varchar(10))  
    
set @gooddelete = 0 
set @linectr = 0 

insert into [dbo].[DDDelete_History]  
       values (@@SERVERNAME, @start_datetime, @linectr, @start_datetime, NULL, NULL) 
    set @saveerror = @@ERROR
    if @saveerror <> 0 
      BEGIN         
        set @msgtext = @msgtext + '
        ' + 'Bad insert to DDDelete_History table, error = ' + cast(@saveerror as varchar(10))
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitDelete;               
      END 

open READ_OUTPUT_CURSOR
fetch next from READ_OUTPUT_CURSOR into @return_line 
while @@FETCH_STATUS = 0 
  BEGIN 
 --   print 'Next return line = ' + @return_line 
    if @gooddelete = 0 /* AND CHARINDEX(@DDDeletemsg, @return_line, 1)  > 0  */  
      BEGIN 
	    set @delmsg_start = CHARINDEX(@DDDeletemsg, @return_line, 1)
		print (@DDDeletemsg+@return_line)
		if @delmsg_start > 0 
		  BEGIN 
		 --   set @comma_start = CHARINDEX(',', @return_line, (@delmsg_start + @delmsg_len))
			--if @comma_Start > 0 
			----  BEGIN 
			--    set @numlen = @comma_start - (@delmsg_start + @delmsg_len) - 1
			--	set @del_cnt_char = SUBSTRING(@return_line, (@delmsg_start + @delmsg_len + 1), @numlen)
			--	set @del_cnt_int = CAST(@del_cnt_char as int)
			--	if @del_cnt_int > 0 				  
                  set @gooddelete = 1  
			  --END 
	     END      
      END 
    set @linectr = @linectr + 1
    insert into [dbo].[DDDelete_History]  
       values (@@SERVERNAME, @start_datetime, @linectr, NULL, NULL, @return_line) 
    set @saveerror = @@ERROR
    if @saveerror <> 0 
      BEGIN         
        set @msgtext = @msgtext + '
        ' + 'Bad insert to DDDelete_History table, error = ' + cast(@saveerror as varchar(10))
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'
        CLOSE READ_OUTPUT_CURSOR
        DEALLOCATE READ_OUTPUT_CURSOR
        goto ExitDelete;               
      END  
    fetch next from READ_OUTPUT_CURSOR into @return_line 
  END 

CLOSE READ_OUTPUT_CURSOR
DEALLOCATE READ_OUTPUT_CURSOR

set @linectr = @linectr + 1
set @end_datetime = getdate()
  
insert into [dbo].[DDDelete_History]  
       values (@@SERVERNAME, @start_datetime, @linectr, @start_datetime, @end_datetime, NULL) 
    set @saveerror = @@ERROR
    if @saveerror <> 0 
      BEGIN         
        set @msgtext = @msgtext + '
        ' + 'Bad insert to DDDelete_History table, error = ' + cast(@saveerror as varchar(10))
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitDelete;               
      END

if @gooddelete = 0 
  BEGIN
    set @msgtext = @msgtext + '    
    ' + '--> No Expired backups deleted; Check in sqldba database table DDDelete_History for detailed output <--' + '
	' + '# deletes found from output = ' + @del_cnt_char + ' (999999 means Summary delete record not found)'  
    EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
      @subject=@osubject, 
      @body=@msgtext,
      @body_format='TEXT' 
  END  
      

delete from [dbo].[DDDelete_History]
  where server_name    = @@SERVERNAME
    and start_datetime < (GETDATE() - 14)    

ExitDelete:

--drop table #t_options














GO

