use scat
go
SELECT DB_NAME() AS Database_Name
, sc.name AS Schema_Name
, o.name AS Table_Name
, i.name AS Index_Name
, i.type_desc AS Index_Type
,STATS_DATE(i.object_id, i.index_id) AS STATSDate
,DATEADD(DAY,-1,GETDATE()) AS STDAY
FROM sys.indexes i
INNER JOIN sys.objects o ON i.object_id = o.object_id
INNER JOIN sys.schemas sc ON o.schema_id = sc.schema_id
WHERE i.name IS NOT NULL
AND o.type = 'U'
ORDER BY o.name, STATS_DATE(i.object_id, i.index_id) desc

INSERT [SQLDBA].[dbo].[VARIABLE] ([VarName], [VarValue]) VALUES (N'Sdays', N'6') 