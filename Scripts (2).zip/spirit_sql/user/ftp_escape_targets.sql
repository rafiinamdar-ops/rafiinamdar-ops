/*
Usage : This table is used to load escape targets 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_escape_target'
)

CREATE TABLE [staging].[ftp_escape_target](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[load_date] [datetime] NOT NULL CONSTRAINT [DF__ftp_escap__load___19AACF41]  DEFAULT (getdate()),
	[model] [nvarchar](255) NOT NULL,
	[heading] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[function] [nvarchar](255) NULL,
	[year] [nvarchar](255) NULL,
	[week] [datetime] NULL,
	[week_no] [int] NULL,
	[weekly_escape_target] [float] NULL,
	[ytd_escape_target] [float] NULL,
	[sheet_name] [nvarchar](255) NULL,
	[location] [varchar](50) NULL,
 CONSTRAINT [PK__ftp_esca__1543595EFC6C6267] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO





