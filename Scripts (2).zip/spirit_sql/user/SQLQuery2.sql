select DB_NAME(database_id ) As dbanme,volume_mount_point,ROUND(total_bytes/1024/1024,2 ) As TotalSizeMB,ROUND(available_bytes/1024/1024,2 ) As FreeSpaceMB 
  from sys.dm_os_volume_stats (5, 1)

select * from sys.master_files

select ROUND(available_bytes/1024/1024,2 ) As FreeSpaceMB 
  from sys.dm_os_volume_stats (5, 1)

  DECLARE @sql varchar(500)
DECLARE @dbid int
DECLARE @fileid int

if exists(SELECT @dbid=database_id,@fileid=file_id FROM sys.master_files 
 where ((is_percent_growth =0 and max_size<>-1 and (((growth*8)/1024)*523)>=
	((select ROUND(available_bytes/1024/1024,2 )  from sys.dm_os_volume_stats (@dbid , @fileid)) ))))
	SELECT name,((growth*8)/1024)*523 FROM sys.master_files  where database_id =5

	select 52202/100

	select * from sys.master_files where database_id =5