USE [msdb]
GO

/****** Object:  Job [Auto Modify Database Growth and Report]    Script Date: 08/08/2017 00:36:17 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 08/08/2017 00:36:17 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'Auto Modify Database Growth and Report', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQL Server DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check and report Growth In Size]    Script Date: 08/08/2017 00:36:17 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check and report Growth In Size', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @sql varchar(500)
DECLARE @Info int=9
DECLARE @Warning int=8
DECLARE @Critical int=3
DECLARE @Subject varchar(100)
DECLARE @OutputParameter int
DECLARE @strMsg varchar(4000)
Declare @RCPT VARCHAR(500)
DECLARE @EMAIL varchar(5000)
DECLARE @DBID int
DECLARE @FileID int
SET @RCPT =''Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;SQLServerDBAs@spiritaero.com'' 
--SET @RCPT =''mahammadrafik.inamdar@hpe.com'' 
if exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical)
   begin

   SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
		CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
						where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
					and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical
set @sql=(SELECT ''ALTER DATABASE ''+DB_NAME(F.database_id )+ '' MODIFY FILE'' +''(NAME=''+F.name+ '',MAXSIZE=''
		+cast((cast(((size*8)/1024) as bigint)+Cast(((growth*8)/1024) as bigint)+1) as Varchar)+''MB)'' FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical)
print(@sql)
EXEC (@sql)

		---SELECT @Subject = ''SQL Monitor Disk Free Space Alert: '' + @@servername
		
			EXEC sqldba.dbo.usp_DBGrowth @OutputParameter OUTPUT 
		
			SELECT @strMSG=( SELECT			''DatabaseName : '' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							''DB Current Size : '' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+'' MB'' + char(10)+CHAR(10)+
							''DB Growth : '' +CAST((CAST((f.growth*8) AS bigint)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''DB MaxSize : '' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''FreeSpace On ''+ SUBSTRING(vs.volume_mount_point,1,2)+ '' Drive : '' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''TotalSpace On '' +SUBSTRING(vs.volume_mount_point,1,2)+ ''  Drive : ''+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''DBA Action : Immediate - Shrink the file, escalate a drive space request, or take other steps to ensure space available for DB to Grow. ''+ char(10) +CHAR(10)+
							''Suggested Additional Space Request : ''+ (CAST((@OutputParameter*1.5) AS VARCHAR))+'' MB''+ char(10) +CHAR(10)+
							convert(char(15),'' EventTime: '') + convert(varchar, getdate())
							FROM sys.master_files AS f
					CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
					WHERE f.database_id =@DBID and f.file_id =@fileid)

			SET @EMAIL = ''msdb.dbo.sp_send_dbmail
   @recipients = '''''' + @RCPT + '''''',
   @body = '''''' + @strMSG + '''''',
   @subject = '''' Critical : Database Grown on '' + @@SERVERNAME + '' !!''''''
 EXEC (@EMAIL)
  

--SELECT  ''CASE 1'', DB_NAME(f.database_id) As DBName,
--		(((f.growth*8)/1024)) AS Growth,
--		((cast(f.max_size as bigint)*8)/1024) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))) As CountS
--		FROM sys.master_files AS f
--	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
--	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
--		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical
end
   
   Else IF

   exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning)
   begin

SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
		CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
		where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and  FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning

set @sql=(SELECT ''ALTER DATABASE ''+DB_NAME(F.database_id )+ '' MODIFY FILE'' +''(NAME=''+F.name+ '',MAXSIZE=''
		+cast((cast(((size*8)/1024) as bigint)+Cast(((growth*8)/1024) as bigint)+1) as Varchar)+''MB)'' FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and  FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning)
print(@sql)
EXEC (@sql)

		---SELECT @Subject = ''SQL Monitor Disk Free Space Alert: '' + @@servername
		
 
			EXEC sqldba.dbo.usp_DBGrowth @OutputParameter OUTPUT 
			SELECT @strMSG=( SELECT			''DatabaseName : '' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							''DB Current Size : '' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+'' MB'' + char(10)+CHAR(10)+
							''DB Growth : '' +CAST((CAST((f.growth*8) AS bigint)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''DB MaxSize : '' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''FreeSpace On ''+ SUBSTRING(vs.volume_mount_point,1,2)+ '' Drive : '' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''TotalSpace On '' +SUBSTRING(vs.volume_mount_point,1,2)+ ''  Drive : ''+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''DBA Action : Send an SR to SRVWINDOWS for more space. ''+ char(10) +CHAR(10)+
							''Suggested Additional Space Request : ''+ (CAST(@OutputParameter AS VARCHAR))+'' MB''+ char(10) +CHAR(10)+
							convert(char(15),'' EventTime: '') + convert(varchar, getdate())
							FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	WHERE f.database_id =@DBID and f.file_id =@fileid)

			SET @EMAIL = ''msdb.dbo.sp_send_dbmail
   @recipients = '''''' + @RCPT + '''''',
   @body = '''''' + @strMSG + '''''',
   @subject = ''''Warning : Database Grown on '' + @@SERVERNAME + '' !!''''''
 EXEC (@EMAIL)
  

--SELECT  ''CASE 2'',DB_NAME(f.database_id) As DBName,
--		(((f.growth*8)/1024)) AS Growth,
--		((cast(f.max_size as bigint)*8)/1024) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))) As CountS
--		FROM sys.master_files AS f
--	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
--	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
--		and  FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning
end
  ELSE IF
  
   exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info)
   begin

SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info

set @sql=(SELECT ''ALTER DATABASE ''+DB_NAME(F.database_id )+ '' MODIFY FILE'' +''(NAME=''+F.name+ '',MAXSIZE=''
		+cast((cast(((size*8)/1024) as bigint)+Cast(((growth*8)/1024) as bigint)+1) as Varchar)+''MB)'' FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info)
print(@sql)
EXEC (@sql)


		---SELECT @Subject = ''SQL Monitor Disk Free Space Alert: '' + @@servername
		
 
		
			SELECT @strMSG=( SELECT			''DatabaseName : '' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							''DB Current Size : '' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+'' MB'' + char(10)+CHAR(10)+
							''DB Growth : '' +CAST((CAST((f.growth*8) AS bigint)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''DB MaxSize : '' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''FreeSpace On ''+ SUBSTRING(vs.volume_mount_point,1,2)+ '' Drive : '' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''TotalSpace On '' +SUBSTRING(vs.volume_mount_point,1,2)+ ''  Drive : ''+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''DBA Action : This is an informational message only; no DBA action is required. ''+ char(10) +CHAR(10)+
							convert(char(15),'' EventTime: '') + convert(varchar, getdate())
							FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs

	WHERE f.database_id =@DBID and f.file_id =@fileid)
	
			SET @EMAIL = ''msdb.dbo.sp_send_dbmail
   @recipients = '''''' + @RCPT + '''''',
   @body = '''''' + @strMSG + '''''',
   @subject = ''''Informational : Database Grown on '' + @@SERVERNAME + '' !!''''''
 EXEC (@EMAIL)
  END
', 
		@database_name=N'master', 
		@output_file_name=N'C:\temp\AutoDetectSQLDataFile.log', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check and report Growth In Percent]    Script Date: 08/08/2017 00:36:17 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check and report Growth In Percent', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'DECLARE @sql varchar(500)
DECLARE @Info int=9
DECLARE @Warning int=8
DECLARE @Critical int=3
DECLARE @Subject varchar(100)
DECLARE @OutputParameter int
DECLARE @strMsg varchar(4000)
Declare @RCPT VARCHAR(500)
DECLARE @EMAIL varchar(5000)
DECLARE @DBID int
DECLARE @FileID int
--SET @RCPT =''mahammadrafik.inamdar@hpe.com'' 
SET @RCPT =''Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;SQLServerDBAs@spiritaero.com''
if exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Critical)
   begin

   SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
		CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
			where (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024)) 
					and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Critical
set @sql=(SELECT ''ALTER DATABASE ''+DB_NAME(F.database_id )+ '' MODIFY FILE'' +''(NAME=''+F.name+ '',MAXSIZE=''
		+cast((((cast(((f.size*8)/1024) as bigint)))+(cast(((f.size*8)/1024) as bigint)*f.growth/100)+1) as Varchar)+''MB)'' FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*growth/100))<=@Critical)
print(@sql)
EXEC (@sql)


		
			EXEC sqldba.dbo.usp_DBGrowth @OutputParameter OUTPUT 
		
			SELECT @strMSG=( SELECT			''DatabaseName : '' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							''DB Current Size : '' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+'' MB'' + char(10)+CHAR(10)+
							''DB Growth : '' +CAST(f.growth  AS varchar)+'' %'' + char(10)+CHAR(10)+
							''DB MaxSize : '' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +'' MB'' + char(10)  +CHAR(10)+
							''FreeSpace On ''+ SUBSTRING(vs.volume_mount_point,1,2)+ '' Drive : '' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''TotalSpace On '' +SUBSTRING(vs.volume_mount_point,1,2)+ ''  Drive : ''+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''DBA Action : Immediate - Shrink the file, escalate a drive space request, or take other steps to ensure space available for DB to Grow. ''+ char(10) +CHAR(10)+
							''Suggested Additional Space Request : ''+ (CAST((@OutputParameter*1.5) AS VARCHAR))+'' MB''+ char(10) +CHAR(10)+
							convert(char(15),'' EventTime: '') + convert(varchar, getdate())
							FROM sys.master_files AS f
					CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
					WHERE f.database_id =@DBID and f.file_id =@fileid)

			SET @EMAIL = ''msdb.dbo.sp_send_dbmail
   @recipients = '''''' + @RCPT + '''''',
   @body = '''''' + @strMSG + '''''',
   @subject = '''' Critical : Database Grown on '' + @@SERVERNAME + '' !!''''''
 EXEC (@EMAIL)
  

--SELECT  ''CASE 1'', DB_NAME(f.database_id) As DBName,
--		((cast(((f.size*8)/1024) as bigint))) As DBSize,
--		(cast(((f.size*8)/1024) as bigint)*f.growth/100) AS Growth,
--		((cast((f.max_size*8) as bigint)/1024) ) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))) As CountS
--		FROM sys.master_files AS F
--CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
-- where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
--	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
--		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Critical
end
   
   Else IF

   exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Warning)
   begin


SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>@Critical 
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Warning

set @sql=(SELECT ''ALTER DATABASE ''+DB_NAME(F.database_id )+ '' MODIFY FILE'' +''(NAME=''+F.name+ '',MAXSIZE=''
		+cast((((cast(((f.size*8)/1024) as bigint)))+(cast(((f.size*8)/1024) as bigint)*f.growth/100)+1) as Varchar)+''MB)'' FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>@Critical 
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Warning)
print(@sql)
EXEC (@sql)

		 
			EXEC sqldba.dbo.usp_DBGrowth @OutputParameter OUTPUT 
			SELECT @strMSG=( SELECT			''DatabaseName : '' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							''DB Current Size : '' +CAST(((cast(((f.size*8)/1024) as bigint))) AS varchar)+'' MB'' + char(10)+CHAR(10)+
							''DB Growth : '' +CAST(f.growth  AS varchar)+'' %'' + char(10)+CHAR(10)+
							''DB MaxSize : '' +cast(((cast((f.max_size*8) as bigint)/1024) ) as Varchar)  +'' MB'' + char(10)  +CHAR(10)+
							''FreeSpace On ''+ SUBSTRING(vs.volume_mount_point,1,2)+ '' Drive : '' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''TotalSpace On '' +SUBSTRING(vs.volume_mount_point,1,2)+ ''  Drive : ''+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''DBA Action : Send an SR to SRVWINDOWS for more space. ''+ char(10) +CHAR(10)+
							''Suggested Additional Space Request : ''+ (CAST(@OutputParameter AS VARCHAR))+'' MB''+ char(10) +CHAR(10)+
							convert(char(15),'' EventTime: '') + convert(varchar, getdate())
							FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	WHERE f.database_id =@DBID and f.file_id =@fileid)

			SET @EMAIL = ''msdb.dbo.sp_send_dbmail
   @recipients = '''''' + @RCPT + '''''',
   @body = '''''' + @strMSG + '''''',
   @subject = ''''Warning : Database Grown on '' + @@SERVERNAME + '' !!''''''
 EXEC (@EMAIL)
  print ''test''

--SELECT  ''CASE 2''
--		,DB_NAME(f.database_id) As DBName,
--		((cast(((f.size*8)/1024) as bigint))) As DBSize,
--		(cast(((f.size*8)/1024) as bigint)*f.growth/100) AS Growth,
--		((cast((f.max_size*8) as bigint)/1024) ) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))) As CountS
--		FROM sys.master_files AS F
--CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
-- where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
--	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
--		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>@Critical 
--		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))<=@Warning
  
end
  ELSE IF
  
   exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>=@Info)
   begin

SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>=@Info

set @sql=(SELECT ''ALTER DATABASE ''+DB_NAME(F.database_id )+ '' MODIFY FILE'' +''(NAME=''+F.name+ '',MAXSIZE=''
		+cast((((cast(((f.size*8)/1024) as bigint)))+(cast(((f.size*8)/1024) as bigint)*f.growth/100)+1) as Varchar)+''MB)'' FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where  (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>=@Info)
print(@sql)
EXEC (@sql)
		
			SELECT @strMSG=( SELECT			''DatabaseName : '' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							''DB Current Size : '' +CAST(((cast(((f.size*8)/1024) as bigint))) AS varchar)+'' MB'' + char(10)+CHAR(10)+
							''DB Growth : '' +CAST(f.growth  AS varchar)+'' %'' + char(10)+CHAR(10)+
							''DB MaxSize : '' +cast(((cast((f.max_size*8) as bigint)/1024) ) as Varchar)  +'' MB'' + char(10)  +CHAR(10)+
							''FreeSpace On ''+ SUBSTRING(vs.volume_mount_point,1,2)+ '' Drive : '' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''TotalSpace On '' +SUBSTRING(vs.volume_mount_point,1,2)+ ''  Drive : ''+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +'' MB'' + char(10) +CHAR(10)+
							''DBA Action : This is an informational message only; no DBA action is required. ''+ char(10) +CHAR(10)+
							convert(char(15),'' EventTime: '') + convert(varchar, getdate())
							FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs

	WHERE f.database_id =@DBID and f.file_id =@fileid)
	
			SET @EMAIL = ''msdb.dbo.sp_send_dbmail
   @recipients = '''''' + @RCPT + '''''',
   @body = '''''' + @strMSG + '''''',
   @subject = ''''Informational : Database Grown on '' + @@SERVERNAME + '' !!''''''
 EXEC (@EMAIL)
  

--SELECT  ''CASE 3'',DB_NAME(f.database_id) As DBName,
--		((cast(((f.size*8)/1024) as bigint))) As DBSize,
--		(cast(((f.size*8)/1024) as bigint)*f.growth/100) AS Growth,
--		((cast((f.max_size*8) as bigint)/1024) ) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))) As CountS
--		FROM sys.master_files AS f
--	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
--	where (f.is_percent_growth =1 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+
--	((cast(((f.size*8)/1024) as bigint)*growth/100))))>=((cast(f.max_size as bigint)*8)/1024))
--		and FLOOR((vs.available_bytes/1024/1024)/(cast(((f.size*8)/1024) as bigint)*f.growth/100))>=@Info
end  
	 
	', 
		@database_name=N'master', 
		@output_file_name=N'C:\temp\AutoDetectSQLDataFile.log', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=15, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20150515, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'4693d823-a05b-4d2d-9929-237854046b2e'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

