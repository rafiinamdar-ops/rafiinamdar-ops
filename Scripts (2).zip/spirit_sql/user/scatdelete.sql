----select * from users where userid in (select userid from temp_users)

----select * into bkusers from users 

----delete users where userid in (select userid from temp_users)

----select * from Focals where BemsID in (select BemsID from temp_focals)

----select * into bkfocals from Focals

----delete Focals where BemsID in (select BemsID from temp_focals)

	
--select a.*  from FocalNames a, [dbo].[temp_FocalNames] b where a.FocalName =b.focalname and a.LastName =b.lastname
--															and a.FirstName =b.firstname --and rtrim(ltrim(a.Phone)) =rtrim(ltrim(b.phone))
--															and a.BemsID 	=b.bemsid

--select * into bkfocalnames from FocalNames 

--select *  from bkFocalNames 

--delete  from FocalNames  from FocalNames a inner join [dbo].[temp_FocalNames] b on  a.FocalName =b.focalname and a.LastName =b.lastname
--															and a.FirstName =b.firstname --and rtrim(ltrim(a.Phone)) =rtrim(ltrim(b.phone))
--															and a.BemsID 	=b.bemsid