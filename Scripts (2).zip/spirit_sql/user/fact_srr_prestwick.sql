IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_srr_prestwick'
)

CREATE TABLE [datamart].[fact_srr_prestwick](
	[total_srr_dollar] [float] NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[location] [varchar](50) NULL,
	[feature_description] [varchar](300) NULL,
	[date_written] [date] NULL,
	[modified_by] [varchar](50) NULL CONSTRAINT [DF__fact_srr___modif__625A9A57]  DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL CONSTRAINT [DF__fact_srr___modif__634EBE90]  DEFAULT (getdate()),
	[created_date] [datetime] NOT NULL,
	[discrepancy_description] [varchar](300) NULL,
	[feature_descrepancy] [varchar](300) NULL,
	[spirit_year] [int] NULL
) 

GO



