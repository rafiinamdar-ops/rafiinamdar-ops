

/*for sqlserver 2008 or 2008R2, version=10.0.0.0, for sql 2012 version=11.0.0.0, for sql2014, version=12.0.0.0*/

DECLARE @recipients varchar(100)
DECLARE @subject varchar(200)
DECLARE @dbname varchar(100) ='scat'
DECLARE @Body NVARCHAR(MAX),
    @TableHead VARCHAR(1000),
    @TableTail VARCHAR(1000)
SET @recipients = 'mahammadrafik.inamdar@dxc.com;mahammadrafik.inamdar@spiritaero.com' 
SET @subject =(SELECT @@ServerName)+' : '+UPPER(@dbname)+': DB Backup Report';

SET @TableTail = '</table></body></html>' ;
SET @TableHead = '<html><head>' + '<style>'
    + 'td {border: solid black;border-width: 1px;padding-left:5px;padding-right:5px;padding-top:1px;padding-bottom:1px;font: 11px arial} '
    + '</style>' + '</head>' + '<body>' + 'Report generated on : '
    + CONVERT(VARCHAR(50), GETDATE(), 113) 
    + ' <br> <table cellpadding=0 cellspacing=0 border=0>' 
    + '<tr> <td bgcolor=#E6E6FA><b>Database</b></td>'
    + '<td bgcolor=#E6E6FA><b>Backup by Username</b></td>'
    + '<td bgcolor=#E6E6FA><b>Backup Type</b></td>'
    + '<td bgcolor=#E6E6FA><b>is copy only</b></td>'
    + '<td bgcolor=#E6E6FA><b>backup start date</b></td>'
    + '<td bgcolor=#E6E6FA><b>backup completed date</b></td>'
	+ '<td bgcolor=#E6E6FA><b>Duration Min</b></td>'
	+ '<td bgcolor=#E6E6FA><b>Size in MB</b></td>' 
	+ '<td bgcolor=#E6E6FA><b>Physical device name</b></td></tr>'
	

SET @Body = ( SELECT    td = s.[database_name], '',
                        td = s.USER_NAME , '',
                        td = CASE s.TYPE
								WHEN 'D' THEN 'Full'
								WHEN 'I' THEN 'Diff'
								WHEN 'L' THEN 'Log'
								END , '',
                        td = s.is_copy_only, '',
                        td = CONVERT(VARCHAR(20), s.backup_start_date, 13) ,'',
                        td = CONVERT(VARCHAR(20), s.backup_finish_date, 13) ,'',
                        td = DATEDIFF(minute, s.backup_start_date, s.backup_finish_date) , '',
						td = CAST(ROUND(s.backup_size * 1.0 / ( 1024 * 1024 ), 2) AS NUMERIC(10, 2)),'',
						td= CAST(mf.physical_device_name AS VARCHAR(100)),''
              FROM   msdb.dbo.backupset s
					INNER JOIN msdb.dbo.backupmediafamily mf ON s.media_set_id = mf.media_set_id
					WHERE  s.database_name = @dbname AND  s.type ='d' and LEFT(mf.physical_device_name, 1) not in ('{')  
					AND s.backup_finish_date =(select max(s.backup_finish_date)  FROM   msdb.dbo.backupset s
					INNER JOIN msdb.dbo.backupmediafamily mf ON s.media_set_id = mf.media_set_id
					WHERE  s.database_name = @dbname AND  s.type ='d' and LEFT(mf.physical_device_name, 1) not in ('{') )
                  FOR   XML RAW('tr'),
                  ELEMENTS
            )
SELECT  @Body = @TableHead + ISNULL(@Body, '') + @TableTail


EXEC msdb..sp_send_dbmail 
   @recipients=@recipients,
  @subject=@subject,
  @body=@Body ,
  @body_format = 'HTML' ;