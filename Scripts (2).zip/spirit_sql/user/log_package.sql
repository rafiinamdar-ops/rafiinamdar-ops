/*
Usage : This table is used to load package log information 

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
Praveen C		# 2017-11-22	# Added Mail sent column to existing table
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'log_package'
)

CREATE TABLE [datamart].[log_package](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[package_name] [varchar](100) NOT NULL,
	[machine_name] [varchar](100) NOT NULL,
	[package_start_time] [datetime] NOT NULL,
	[package_status] [varchar](20) NULL,
	[package_end_time] [datetime] NULL,
	[error_message] [varchar](max) NULL,
	[time_in_seconds]  AS (datediff(second,[package_start_time],[package_end_time])),
	[process_number] [uniqueidentifier] NOT NULL,
 CONSTRAINT [PK__package___1543595EB07DCC7B] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)
GO

ALTER TABLE datamart.log_package
ADD mail_sent bit NOT NULL DEFAULT(0)
GO
