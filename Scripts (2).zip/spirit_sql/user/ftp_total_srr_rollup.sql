/*
Usage : This table is used to load structured data  for greenline costs

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-17	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_total_srr_rollup'
)

CREATE TABLE [staging].[ftp_total_srr_rollup](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[gl_dollar] [float] NULL,
	[source_load_dt] [datetime] NULL,
	[week_date] [date] NULL,
	[load_date] [datetime] DEFAULT (getdate()),
	[prog_key] [int] NOT NULL,
	[spirit_week_no] [int] NULL,
	[yr] [int] NULL
)

GO



