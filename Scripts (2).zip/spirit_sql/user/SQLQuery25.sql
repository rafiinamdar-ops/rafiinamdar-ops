SELECT 
n.value('(@name)[1]', 'varchar(50)') AS event_name,
n.value('(@timestamp)[1]', 'datetime') AS [EventDate],
[n].value('(/event/action[@name="query_hash"])[1]', 'decimal(38,0)') AS query_hash,
       [n].value('(/event/action[@name="query_plan_hash"])[1]', 'decimal(38,0)') AS query_plan_hash,
	   [n].value('(/event/action[@name="plan_handle"])[1]', 'nvarchar(max)') AS plan_handle,
	   [n].value('(/event/action[@name="client_hostname"])[1]', 'nvarchar(max)') AS client_hostname,
       [n].value('(/event/action[@name="database_name"])[1]', 'nvarchar(max)') AS database_name,
       [n].value('(/event/data[@name="sql_text"])[1]', 'nvarchar(max)') AS statement,
       [n].value('(/event/data[@name="duration"])[1]', 'bigint') AS duration_ms,
       [n].value('(/event/data[@name="cpu_time"])[1]', 'bigint') AS cpu_time_ms,
       [n].value('(/event/data[@name="physical_reads"])[1]', 'bigint') AS physical_reads,
       [n].value('(/event/data[@name="logical_reads"])[1]', 'bigint') AS logical_reads,
       [n].value('(/event/data[@name="writes"])[1]', 'bigint') AS writes,
[n].value('(/event/data[@name="row_count"])[1]', 'bigint') AS row_count
--INTO
--sqldba..Temp_CEOACTion

FROM
   (
         select CAST(event_data as XML) AS event_data
		
		 from sys.fn_xe_file_target_read_file
        (
        'J:\SQLBackups\AppSlow_0_131*.xel', 
       null, 
		null, 
		null
        )

    ) 
	--as xmlr(xdata) 
	 as tab
		CROSS APPLY event_data.nodes('event') as q(n)
Where n.value('(@name)[1]', 'varchar(50)') in ('attention') --and [n].value('(/event/data[@name=''duration'']/value)[1]','BIGINT')/1024>0 
and [n].value('(/event/action[@name="client_hostname"])[1]', 'nvarchar(max)')<>'hpn-ict-70'

--SELECT * FROM #Temp --WHERE LoginName <>'CORP\s9012592'

	
--SELECT cp.plan_handle,
--		qp.query_plan, 
--       SQLText.text
--  FROM #Temp AS CP
--  CROSS APPLY sys.dm_exec_sql_text( convert(varbinary(64),plan_handle,1)) AS SQLText
--  CROSS APPLY sys.dm_exec_query_plan( convert(varbinary,plan_handle)) AS QP

--DROP TABLE #Temp
	
	




