/*
Usage : This table is used to load list of models/programs
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_model'
)

CREATE TABLE [datamart].[dim_model](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](50) NULL,
	[created_by] [varchar](30) NULL,
	[created_date] [datetime] NOT NULL,
	[modified_by] [varchar](30) NULL,
	[modified_date] [datetime] NOT NULL CONSTRAINT [DF_dim_model_modified_date]  DEFAULT (getdate()),
 CONSTRAINT [PK__dim_mode__1543595E02D37D3F] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)

GO


