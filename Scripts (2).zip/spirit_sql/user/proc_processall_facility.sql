
IF EXISTS (SELECT name from sys.procedures where name ='proc_processall_facility')
 DROP PROC datamart.proc_processall_facility
GO

CREATE PROC datamart.proc_processall_facility
as

/*
Usage : Process all facilities related data 

Creator/Editor #Date #Comments
Pratheesh N # 2018-01-30 # Initial Creation
*/

BEGIN

SET NOCOUNT ON;

BEGIN TRAN process_facility;

DECLARE 
@errorline int -- used to call raiseerror
,@errornumber int -- used to call raiseerror
,@errorseverity int -- used to call raiseerror
,@errorstate int -- used to call raiseerror
,@errormessage varchar(2048) -- used to call raiseerror

,@errorprocedure varchar(50)


BEGIN TRY;

execute datamart.proc_cleansing_facility
execute datamart.proc_generate_facility_summary
execute datamart.proc_generate_facility_weekly_variance


COMMIT TRAN process_facility;

END TRY

BEGIN CATCH;

ROLLBACK TRAN process_facility

SELECT @errorprocedure='[datamart].[proc_cleansing_quality]', 
      @errorline=ERROR_LINE(),
      @errornumber=ERROR_NUMBER(),
	   @errorseverity=ERROR_SEVERITY(),
	   @errorstate=CASE WHEN ERROR_STATE()=0 THEN 1 ELSE ERROR_STATE() END,
      @errormessage=ERROR_MESSAGE();


EXECUTE datamart.proc_log_error
                                 @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
					  
RETURN -1;
END CATCH;
RETURN 0;


END

GO
