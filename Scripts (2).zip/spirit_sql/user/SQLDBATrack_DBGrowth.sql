USE [msdb]
GO

/****** Object:  Job [SQLDBA_TrackDBGrowth]    Script Date: 08/08/2017 00:38:24 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 08/08/2017 00:38:24 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLDBA_TrackDBGrowth', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'CORP\s9012592', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run DB Growth]    Script Date: 08/08/2017 00:38:24 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run DB Growth', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'If exists (SELECT Name FROM sys.databases EXCEPT  SELECT  dbName FROM sqldba..dbgrowthrate )
begin
Select sd.name as DBName,mf.type_desc as type_desc, mf.name as FileName,mf.physical_name as FilePath,mf.database_id, file_id, size
into #TempDBSize
from sys.databases sd
join sys.master_files mf
on sd.database_ID = mf.database_ID
--where mf.type_desc not in (''LOG'')
Order by mf.database_id, sd.name
Insert into dbo.DBGrowthRate (DBName,type_desc,lfname,physical_name, DBID, NumPages, OrigSize_In_MB, CurSize_In_MB, GrowthAmt, MetricDate)
(Select tds.DBName,tds.type_desc,tds.Filename,tds.Filepath, tds.database_ID, Sum(tds.Size) as NumPages, 
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8192)/1024)/1024)) as OrigSize,
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8192)/1024)/1024)) as CurSize,
''0.00 MB'' as GrowthAmt, GetDate() as MetricDate
from #TempDBSize tds
where tds.database_ID not in (SELECT DBID  FROM DBGrowthRate AS t1 
LEFT OUTER JOIN #TempDBSize AS t2 ON t1.DBID = t2.database_ID 
WHERE t2.database_ID IS NULL) 
Group by tds.database_ID, tds.DBName,tds.type_desc,tds.Filename,tds.Filepath)
Drop table #TempDBSize
end

Select sd.name as DBName, mf.type_desc as type_desc,mf.name as FileName,mf.physical_name as FilePath, mf.database_id, file_id, size
into #TempDBSize2
from sys.databases sd
join sys.master_files mf
on sd.database_ID = mf.database_ID
Order by mf.database_id, sd.name
If Exists (Select Distinct DBName from #TempDBSize2 
where DBName in (Select Distinct DBName from DBGrowthRate))
and Convert(varchar(10),GetDate(),102) > (Select Distinct Convert(varchar(10),Max(MetricDate),102) as MetricDate
from DBGrowthRate)

Begin
Insert into dbo.DBGrowthRate (DBName,type_desc,Lfname,physical_name, DBID, NumPages, OrigSize_In_MB, CurSize_In_MB, GrowthAmt, MetricDate)
(Select tds.DBName,tds.type_desc,tds.FileName,tds.FilePath, tds.database_ID, Sum(tds.Size) as NumPages, 
dgr.CurSize_In_MB as OrigSize,
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8192)/1024)/1024)) as CurSize,
Convert(varchar(100),(Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8192)/1024)/1024))
- dgr.CurSize_In_MB)) + '' MB'' as GrowthAmt, GetDate() as MetricDate
from #TempDBSize2 tds
join DBGrowthRate dgr
on tds.database_ID = dgr.DBID
Where DBGrowthID = (Select Distinct Max(DBGrowthID) from DBGrowthRate
where DBID = dgr.DBID)
Group by tds.database_ID, tds.DBName,tds.type_desc,tds.FileName,tds.FilePath,  dgr.CurSize_In_MB)
End
Else
IF Not Exists (Select Distinct DBName from #TempDBSize2 
where DBName in (Select Distinct DBName from DBGrowthRate))
Begin
Insert into dbo.DBGrowthRate (DBName,type_desc,Lfname,physical_name, DBID, NumPages, OrigSize_In_MB, CurSize_In_MB, GrowthAmt, MetricDate)
(Select tds.DBName,tds.type_desc,tds.FileName,tds.FilePath, tds.database_ID, Sum(tds.Size) as NumPages, 
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8192)/1024)/1024)) as OrigSize,
Convert(decimal(10,2),(((Sum(Convert(decimal(10,2),tds.Size)) * 8192)/1024)/1024)) as CurSize,
''0.00 MB'' as GrowthAmt, GetDate() as MetricDate
from #TempDBSize2 tds
where tds.database_ID not in (Select Distinct DBID from DBGrowthRate 
where DBName = tds.database_ID)
Group by tds.database_ID, tds.DBName,tds.type_desc,tds.FileName,tds.FilePath)
End
--declare @mdate datetime
--Select @mdate=MAX(MetricDate)
--from DBGrowthRate
--PRINT @mdate
--select * from DBGrowthRate WHERE MetricDate>=@mdate and dbname=''AAF''
--order by MetricDate desc 
--where MetricDate=Max(MetricDate)
--group by MetricDate
--Verifies values were entered
Drop table #TempDBSize2

', 
		@database_name=N'sqldba', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=8, 
		@freq_subday_interval=12, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160804, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'76cdedb3-988e-414b-8670-46f2ca7fbae2'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

