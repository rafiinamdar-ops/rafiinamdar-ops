sp_configure 'show advanced options' ,1
reconfigure
with override
go
----- Enable xp_cmdshell


sp_configure 'xp_cmdshell' ,1
reconfigure
with override
go
------Enable Database Mail XPs

sp_configure 'Database Mail XPs' ,1
reconfigure
with override
go

sp_configure 'show advanced options' ,0
reconfigure
with override
go



DECLARE @FilePathName VARCHAR (250)
DECLARE @LFilePathName VARCHAR (250)
DECLARE @cmd varchar(500)
SET @FilePathName = 'H:\Data\sqldba'
set @cmd = 'mkdir '+@FilePathName
exec master..xp_cmdshell @cmd
print(@cmd)

SET @LFilePathName = 'G:\Logs\sqldba'
set @cmd = 'mkdir '+@LFilePathName
exec master..xp_cmdshell @cmd
print(@cmd)

USE [master]
GO

/****** Object:  Database [sqldba]    Script Date: 11/9/2015 6:15:22 AM ******/
CREATE DATABASE [sqldba] ON  PRIMARY 
( NAME = N'SQLDBA_Data', FILENAME = N'H:\Data\sqldba\sqldba.MDF' , SIZE = 100000KB , MAXSIZE = UNLIMITED, FILEGROWTH = 10%)
 LOG ON 
( NAME = N'SQLDBA_Log', FILENAME = N'G:\Logs\sqldba\sqldba_1.ldf' , SIZE = 50000KB , MAXSIZE = 2048GB , FILEGROWTH = 10%)
GO

USE sqldba EXEC sp_changedbowner 'sa'

-- Create a Database Mail account
EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name = 'svcSQL',
   -- @description = 'Mail account for administrative e-mail.',
    @email_address = 'svcSQL@spiritaero.com',
    @replyto_address = 'SQLServerDBAs@spiritaero.com',
    @display_name = 'svcSQL',
    @mailserver_name = 'sec-relay-na.spiritaero.com' ;

-- Create a Database Mail profile
EXECUTE msdb.dbo.sysmail_add_profile_sp
    @profile_name = 'svcSQL'
    --@description = 'Profile used for administrative mail.' ;
    
    -- Add the account to the profile

EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
    @profile_name = 'svcSQL',
    @account_name = 'svcSQL',
    @sequence_number = 1;

 


-- Grant access to the profile to the public role

EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
    @profile_name = 'svcSQL',
    @principal_name = 'public',
   @is_default = 1;
GO

USE [msdb]
GO

/****** Object:  Operator [SQL Server DBA]    Script Date: 11/27/2014 00:42:31 ******/
EXEC msdb.dbo.sp_add_operator @name=N'SQL Server DBA', 
		@enabled=1, 
		@weekday_pager_start_time=0, 
		@weekday_pager_end_time=235959, 
		@saturday_pager_start_time=0, 
		@saturday_pager_end_time=235959, 
		@sunday_pager_start_time=0, 
		@sunday_pager_end_time=235959, 
		@pager_days=127, 
		@email_address=N'SQLServerDBAs@spiritaero.com;Spirit_HP_NEN_SQL@groups.ext.hpe.com', 
		@pager_address=N'max-dbsql-members@pager.corp.spiritaero.com', 
		@category_name=N'[Uncategorized]'
GO


USE [msdb]
GO
EXEC msdb.dbo.sp_update_operator @name=N'SQL Server DBA', 
		@enabled=1, 
		@weekday_pager_start_time=0, 
		@weekday_pager_end_time=235959, 
		@saturday_pager_start_time=0, 
		@saturday_pager_end_time=235959, 
		@sunday_pager_start_time=0, 
		@sunday_pager_end_time=235959, 
		@pager_days=127, 
		@email_address=N'SQLServerDBAs@spiritaero.com;Spirit_HP_NEN_SQL@groups.ext.hpe.com', 
		@pager_address=N'max-dbsql-members@pager.corp.spiritaero.com', 
		@netsend_address=N''
GO

/****** Object:  LinkedServer [SQLC-ENT-01-DFA]    Script Date: 06/09/2011 03:23:34 ******/
EXEC master.dbo.sp_addlinkedserver @server = N'SQL-ENT-21', @srvproduct=N'SQL Server'
 /* For security reasons the linked server remote logins password is changed with ######## */
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'SQL-ENT-21',@useself=N'True',@locallogin=NULL,@rmtuser=NULL,@rmtpassword=NULL
GO

/****** Object:  LinkedServer [SQL-ENT-35]    Script Date: 06/09/2011 03:28:06 ******/
EXEC master.dbo.sp_addlinkedserver @server = N'SQL-ENT-35', @srvproduct=N'SQL Server'
 /* For security reasons the linked server remote logins password is changed with ######## */
EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname=N'SQL-ENT-35',@useself=N'True',@locallogin=NULL,@rmtuser=NULL,@rmtpassword=NULL

GO

USE [msdb]
GO
EXEC master.dbo.sp_MSsetalertinfo @failsafeoperator=N'SQL Server DBA', 
		@notificationmethod=1
GO
USE [msdb]
GO
EXEC msdb.dbo.sp_set_sqlagent_properties @email_save_in_sent_folder=1
GO
EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', N'UseDatabaseMail', N'REG_DWORD', 1
GO
EXEC master.dbo.xp_instance_regwrite N'HKEY_LOCAL_MACHINE', N'SOFTWARE\Microsoft\MSSQLServer\SQLServerAgent', N'DatabaseMailProfile', N'REG_SZ', N'svcSQL'
GO



