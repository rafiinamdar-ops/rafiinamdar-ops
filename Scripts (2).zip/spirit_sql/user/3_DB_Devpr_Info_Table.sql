DECLARE @name VARCHAR(100) -- database name  
/****** Object:  Table [dbo].[!DB_Devpr_Info]    Script Date: 6/8/2017 12:29:57 AM ******/
DECLARE @cmd varchar(1000)
DECLARE @objectname varchar(50)
DECLARE db_cursor CURSOR FOR  
select name from sys.databases 
WHERE name NOT IN ('master','msdb','tempdb')  and state_desc not in ('OFFLINE')

OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @name  

WHILE @@FETCH_STATUS = 0  
BEGIN 
SET @cmd='USE ['+@name+'] 
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'''+'[dbo].[!DB_Devpr_Info]'''+') AND type in (N'''+'U'''+'))
BEGIN
CREATE TABLE [dbo].[!DB_Devpr_Info](
	[DB_Nm] [varchar](100) NOT NULL,
	[Devpr_Nm] [varchar](50) NULL,
	[Devpr_Ph] [varchar](20) NULL,
	[Devpr_UID] [varchar](8) NULL,
	[DB_Cr_Dt] [varchar](10) NULL,
	[TRD_PRTY_APP] [char](10) NULL CONSTRAINT [DF_!DB_Devpr_Info_TRD_PRTY_APP]  DEFAULT ('''+'N'''+'),
	[E_Mail] [varchar](100) NULL,
	[Application_name] [varchar](255) NULL
) ON [PRIMARY]
END
ELSE IF NOT EXISTS (select * from sys.columns WHERE name ='''+'Application_name'''+' and object_id =OBJECT_ID('''+'!DB_Devpr_Info'''+'))
BEGIN
ALTER TABLE dbo.[!DB_Devpr_Info] ADD
	Application_name varchar(255) NULL
alter table [dbo].[!DB_Devpr_Info] alter column [DB_Nm] varchar(100)
END
 '
--PRINT @Cmd
EXEC (@cmd)

 FETCH NEXT FROM db_cursor INTO @name  
END  


CLOSE db_cursor  
DEALLOCATE db_cursor 