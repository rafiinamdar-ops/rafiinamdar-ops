/*
Usage : This datamart table is used to populate the data for downtime attribute priority wise

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_downtime_dailyclocking'
)

CREATE TABLE datamart.fact_downtime_dailyclocking
(
	assetnum nvarchar(25),
	change_date date,
	wo_num nvarchar(20),
	downtime float,
	assetdept nvarchar(12),
	
	wo_description nvarchar(158),
	location nvarchar(35),
	wo_priority float,
	busunit nvarchar(10),
	wo_status nvarchar(20),
	
	siteid nvarchar(8),
	shopid nvarchar(15),
	report_date nvarchar(21),
	actfinish nvarchar(21),
	leadcraft nvarchar(8),
	
	maintgrp nvarchar(10),
	reqpri nvarchar(10),
	amflag float,
	workorder_desc nvarchar(100),
	work_type nvarchar(5),
	
	failure_desc nvarchar(100) 
)

GO


