/*
Usage : This table is used to load prestwick srr ytd data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-11-01	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_srr_prestwick'
)

CREATE TABLE [staging].[ftp_srr_prestwick](
	[value_chain] [varchar](50) NULL,
	[location] [varchar](50) NULL,
	[program] [varchar](50) NULL,
	[date_written] [date] NULL,
	[feature_descrepancy] [varchar](255) NULL,
	[total_srr_dollar] [money] NULL,
	[week] [int] NULL,
	[Month] [int] NULL,
	[load_date] [datetime] NULL DEFAULT (getdate())
)

GO




