USE [sqldba]
GO

DECLARE @RC int

-- TODO: Set parameter values here.
EXEC sp_serveroption @server = 'ServerName',@optname = 'remote proc transaction promotion', @optvalue = 'false' 
EXECUTE @RC = [dbo].[porc_SSRSRestart] 
GO

use master 
go
CREATE ROLE [CmdShell_Executor] AUTHORIZATION [dbo]
GRANT EXEC ON xp_cmdshell TO [CmdShell_Executor]

USE [master]
GO
ALTER ROLE [CmdShell_Executor] ADD MEMBER [CORP\svcsqlagt]
GO

EXEC sp_xp_cmdshell_proxy_account 'corp\svcsqlagt', 'Password';



use master
GRANT EXECUTE ON master.dbo.xp_sqlagent_notify TO [corp\svcsqlrs]
GRANT EXECUTE ON master.dbo.xp_sqlagent_enum_jobs TO [corp\svcsqlrs]
GRANT EXECUTE ON master.dbo.xp_sqlagent_is_starting TO [corp\svcsqlrs]
use msdb
GRANT EXECUTE ON msdb.dbo.sp_help_category TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_add_category TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_add_job TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_add_jobserver TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_add_jobstep TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_add_jobschedule TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_help_job TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_delete_job TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_help_jobschedule TO [corp\svcsqlrs]
GRANT EXECUTE ON msdb.dbo.sp_verify_job_identifiers TO [corp\svcsqlrs]

