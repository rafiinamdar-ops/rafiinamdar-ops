
IF EXISTS 
(
SELECT name 
from sys.procedures 
where name ='proc_sendmail_failed_packages'
)
DROP PROC datamart.proc_sendmail_failed_packages
GO

CREATE PROCEDURE datamart.proc_sendmail_failed_packages
AS
BEGIN
/*
Usage : To send email alert if any package is failed.

Creator/Editor #Date #Comments
Praveen C # 2017-11-28 # Initial creation
*/
SET NOCOUNT ON

DECLARE @xml NVARCHAR(MAX)
,@body NVARCHAR(MAX)
,@mail_recipients VARCHAR(1000)='praveen.d@genpact.com'
,@total_counts int
,@failed_counts int 

DECLARE @FailedPackages TABLE
(
pk_id INT,
package_name VARCHAR(100),
package_end_time DATETIME,
[error_message] VARCHAR(MAX),
package_status VARCHAR(50)
)

Insert INTO @FailedPackages
SELECT pk_id, package_name, package_end_time, [error_message],package_status
FROM datamart.log_package 
WHERE package_status = 'fail'
AND mail_sent = 0

SELECT @total_counts = COUNT(pk_id)
FROM @FailedPackages

SELECT @failed_counts = COUNT(pk_id)
FROM @FailedPackages
WHERE package_status = 'fail'

IF @failed_counts > 0
BEGIN

SET @xml = CAST(( SELECT package_name AS 'td', '', package_end_time as 'td','',[error_message] AS 'td'
FROM @FailedPackages 
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

SET @body ='<html><body>
Hi Team,
<p>Below packages are failed while processing data, please look into it ASAP.</p>
<H4 style="color:red">Failed packages Info</H4>
<table border = 1> 
<tr>
<th>Package Name</th> <th>Last run Time</th> <th>Error Message</th></tr>'    

SET @body = @body + @xml +'</table>

<p></br>Thanks & Regards,</br>
Digi Analytics Admin</p>
</body></html>'

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'Spirit_Digi',
@body = @body,
@body_format ='HTML',
@recipients = @mail_recipients,
@subject = 'Alert - Packages failed';

UPDATE L SET mail_sent = 1
From datamart.log_package L
INNER JOIN @FailedPackages T 
ON T.pk_id = L.pk_id

--Print @body
END

IF (@failed_counts=0 AND @total_counts=0)
BEGIN

SET @body = '<html><body>
Hi Team,
<p style="color:red">There are no logs found, please check all packages ran correctly?</p>

<p></br>Thanks & Regards,</br>
Digi Analytics Admin</p>
</body></html>'  

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'Spirit_Digi',
@body = @body,
@body_format ='HTML',
@recipients = @mail_recipients,
@subject = 'Alert - Packages are not ran';

END

END

GO
