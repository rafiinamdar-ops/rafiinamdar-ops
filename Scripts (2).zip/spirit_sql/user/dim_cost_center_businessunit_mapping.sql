/*
Usage : This table is used to populate the categorized data For  headcount metric for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_cost_center_businessunit_mapping'
)

CREATE TABLE datamart.dim_cost_center_businessunit_mapping
(
	cost_center nvarchar(100) ,
	business_unit nvarchar(500) ,
	location varchar(50) ,
	
PRIMARY KEY CLUSTERED 
(
	cost_center ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


