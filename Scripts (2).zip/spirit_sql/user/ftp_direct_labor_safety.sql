/*
Usage :It is used to load Genpact DT Labor & Safery excel 

Creator/Editor #Date #Comments
Pratheesh N # 2017-10-13 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_direct_labor_safety'
)

CREATE TABLE staging.ftp_direct_labor_safety
(
srno bigint identity
,sheet_name nvarchar(200)
,week_no int not null
,cost_center nvarchar (200)
,metric_name nvarchar (200)
,actuals float (53)
,planned float (53)
) 

GO

