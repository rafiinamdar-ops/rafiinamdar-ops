USE sqldba
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[AGJobs]') AND type in (N'U'))
Create table sqldba..AGJobs
(
Job_Name varchar(100),
Status bit
)

IF (select rs.role_desc from sys.dm_hadr_availability_replica_cluster_nodes n 
	join sys.dm_hadr_availability_replica_cluster_states cs 
	on n.replica_server_name = cs.replica_server_name 
		join sys.dm_hadr_availability_replica_states rs  
		on rs.replica_id = cs.replica_id 
	Where node_name =(@@SERVERNAME) )='PRIMARY'
		Begin
		TRUNCATE TABLE sqldba..AGJobs
			INSERT INTO sqldba..AGJobs SELECT name,enabled 
				FROM msdb.dbo.sysjobs WHERE originating_server_id =0 and  name not in ('syspolicy_purge_history')
        End
		select * from sqldba..AGJobs

		select * from  msdb.dbo.sysjobs