/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6544)
    Source Database Engine Edition : Microsoft SQL Server Standard Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2012
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_get_outdated_statistics_lb]    Script Date: 12/8/2017 5:17:58 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO





CREATE PROC [dbo].[proc_get_outdated_statistics_lb] @sdays int = 1
AS

/******************************
** File:    proc_get_outdated_statistics_lb.sql
** Name: proc_get_outdated_statistics_lb
** Desc: Updated the statistics older than 1 Day.
** Auth: Mahammadrafik Inamdar
** Date: 12/07/2017
**************************
** Change History
**************************
** PR   Date        Author  Description 
** --   --------   -------   ------------------------------------
** 
*******************************/
SET NOCOUNT ON;
DECLARE @dbid int;
DECLARE @dbname VARCHAR(150) -- database name 
DECLARE @sql varchar(max);
DECLARE @uscmd varchar(300);
DECLARE @Days int;
SET @Days=-1*@sdays

CREATE TABLE #Temp (cmd varchar(500) )

		DECLARE db CURSOR FAST_FORWARD FOR SELECT  [name] FROM master.sys.databases 
		WHERE name NOT IN ('master','model','msdb','tempdb','sqldba','APRARCH2016','APRARCH2016_FRZ','ReportServerTempDB','ReportServer_2008TempDB')  and state_desc <>'OFFLINE' 

		

OPEN db;

/* Get database(s) to be processed */
FETCH NEXT FROM db INTO  @dbname
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
		set @sql = 'USE ['+@dbname+'] 
				 SELECT 
				 ''UPDATE STATISTICS ['+@dbname+'].[''+sc.name+''].['' + o.name+'']([''+i.name+''])''+''   WITH FULLSCAN''
				FROM sys.indexes i
				INNER JOIN sys.objects o ON i.object_id = o.object_id
				INNER JOIN sys.schemas sc ON o.schema_id = sc.schema_id
				WHERE i.name IS NOT NULL AND o.type = ''U'' 
					  AND ISNULL(STATS_DATE(i.object_id, i.index_id),DATEADD(DAY,-2,GETDATE()))<=DATEADD(DAY,'+CAST(@Days AS VARCHAR)+',GETDATE())'
	--print @sql
	----exec (@sql)
	INSERT INTO #Temp exec (@sql)
		
	END
	FETCH NEXT FROM db INTO  @dbname
END

CLOSE db
DEALLOCATE db


DECLARE db_cursor CURSOR FOR  
SELECT cmd
FROM #Temp


OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @uscmd  

WHILE @@FETCH_STATUS = 0  
BEGIN  
      PRINT 'Executed Updating Stats : '+@uscmd 
	  Exec(@uscmd)      

       FETCH NEXT FROM db_cursor INTO @uscmd
END  

CLOSE db_cursor  
DEALLOCATE db_cursor 
--SELECT * FROM #Temp 
DROP TABLE  #Temp



GO

