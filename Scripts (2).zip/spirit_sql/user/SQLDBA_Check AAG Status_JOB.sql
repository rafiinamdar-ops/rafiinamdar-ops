USE [msdb]
GO

/****** Object:  Job [SQLDBA_Check AAG Status]    Script Date: 12/19/2017 1:04:30 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 12/19/2017 1:04:30 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLDBA_Check AAG Status', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=2, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', 
		@notify_email_operator_name=N'SQL Server DBA', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Wait Delay 2 Minitues]    Script Date: 12/19/2017 1:04:30 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Wait Delay 2 Minitues', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Begin
WAITFOR DELAY ''00:02'';
End', 
		@database_name=N'master', 
		@output_file_name=N'C:\temp\AAGStatus.out', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check AAG Status]    Script Date: 12/19/2017 1:04:30 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check AAG Status', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'
DECLARE @state VARCHAR(30) 
DECLARE  @DbAAG INT 
DECLARE  @DbName VARCHAR(30)
DECLARE  @String VARCHAR(100) 
DECLARE  @databases TABLE (AGGroup VARCHAR (20),DBName VARCHAR(100),Role VARCHAR(10),synchronization_state_desc VARCHAR(30),synchronization_health_desc  VARCHAR(30)
			,suspend_reason_desc  VARCHAR(50)) 
DECLARE @Body VARCHAR(600)
Declare @Role VARCHAR(10)
Declare @SyncHealth VARCHAR(20)
DECLARE @SuspendReason VARCHAR(20)

-- get status for mirrored databases 
 
INSERT  @databases 

SELECT
AG.name AS [AvailabilityGroupName],
--ISNULL(agstates.primary_replica, '''') AS [PrimaryReplicaServerName],
--ISNULL(arstates.role, 3) AS [LocalReplicaRole],
dbcs.database_name AS [DatabaseName],
arstates.role_desc,
--ISNULL(dbrs.synchronization_state, 0) AS [SynchronizationState],
--ISNULL(dbrs.is_suspended, 0) AS [IsSuspended],
--ISNULL(dbcs.is_database_joined, 0) AS [IsJoined],
dbrs.synchronization_state_desc,
dbrs.synchronization_health_desc,
dbrs.suspend_reason_desc
FROM master.sys.availability_groups AS AG
LEFT OUTER JOIN master.sys.dm_hadr_availability_group_states as agstates
   ON AG.group_id = agstates.group_id
INNER JOIN master.sys.availability_replicas AS AR
   ON AG.group_id = AR.group_id
INNER JOIN master.sys.dm_hadr_availability_replica_states AS arstates
   ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1
INNER JOIN master.sys.dm_hadr_database_replica_cluster_states AS dbcs
   ON arstates.replica_id = dbcs.replica_id
LEFT OUTER JOIN master.sys.dm_hadr_database_replica_states AS dbrs
   ON dbcs.replica_id = dbrs.replica_id AND dbcs.group_database_id = dbrs.group_database_id
WHERE dbrs.synchronization_state_desc NOT IN (''SYNCHRONIZED'',''SYNCHRONIZING'')
ORDER BY AG.name ASC, dbcs.database_name

 -- iterate through mirrored databases and send email alert 
 
WHILE

 EXISTS (SELECT TOP 1 DBName FROM @databases WHERE synchronization_state_desc IS NOT NULL) 

BEGIN

 

SELECT TOP 1 @DbName = DBName ,@Role=Role, @State =synchronization_state_desc,@SyncHealth=synchronization_health_Desc, @SuspendReason=suspend_reason_desc

FROM @databases 

IF @SuspendReason is NULL
SET @SuspendReason=''NULL''


SET @string = ''Host: ''+@@servername+''.''+@DBName+ '' - DB AAG Status is ''+@state +'' - Please Check '' 
SET @Body = ''Host: ''+@@servername+'' --DataBaseName : ''+@DBName+ +'' --Role : ''+@Role +'' --DB AAG Status : ''+@state 
			+''  --Synchronization_Health : ''+@SyncHealth
			+''  --Suspend_Reason : ''+ @SuspendReason

EXEC msdb.dbo.sp_send_dbmail ''svcsql'', ''SQLServerDBAs@spiritaero.com;Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com'', @body = @Body, @subject =@string

DELETE FROM @databases WHERE DBName = @DbName 

END

 

 

--also alert if there is no mirroring just in case there should be mirroring :)
 
SELECT

 @DbAAG = COUNT(*) 
FROM master.sys.availability_groups AS AG
LEFT OUTER JOIN master.sys.dm_hadr_availability_group_states as agstates
   ON AG.group_id = agstates.group_id
INNER JOIN master.sys.availability_replicas AS AR
   ON AG.group_id = AR.group_id
INNER JOIN master.sys.dm_hadr_availability_replica_states AS arstates
   ON AR.replica_id = arstates.replica_id AND arstates.is_local = 1
INNER JOIN master.sys.dm_hadr_database_replica_cluster_states AS dbcs
   ON arstates.replica_id = dbcs.replica_id
LEFT OUTER JOIN master.sys.dm_hadr_database_replica_states AS dbrs
   ON dbcs.replica_id = dbrs.replica_id AND dbcs.group_database_id = dbrs.group_database_id

IF

 @DbAAG = 0 

BEGIN

 

SET @string = ''Host: ''+@@servername+'' - No databases are Added to AAG on this server - notify SQL DBA'' 

EXEC msdb.dbo.sp_send_dbmail ''svcsql'', ''SQLServerDBAs@spiritaero.com;Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com'', @body = @string, @subject = @string 

END
', 
		@database_name=N'master', 
		@output_file_name=N'C:\temp\AAGStatus.out', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily', 
		@enabled=1, 
		@freq_type=4, 
		@freq_interval=1, 
		@freq_subday_type=4, 
		@freq_subday_interval=8, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=0, 
		@active_start_date=20160321, 
		@active_end_date=99991231, 
		@active_start_time=0, 
		@active_end_time=235959, 
		@schedule_uid=N'7c265057-f746-4956-8c40-8758cf1fc39c'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

