/*
Usage : This table is used to populate the data for summary dashboard graph for facility for all metrics

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'facility_summary'
)

CREATE TABLE reporting.facility_summary
(
spirit_year int
,spirit_week int
,date_written date
,program nvarchar(100)
,location nvarchar(100)

,rr_amount_actual float
,rr_amount_target float
,scrap_amount_actual float
,scrap_amount_target float
,manpower_available float

,manpower_clocked float
,downtime_actual float
,downtime_target float
,headcount_actuals float
,attribute varchar(100)

,value_chain nvarchar(200)
,manpower_clocked_noa float
,abs_std_pcg float
,actual_over_time_hours float
,actual_regular_hours float

,forecast_regular_hours float
,forecast_over_time_hours float
,business_unit nvarchar(200)
,total_abs_hours float
,std_hours_per_week float

,unit float
,planned_maint float
,target_maint float
,rr_reduction_target_pcg float
,scrap_reduction_target_pcg float

,laborcost float
,matlcost float
,nonstockcost float
,assetnum nvarchar(200)
,reqpri int

,priority int
,criticality varchar(50)
,asset_count bigint
,effective_hrs float
,effective_hours float

,reactive_maint float
,week_str varchar (100)
,month_no int
,month_name varchar (50)
,monthly_rr_per_unit float

,monthly_scrap_per_unit float
)

GO
