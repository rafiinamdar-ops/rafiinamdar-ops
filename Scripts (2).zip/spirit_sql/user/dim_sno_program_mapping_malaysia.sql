/*
Usage : This table is used to load mapping information of models and sno for Malysia location data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_sno_program_mapping_malaysia'
)


CREATE TABLE [datamart].[dim_sno_program_mapping_malaysia](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[sno] [int] NULL,
	[program] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO



