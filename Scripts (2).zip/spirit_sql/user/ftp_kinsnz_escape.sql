/*
Usage : This table is used to load escapes actual data from Kinston/SNZ 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_kinsnz_escape'
)

CREATE TABLE [staging].[ftp_kinsnz_escape](
	[date] [datetime] NULL,
	[airbus_escape_number] [nvarchar](255) NULL,
	[panel] [nvarchar](255) NULL,
	[escape_description] [nvarchar](255) NULL,
	[rcca_number] [nvarchar](255) NULL,
	[note] [nvarchar](255) NULL,
	[belongs_to] [nvarchar](255) NULL,
	[last_msn_on_which_escape_was_reported] [float] NULL,
	[escape_supplier_responsible_Y-N] [nvarchar](255) NULL,
	[count] [float] NULL,
	[3_defect_reoccurrence] [nvarchar](255) NULL,
	[containment_implemented_from_msn] [float] NULL,
	[containment_target] [float] NULL,
	[submission_target] [float] NULL,
	[closure_target] [float] NULL,
	[sari] [nvarchar](255) NULL,
	[noes] [nvarchar](255) NULL,
	[qsrs] [nvarchar](255) NULL,
	[f25] [nvarchar](255) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime] NULL CONSTRAINT [DF_ftp_kinsnz_escape_load_date]  DEFAULT (getdate()),
	[program_nm] [varchar](50) NULL
) 

GO

