USE [SQLDBA]
GO

/****** Object:  Table [dbo].[IServers]    Script Date: 11/20/2017 12:37:20 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[IDevServers](
	[Servername] [varchar](100) NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

