IF  NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'CORP\svcsqlagt')
CREATE LOGIN [CORP\svcsqlagt] FROM WINDOWS WITH DEFAULT_DATABASE=[master]
GO
USE [SQLDBA]
GO
/****** Object:  User [CORP\svcsqlagt]    Script Date: 2/17/2016 7:11:14 AM ******/
IF  EXISTS (SELECT * FROM sys.database_principals WHERE name = N'CORP\svcsqlagt')
DROP USER [CORP\svcsqlagt]
GO
/****** Object:  User [CORP\svcsqlagt]    Script Date: 2/17/2016 7:11:14 AM ******/
IF NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'CORP\svcsqlagt')
CREATE USER [CORP\svcsqlagt] FOR LOGIN [CORP\svcsqlagt] WITH DEFAULT_SCHEMA=[dbo]
GO

use [master]
GO
GRANT DELETE ON [dbo].[DBA_sysFiles] TO [CORP\svcsqlagt]
GO
use [master]
GO
GRANT INSERT ON [dbo].[DBA_sysFiles] TO [CORP\svcsqlagt]
GO
use [master]
GO
GRANT SELECT ON [dbo].[DBA_sysFiles] TO [CORP\svcsqlagt]
GO
use [master]
GO
GRANT DELETE ON [dbo].[DBA_sysDatabases] TO [CORP\svcsqlagt]
GO
use [master]
GO
GRANT INSERT ON [dbo].[DBA_sysDatabases] TO [CORP\svcsqlagt]
GO
use [master]
GO
GRANT SELECT ON [dbo].[DBA_sysDatabases] TO [CORP\svcsqlagt]
GO
USE [sqldba]
GO
IF  NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'CORP\svcsqlagt')
CREATE USER [CORP\svcsqlagt] FOR LOGIN [CORP\svcsqlagt]
GO

use [sqldba]
GO
GRANT DELETE ON [dbo].[DB_SZ_Stats] TO [CORP\svcsqlagt]
GO
use [sqldba]
GO
GRANT INSERT ON [dbo].[DB_SZ_Stats] TO [CORP\svcsqlagt]
GO
use [sqldba]
GO
GRANT SELECT ON [dbo].[DB_SZ_Stats] TO [CORP\svcsqlagt]
GO
use [sqldba]
GO
GRANT DELETE ON [dbo].[SVR_INFO] TO [CORP\svcsqlagt]
GO
use [sqldba]
GO
GRANT INSERT ON [dbo].[SVR_INFO] TO [CORP\svcsqlagt]
GO
use [sqldba]
GO
GRANT SELECT ON [dbo].[SVR_INFO] TO [CORP\svcsqlagt]
GO

USE [master]
GO
IF  NOT EXISTS (SELECT * FROM sys.database_principals WHERE name = N'CORP\svcsqlagt')
CREATE USER [CORP\svcsqlagt] FOR LOGIN [CORP\svcsqlagt]
GO
use [master]
GO
GRANT VIEW ANY DATABASE TO [CORP\svcsqlagt]
GO
