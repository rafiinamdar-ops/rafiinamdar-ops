DECLARE @xml NVARCHAR(MAX)
DECLARE @body NVARCHAR(MAX)
DECLARE @Sub NVARCHAR(300)


--Session 164 blocking for 5524 seconds, since 1/21/2019 3:11:06 PM (UTC). on sql-ent-35
select spid, blocked from master..sysprocesses where blocked <> 0 and  db_name(dbid)='scat' and waittime > 60000 and spid
  in (select blocked from master..sysprocesses where db_name(dbid)='scat')

IF @@ROWCouNT>= 1

BEGIN

SET @Sub='The Blocking found on SCAT Database - Server : '+(SELECT @@ServerName)
SET @xml=CAST((select db_name(p.dbid) As 'td','', p.spid as 'td','', p.blocked as 'td','',t.text as 'td','', 
CAST((p.waittime/1000) as Varchar) as 'td','', p.lastwaittype  as 'td','', cast(p.login_time as varchar)  as 'td','', cast(p.last_batch as varchar)  as 'td','',
 p.hostname as 'td','', p.program_name as 'td','', p.loginame as 'td'
from master..sysprocesses p 
CROSS APPLY sys.dm_exec_sql_text(p.sql_handle) AS t
where blocked <> 0 and  db_name(p.dbid)='scat' and waittime > 60000 or spid in (select blocked from master..sysprocesses where db_name(p.dbid)='scat')
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

select @xml 

SET @body ='<html><body><H3>The Blocking Details below</H3>
<table border = 1> 
<tr>
<th> DB Name </th> <th> SPID </th> <th> Blocked </th><th width="100%"> Text </th><th> Waittime-Sec </th><th> lastwaittype </th><th> login_time </th><th> last_batch </th>
<th> hostname </th>
<th> program_name </th>
<th> loginame </th>
</tr>'    
 
SET @body = @body + @xml +'</table></body></html>'

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'svcsql', -- replace with your SQL Database Mail Profile 
@body = @body,
@body_format ='HTML',
@recipients = 'mahammadrafik.inamdar@dxc.com', -- replace with your email address
--@copy_recipients = 'DL-SQLServerDBAs@spiritaero.com;spiritdxcnensql@dxc.com',
@subject = @sub ;

END