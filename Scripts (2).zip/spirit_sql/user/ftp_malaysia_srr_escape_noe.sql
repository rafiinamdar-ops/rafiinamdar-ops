/*
Usage : This table is used to load unstructured data for ceo metric actuals from Malaysia location 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_malaysia_srr_escape_noe'
)

CREATE TABLE [staging].[ftp_malaysia_srr_escape_noe](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[previousyear_YE] [money] NULL,
	[currentyear_targets] [money] NULL,
	[variance_targets] [money] NULL,
	[weekly_plan] [money] NULL,
	[weekly_actual] [money] NULL,
	[variance_weekly] [money] NULL,
	[ytd_plan] [money] NULL,
	[ytd_actual] [money] NULL,
	[variance_ytd] [money] NULL,
	[spirit_week] [nvarchar](50) NULL,
	[program] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO



