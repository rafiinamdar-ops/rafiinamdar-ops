/*
Usage : This table is used to load Malaysia SRR,Escapes and NOE data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_malaysia_ceo_metrics_master'
)

CREATE TABLE [datamart].[fact_malaysia_ceo_metrics_master](
	[load_date] [datetime] NULL DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[spirit_year] [int] NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[metric_value] [float] NULL,
	[attribute] [varchar](50) NULL,
	[defect_qty] [int] NULL
) 

GO




