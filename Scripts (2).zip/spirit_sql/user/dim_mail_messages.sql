/*
Usage : To store list of input files and mail recipients/biz users

Creator/Editor #Date #Comments
Praveen C # 2017-11-20 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_mail_messages'
)
CREATE Table datamart.dim_mail_messages
(
file_code varchar(100) Not NULL,
file_name varchar(100) NOT NULL,
file_location varchar(500) NOT NULL,
file_description varchar(100) NOT NULL ,
msg_subject varchar(100) NOT NULL,
msg_unavailable varchar(max) NOT NULL,
mailgroup_user varchar(max) NOT NULL,
mailgroup_dev varchar(max) NOT NULL,
frequency varchar(10) NOT NULL,
constraint pk_dim_mail_messages primary key clustered (file_code asc)
)
GO
