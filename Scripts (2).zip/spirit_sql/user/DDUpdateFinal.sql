USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_BackupDD]    Script Date: 8/30/2017 12:17:02 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




USE [sqldba]
GO
------DD Backup user------
INSERT [dbo].[VARIABLE] ([VarName], [VarValue]) VALUES (N'DDBackupUser', N'dbauser')
GO
-----------------DD Devive Path-----------------------------------
INSERT [dbo].[VARIABLE] ([VarName], [VarValue]) VALUES (N'DDDevicePath', N'/MSSQL')
GO

------------Give stripe value 0 for sql server 2005 and 5 for higher version--------
INSERT [dbo].[VARIABLE] ([VarName], [VarValue]) VALUES (N'StripesValue', N'5')
GO










ALTER PROCEDURE [dbo].[proc_BackupDD] @sBackupType varchar(5) = '', @sdbname nvarchar(128) = '' 
as
/* Procedure to back up transaction log. Expects:                           */
/* 	@sBackupType  --> Type of backup, db, diff, or tlog	                    */
/*  @sdbname      --> Name of database to backup   	                        */
/* Written by: 		Clint Richardson (copied from prod_Backup)              */ 					                        
/* Date Written:	02/02/2015												*/	
/* Modified by : Mahammadrafik Inamdar										*/
/* Date of Modification:5/24/2017													*/
/* Revision Log	: To dynamically suppy values from sqldba..variable table for data domain tree 
/*                Makes uniform procedure for 	both ITAR and nonITAR SQL Servers
Included stats update before  full and differential backup */			                                            */

declare @return_line varchar(1000) 
declare @ErrOccurred bit
declare @iError int
declare @db_backup_finish_date datetime
declare @rc int
declare @sOption as varchar(50)
declare @sql as nvarchar(2000)
declare @cmd as varchar(2000)
declare @Retention as int
declare @dbbackupmode varchar(10)
declare @lastbackupmode varchar(10)
declare @dbcreatedate datetime
declare @bksize as bigint
declare @StripeValue as varchar(2)
SET @StripeValue='0'
declare @saveerror int 
declare @orecipients nvarchar(max)
Set @orecipients = 'Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;Spirit_HP_NEN_SQL@groups.ext.hpe.com;SQLServerDBAs@spiritaero.com' 
declare @msgtext nvarchar(max)
declare @osubject nvarchar(255) 
declare @Emsgtext nvarchar(max)
declare @Eosubject nvarchar(255)
declare @goodbackup as int
declare @linectr as int 
declare @current_datetime datetime  
declare @DDserver varchar(50) 
declare @DDBackupServer varchar(1000) 
declare @DDDomain     varchar(50)
declare @DDBackupDays varchar(10)
declare @DDBackupDaysN int 
declare @DDbackuptype varchar(10)
declare @DDbackuptypO varchar(10)  
declare @DDretention  varchar(25) 
declare @DDdbname     varchar(150) 
declare @DDname       varchar(500) 
declare @DDdesc       varchar(500) 
declare @DDfullparm   varchar(2000) 
declare @DDaparm1     varchar(50)
Set @DDaparm1='NSR_DFA_SI=TRUE'
declare @DDaparm2     varchar(50)
Set @DDaparm2= 'NSR_DFA_SI_USE_DD=TRUE'
declare @DDaparm3     varchar(1050)  
declare @DDaparm3base varchar(25)
Set @DDaparm3base = 'NSR_DFA_SI_DD_HOST='
declare @DDaparm4     varchar(50) 
Set @DDaparm4= 'NSR_DFA_SI_DD_USER='+(select VarValue from SQLDBA.dbo.Variable where VarName = 'DDBackupUser')
declare @DDaparm5     varchar(50)   
Set @DDaparm5 = 'NSR_DFA_SI_DEVICE_PATH='+(select VarValue from SQLDBA.dbo.Variable where VarName = 'DDDevicePath')
declare @DDBackupmsg  varchar(200) 
declare @save_log_lsn numeric(25)
set @dbbackupmode = (select recovery_model_desc from sys.databases where name = @sdbname)
	if  @dbbackupmode = 'SIMPLE' and @sBackupType='diff'
	  begin
		print 'database ' + @sdbname + ' set to SIMPLE recovery. Changing backup type to Full for diff '
		set @sBackupType = 'db'
		--goto RestartBackup
		 end
		 Else if  @dbbackupmode = 'SIMPLE' and @sBackupType='tlog'
	  begin
		print 'database ' + @sdbname + ' set to SIMPLE recovery. Changing backup type to Diff for tlog '
		set @sBackupType = 'diff'
		--goto RestartBackup
		 end

	  	set @save_log_lsn = NULL 
	set @save_log_lsn = (select last_log_backup_lsn 
	                       from [master].[sys].[database_recovery_status]
						   where DB_NAME(database_id) = @sdbName
						)	
    if @save_log_lsn is NULL and @dbbackupmode <>'SIMPLE'     /* If so, change backup type to 'db' and restart */
		Begin
			print 'Changing backup type to db due to trunc. log on chkpt. being set...'
			set @sBackupType = 'db'
		END
DECLARE @cmd_output_tbl table (output varchar(1000))  
DECLARE READ_OUTPUT_CURSOR CURSOR for 
  select output from @cmd_output_tbl 

set @current_datetime = getdate() 

if @sBackupType not in ('db','tlog','diff') 
	or len(@sdbname)     = 0 
	or len(@sBackupType) = 0	
	BEGIN
		print '
/* Procedure to back up transaction log. Expects:                               */
/* 		@sBackupType  --> Type of backup db, diff, or tlog	        	        */
/*      @sdbname      --> Name of database to backup   	                        */ 
/*                                                                              */'
		goto ExitBackup
	END
	
set @ErrOccurred = 0

    
RestartBackup:
/* Build Data Domain parameters */

IF ((SELECT SERVERPROPERTY ('InstanceName')) is NULL)
set @DDdbname = 'MSSQL:' + @sdbname 
ELSE
set @DDdbname = 'MSSQL$'+CAST((SELECT SERVERPROPERTY ('InstanceName'))As varchar)+':' + @sdbname 

IF  (@sBackupType='tlog') and (SELECT DATABASEPROPERTYEX(@sdbname, 'Updateability')) = ('READ_ONLY')
set @DDbackuptype= 'diff'
ELSE
set @DDbackuptype = case 
                      when @sBackupType = 'db'   then 'full'
                      when @sBackupType = 'diff' then 'diff' 
                      when @sBackupType = 'tlog' then 'incr' 
                      else 'badtype' 
                    end 


set @DDname =  @@servername + '.' + @sdbname + '.' + upper(@DDbackuptype) 
print 'DDbackuptype = ' + @DDbackuptype 
set @DDdesc = upper(@DDbackuptype) + ' backup taken on ' + convert(varchar(20), GETDATE(), 20) 
print 'DDdesc = ' + @DDdesc 
set @DDbackuptypO = @DDbackuptype


  
set @DDBackupmsg = 'Backing up of ' + @sdbname + ' succeeded' 
set @osubject = 'UNSUCCESSFUL DATA DOMAIN BACKUP on server ' + @@SERVERNAME + ' for DB ' + @sdbname
set @msgtext = 'No successful backup message found for ' + '
    ' + 'Database = ' + @sdbname + '
    ' + 'Server = ' + @@SERVERNAME + '
    ' + 'Backup type = ' + @DDBackuptypO + '
    ' + 'Backup start = ' + CONVERT(varchar, @current_datetime, 120)
 
set @DDDomain = (select VarValue from SQLDBA.dbo.Variable where VarName = 'DDDomain')
if @DDDomain is NULL 
  BEGIN 
    set @msgtext = @msgtext + '
        ' + 'Missing Data Domain Server Domain value in sysdba VARIABLE table -- cannot continue '  
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitBackup;
  END  
    
set @DDserver =  CAST((SELECT SERVERPROPERTY('MachineName')) AS VARCHAR) + '.' + @DDDomain 
print 'DDserver = ' + @DDserver

set @DDBackupDays = (select VarValue from SQLDBA.dbo.Variable where VarName = 'DDBackupRetention')
if @DDBackupDays is NULL 
  BEGIN 
    set @msgtext = @msgtext + '
        ' + 'Missing Data Domain Server Backup Retention Days value in sysdba VARIABLE table -- cannot continue '  
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitBackup;
  END   
print 'DDBackupDays = ' + @DDBackupDays 
set @DDBackupDaysN = CONVERT(INT, @DDBackupDays)   
print 'DDBackupDaysN = ' + CAST(@DDBackupDaysN as varchar(4)) 

set @DDretention = convert(varchar(10),(getdate() + @DDBackupDaysN), 101) + ' 23:59:59' 
print 'DDretention = ' + @DDretention

set @DDBackupServer = (select VarValue from SQLDBA.dbo.Variable where VarName = 'DDBackupServer')
if @DDBackupServer is NULL 
  BEGIN 
    set @msgtext = @msgtext + '
        ' + 'Missing Data Domain Server value in sysdba VARIABLE table -- cannot continue '  
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitBackup;
  END 
set @DDaparm3 = @DDaparm3base + @DDBackupServer    

SET @bksize=(SELECT TOP 1
						CAST(s.backup_size / 1000000 AS bigINT)
						FROM msdb.dbo.backupset s
						INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id
						WHERE s.database_name =  @sdbname and s.[type]='D' -- Remove this line for all the database
						ORDER BY backup_start_date DESC, backup_finish_date)
			If @bksize >25000 and @sBackupType='db' and (SELECT VarValue  from sqldba ..VARIABLE where VarName ='StripesValue' )>0
					SET @StripeValue =cast((SELECT VarValue  from sqldba ..VARIABLE where VarName ='StripesValue' ) as varchar )
								
set @DDfullparm = '-q -c ' 
					+ isnull(@DDserver,'') + ' -S ' 
					+ isnull(@StripeValue,'')+ ' -l ' 
					+ isnull(@DDbackuptype,'') + ' -N "' 
					+ isnull(@DDname,'') + '" -b "' 
					+  isnull(@DDdesc,'') + '" -y "'
					+ isnull(@DDretention,'')  + '" -a "' 
					+ isnull(@DDaparm1,'')     + '" -a "' 
					+ isnull(@DDaparm2,'')     + '" -a "' 
					+ isnull(@DDaparm3,'')     + '" -a "' 
					+ isnull(@DDaparm4,'')     + '" -a "'
					+ isnull(@DDaparm5,'')     + '" "' 
					+ isnull(@DDdbname,'')     + '"' 
                  
print 'END of DD variables'      

--print @DDfullparm
/* Update Stats */
BEGIN TRY
if  (@sBackupType='db' or  @sBackupType='diff') and (SELECT DATABASEPROPERTYEX(@sdbname, 'Updateability')) <> ('READ_ONLY')
			begin
			print 'Updating Stats:'+@sdbname
				set @sql = 'use ['+@sdbname+']
					exec sp_updatestats'
				exec (@sql)
			end

END TRY
	
	BEGIN CATCH
	
	SELECT 'Beginning CATCH block';
		
	SET @Emsgtext= 'Message ID : '+((SELECT cast(ERROR_NUMBER() as varchar))+' - The Message : '+(SELECT ERROR_MESSAGE()))
	SET @Eosubject='Failed Update Stats on server ' + @@SERVERNAME + ' for DB ' + @sdbname
	EXEC msdb.dbo.sp_send_dbmail 
		 @recipients=@orecipients,
          @subject=@Eosubject, 
          @body=@Emsgtext,
          @body_format='TEXT'
	PRINT (@Emsgtext)
	SELECT 'Ending  CATCH block';
	END CATCH
	
--  Invoke Avomar Data Domain backup here 
print 'BEFORE BACKUP COMMAND ISSUED' 

print 'Data Domain backup parms=' + @DDfullparm 
    
delete from @cmd_output_tbl 
set @cmd = 'ddbmsqlsv.exe ' + @DDfullparm  /* + ' > ' + @DDFilename  */ 
print ' cmd variable = ' + @cmd 
  
print 'AFTER BACKUP COMMAND ISSUED' 
		
insert into @cmd_output_tbl  exec master..xp_cmdshell @cmd  
set @rc = (select COUNT(*)from @cmd_output_tbl) 
print 'Rows returned from backup command = ' + cast(@rc as varchar(10))  

set @rc = (select COUNT(*) from 
             (select distinct database_name, server_name, start_datetime
                FROM [sqldba].[dbo].[DDBackup_History] 
             ) as distinctquery
          ) 
print '# distinct backups rows = ' + cast(@rc as varchar(10))

if @rc > 1
  BEGIN 
    delete from [dbo].[DDBackup_History]  
      where database_name = @sdbname
        and server_name = @@servername
        and start_datetime < (GETDATE() - 60) 
  END 
  
set @goodbackup = 0 
set @linectr = 0 

open READ_OUTPUT_CURSOR
fetch next from READ_OUTPUT_CURSOR into @return_line 
while @@FETCH_STATUS = 0 
  BEGIN 
 --   print 'Next return line = ' + @return_line 
    if CHARINDEX(@DDBackupmsg, @return_line, 1)  > 0 
      BEGIN 
        set @goodbackup = 1        
      END 
    set @linectr = @linectr + 1
    SET NOCOUNT ON
    insert into [dbo].[DDBackup_History] 
           values (@sdbname, @@SERVERNAME, @current_datetime, @DDBackuptypO, @linectr, @return_line) 
    SET NOCOUNT OFF 
    set @saveerror = @@ERROR
    if @saveerror <> 0 
      BEGIN         
        set @msgtext = @msgtext + '
        ' + 'Bad insert to Backup_History table, error = ' + cast(@saveerror as varchar(10))
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'
        CLOSE READ_OUTPUT_CURSOR
        DEALLOCATE READ_OUTPUT_CURSOR
        goto ExitBackup;               
      END  
    fetch next from READ_OUTPUT_CURSOR into @return_line 
  END 
  
print 'good backup flag = ' + cast(@goodbackup as varchar(2)) 
if @goodbackup = 0 
  BEGIN
    set @msgtext = @msgtext + '    
    ' + '--> Check Backup_History table in sqldba database for detailed output <--'   
    EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
      @subject=@osubject, 
      @body=@msgtext,
      @body_format='TEXT' 
  END  
      
CLOSE READ_OUTPUT_CURSOR
DEALLOCATE READ_OUTPUT_CURSOR     

ExitBackup:
--drop table #t_options

























GO


