USE [master]
GO

/****** Object:  StoredProcedure [dbo].[proc_loginCreation]    Script Date: 5/5/2019 7:41:12 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[proc_loginCreation] @login_name varchar(100), @login_commond varchar(500),@user nvarchar(max)
AS
IF NOT EXISTS(select  name from master.sys.server_principals where name=@login_name )
BEGIN;
DECLARE @mailSubject Nvarchar(100);
DECLARE @mailBody Nvarchar(MAX);
DISABLE TRIGGER [ddl_trig_CreateLogin] ON ALL Server
EXEC (@login_commond);
  ---- Set the email data
   SET @mailSubject = 'New SQL Login Created On: ' + @@SERVERNAME;
   SET @mailBody = '<font color="black">A new login <b>['+@login_name+']</b> Was created on SQL Server: <b>'  + @@SERVERNAME + '
   </b>' +   
               ' At: <b>' + CONVERT(nvarchar, getdate(), 120) + '
</b>' +  
               'By user: <b>' + ISNULL(@user, 'Null Login' ) + '
</b>' ;
      --Send the mail
   EXEC msdb.dbo.sp_send_dbmail
      @recipients=N'SQLServerDBAs@spiritaero.com;spiritdxcnensqlnonitar@dxc.com',
      @subject=@mailSubject,
      @body = @mailBody,
      @body_format = HTML;

ENABLE TRIGGER [ddl_trig_CreateLogin] ON ALL Server
END;

GO


