IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_fab_planned_hours'
)
CREATE TABLE [datamart].[fact_fab_planned_hours](
	[rpt_week_end_dt] [date] NULL,
	[category] [varchar](30) NULL,
	[sub_category] [varchar](30) NULL,
	[wkl_stdhrs_ex_pln] [float] NULL,
	[adj_actual_spl_hrs] [float] NULL,
	[adj_cycle_hrs] [float] NULL,
	[adj_int_rwrk_hrs] [float] NULL,
	[adj_ext_rwrk_hrs] [float] NULL,
	[adj_vendor_assist_hrs] [float] NULL,
	[adj_behind_sch_hrs] [float] NULL,
	[adj_third_party_hrs] [float] NULL,
	[last_updt_dt] [datetime] NULL DEFAULT (getdate())
)
GO
SET ANSI_PADDING OFF
GO