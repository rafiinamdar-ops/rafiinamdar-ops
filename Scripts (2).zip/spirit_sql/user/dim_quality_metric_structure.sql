/*
Usage : This table is used to load structure of weekly program metrics
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-11-09	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_quality_metric_structure'
)

CREATE TABLE [datamart].[dim_quality_metric_structure](
	[sno] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[business_unit] [varchar](50) NULL,
	[header] [varchar](50) NULL,
	[load_date] [datetime] NULL DEFAULT (getdate())
) 

GO

