raiserror('Obsolete file odsole.sql.  Please remove use.',0,1)
go
