delete sqldba.dbo.DiskSpaceCheck
go
BULK INSERT sqldba.dbo.DiskSpaceCheck
   FROM 'F:\DiskSpaceCheck\SPSDBHealth1.txt'
   WITH 
      (
         FIELDTERMINATOR ='|',
         ROWTERMINATOR ='\n'
      )
      if exists (SELECT * FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'[tempdb]..[##temp]') AND type in (N'U'))
      drop table ##temp 
      
      CREATE TABLE ##Temp(
      RowId int identity(1,1),
	[Drive] [varchar](10) NOT NULL,
	[Label] [varchar](15) NOT NULL,
	[FreePercent] [varchar](8) NOT NULL,
	[FreeSpace] [varchar](8) NOT NULL,
	[UsedSpace] [varchar](8) NOT NULL,
	[TotalSpace] [varchar](8) NOT NULL) 
	
	insert into ##temp SELECT  [Drive],[Label],[FreePercent],[FreeSpace],[UsedSpace],[TotalSpace]
							FROM [sqldba].[dbo].[DiskSpaceCheck]
DECLARE @Loop int
		DECLARE @Subject varchar(100)
		DECLARE @strMsg varchar(4000)
		Declare @RCPT VARCHAR(500)
		DECLARE @EMAIL varchar(5000)
 
		---SELECT @Subject = 'SQL Monitor Disk Free Space Alert: ' + @@servername
		SET @RCPT ='Spirit_HP_NEN_SQL_nonITAR@external.groups.hp.com;SQLServerDBAs@spiritaero.com'
 
		SELECT @Loop = min(RowID)
		FROM ##Temp 
		WHERE cast(FreePercent as decimal(20,2))  <= 15
 
		WHILE @Loop IS NOT NULL
		BEGIN
 
			SELECT 	@strMsg =  convert(char(10),'Drive:') + isnull(Drive, 'Unknown') +CHAR(10)+
					convert(char(10),'') + convert(varchar, convert(decimal(20,2), FreePercent)) + '% free space remaining.'+ char(10)  + CHAR(10) +
					 convert(char(12),'FreeSpace:') + isnull(ltrim(rtrim(FreeSpace)), 'Unknown') + char(10)  +CHAR(10)+
					  convert(char(12),'UsedSpace:') + isnull(ltrim(rtrim(UsedSpace)), 'Unknown') + char(10)  +CHAR(10)+
					  convert(char(12),'TotalSpace:') + isnull(ltrim(rtrim(TotalSpace)), 'Unknown') + char(10)  +CHAR(10)+
					 
					convert(char(15),'') + char(10) +
					convert(char(15),'EventTime:') + convert(varchar, getdate())
			FROM ##Temp 
			WHERE RowID = @Loop
 
			SET @EMAIL = 'msdb.dbo.sp_send_dbmail
   @recipients = ''' + @RCPT + ''',
   @body = ''' + @strMSG + ''',
   @subject = '' LOW FREE DISK SPACE ON ' + @@SERVERNAME + ' !!'''
 EXEC (@EMAIL)
  
			SELECT @Loop = min(RowID)
			FROM ##temp
			WHERE cast(FreePercent as decimal(20,2)) <= 15 and RowID > @Loop
			
 
		END
