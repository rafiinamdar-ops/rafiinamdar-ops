/*
Usage : This table is used to load data which doesnot obey cleansing rules
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'bad_table'
)

CREATE TABLE [datamart].[bad_table](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[table_name] [varchar](50) NULL,
	[run_date] [datetime] NULL,
	[records] [xml] NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) 

GO





/*
Usage : This table is used to map the charge management codes used for different function
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-09	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_a350_mapping'
)


CREATE TABLE [datamart].[dim_a350_mapping](
	[sno] [int] IDENTITY(1,1) NOT NULL,
	[charge_management_code] [varchar](50) NULL,
	[program] [varchar](50) NULL,
	[function] [varchar](50) NULL,
	[load_date] [datetime] NULL DEFAULT (getdate())
) 

GO



/*
Usage : This table is used to provide the alias mapping information

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_alias_mapping'
)

CREATE TABLE datamart.dim_alias_mapping
(
	alias_name varchar(100),
	actual_name varchar(100),
	category varchar(100),
	pk_id int IDENTITY(1,1),
	
 CONSTRAINT uk_alias_name_category UNIQUE NONCLUSTERED 
(
	alias_name ASC,
	category ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO




/*
Usage : To find spirit year & spirit week 

Creator/Editor #Date #Comments
Pratheesh N # 2017-06-01 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_calendar'
)

CREATE TABLE datamart.dim_calendar
(
date_key date not null
,spirit_year int not null
,calendar_year int not null
,fin_year varchar(20) not null
,qtr int not null

,mnth int not null
,mnth_name varchar(20) not null
,spirit_week int not null
,calendar_week int not null
,budget_month_end datetime null

,spirit_mnth int
,spirit_mnth_name varchar(20)
,modified_by varchar(30) not null
,modified_date datetime  default (getdate())
,is_holiday tinyint default (0)

,is_current_week tinyint default(0)

constraint pk__dim_calendar primary key clustered 
(
date_key asc
)with (pad_index = off, statistics_norecompute = off, ignore_dup_key = off, allow_row_locks = on, allow_page_locks = on) 
) 

GO

	/*
Usage :It is a mapping table to read dynamically changing Genpact DT Labour & Safety excel file

Creator/Editor #Date #Comments
Pratheesh N # 2017-10-12 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_cellrange_dynamic_excel_cols'
)

CREATE TABLE datamart.dim_cellrange_dynamic_excel_cols
(
filename varchar(100) not null
,sheet_name varchar(100) not null
,week_no int not null
,cellrange varchar(50) not null
,srno int not null unique
,location varchar(100)
,querystr varchar(500) 
) 

GO

/*
Usage : This table is used to load mapping data for charge management code and function for Quality
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_charge_management_code_function'
)

CREATE TABLE [datamart].[dim_charge_management_code_function](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[management_code] [varchar](50) NULL,
	[description] [varchar](50) NULL,
	[org] [varchar](50) NULL,
	[organization] [varchar](50) NULL,
	[functions] [varchar](50) NULL,
	[QA_Support] [varchar](50) NULL,
	[site] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)

GO




/*
Usage : This table is used to load cleansing rules
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_cleansing_rule'
)

CREATE TABLE [datamart].[dim_cleansing_rule](
	[table_name] [varchar](50) NULL,
	[column_name] [varchar](50) NULL,
	[column_value] [varchar](50) NULL,
	[operation] [varchar](50) NULL
) 


GO
/*
Usage : This table is used to populate the categorized data For  headcount metric for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_cost_center_businessunit_mapping'
)

CREATE TABLE datamart.dim_cost_center_businessunit_mapping
(
	cost_center nvarchar(100) ,
	business_unit nvarchar(500) ,
	location varchar(50) ,
	
PRIMARY KEY CLUSTERED 
(
	cost_center ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


/*
Usage : To find downtime target for facilities

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-04 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_downtime_target'
)

CREATE TABLE datamart.dim_downtime_target
(
spirit_year int
,location varchar(100)
,business_unit varchar(100)
,asset_priority int
,total_downtime_previous_year float

,improvement_pcg float
,downtime_target float
)

GO

/*
Usage : This table is used to load mapping information for greenline costs 
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-01-17	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_dynamic_cellrange_greenlinecosts'
)


CREATE TABLE [datamart].[dim_dynamic_cellrange_greenlinecosts](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[filename] [varchar](100) NULL,
	[sheetname] [varchar](100) NULL,
	[yr] [int] NULL,
	[value_chain] [varchar](50) NULL,
	[querystr] [varchar](500) NULL,
	[created_date] [datetime] NOT NULL DEFAULT (getdate())
)
GO
/*
Usage : This table is used to load escape targets data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_escape_target'
)


CREATE TABLE [datamart].[dim_escape_target](
	[model] [varchar](255) NULL,
	[function] [varchar](255) NULL,
	[year] [int] NOT NULL,
	[date_written] [date] NULL,
	[week_no] [int] NULL,
	[weekly_escape_target] [float] NULL,
	[ytd_escape_target] [float] NULL,
	[createddate] [datetime] NULL,
	[modifieddate] [datetime] NULL CONSTRAINT [DF__fact_esca__modif__25518C17]  DEFAULT (getdate()),
	[modifiedby] [varchar](30) NULL CONSTRAINT [DF__fact_esca__modif__2645B050]  DEFAULT (suser_sname()),
	[heading] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[location] [varchar](50) NULL
) 


GO



/*
Usage : This table is used to load list of locations and codes
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_location'
)

CREATE TABLE [datamart].[dim_location](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[code] [int] NOT NULL,
	[location_name] [varchar](50) NULL,
	[created_by] [varchar](30) NULL,
	[created_date] [datetime] NOT NULL,
	[modified_by] [varchar](30) NULL,
	[modified_date] [datetime] NOT NULL CONSTRAINT [DF_dim_location_modified_date]  DEFAULT (getdate()),
 CONSTRAINT [PK__dim_loca__1543595ED7AE298F] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


/*
Usage : To store list of input files and mail recipients/biz users

Creator/Editor #Date #Comments
Praveen C # 2017-11-20 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_mail_messages'
)
CREATE Table datamart.dim_mail_messages
(
file_code varchar(100) Not NULL,
file_name varchar(100) NOT NULL,
file_location varchar(500) NOT NULL,
file_description varchar(100) NOT NULL ,
msg_subject varchar(100) NOT NULL,
msg_unavailable varchar(max) NOT NULL,
mailgroup_user varchar(max) NOT NULL,
mailgroup_dev varchar(max) NOT NULL,
frequency varchar(10) NOT NULL,
constraint pk_dim_mail_messages primary key clustered (file_code asc)
)
GO
/*
Usage : This table is used to load list of models/programs
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_model'
)

CREATE TABLE [datamart].[dim_model](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](50) NULL,
	[created_by] [varchar](30) NULL,
	[created_date] [datetime] NOT NULL,
	[modified_by] [varchar](30) NULL,
	[modified_date] [datetime] NOT NULL CONSTRAINT [DF_dim_model_modified_date]  DEFAULT (getdate()),
 CONSTRAINT [PK__dim_mode__1543595E02D37D3F] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)

GO


/*
Usage : This table is used to load structure of weekly program metrics
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-11-09	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_quality_metric_structure'
)

CREATE TABLE [datamart].[dim_quality_metric_structure](
	[sno] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[business_unit] [varchar](50) NULL,
	[header] [varchar](50) NULL,
	[load_date] [datetime] NULL DEFAULT (getdate())
) 

GO

/*
Usage : This table is used to load the chargemanagement mapping with function for weekly program metrics
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_quality_prg_metrics_mapping'
)

CREATE TABLE [datamart].[dim_quality_prg_metrics_mapping](
	[sno] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[function] [varchar](50) NULL,
	[mgcode_like] [varchar](50) NULL,
	[mgcode_notlike] [varchar](50) NULL,
	[business_unit] [varchar](50) NULL
) 

GO




/*
Usage : This datamart table is used to populate the data for quality attribute for scrap reduction target

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_scrap_rr_reduction_target'
)
CREATE TABLE datamart.dim_scrap_rr_reduction_target
(
	scrap_amount_target_per_unit float,
	rr_amount_target_per_unit float,
	scrap_amount_target_pcg float,
	rr_amount_target_pcg float,
	location nvarchar(255),
	
	Spirit_year float,
	program nvarchar(255) 
) 

GO


/*
Usage : This table is used to load mapping information of models and sno for Malysia location data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_sno_program_mapping_malaysia'
)


CREATE TABLE [datamart].[dim_sno_program_mapping_malaysia](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[sno] [int] NULL,
	[program] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO



/*
Usage : This table is used to load mapping information of models and sno for Prastwick locatio ceo data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_sno_program_mapping_prestwick'
)


CREATE TABLE [datamart].[dim_sno_program_mapping_prestwick](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[sno] [int] NULL,
	[program] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) 

GO


/*
Usage : This table is used to load srr target data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_srr_target'
)

CREATE TABLE [datamart].[dim_srr_target](
	[model] [varchar](255) NULL,
	[function] [varchar](255) NULL,
	[year] [int] NOT NULL,
	[date_written] [date] NULL,
	[week_no] [int] NULL,
	[weekly_srr_target] [float] NULL,
	[ytd_srr_target] [float] NULL,
	[weekly_gl_target] [float] NULL,
	[ytd_gl_target] [float] NULL,
	[createddate] [datetime] NULL,
	[modifieddate] [datetime] NULL CONSTRAINT [DF__fact_srr___modif__282DF8C2]  DEFAULT (getdate()),
	[modifiedby] [varchar](30) NULL CONSTRAINT [DF__fact_srr___modif__29221CFB]  DEFAULT (suser_sname()),
	[heading] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[location] [varchar](50) NULL
) 

GO
/*
Usage : To find standard abs % for facilities (headcount)

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-07 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_standard_abs_pcg'
)

CREATE TABLE datamart.dim_standard_abs_pcg
(
spirit_year int
,location varchar(100)
,business_unit varchar(100)
,standard_abs_pcg float
)

GO

/*
Usage : This table is used to load list of valuechains
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_value_chain'
)


CREATE TABLE [datamart].[dim_value_chain](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](50) NOT NULL,
	[created_by] [varchar](30) NULL,
	[created_date] [datetime] NOT NULL,
	[modified_by] [varchar](30) NULL,
	[modified_date] [datetime] NOT NULL CONSTRAINT [DF_dim_valuechain_modified_date]  DEFAULT (getdate()),
 CONSTRAINT [PK__dim_valu__1543595E919D6E40] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)

GO



IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fabrication_staffing_summary'
)
CREATE TABLE reporting.fabrication_staffing_summary(
	rpt_week_end_dt date NULL,
	rpt_year int NULL,
	rpt_week int NULL,
	category varchar(30) NULL,
	sub_category varchar(30) NULL,
	flg_curr_week int NULL,
	wkl_hc_assigned_actual float NULL,
	wkl_hc_demand float NULL,
	wkl_hc_effective_actual float NULL,
	wkl_stdhrs_earned_actual float NULL,
	wkl_stdhrs_earned_planned float NULL,
	wkl_bhndsch_hrs float NULL,
	wkl_bhndsch_ucl float NULL,
	wkl_bhndsch_to_fnsh_hrs float NULL,
	wkl_bhndsch_to_fnsh_ucl float NULL,
	wkl_rlzn_pcg_actual float NULL,
	wkl_rlzn_pcg_planned float NULL,
	ytd_rlzn_pcg_actual float NULL,
	ytd_qlty_srr_touch_pcg_actual float NULL,
	ytd_qlty_srr_touch_pcg_planned float NULL,
	wkl_stfg_aop_planned float NULL,
	OT_Metrics varchar(7) NOT NULL,
	OT_Values float NULL
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fabrication_summary'
)
CREATE TABLE reporting.fabrication_summary(
	rpt_week_end_dt date NULL,
	rpt_year int NULL,
	rpt_week int NULL,
	category varchar(30) NULL,
	sub_category varchar(30) NULL,
	flg_curr_week int NULL,
	wkl_qlty_srr_actual float NULL,
	wkl_qlty_srr_planned float NULL,
	wkl_qlty_srr_variance float NULL,
	ytd_qlty_srr_actual float NULL,
	ytd_qlty_srr_planned float NULL,
	ytd_qlty_srr_variance float NULL,
	wkl_qlty_srr_touch_pcg_actual float NULL,
	wkl_qlty_srr_touch_pcg_planned float NULL,
	wkl_qlty_srr_touch_pcg_variance float NULL,
	ytd_qlty_srr_touch_pcg_actual float NULL,
	ytd_qlty_srr_touch_pcg_planned float NULL,
	ytd_qlty_srr_touch_pcg_variance float NULL,
	wkl_qlty_escap_to_assy_actual float NULL,
	wkl_qlty_escap_to_assy_planned float NULL,
	wkl_qlty_escap_to_assy_variance float NULL,
	ytd_qlty_escap_to_assy_actual float NULL,
	ytd_qlty_escap_to_assy_planned float NULL,
	ytd_qlty_escap_to_assy_variance float NULL,
	wkl_qlty_escap_to_cust_actual float NULL,
	wkl_qlty_escap_to_cust_planned float NULL,
	wkl_qlty_escap_to_cust_variance float NULL,
	ytd_qlty_escap_to_cust_actual float NULL,
	ytd_qlty_escap_to_cust_planned float NULL,
	ytd_qlty_escap_to_cust_variance float NULL,
	wkl_rlzn_pcg_actual float NULL,
	wkl_rlzn_pcg_planned float NULL,
	wkl_rlzn_pcg_variance float NULL,
	ytd_rlzn_pcg_actual float NULL,
	ytd_rlzn_pcg_planned float NULL,
	ytd_rlzn_pcg_variance float NULL,
	wkl_stdhrs_earned_actual float NULL,
	wkl_stdhrs_earned_planned float NULL,
	wkl_stdhrs_earned_variance float NULL,
	ytd_stdhrs_earned_actual float NULL,
	ytd_stdhrs_earned_planned float NULL,
	ytd_stdhrs_earned_variance float NULL,
	wkl_dlvry_kfr_pcg_actual float NULL,
	wkl_dlvry_kfr_pcg_planned float NULL,
	wkl_dlvry_kfr_pcg_variance float NULL,
	ytd_dlvry_kfr_pcg_actual float NULL,
	ytd_dlvry_kfr_pcg_planned float NULL,
	ytd_dlvry_kfr_pcg_variance float NULL,
	wkl_ot_pcg_actual float NULL,
	wkl_ot_pcg_planned float NULL,
	wkl_ot_pcg_variance float NULL,
	ytd_ot_pcg_actual float NULL,
	ytd_ot_pcg_variance float NULL,
	aop_ot_pcg float NULL,
	wkl_hc_assigned_actual float NULL,
	wkl_hc_assigned_planned float NULL,
	wkl_hc_assigned_variance float NULL,
	ytd_hc_assigned_actual float NULL,
	ytd_hc_assigned_planned float NULL,
	ytd_hc_assigned_variance float NULL,
	wkl_hc_doi_pcg_actual float NULL,
	wkl_hc_doi_pcg_planned float NULL,
	wkl_hc_doi_pcg_variance float NULL,
	ytd_hc_doi_pcg_actual float NULL,
	ytd_hc_doi_pcg_planned float NULL,
	ytd_hc_doi_pcg_variance float NULL,
	hc_std_abs_pcg float NULL,
	wkl_hc_abs_pcg_actual float NULL,
	wkl_hc_abs_pcg_variance float NULL,
	ytd_hc_abs_pcg_actual float NULL,
	ytd_hc_abs_pcg_variance float NULL,
	wkl_bhndsch_hrs float NULL,
	wkl_bhndsch_ucl float NULL,
	wkl_bhndsch_to_fnsh_hrs float NULL,
	wkl_bhndsch_to_fnsh_ucl float NULL,
	wkl_hc_effective_actual float NULL,
	wkl_hc_demand float NULL,
	wkl_hc_eff_vs_demand_variance float NULL,
	ytd_hc_effective_actual float NULL,
	ytd_hc_demand float NULL,
	ytd_hc_eff_vs_demand_variance float NULL,
	wkl_stfg_aop_planned float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

/*
Usage : This table is used to populate the data for summary dashboard graph for facility for all metrics

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'facility_summary'
)

CREATE TABLE reporting.facility_summary
(
spirit_year int
,spirit_week int
,date_written date
,program nvarchar(100)
,location nvarchar(100)

,rr_amount_actual float
,rr_amount_target float
,scrap_amount_actual float
,scrap_amount_target float
,manpower_available float

,manpower_clocked float
,downtime_actual float
,downtime_target float
,headcount_actuals float
,attribute varchar(100)

,value_chain nvarchar(200)
,manpower_clocked_noa float
,abs_std_pcg float
,actual_over_time_hours float
,actual_regular_hours float

,forecast_regular_hours float
,forecast_over_time_hours float
,business_unit nvarchar(200)
,total_abs_hours float
,std_hours_per_week float

,unit float
,planned_maint float
,target_maint float
,rr_reduction_target_pcg float
,scrap_reduction_target_pcg float

,laborcost float
,matlcost float
,nonstockcost float
,assetnum nvarchar(200)
,reqpri int

,priority int
,criticality varchar(50)
,asset_count bigint
,effective_hrs float
,effective_hours float

,reactive_maint float
,week_str varchar (100)
,month_no int
,month_name varchar (50)
,monthly_rr_per_unit float

,monthly_scrap_per_unit float
)

GO

/*
Usage : This table is used to populate the data forr weekly program metric graph for facility 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'facility_weekly_variance'
)

CREATE TABLE reporting.facility_weekly_variance
(
	business_unit nvarchar(50),
	weekly_scrap_actual float ,
	weekly_rr_actual float ,
	scrap_target_per_unit float ,
	rr_target_per_unit float ,
	
	ytd_scrap_avg_per_unit float,
	ytd_rr_avg_per_unit float ,
	weekly_available float ,
	weekly_clocked float ,
	weekly_noa float ,
	
	ytd_noa float ,
	effective_hours float ,
	weekly_actual_pcg float ,
	weekly_planned_pcg float ,
	ytd_actual_pcg float ,
	
	planned_ot_pcg float ,
	assigned_actuals float ,
	abs_std_pcg float ,
	week_abs_pcg_actual float ,
	ytd_abs_pcg_actual float ,
	
	crit_1_3_asset bigint ,
	crit_1_3_weekly_dt_actuals_per_hrs float ,
	crit_1_3_prior_week_dt_actuals_per_hrs float ,
	crit_1_3_ytd_dt_actuals_per_hrs float ,
	crit_4_assets bigint ,
	
	crit_4_weekly_dt_actuals_per_hrs float ,
	crit_4_prior_week_dt_actuals_per_hrs float ,
	crit_4_ytd_dt_actuals_per_hrs float ,
	crit_5_assets bigint ,
	crit_5_weekly_dt_tgt_hrs float ,
	
	crit_5_weekly_dt_actuals_per_hrs float ,
	crit_5_prior_weekly_dt_actuals_per_hrs float ,
	crit_5_ytd_dt_actuals_per_hrs float ,
	spirit_week int ,
	location nvarchar(100) ,
	
	spirit_year int 
)

GO


/*
Usage : This datamart table is used to populate the data for headcount metric for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_absenteeism'
)
CREATE TABLE datamart.fact_absenteeism
(
	cost_center nvarchar(255),
	working_level nvarchar(255),
	shifts nvarchar(255),
	period nvarchar(50),
	abs_p float,
	
	abs_up float,
	abs_fmla nvarchar(255),
	countofpaycode int,
	total_abs_hours float,
	std_hours_per_week float,
	
	std_abs_pcg float,
	loaddate datetime,
	business_unit nvarchar(510),
	location nvarchar(50) 
) 

GO


/*
Usage : This datamart table is used to populate the data for top 10 asset summary dashboard

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_asset_cost'
)

CREATE TABLE datamart.fact_asset_cost
(
	wonum nvarchar(20),
	wo_description nvarchar(100),
	actfinish nvarchar(21),
	busunit nvarchar(10),
	reqpri nvarchar(10),
	
	siteid nvarchar(8),
	maintgrp nvarchar(10),
	startdate nvarchar(21),
	reportdate nvarchar(21),
	assetlocpriority float,
	
	wo_type varchar(16),
	assetnum nvarchar(25),
	labor_hrs float,
	labor_cost float,
	cause nvarchar(8),
	
	failuremark_desc nvarchar(100),
	problemcode nvarchar(8),
	wo_priority float,
	shopid nvarchar(15),
	stock_cost float,
	
	nonstock_cost float 
) 

GO



/*
Usage : This datamart table is used to populate the data for downtime attribute for assetcount

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_asset_count'
)

CREATE TABLE datamart.fact_asset_count
(
	busunit nvarchar(10),
	assetnum nvarchar(25),
	priority float,
	siteid nvarchar(8),
	isrunning float,
	
	installdate date,
	status nvarchar(20),
	statusdate nvarchar(21) 
)

GO


/*
Usage :It is used to keep cleaned data of Genpact DT Labor & Safery 

Creator/Editor #Date #Comments
Pratheesh N # 2017-10-20 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_direct_labor_safety'
)

CREATE TABLE datamart.fact_direct_labor_safety
(
sheet_name varchar(100)
,location varchar (100)
,spirit_year int not null
,spirit_week int not null

,cost_center varchar (100)
,metric_name varchar (100)
,actuals float (53)
,planned float (53)
) 

GO

/*
Usage : This datamart table is used to populate the data for downtime attribute priority wise

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_downtime_dailyclocking'
)

CREATE TABLE datamart.fact_downtime_dailyclocking
(
	assetnum nvarchar(25),
	change_date date,
	wo_num nvarchar(20),
	downtime float,
	assetdept nvarchar(12),
	
	wo_description nvarchar(158),
	location nvarchar(35),
	wo_priority float,
	busunit nvarchar(10),
	wo_status nvarchar(20),
	
	siteid nvarchar(8),
	shopid nvarchar(15),
	report_date nvarchar(21),
	actfinish nvarchar(21),
	leadcraft nvarchar(8),
	
	maintgrp nvarchar(10),
	reqpri nvarchar(10),
	amflag float,
	workorder_desc nvarchar(100),
	work_type nvarchar(5),
	
	failure_desc nvarchar(100) 
)

GO


/*
Usage : This table is used to load escapes actuals data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_escape'
)

CREATE TABLE [datamart].[fact_escape](
	[program_nm] [varchar](30) NULL,
	[value_chain_cd] [varchar](50) NULL,
	[responsible_mgmt_code] [varchar](200) NULL,
	[feature_description] [varchar](100) NULL,
	[discrepancy_description] [varchar](100) NULL,
	[feature_code] [varchar](50) NULL,
	[ca_count] [int] NULL,
	[ncr_part_no] [varchar](50) NULL,
	[ca_ser_no] [varchar](50) NULL,
	[sum_ncr_cost_amt] [float] NULL,
	[discrepancy_code] [varchar](50) NULL,
	[unit_no] [float] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL CONSTRAINT [DF__fact_esca__modif__7D439ABD]  DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL CONSTRAINT [DF__fact_esca__modif__7E37BEF6]  DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL
)

GO




/*
Usage : This table is used to load escape data from kinston and SNZ locations
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_escape_kinsnz'
)

CREATE TABLE [datamart].[fact_escape_kinsnz](
	[program_nm] [varchar](30) NULL,
	[value_chain_cd] [varchar](50) NULL,
	[feature_description] [varchar](100) NULL,
	[ca_count] [int] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL
) 

GO


/*
Usage : This table is used to load escapes from Prestwick
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_escape_prestwick'
)

CREATE TABLE [datamart].[fact_escape_prestwick](
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[ca_count] [int] NULL,
	[date_written] [date] NULL,
	[escape_amount_actual] [float] NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](255) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime] NOT NULL,
	[feature_descrepancy] [varchar](300) NULL,
	[modified_by] [varchar](50) NULL DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL DEFAULT (getdate()),
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL
) 

GO



IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_fab_planned_hours'
)
CREATE TABLE [datamart].[fact_fab_planned_hours](
	[rpt_week_end_dt] [date] NULL,
	[category] [varchar](30) NULL,
	[sub_category] [varchar](30) NULL,
	[wkl_stdhrs_ex_pln] [float] NULL,
	[adj_actual_spl_hrs] [float] NULL,
	[adj_cycle_hrs] [float] NULL,
	[adj_int_rwrk_hrs] [float] NULL,
	[adj_ext_rwrk_hrs] [float] NULL,
	[adj_vendor_assist_hrs] [float] NULL,
	[adj_behind_sch_hrs] [float] NULL,
	[adj_third_party_hrs] [float] NULL,
	[last_updt_dt] [datetime] NULL DEFAULT (getdate())
)
GO


IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_fab_srr_escapes'
)

CREATE TABLE datamart.fact_fab_srr_escapes(
	rpt_week_end_dt date NULL,
	category varchar(30) NULL,
	sub_category varchar(30) NULL,
	wkl_qlty_srr_act float NULL,
	wkl_qlty_srr_pln float NULL,
	ytd_qlty_srr_act float NULL,
	ytd_qlty_srr_pln float NULL,
	wkl_qlty_esc_assy_act float NULL,
	wkl_qlty_esc_assy_pln float NULL,
	ytd_qlty_esc_assy_act float NULL,
	ytd_qlty_esc_assy_pln float NULL,
	wkl_qlty_esc_cust_act float NULL,
	wkl_qlty_esc_cust_pln float NULL,
	ytd_qlty_esc_cust_act float NULL,
	ytd_qlty_esc_cust_pln float NULL,
	last_updt_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_fab_standard_hours'
)

CREATE TABLE datamart.fact_fab_standard_hours(
	rpt_week_end_dt date NULL,
	category varchar(30) NULL,
	sub_category varchar(30) NULL,
	wkl_stdhrs_earned_actual float NULL,
	wkl_stdhrs_earned_planned float NULL,
	wkl_bhndsch_hrs float NULL,
	wkl_bhndsch_ucl float NULL,
	wkl_bhndsch_to_fnsh_hrs float NULL,
	wkl_bhndsch_to_fnsh_ucl float NULL,
	wkl_labor_hrs_actual float NULL,
	wkl_overtime_hrs_actual float NULL,
	wkl_doi_chgs_actual float NULL,
	wkl_abs_hrs float NULL,
	last_updt_dt datetime NULL CONSTRAINT DF_fact_fab_standard_hours_last_updt_dt  DEFAULT (getdate())
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_fab_summary'
)

CREATE TABLE datamart.fact_fab_summary(
	rpt_week_end_dt date NULL,
	rpt_year int NULL,
	rpt_week int NULL,
	category varchar(30) NULL,
	sub_category varchar(30) NULL,
	flg_curr_week int NULL DEFAULT ((0)),
	wkl_qlty_srr_actual float NULL,
	wkl_qlty_srr_planned float NULL,
	ytd_qlty_srr_actual float NULL,
	ytd_qlty_srr_planned float NULL,
	wkl_qlty_srr_touch_pcg_actual float NULL,
	wkl_qlty_srr_touch_pcg_planned float NULL,
	ytd_qlty_srr_touch_pcg_actual float NULL,
	ytd_qlty_srr_touch_pcg_planned float NULL,
	wkl_qlty_escap_to_assy_actual float NULL,
	wkl_qlty_escap_to_assy_planned float NULL,
	ytd_qlty_escap_to_assy_actual float NULL,
	ytd_qlty_escap_to_assy_planned float NULL,
	wkl_qlty_escap_to_cust_actual float NULL,
	wkl_qlty_escap_to_cust_planned float NULL,
	ytd_qlty_escap_to_cust_actual float NULL,
	ytd_qlty_escap_to_cust_planned float NULL,
	wkl_rlzn_pcg_actual float NULL,
	wkl_rlzn_pcg_planned float NULL,
	ytd_rlzn_pcg_actual float NULL,
	ytd_rlzn_pcg_planned float NULL,
	wkl_stdhrs_earned_actual float NULL,
	wkl_stdhrs_earned_planned float NULL,
	ytd_stdhrs_earned_actual float NULL,
	ytd_stdhrs_earned_planned float NULL,
	wkl_dlvry_kfr_pcg_actual float NULL,
	wkl_dlvry_kfr_pcg_planned float NULL,
	ytd_dlvry_kfr_pcg_actual float NULL,
	ytd_dlvry_kfr_pcg_planned float NULL,
	wkl_ot_pcg_actual float NULL,
	wkl_ot_pcg_planned float NULL,
	ytd_ot_pcg_actual float NULL,
	aop_ot_pcg float NULL,
	wkl_hc_assigned_actual float NULL,
	wkl_hc_assigned_planned float NULL,
	ytd_hc_assigned_actual float NULL,
	ytd_hc_assigned_planned float NULL,
	wkl_hc_doi_pcg_actual float NULL,
	wkl_hc_doi_pcg_planned float NULL,
	ytd_hc_doi_pcg_actual float NULL,
	ytd_hc_doi_pcg_planned float NULL,
	hc_std_abs_pcg float NULL,
	wkl_hc_abs_pcg_actual float NULL,
	ytd_hc_abs_pcg_actual float NULL,
	wkl_bhndsch_hrs float NULL,
	wkl_bhndsch_ucl float NULL,
	wkl_bhndsch_to_fnsh_hrs float NULL,
	wkl_bhndsch_to_fnsh_ucl float NULL,
	wkl_hc_effective_actual float NULL,
	wkl_hc_demand float NULL,
	ytd_hc_effective_actual float NULL,
	ytd_hc_demand float NULL,
	wkl_stfg_aop_planned float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

/*
Usage : To log the status of input files 

Creator/Editor #Date #Comments
Praveen C # 2017-11-20 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_file_exist_log'
)
CREATE Table datamart.fact_file_exist_log
(
logdate datetime default (getdate()),
file_code varchar(100) NOT NULL,
file_name varchar(500) NOT NULL,
existence varchar(3)  NOT NULL DEFAULT('Yes'),
mail_sent BIT NOT NULL DEFAULT(0)
)
GO

/*
Usage : This table is used to load greenline costs data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_greenlinecosts'
)


CREATE TABLE [datamart].[fact_greenlinecosts](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[spirit_year] [int] NULL,
	[weeklyactuals] [float] NULL,
	[headers] [varchar](50) NULL,
	[actualcummulativeytd] [float] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [datetime] NULL DEFAULT (getdate()),
	[modified_date] [varchar](50) NULL DEFAULT (suser_sname())
) 

GO




/*
Usage : This table is used to load Malaysia SRR,Escapes and NOE data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_malaysia_ceo_metrics_master'
)

CREATE TABLE [datamart].[fact_malaysia_ceo_metrics_master](
	[load_date] [datetime] NULL DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[spirit_year] [int] NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[metric_value] [float] NULL,
	[attribute] [varchar](50) NULL,
	[defect_qty] [int] NULL
) 

GO




/*
Usage : This datamrt table is used to populate the data for planned vs reactive maint for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_manpower_plannedvsreactive_maintenance'
)

CREATE TABLE datamart.fact_manpower_plannedvsreactive_maintenance
(
	wonum nvarchar(20),
	wo_description nvarchar(100),
	actfinish nvarchar(21),
	regularhrs float,
	wo_status nvarchar(16),
	
	busunit nvarchar(10),
	reqpri nvarchar(10),
	assetlocpriority float,
	priority_num float,
	siteid nvarchar(8),
	
	maintgrp nvarchar(10),
	laborhrs varchar(6) 
) 

GO



/*
Usage : This datmart table is used to populate the data for utilization attribute for qual site

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_manpower_utilization'
)

CREATE TABLE datamart.fact_manpower_utilization
(
	personid nvarchar(30),
	shiftnum nvarchar(8),
	workdate date,
	availablehrs float,
	modhrs float,
	
	regularhrs float,
	siteid nvarchar(8),
	displayname nvarchar(62),
	costcenter nvarchar(20),
	supervisor nvarchar(30),
	
	department nvarchar(30),
	super_name nvarchar(62),
	sec_personid nvarchar(30),
	sec_level_mgr nvarchar(62),
	craft nvarchar(8),
	
	qualificationid nvarchar(8) 
) 

GO


/*
Usage : This datamart table is used to populate the data or utilization attribute for noa site

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_manpower_utilization_noa'
)

CREATE TABLE datamart.fact_manpower_utilization_noa
(
	personid nvarchar(30),
	shiftnum nvarchar(8),
	workdate date,
	availablehrs float,
	regularhrs float,
	
	siteid nvarchar(8),
	displayname nvarchar(62),
	costcenter nvarchar(20),
	supervisor nvarchar(30),
	department nvarchar(30),
	
	super_name nvarchar(62),
	sec_personid nvarchar(30),
	sec_level_mgr nvarchar(62),
	craft nvarchar(8),
	qualificationid nvarchar(8) 
	)

GO


/*
Usage : This table is used to load noe data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_noe'
)

CREATE TABLE [datamart].[fact_noe](
	[ecd] [varchar](30) NULL,
	[date_written] [date] NULL,
	[date_closed] [date] NULL,
	[noe_sdr_nar_nod] [varchar](20) NULL,
	[status] [varchar](50) NULL,
	[bu_supplier] [varchar](100) NULL,
	[customer] [varchar](30) NULL,
	[owner] [varchar](30) NULL,
	[models] [varchar](50) NULL,
	[assigned_to] [varchar](100) NULL,
	[description_of_condition] [varchar](300) NULL,
	[comments_disposition] [varchar](300) NULL,
	[rcca_summary] [varchar](max) NULL,
	[previous_occurrence] [varchar](30) NULL,
	[units_affected] [varchar](max) NULL,
	[rcca_initiated] [varchar](20) NULL,
	[rcca_completed] [varchar](20) NULL,
	[safety_of_flight] [varchar](20) NULL,
	[cust_ref] [varchar](20) NULL,
	[Z7] [varchar](max) NULL,
	[aftermarke_groups_affected] [varchar](30) NULL,
	[qn_number] [varchar](300) NULL,
	[qn_initiation_date] [datetime] NULL,
	[vendor_code] [varchar](20) NULL,
	[pns] [varchar](300) NULL,
	[disposition] [varchar](30) NULL,
	[can] [varchar](200) NULL,
	[can_initiated] [varchar](20) NULL,
	[can_action_plans_sent] [varchar](20) NULL,
	[can_closed] [varchar](30) NULL,
	[ecd_of_ca] [varchar](20) NULL,
	[z7_close_with_executive_summary] [varchar](30) NULL,
	[customer_closure_notice_received] [varchar](30) NULL,
	[path] [varchar](30) NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL,
	[modified_date] [datetime] NULL,
	[noe_sdr] [varchar](300) NULL,
	[tracking] [varchar](20) NULL,
	[item_type] [varchar](20) NULL,
	[boeing_mrb_appendix_C_authority_used] [varchar](200) NULL
)


GO


/*
Usage : This datamart table is used to populate the data for overtime metric for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_overtime'
)

CREATE TABLE datamart.fact_overtime
(
	business_unit nvarchar(50),
	cost_center nvarchar(255),
	week_end_date datetime,
	actual_regular_hours float,
	actual_overtime_hours float,
	
	forecast_regular_hours float,
	forecast_overtime_hours float,
	actual_ot_pcg float,
	forecast_ot_pcg float,
	location nvarchar(50) 
)

GO


IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_prestwick_ceo_metrics_master'
)


CREATE TABLE [datamart].[fact_prestwick_ceo_metrics_master](
	[load_date] [datetime] NULL DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[spirit_year] [int] NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[metric_value] [float] NULL,
	[attribute] [varchar](50) NULL,
	[defect_qty] [int] NULL
) 

GO
/*
Usage : This datamrt table is used to populate the data for quality attribute for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_srr_facility'
)

CREATE TABLE datamart.fact_srr_facility
(
nc_key varchar(50)
,dtwritten datetime
,model_ist3 varchar(50)
,unit float
,defect_qty float

,defect_dollars float
,scrap_dollars float
,admin_cost float
,mgcode varchar(50)
,featdef_cd varchar(50)

,feat_decrip varchar(100)
,desc_description varchar(100)
,ncr_type varchar(50)
,value_chain varchar(50)
,parts varchar(100)

,origshop varchar(50)
,reasoncd varchar(50)
,code_set_id varchar(50)
) 

GO



/*
Usage : This table is used to load srr actuals data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_srr_fuselage'
)

CREATE TABLE [datamart].[fact_srr_fuselage](
	[date_written] [date] NULL,
	[ncr_type] [varchar](255) NULL,
	[model] [varchar](50) NULL,
	[unit] [float] NULL,
	[feature_defect_code] [varchar](255) NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](255) NULL,
	[value_chain] [varchar](255) NULL,
	[charge_mgmt_code] [nvarchar](255) NULL,
	[defect_qty] [int] NULL,
	[defect_dollars] [float] NULL,
	[scrap_dollars] [float] NULL,
	[admin_cost] [float] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL CONSTRAINT [DF_fact_srr_fuselage_modified_by]  DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL CONSTRAINT [DF_fact_srr_fuselage_modified_date]  DEFAULT (getdate()),
	[total_srr_dollar] [float] NULL,
	[location] [varchar](50) NULL
) 

GO



IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_srr_prestwick'
)

CREATE TABLE [datamart].[fact_srr_prestwick](
	[total_srr_dollar] [float] NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[location] [varchar](50) NULL,
	[feature_description] [varchar](300) NULL,
	[date_written] [date] NULL,
	[modified_by] [varchar](50) NULL CONSTRAINT [DF__fact_srr___modif__625A9A57]  DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL CONSTRAINT [DF__fact_srr___modif__634EBE90]  DEFAULT (getdate()),
	[created_date] [datetime] NOT NULL,
	[discrepancy_description] [varchar](300) NULL,
	[feature_descrepancy] [varchar](300) NULL,
	[spirit_year] [int] NULL
) 

GO



/*
Usage : This datamart table is used to populate the data for quality attribuet of units for facility 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_units_facility'
)

CREATE TABLE datamart.fact_units_facility
(
	location nvarchar(255),
	program nvarchar(255),
	weekenddate date,
	units float 
) 

GO


/*
Usage : To find the source data 

Creator/Editor #Date #Comments
Prakhar  # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name ='ftp_absenteeism'
)

CREATE TABLE staging.ftp_absenteeism
 (
	cost_center nvarchar(255),
	working_level nvarchar(255),
	shifts nvarchar(255),
	period nvarchar(50),
	abs_p float,
	
	abs_up float,
	abs_fmla nvarchar(255),
	countofpaycode int,
	total_abs_hours float,
	std_hours_per_week float,
	
	std_abs_pcg float,
    loaddate datetime 
	
CONSTRAINT DF_ftp_absenteeism_loaddate  DEFAULT (getdate()),
	business_unit nvarchar(255),
	location nvarchar(50)
) 

GO


/*
Usage :It is used to load Genpact DT Labor & Safery excel 

Creator/Editor #Date #Comments
Pratheesh N # 2017-10-13 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_direct_labor_safety'
)

CREATE TABLE staging.ftp_direct_labor_safety
(
srno bigint identity
,sheet_name nvarchar(200)
,week_no int not null
,cost_center nvarchar (200)
,metric_name nvarchar (200)
,actuals float (53)
,planned float (53)
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_escape_prestwick'
)

CREATE TABLE [staging].[ftp_escape_prestwick](
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[ca_count] [int] NULL,
	[date_written] [date] NULL,
	[escape_amount_actual] [float] NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](255) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime] NULL DEFAULT (getdate()),
	[feature_descrepancy] [varchar](300) NULL
) 

GO



/*
Usage : This table is used to load escape targets 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_escape_target'
)

CREATE TABLE [staging].[ftp_escape_target](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[load_date] [datetime] NOT NULL CONSTRAINT [DF__ftp_escap__load___19AACF41]  DEFAULT (getdate()),
	[model] [nvarchar](255) NOT NULL,
	[heading] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[function] [nvarchar](255) NULL,
	[year] [nvarchar](255) NULL,
	[week] [datetime] NULL,
	[week_no] [int] NULL,
	[weekly_escape_target] [float] NULL,
	[ytd_escape_target] [float] NULL,
	[sheet_name] [nvarchar](255) NULL,
	[location] [varchar](50) NULL,
 CONSTRAINT [PK__ftp_esca__1543595EFC6C6267] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO





IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_absenteeism'
)
CREATE TABLE staging.ftp_fab_absenteeism(
	period nvarchar(20) NULL,
	wt_group nvarchar(255) NULL,
	work_hours float NULL,
	working_level nvarchar(255) NULL,
	cost_center nvarchar(255) NULL,
	pers_area nvarchar(255) NULL,
	shift nvarchar(255) NULL
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_adp_hours'
)
CREATE TABLE staging.ftp_fab_adp_hours(
	posting_dt nvarchar(50) NULL,
	labor_worked_dt nvarchar(50) NULL,
	cost_center nvarchar(50) NULL,
	emp_id nvarchar(50) NULL,
	emp_name nvarchar(50) NULL,
	gl_acc_code nvarchar(50) NULL,
	gl_acc_desc nvarchar(50) NULL,
	labor_hrs nvarchar(50) NULL
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_aop_ot_pcg'
)

CREATE TABLE [staging].[ftp_fab_aop_ot_pcg](
	[week_end_date] [date] NULL,
	[fab_category] [varchar](30) NULL,
	[aop_ot_pcg] [float] NULL,
	[extract_dt] [datetime] NULL DEFAULT (getdate())
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_behind_schedule_ucl'
)

CREATE TABLE staging.ftp_fab_behind_schedule_ucl(
	spirit_year int NULL,
	spirit_month int NULL,
	cost_center varchar(10) NULL,
	bhnd_sch_to_fnsh_ucl float NULL,
	bhnd_sch_ucl float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_business_unit'
)

CREATE TABLE staging.ftp_fab_business_unit(
	cost_center varchar(10) NULL,
	fab_category varchar(50) NULL,
	category varchar(50) NULL,
	sub_category varchar(50) NULL,
	pwhse_category varchar(50) NULL,
	pwhse_sub_category varchar(50) NULL,
	category_desc varchar(100) NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_doi_tgt_pcg'
)
CREATE TABLE staging.ftp_fab_doi_tgt_pcg(
	spirit_year int NULL,
	fab_category varchar(30) NULL,
	doi_tgt_pcg float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_escapes_assy_plan'
)

CREATE TABLE staging.ftp_fab_escapes_assy_plan(
	spirit_year int NULL,
	fab_category varchar(30) NULL,
	target_reduction_pcg float NULL,
	baseline float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_escapes_end_cust_plan'
)

CREATE TABLE staging.ftp_fab_escapes_end_cust_plan(
	spirit_year int NULL,
	fab_category varchar(30) NULL,
	tot_wkl_target float NULL,
	breakup_pcg float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_kit_fill_rate'
)

CREATE TABLE staging.ftp_fab_kit_fill_rate(
	row_num int NULL,
	week_end_dt date NULL,
	lsn nvarchar(50) NULL,
	cmcs_mach nvarchar(50) NULL,
	cmcs_wtw nvarchar(50) NULL,
	lss nvarchar(50) NULL,
	smc nvarchar(50) NULL,
	cmce nvarchar(50) NULL,
	cfc nvarchar(50) NULL,
	cmcw nvarchar(50) NULL,
	skin_fab_1 nvarchar(50) NULL,
	machine_fab nvarchar(50) NULL,
	sheet_metal nvarchar(50) NULL,
	skin_fab nvarchar(50) NULL,
	cfc_1 nvarchar(50) NULL,
	total_fab nvarchar(50) NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_m08_list'
)
CREATE TABLE staging.ftp_fab_m08_list(
	cost_center varchar(10) NULL,
	source_file nvarchar(255) NULL,
	emp_id nvarchar(255) NULL,
	emp_name nvarchar(255) NULL,
	extract_dt datetime NULL DEFAULT (getdate())
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_realization_pcg_plan'
)
CREATE TABLE staging.ftp_fab_realization_pcg_plan(
	week_end_date date NULL,
	fab_category varchar(30) NULL,
	wkl_rlzn_target_pcg float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_srr_target'
)
CREATE TABLE staging.ftp_fab_srr_target(
	week_end_date date NULL,
	fab_category varchar(30) NULL,
	wkl_srr_target float NULL,
	breakup_pcg float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_srr_touch_to_plan_pcg'
)
CREATE TABLE staging.ftp_fab_srr_touch_to_plan_pcg(
	spirit_year int NULL,
	fab_category varchar(30) NULL,
	srr_touch_to_plan_pcg float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_staffing_aop'
)
CREATE TABLE staging.ftp_fab_staffing_aop(
	week_end_date date NULL,
	fab_category varchar(30) NULL,
	wkl_staffing_aop float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
)

GO
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_fab_standard_abs_pcg'
)
CREATE TABLE staging.ftp_fab_standard_abs_pcg(
	spirit_year int NULL,
	fab_category varchar(30) NULL,
	wkl_std_abs_pcg float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO
/*
Usage : This table is used to load unstructured data for greenlinecost 

Creator/Editor #Date            #Comments
Rammanohar     # 2017-10-17		# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_greenlinecosts'
)

CREATE TABLE [staging].[ftp_greenlinecosts](
	[week_date] [date] NULL,
	[737NG_gl] [float] NULL,
	[737MAX_gl] [float] NULL,
	[P8A_gl] [float] NULL,
	[747_gl] [float] NULL,
	[767_gl] [float] NULL,
	[777_gl] [float] NULL,
	[787_GL] [float] NULL,
	[C-Series_gl] [float] NULL,
	[br725_gl] [float] NULL,
	[value_chain] [nvarchar](50) NULL,
	[load_date] [datetime] DEFAULT (getdate())
) 

GO




/*
Usage : This table is used to load escapes actual data from Kinston/SNZ 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_kinsnz_escape'
)

CREATE TABLE [staging].[ftp_kinsnz_escape](
	[date] [datetime] NULL,
	[airbus_escape_number] [nvarchar](255) NULL,
	[panel] [nvarchar](255) NULL,
	[escape_description] [nvarchar](255) NULL,
	[rcca_number] [nvarchar](255) NULL,
	[note] [nvarchar](255) NULL,
	[belongs_to] [nvarchar](255) NULL,
	[last_msn_on_which_escape_was_reported] [float] NULL,
	[escape_supplier_responsible_Y-N] [nvarchar](255) NULL,
	[count] [float] NULL,
	[3_defect_reoccurrence] [nvarchar](255) NULL,
	[containment_implemented_from_msn] [float] NULL,
	[containment_target] [float] NULL,
	[submission_target] [float] NULL,
	[closure_target] [float] NULL,
	[sari] [nvarchar](255) NULL,
	[noes] [nvarchar](255) NULL,
	[qsrs] [nvarchar](255) NULL,
	[f25] [nvarchar](255) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime] NULL CONSTRAINT [DF_ftp_kinsnz_escape_load_date]  DEFAULT (getdate()),
	[program_nm] [varchar](50) NULL
) 

GO

/*
Usage : This table is used to load esacpes from Kinston location
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-01-17	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_kinston_escape'
)


CREATE TABLE [staging].[ftp_kinston_escape](
	[date] [datetime] NULL,
	[airbus_escape_number] [nvarchar](255) NULL,
	[panel] [nvarchar](255) NULL,
	[escape_description] [nvarchar](255) NULL,
	[rcca_number] [nvarchar](255) NULL,
	[note] [nvarchar](255) NULL,
	[submission_target] [float] NULL,
	[closure_target] [float] NULL,
	[sari] [nvarchar](255) NULL,
	[escape_supplier_responsible] [nvarchar](255) NULL,
	[f1_containment_implemented_from_msn] [float] NULL,
	[f2_containment_implemented_from_msn] [nvarchar](255) NULL,
	[date_containment_implemented_at_spirit] [datetime] NULL,
	[workdays_defect_contained] [nvarchar](255) NULL,
	[containment_target] [nvarchar](255) NULL,
	[rcca_submisssion_corrective_action_plan_date] [nvarchar](255) NULL,
	[workdays_corrective_action_plan] [nvarchar](255) NULL,
	[workdays_rcca_closure] [nvarchar](255) NULL,
	[noe] [nvarchar](255) NULL,
	[qsr] [nvarchar](255) NULL,
	[program_nm] [varchar](50) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime]   DEFAULT getdate()
)


GO
/*
Usage : This table is used to load structured data for ceo metric actuals from Malaysia location 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_malaysia_ceo_metrics_master'
)

CREATE TABLE [staging].[ftp_malaysia_ceo_metrics_master](
	[load_date] [datetime] NULL DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[spirit_year] [int] NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[metric_value] [float] NULL,
	[attribute] [varchar](50) NULL,
	[defect_qty] [int] NULL
)

GO



/*
Usage : This table is used to load unstructured data for ceo metric actuals from Malaysia location 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_malaysia_srr_escape_noe'
)

CREATE TABLE [staging].[ftp_malaysia_srr_escape_noe](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[previousyear_YE] [money] NULL,
	[currentyear_targets] [money] NULL,
	[variance_targets] [money] NULL,
	[weekly_plan] [money] NULL,
	[weekly_actual] [money] NULL,
	[variance_weekly] [money] NULL,
	[ytd_plan] [money] NULL,
	[ytd_actual] [money] NULL,
	[variance_ytd] [money] NULL,
	[spirit_week] [nvarchar](50) NULL,
	[program] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO



/*
Usage : This table is used to load noe data 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_noe'
)

CREATE TABLE [staging].[ftp_noe](
	[load_date] [datetime] NULL CONSTRAINT [DF_ftp_noe_load_date]  DEFAULT (getdate()),
	[#] [float] NULL,
	[ecd] [nvarchar](255) NULL,
	[date] [datetime] NULL,
	[date_closed] [datetime] NULL,
	[noe_sdr_nar_nod] [nvarchar](255) NULL,
	[noe_sdr] [nvarchar](255) NULL,
	[status] [nvarchar](255) NULL,
	[bu_supplier] [nvarchar](255) NULL,
	[customer] [nvarchar](255) NULL,
	[owner] [nvarchar](255) NULL,
	[models] [nvarchar](255) NULL,
	[assigned_to] [nvarchar](255) NULL,
	[description_of_condition] [nvarchar](255) NULL,
	[comments_disposition] [nvarchar](255) NULL,
	[rcca_summary] [nvarchar](max) NULL,
	[previous_occurrence] [nvarchar](255) NULL,
	[units_affected] [nvarchar](max) NULL,
	[rcca_initiated] [nvarchar](255) NULL,
	[rcca_completed] [nvarchar](255) NULL,
	[safety_of_flight] [nvarchar](255) NULL,
	[tracking] [nvarchar](255) NULL,
	[cust_ref] [nvarchar](255) NULL,
	[Z7] [nvarchar](max) NULL,
	[aftermarke_groups_affected] [nvarchar](255) NULL,
	[qn_number] [nvarchar](255) NULL,
	[qn_initiation_date] [datetime] NULL,
	[vendor_code] [nvarchar](255) NULL,
	[pns] [nvarchar](255) NULL,
	[disposition] [nvarchar](255) NULL,
	[boeing_mrb_appendix_C_authority_used] [nvarchar](255) NULL,
	[can] [nvarchar](255) NULL,
	[can_initiated] [nvarchar](255) NULL,
	[can_action_plans_sent] [nvarchar](255) NULL,
	[can_closed] [nvarchar](255) NULL,
	[ecd_of_ca] [nvarchar](255) NULL,
	[z7_close_with_executive_summary] [nvarchar](255) NULL,
	[customer_closure_notice_received] [nvarchar](255) NULL,
	[item_type] [nvarchar](255) NULL,
	[path] [nvarchar](255) NULL
) 

GO


IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_overtime'
)

CREATE TABLE staging.ftp_overtime
(
business_unit nvarchar(100) null
,cost_center nvarchar(100) null
,week_end_date datetime null
,actual_regular_hours float null
,actual_overtime_hours float null

,forecast_regular_hours float null
,forecast_overtime_hours float null
,actual_ot_pcg float null
,forecast_ot_pcg float null
,location nvarchar(100) null
)

GO
/*
Usage : This table is used to load untructured data for ceo metrics from Prestwick location

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_prestwick_srr_escape_noe'
)

CREATE TABLE [staging].[ftp_prestwick_srr_escape_noe](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[previousyear_YE] [float] NULL,
	[currentyear_targets] [float] NULL,
	[variance_targets] [float] NULL,
	[weekly_plan] [float] NULL,
	[weekly_actual] [float] NULL,
	[variance_weekly] [float] NULL,
	[ytd_plan] [float] NULL,
	[ytd_actual] [float] NULL,
	[variance_ytd] [float] NULL,
	[spirit_week] [nvarchar](50) NULL,
	[program] [varchar](50) NULL,
 CONSTRAINT [PK__ftp_pres__1543595E26A3750A] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO

/*
Usage : This datamart table is used to populate the data for quality attribute of reduction target

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_scrap_rr_reduction_target'
)

CREATE TABLE staging.ftp_scrap_rr_reduction_target
(
	scrap_amount_target_per_unit float,
	rr_amount_target_per_unit float,
	scrap_amount_target_pcg float,
	rr_amount_target_pcg float,
	location nvarchar(255),
	
	Spirit_year float,
	program nvarchar(255) 
) 

GO





/*
Usage : This table is used to load prestwick srr ytd data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-11-01	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_srr_prestwick'
)

CREATE TABLE [staging].[ftp_srr_prestwick](
	[value_chain] [varchar](50) NULL,
	[location] [varchar](50) NULL,
	[program] [varchar](50) NULL,
	[date_written] [date] NULL,
	[feature_descrepancy] [varchar](255) NULL,
	[total_srr_dollar] [money] NULL,
	[week] [int] NULL,
	[Month] [int] NULL,
	[load_date] [datetime] NULL DEFAULT (getdate())
)

GO




/*
Usage : This table is used to load srr targets data 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_srr_target'
)

CREATE TABLE [staging].[ftp_srr_target](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[load_date] [datetime] NOT NULL CONSTRAINT [DF__ftp_srr_t__load___1C873BEC]  DEFAULT (getdate()),
	[model] [nvarchar](255) NOT NULL,
	[heading] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[function] [nvarchar](255) NULL,
	[year] [nvarchar](255) NULL,
	[week] [datetime] NULL,
	[week_no] [int] NULL,
	[weekly_srr_target] [float] NULL,
	[ytd_srr_target] [float] NULL,
	[weekly_gl_target] [float] NULL,
	[ytd_gl_target] [float] NULL,
	[sheet_name] [nvarchar](255) NULL,
	[location] [nvarchar](50) NULL,
 CONSTRAINT [PK__ftp_srr___1543595EAC553A35] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


/*
Usage : This table is used to load structured data  for greenline costs

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-17	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_total_srr_rollup'
)

CREATE TABLE [staging].[ftp_total_srr_rollup](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[gl_dollar] [float] NULL,
	[source_load_dt] [datetime] NULL,
	[week_date] [date] NULL,
	[load_date] [datetime] DEFAULT (getdate()),
	[prog_key] [int] NOT NULL,
	[spirit_week_no] [int] NULL,
	[yr] [int] NULL
)

GO



/*
Usage : To find source data for quality attribute for units

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_units_facility'
)


CREATE TABLE staging.ftp_units_facility
(
location nvarchar(100) null
,program nvarchar(150) null
,weekenddate datetime null
,units float null
)

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'hana_fab_wkly_intopsrwk'
)
CREATE TABLE staging.hana_fab_wkly_intopsrwk(
	cost_center varchar(10) NULL,
	prev_week_enddt date NULL,
	mat_act_task varchar(100) NULL,
	SetupHr float NULL,
	PrcessHr float NULL,
	AssyHr float NULL,
	CnfSetupHr float NULL,
	CnfProcessHr float NULL,
	CnfAssyHr float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
)

GO
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'hana_fab_wkly_stdhrs_kpis'
)
CREATE TABLE staging.hana_fab_wkly_stdhrs_kpis(
	cost_center varchar(10) NULL,
	prev_week_enddt date NULL,
	wkly_hrs_act float NULL,
	wkly_hrs_ex_pln float NULL,
	behind_sch_to_finish_hrs float NULL,
	behind_sch_hrs float NULL,
	vendor_assist_adj_hrs float NULL,
	behind_sch_adj_hrs float NULL,
	cycle_adj_hrs float NULL,
	third_party_adj_hrs float NULL,
	ext_rwrk_adj_hrs float NULL,
	actual_spl_adj_hrs float NULL,
	wkly_spl_hrs_pln float NULL,
	wkly_3rd_party_pln float NULL,
	extract_dt datetime NULL DEFAULT (getdate()),
	int_rwrk_adj_hrs float NULL
) 

GO

/*
Usage : This table is used to load error data from SP

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
Praveen C		# 2017-11-22	# Added Mail sent column to existing table
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'log_error'
)


CREATE TABLE [datamart].[log_error](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[procedure_name] [varchar](386) NULL,
	[line_no] [int] NULL,
	[message] [varchar](2048) NULL,
	[error_number] [int] NULL,
	[severity] [int] NULL,
	[state] [int] NULL,
	[spid] [int] NULL,
	[user_name] [varchar](300) NULL,
	[created_date] [datetime] NULL,
	[package_guid] [uniqueidentifier] NULL,
	mail_sent bit NOT NULL DEFAULT(0),
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO

/*
Usage : This table is used to load package log information 

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
Praveen C		# 2017-11-22	# Added Mail sent column to existing table
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'log_package'
)

CREATE TABLE [datamart].[log_package](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[package_name] [varchar](100) NOT NULL,
	[machine_name] [varchar](100) NOT NULL,
	[package_start_time] [datetime] NOT NULL,
	[package_status] [varchar](20) NULL,
	[package_end_time] [datetime] NULL,
	[error_message] [varchar](max) NULL,
	[time_in_seconds]  AS (datediff(second,[package_start_time],[package_end_time])),
	[process_number] [uniqueidentifier] NOT NULL,
	mail_sent bit NOT NULL DEFAULT(0),
 CONSTRAINT [PK__package___1543595EB07DCC7B] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)
GO


/*
Usage : To find source data for assetcost 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_asset_cost'
)

CREATE TABLE staging.maximo_asset_cost
(
	startdate nvarchar(21),
	wonum nvarchar(20),
	description nvarchar(100),
	reportdate nvarchar(21),
	actfinish nvarchar(21),
	
	busunit nvarchar(10),
	reqpri nvarchar(10),
	assetlocpriority float,
	wo_type varchar(16),
	assetnum nvarchar(25),
	
	labor_hrs float,
	labor_cost numeric(10,2),
	cause nvarchar(8),
	failuremark_desc nvarchar(100),
	problemcode nvarchar(8),
	
	wo_priority float,
	siteid nvarchar(8),
	maintgrp nvarchar(10),
	stockcost numeric(10, 2),
	nonstock_cost numeric(10, 2) 
)
GO

/*
Usage : To find source data for assetcount 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_asset_count'
)

CREATE TABLE staging.maximo_asset_count
(
	busunit nvarchar(10),
	assetnum nvarchar(25),
	priority float,
	siteid nvarchar(8),
	isrunning float,
	
	installdate nvarchar(21),
	status nvarchar(20),
	statusdate nvarchar(21) 
) 

GO



/*
Usage : To find source data for downtime attribute

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_downtime_dailyclocking'
)

CREATE TABLE staging.maximo_downtime_dailyclocking
(
	assetnum nvarchar(25) ,
	change_date nvarchar(21) ,
	wo_num nvarchar(20) ,
	downtime float ,
	assetdept nvarchar(12) ,
	
	wo_description nvarchar(158),
	location nvarchar(35) ,
	wo_priority float ,
	busunit nvarchar(10) ,
	wo_status nvarchar(20) ,
	
	siteid nvarchar(8) ,
	shopid nvarchar(15) ,
	report_date nvarchar(21) ,
	actfinish nvarchar(21) ,
	leadcraft nvarchar(8) ,
	
	maintgrp nvarchar(10) ,
	reqpri nvarchar(10) ,
	amflag float ,
	workorder_desc nvarchar(100) ,
	work_type nvarchar(5) ,
	
	failure_desc nvarchar(100) 
) 

GO


/*
Usage : To find source data for planned vs reactive maint attribute

Creator/Editor #Date #Comments
Prakhar  # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_manpower_plannedvsreactive_maintenance'
)

CREATE TABLE staging.maximo_manpower_plannedvsreactive_maintenance
(
	wonum nvarchar(20),
	wo_description nvarchar(100),
	actfinish nvarchar(21),
	regularhrs float,
	wo_status nvarchar(16),
	
	busunit nvarchar(10),
	reqpri nvarchar(10),
	assetlocpririty float,
	priority_num float,
	siteid nvarchar(8),
	
	maintgrp nvarchar(10),
	laborhrs varchar(6) 
) 

GO



/*
Usage : To find source data for utilization attribute

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_manpower_utilization'
)

CREATE TABLE staging.maximo_manpower_utilization
(
	personid nvarchar(30),
	shiftnum nvarchar(8),
	workdate nvarchar(21),
	availablehrs float,
	modhrs float,
	
	regularhrs float,
	siteid nvarchar(8),
	displayname nvarchar(62),
	costcenter nvarchar(20),
	supervisor nvarchar(30),
	department nvarchar(30),
	
	super_name nvarchar(62),
	sec_personid nvarchar(30),
	sec_level_mgr nvarchar(62),
	craft nvarchar(8),
	qualificationid nvarchar(8) 
) 

GO


/*
Usage : To find source data for utilization attribute for noa site

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_manpower_utilization_noa'
)
CREATE TABLE staging.maximo_manpower_utilization_noa
(
	personid nvarchar(30),
	shiftnum nvarchar(8),
	workdate date,
	availablehrs float,
	regularhrs float,
	
	siteid nvarchar(8),
	displayname nvarchar(62),
	costcenter nvarchar(20),
	supervisor nvarchar(30),
	department nvarchar(30),
	
	super_name nvarchar(62),
	sec_personid nvarchar(30),
	sec_level_mgr nvarchar(62),
	craft nvarchar(8),
	qualificationid nvarchar(8) 
)

GO


/*
Usage : This table is used to load escapes actuals data  
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ora_escape'
)

CREATE TABLE [staging].[ora_escape](
	[load_date] [datetime] NULL CONSTRAINT [DF_ora_escape_load_date]  DEFAULT (getdate()),
	[progam_nm] [varchar](255) NULL,
	[value_chain_cd] [varchar](255) NULL,
	[responsible_mgmt_code] [varchar](255) NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](max) NULL,
	[feature_code] [varchar](255) NULL,
	[ca_count] [float] NULL,
	[ncr_part_no] [varchar](255) NULL,
	[ca_ser_no] [varchar](255) NULL,
	[sum_ncr_cost_amt] [float] NULL,
	[discrepancy_code] [varchar](255) NULL,
	[unit_no] [varchar](50) NULL,
	[date_written] [datetime] NULL CONSTRAINT [DF__ora_escap__date___607251E5]  DEFAULT (getdate()),
	[SNN_suppl_notification_flag] [numeric](10, 0) NULL,
	[dir_title] [varchar](50) NULL,
	[man_name] [varchar](100) NULL,
	[supt_title] [varchar](50) NULL,
	[resp_ca_team] [varchar](50) NULL,
	[location] [varchar](50) NULL
) 

GO




/*
Usage : To find source data for quality attribute from oracl source 

Creator/Editor #Date #Comments
Prakhar  # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ora_srr_facility'
)

CREATE TABLE staging.ora_srr_facility
(
nc_key varchar(50)
,dtwritten datetime
,model_ist3 varchar(50)
,unit float
,defect_qty float

,defect_dollars float
,scrap_dollars float
,admin_cost float
,mgcode varchar(50)
,featdef_cd varchar(50)

,feat_descrip varchar(100)
,desc_description varchar(100)
,ncr_type varchar(20)
,value_chain varchar(20)
,parts varchar(40)

,origshop varchar(12)
,reasoncd varchar(3) 
,code_set_id varchar(50)
)

GO


/*
Usage : This table is used to load srr actuals data  
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ora_srr_fuselage'
)

CREATE TABLE [staging].[ora_srr_fuselage](
	[load_date] [datetime] NULL CONSTRAINT [DF_ora_srr_fuselage_load_date]  DEFAULT (getdate()),
	[date_written] [datetime] NULL,
	[ncr_type] [varchar](255) NULL,
	[model] [varchar](50) NULL,
	[unit] [varchar](50) NULL,
	[feature_defect_code] [varchar](255) NULL,
	[feature_description] [varchar](300) NULL,
	[discrepancy_description] [varchar](300) NULL,
	[value_chain] [varchar](255) NULL,
	[charge_mgmt_code] [varchar](255) NULL,
	[defect_qty] [int] NULL,
	[defect_dollars] [float] NULL,
	[scrap_dollars] [float] NULL,
	[admin_cost] [float] NULL,
	[total_srr_dollar] [float] NULL,
	[location] [varchar](50) NULL
)


GO
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'pwhse_fab_escape_assy'
)
CREATE TABLE staging.pwhse_fab_escape_assy(
	dtwritten date NULL,
	supt_title varchar(25) NULL,
	gen_title varchar(25) NULL,
	qn_qty float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'pwhse_fab_escape_end_cust'
)
CREATE TABLE staging.pwhse_fab_escape_end_cust(
	ncr_written_dt date NULL,
	supt_title varchar(30) NULL,
	suppl_notif_flg float NULL,
	car_ser_no varchar(30) NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'pwhse_fab_sap_routing'
)
CREATE TABLE staging.pwhse_fab_sap_routing(
	cost_center varchar(10) NULL,
	mat_act_task varchar(100) NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'pwhse_fab_srr'
)
CREATE TABLE staging.pwhse_fab_srr(
	dtwritten date NULL,
	supt_title varchar(25) NULL,
	gen_title varchar(25) NULL,
	total_srr float NULL,
	extract_dt datetime NULL DEFAULT (getdate())
) 

GO
/*
Usage : This table is used to load summary report data for Quality

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'quality_srr_escape_noe'
)

CREATE TABLE [reporting].[quality_srr_escape_noe](
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL,
	[date_written] [date] NULL,
	[program] [varchar](30) NULL,
	[location] [varchar](30) NULL,
	[value_chain] [varchar](30) NULL,
	[feature_defect_description] [varchar](100) NULL,
	[srr_qty_actual] [int] NULL,
	[srr_amount_actual] [float] NULL,
	[escapes_amount_actual] [float] NULL,
	[escapes_qty_actual] [int] NULL,
	[noe_actual] [int] NULL,
	[srr_amount_planned] [float] NULL,
	[escapes_amount_planned] [float] NULL,
	[escapes_qty_planned] [float] NULL,
	[noe_planned] [numeric](18, 2) NULL,
	[attribute] [varchar](20) NULL,
	[charge_mgmt_code] [varchar](255) NULL,
	[function] [varchar](50) NULL,
	[noe_description] [varchar](255) NULL,
	[srr_amount_planned_summary] [float] NULL,
	[escapes_qty_planned_summary] [float] NULL
) 

GO




/*
Usage : This table is used to load weekly program metrics data for Quality

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'quality_weekly_program_metrics'
)


CREATE TABLE [reporting].[quality_weekly_program_metrics](
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL,
	[program] [varchar](30) NULL,
	[business_units] [varchar](30) NULL,
	[headers] [varchar](255) NULL,
	[weeklyactuals] [float] NULL,
	[weeklyplanned] [float] NULL,
	[weekly_variance] [float] NULL,
	[variance_planned] [float] NULL,
	[escape_weekly$_actuals] [float] NULL,
	[actualcumulativeytd] [float] NULL,
	[plannedcumulativeytd] [float] NULL
) 

GO

/*
Usage : This datamart table is used to populate the data for quality attribute of reduction target

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_scrap_rr_reduction_target'
)

CREATE TABLE datamart.dim_scrap_rr_reduction_target
(
	scrap_amount_target_per_unit float,
	rr_amount_target_per_unit float,
	scrap_amount_target_pcg float,
	rr_amount_target_pcg float,
	location nvarchar(255),
	
	Spirit_year float,
	program nvarchar(255) 
)

GO



IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'refresh_log'
)

CREATE TABLE reporting.refresh_log
(
report_name nvarchar(255) null
,report_owner_name nvarchar(255) null
,reporting_period nvarchar(255) null
,last_refresh_date_time datetime null
,week_no int null
)

GO

