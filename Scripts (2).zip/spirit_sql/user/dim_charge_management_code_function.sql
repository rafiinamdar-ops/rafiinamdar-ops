/*
Usage : This table is used to load mapping data for charge management code and function for Quality
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_charge_management_code_function'
)

CREATE TABLE [datamart].[dim_charge_management_code_function](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[management_code] [varchar](50) NULL,
	[description] [varchar](50) NULL,
	[org] [varchar](50) NULL,
	[organization] [varchar](50) NULL,
	[functions] [varchar](50) NULL,
	[QA_Support] [varchar](50) NULL,
	[site] [varchar](50) NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
)

GO




