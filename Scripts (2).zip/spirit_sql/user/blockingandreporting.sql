DECLARE @dbname as varchar(100)
DECLARE @sub as varchar(200)


SET NOCOUNT ON
SET @dbname='sqldba'
SET @sub='The Blocking found on SCAT Database - Server : ' + (SELECT @@Servername)

-- Checked for currenlty running queries by putting data in temp table
SELECT s.session_id
	    ,r.blocking_session_id
    INTO #temp_requests
FROM  sys.dm_exec_sessions AS s
INNER JOIN sys.dm_exec_requests AS r ON r.session_id = s.session_id
--CROSS APPLY sys.dm_exec_sql_text(r.sql_handle) AS st
WHERE r.session_id != @@SPID and db_name(r.database_id )=@dbname
select * FROM #temp_requests
IF (
        
		SELECT count(*)
        FROM #temp_requests
        WHERE blocking_session_id > 50
        ) <> 0

BEGIN
-- blocking found, sent email. 
    DECLARE @tableHTML NVARCHAR(MAX);

    SET @tableHTML = N'<H1>The Blocking Details below</H1>' + N'<table border="1">'+N'<col width="130">
  <col width="80">' + N'<tr>' + N'<th>DB_Name</th>' + N'<th>SP_ID</th>' + 
                     N'<th>Blocked</th><th>Login_Name</th><th>Text</th>' + 
                     N'<th>Program_Name</th>' +
					 N'<th>wait_duration_ms</th>' + N'<th>wait_type</th>' + N'<th>login_time</th>' + 
                     N'<th>last_request_start_time</th>' + N'<th>host_name</th>' +  N'<th>Commond</th>' +
                     + '</tr>' + CAST((
SELECT 
       td = ISNULL(db_name(r.database_id), @dbname)
        ,''
         
	   ,td =s.session_id
	   ,''
         ,td = ISNULL(CONVERT (varchar, w.blocking_session_id), '0')
       --UserProcess  = CONVERT(CHAR(1), s.is_user_process),
	          ,''
        ,td = s.login_name   
        ,''	
          ,td = (select text from sys.dm_exec_sql_text(c.most_recent_sql_handle)) 
		  	  
        ,''
            ,td = ISNULL(s.program_name, N'')
        ,''
           ,td =ISNULL(w.wait_duration_ms, 0)
        ,''
                    ,td = ISNULL(w.wait_type, N'')
       ,''
                    ,td =cast(s.login_time as varchar)
       ,''
                    ,td = cast(s.last_request_start_time as varchar)
        ,''
                    ,td =ISNULL(s.host_name, N'')
       ,''
                    ,td = ISNULL(r.command, N'') 
    FROM sys.dm_exec_sessions s LEFT OUTER JOIN sys.dm_exec_connections c ON (s.session_id = c.session_id)
    LEFT OUTER JOIN sys.dm_exec_requests r ON (s.session_id = r.session_id)
    LEFT OUTER JOIN sys.dm_os_tasks t ON (r.session_id = t.session_id AND r.request_id = t.request_id)
    LEFT OUTER JOIN 
    (
        -- Using row_number to select longest wait for each thread, 
        -- should be representative of other wait relationships if thread has multiple involvements. 
        SELECT  *, ROW_NUMBER() OVER (PARTITION BY waiting_task_address ORDER BY wait_duration_ms DESC) AS row_num
        FROM sys.dm_os_waiting_tasks 
    ) w ON (t.task_address = w.waiting_task_address) AND w.row_num = 1
    LEFT OUTER JOIN sys.dm_exec_requests r2 ON (r.session_id = r2.blocking_session_id)
    OUTER APPLY sys.dm_exec_sql_text(r.sql_handle) as st

    WHERE s.session_Id in (select session_id from #temp_requests)   or  s.session_Id in (select blocking_session_id from #temp_requests)                   -- ignore anything pertaining to the system spids.

     -- let's avoid our own query! :)

    --ORDER BY s.session_id
	
                FOR XML PATH('tr')
                    ,TYPE
                ) AS NVARCHAR(MAX)) + N'</table>';
	    EXEC msdb.dbo.sp_send_dbmail @body = @tableHTML
        ,@body_format = 'HTML'
        ,@profile_name = N'svcsql'
        ,@recipients = 'mahammadrafik.inamdar@dxc.com' -- replace with your email address
		--,@copy_recipients = 'DL-SQLServerDBAs@spiritaero.com;spiritdxcnensql@dxc.com'
        ,@Subject = @sub
END

drop table #temp_requests