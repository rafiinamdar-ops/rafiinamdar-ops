USE [master]
GO

/****** Object:  DdlTrigger [ddl_trig_CreateLogin]    Script Date: 3/21/2018 6:10:08 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [ddl_trig_CreateLogin]
ON ALL SERVER
FOR CREATE_LOGIN
AS
   -- Declare variables
	DECLARE @mailSubject Nvarchar(100);
	DECLARE @mailBody Nvarchar(MAX);
	DECLARE @data xml;
	DECLARE @text nvarchar(max);
	DECLARE @user nvarchar(max);
	DECLARE @RC int
	DECLARE @login_name varchar(100)
	DECLARE @cmd varchar(500)
	DECLARE @code varchar(500)
	DECLARE @othernode varchar(100)
	DECLARE @knownStartString VARCHAR(100) = 'CREATE LOGIN [';
	DECLARE @knownEndString VARCHAR(100) = '] ';
    SET @data = EVENTDATA();
    SET @code = @data.value('(/EVENT_INSTANCE/TSQLCommand)[1]', 'nvarchar(max)');
    SET @user = @data.value('(/EVENT_INSTANCE/LoginName)[1]', 'nvarchar(max)');
	SET @login_name=(SELECT RTRIM(LTRIM(SUBSTRING(@code, CHARINDEX(@knownStartString, @code) + LEN(@knownStartString) , CHARINDEX(@knownEndString,@code) - (CHARINDEX(@knownStartString, @code) + LEN(@knownStartString))))))
CREATE TABLE #Temp (line varchar(500))
SET @othernode=(select replica_server_name from sys.availability_replicas where replica_server_name<>(SELECT @@SERVERNAME))
SET @cmd='EXEC [master].[dbo].[sp_help_revlogin_ag] '''+@login_name+''''
---- TODO: Set parameter values here.
PRINT @cmd
INSERT INTO #Temp(line) EXEC (@cmd)
SET @text = (SELECT line FROM #Temp)

   ---- Set the email data
   SET @mailSubject = 'New SQL Login Created On: ' + @@SERVERNAME;
   SET @mailBody = '<font color="green">A new login was created on SQL Server: <b>'  + @@SERVERNAME + '
   </b>' +   
               ' At: <b>' + CONVERT(nvarchar, getdate(), 120) + '
</b>' +  
               'By user: <b>' + ISNULL(@user, 'Null Login' ) + '
</b>' +  +
               ' The below TSql can be used to create login on other node: <b>'+ISNULL(@othernode,'Null Other Node')+'</br></br>' +
			   '-------------------------------------------------------------------------- <b><br/><br/></font>'+
               ISNULL(@text, 'Null SQL ' )+  '
</b>' ;

      --Send the mail
   EXEC msdb.dbo.sp_send_dbmail
      @recipients=N'SQLServerDBAs@spiritaero.com; Spirit_HP_NEN_SQL@groups.ext.hpe.com',
      @subject=@mailSubject,
      @body = @mailBody,
      @body_format = HTML;
GO

ENABLE TRIGGER [ddl_trig_CreateLogin] ON ALL SERVER
GO


