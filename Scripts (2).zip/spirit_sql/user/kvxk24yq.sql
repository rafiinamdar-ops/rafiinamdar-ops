/*
**  repl_hotfix_install.SQL
**  Patch install script for replication components.
*/

exec sp_vupgrade_replication 