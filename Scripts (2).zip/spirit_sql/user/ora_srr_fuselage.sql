/*
Usage : This table is used to load srr actuals data  
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ora_srr_fuselage'
)

CREATE TABLE [staging].[ora_srr_fuselage](
	[load_date] [datetime] NULL CONSTRAINT [DF_ora_srr_fuselage_load_date]  DEFAULT (getdate()),
	[date_written] [datetime] NULL,
	[ncr_type] [varchar](255) NULL,
	[model] [varchar](50) NULL,
	[unit] [varchar](50) NULL,
	[feature_defect_code] [varchar](255) NULL,
	[feature_description] [varchar](300) NULL,
	[discrepancy_description] [varchar](300) NULL,
	[value_chain] [varchar](255) NULL,
	[charge_mgmt_code] [varchar](255) NULL,
	[defect_qty] [int] NULL,
	[defect_dollars] [float] NULL,
	[scrap_dollars] [float] NULL,
	[admin_cost] [float] NULL,
	[total_srr_dollar] [float] NULL,
	[location] [varchar](50) NULL
)


GO
