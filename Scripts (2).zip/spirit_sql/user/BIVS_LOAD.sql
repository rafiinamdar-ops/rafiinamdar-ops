CREATE TABLE #TEMP(FileList Varchar(MAX))

INSERT INTO #TEMP
EXEC XP_CMDSHELL 'DIR "\\corp\data\it_sqlftp\BIVS_devl\*.txt" /B' 

IF ((SELECT count(*) FROM #TEMP where FileList like '%.txt%')>0)
BEGIN
	SELECT * from #TEMP where FileList
END
ElSE
 SELECT * from #TEMP

Drop Table #TEMP