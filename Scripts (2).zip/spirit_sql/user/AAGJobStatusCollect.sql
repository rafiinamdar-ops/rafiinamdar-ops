

DECLARE @name VARCHAR(50) -- Server Name
DECLARE @cmd varchar(100)

DECLARE db_cursor CURSOR FOR  
select n.replica_server_name from sys.dm_hadr_availability_replica_cluster_nodes n 
	join sys.dm_hadr_availability_replica_cluster_states cs 
	on n.replica_server_name = cs.replica_server_name 
		join sys.dm_hadr_availability_replica_states rs  
		on rs.replica_id = cs.replica_id 
OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @name  

WHILE @@FETCH_STATUS = 0  
BEGIN  
       IF (Select @name) NOT IN (select name from sys.servers)
	   Begin
		EXEC master.dbo.sp_addlinkedserver @server = @name, @srvproduct=N'SQL Server'

		EXEC master.dbo.sp_addlinkedsrvlogin @rmtsrvname = @name, @locallogin = NULL , @useself = N'True'
		END

	SET @cmd=' EXECUTE ['+@name+'].[sqldba].[dbo].[proc_JobStatus_Update]'
	PRINT (@cmd)
	EXEC (@cmd)
	
  FETCH NEXT FROM db_cursor INTO @name  
END  

CLOSE db_cursor  
DEALLOCATE db_cursor 

		