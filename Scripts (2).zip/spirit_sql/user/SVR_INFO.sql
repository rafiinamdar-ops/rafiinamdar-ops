USE [sqldba]
GO

/****** Object:  Table [dbo].[SVR_INFO]    Script Date: 2/17/2016 7:00:36 AM ******/
DROP TABLE [dbo].[SVR_INFO]
GO

/****** Object:  Table [dbo].[SVR_INFO]    Script Date: 2/17/2016 7:00:36 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[SVR_INFO](
	[Server] [varchar](100) NOT NULL,
	[Index] [int] NOT NULL,
	[Name] [varchar](500) NULL,
	[Internal_Value] [varchar](500) NULL,
	[Character_Value] [varchar](500) NULL,
 CONSTRAINT [PK_SVR_INFO] PRIMARY KEY CLUSTERED 
(
	[Server] ASC,
	[Index] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

