
/*
Usage : This table is used to load escape data from kinston and SNZ locations
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_escape_kinsnz'
)

CREATE TABLE [datamart].[fact_escape_kinsnz](
	[program_nm] [varchar](30) NULL,
	[value_chain_cd] [varchar](50) NULL,
	[feature_description] [varchar](100) NULL,
	[ca_count] [int] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [varchar](30) NULL DEFAULT (suser_sname()),
	[modified_date] [datetime] NULL DEFAULT (getdate()),
	[date_written] [date] NULL,
	[location] [varchar](50) NULL
) 

GO


