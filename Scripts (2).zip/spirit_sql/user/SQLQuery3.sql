DECLARE @dbid int
DECLARE @fileid int
DECLARE DB_Cursor CURSOR FORWARD_ONLY
FOR
SELECT database_id,file_id FROM sys.master_files 
    
OPEN DB_Cursor
    
FETCH NEXT FROM DB_Cursor
INTO @dbid,@fileid
    
WHILE @@FETCH_STATUS = 0
BEGIN
 if exists(SELECT * FROM sys.master_files
 where (is_percent_growth =0 and max_size<>-1 and ((cast(((size*8)/1024) as bigint)+((growth*8)/1024)))>=((cast(max_size as bigint)*8)/1024)) 
	and  (((growth*8)/1024)*523)>=(select ROUND(available_bytes/1024/1024,2 )  from sys.dm_os_volume_stats (@dbid , @fileid)) )
	Begin
	SELECT db_name(database_id),(((growth*8)/1024)*523) As gorwth,(select ROUND(available_bytes/1024/1024,2 )  from sys.dm_os_volume_stats (@dbid , @fileid)) as FreeSpace from sys.master_files
	end 
FETCH NEXT FROM DB_Cursor
INTO @dbid,@fileid
END
    
CLOSE DB_Cursor
    
DEALLOCATE DB_Cursor