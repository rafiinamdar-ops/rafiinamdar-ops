/*
Usage : This table is used to load srr target data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_srr_target'
)

CREATE TABLE [datamart].[dim_srr_target](
	[model] [varchar](255) NULL,
	[function] [varchar](255) NULL,
	[year] [int] NOT NULL,
	[date_written] [date] NULL,
	[week_no] [int] NULL,
	[weekly_srr_target] [float] NULL,
	[ytd_srr_target] [float] NULL,
	[weekly_gl_target] [float] NULL,
	[ytd_gl_target] [float] NULL,
	[createddate] [datetime] NULL,
	[modifieddate] [datetime] NULL CONSTRAINT [DF__fact_srr___modif__282DF8C2]  DEFAULT (getdate()),
	[modifiedby] [varchar](30) NULL CONSTRAINT [DF__fact_srr___modif__29221CFB]  DEFAULT (suser_sname()),
	[heading] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[location] [varchar](50) NULL
) 

GO
