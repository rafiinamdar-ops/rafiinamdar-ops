select distinct j.name
,run_status = CASE jh.run_status 
   WHEN 0 THEN 'Failed'
   WHEN 1 THEN 'Succeeded'
   WHEN 2 THEN 'Retry'
   WHEN 3 THEN 'Canceled'
   WHEN 4 THEN 'In progress'
   END
   ,dbo.agent_datetime(jh.run_date, jh.run_time) AS LastRunDateandTime,  
	STUFF(STUFF(STUFF(RIGHT(REPLICATE('0', 8) + CAST(jh.run_duration as varchar(8)), 8), 3, 0, ':'), 6, 0, ':'), 9, 0, ':') 'run_duration (HH:MM:SS)  '
   ,dbo.agent_datetime(js.next_run_date,js.next_run_time ) As NexRunDateTime
   ,jh.message from sysjobs j
LEFT JOIN sysjobhistory jh
ON j.job_id =jh.job_id 
LEFT JOIN sysjobschedules js
ON jh.job_id =js.job_id 
where j.enabled = 1 --and jh.step_id =0 
AND jh.instance_id IN        (SELECT MAX(h.instance_id)             FROM sysjobhistory h GROUP BY (h.job_id))
		and j.name like '%SpritDigi%'
ORDER BY j.name 
