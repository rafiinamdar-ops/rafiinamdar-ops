/*
Usage : This table is used to load the chargemanagement mapping with function for weekly program metrics
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_quality_prg_metrics_mapping'
)

CREATE TABLE [datamart].[dim_quality_prg_metrics_mapping](
	[sno] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[function] [varchar](50) NULL,
	[mgcode_like] [varchar](50) NULL,
	[mgcode_notlike] [varchar](50) NULL,
	[business_unit] [varchar](50) NULL
) 

GO




