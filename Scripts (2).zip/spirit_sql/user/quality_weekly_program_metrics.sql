/*
Usage : This table is used to load weekly program metrics data for Quality

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'quality_weekly_program_metrics'
)


CREATE TABLE [reporting].[quality_weekly_program_metrics](
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL,
	[program] [varchar](30) NULL,
	[business_units] [varchar](30) NULL,
	[headers] [varchar](255) NULL,
	[weeklyactuals] [float] NULL,
	[weeklyplanned] [float] NULL,
	[weekly_variance] [float] NULL,
	[variance_planned] [float] NULL,
	[escape_weekly$_actuals] [float] NULL,
	[actualcumulativeytd] [float] NULL,
	[plannedcumulativeytd] [float] NULL
) 

GO

