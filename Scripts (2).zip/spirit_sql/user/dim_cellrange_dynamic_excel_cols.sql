	/*
Usage :It is a mapping table to read dynamically changing Genpact DT Labour & Safety excel file

Creator/Editor #Date #Comments
Pratheesh N # 2017-10-12 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_cellrange_dynamic_excel_cols'
)

CREATE TABLE datamart.dim_cellrange_dynamic_excel_cols
(
filename varchar(100) not null
,sheet_name varchar(100) not null
,week_no int not null
,cellrange varchar(50) not null
,srno int not null unique
,location varchar(100)
,querystr varchar(500) 
) 

GO

