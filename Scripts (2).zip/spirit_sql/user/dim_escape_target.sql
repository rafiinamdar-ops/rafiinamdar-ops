/*
Usage : This table is used to load escape targets data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_escape_target'
)


CREATE TABLE [datamart].[dim_escape_target](
	[model] [varchar](255) NULL,
	[function] [varchar](255) NULL,
	[year] [int] NOT NULL,
	[date_written] [date] NULL,
	[week_no] [int] NULL,
	[weekly_escape_target] [float] NULL,
	[ytd_escape_target] [float] NULL,
	[createddate] [datetime] NULL,
	[modifieddate] [datetime] NULL CONSTRAINT [DF__fact_esca__modif__25518C17]  DEFAULT (getdate()),
	[modifiedby] [varchar](30) NULL CONSTRAINT [DF__fact_esca__modif__2645B050]  DEFAULT (suser_sname()),
	[heading] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[location] [varchar](50) NULL
) 


GO



