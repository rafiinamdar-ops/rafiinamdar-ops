SELECT convert(date,a.[UTCOccurrenceDateTime]), b.Name,COUNT(*) AS COUNTS
FROM [SQLdmRepository].[dbo].[Alerts] a 
INNER JOIN [SQLdmRepository].[dbo].[MetricInfo] b  ON a.Metric = b.Metric 
WHERE b.Name in ('Database Status','Table Fragmentation (Percent)','Filegroup Space Full (Percent)','Session CPU Time (Seconds)')
GROUP BY convert(date,a.[UTCOccurrenceDateTime]), b.Name
ORDER BY convert(date,a.[UTCOccurrenceDateTime]) DESC,COUNTS DESC

SELECT convert(date,a.[UTCOccurrenceDateTime]),COUNT(*) AS COUNTS
FROM [SQLdmRepository].[dbo].[Alerts] a 
INNER JOIN [SQLdmRepository].[dbo].[MetricInfo] b  ON a.Metric = b.Metric 
GROUP BY convert(date,a.[UTCOccurrenceDateTime])
ORDER BY convert(date,a.[UTCOccurrenceDateTime]) DESC,COUNTS DESC