/*
Usage : To find source data for assetcost 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_asset_cost'
)

CREATE TABLE staging.maximo_asset_cost
(
	startdate nvarchar(21),
	wonum nvarchar(20),
	description nvarchar(100),
	reportdate nvarchar(21),
	actfinish nvarchar(21),
	
	busunit nvarchar(10),
	reqpri nvarchar(10),
	assetlocpriority float,
	wo_type varchar(16),
	assetnum nvarchar(25),
	
	labor_hrs float,
	labor_cost numeric(10,2),
	cause nvarchar(8),
	failuremark_desc nvarchar(100),
	problemcode nvarchar(8),
	
	wo_priority float,
	siteid nvarchar(8),
	maintgrp nvarchar(10),
	stockcost numeric(10, 2),
	nonstock_cost numeric(10, 2) 
)
GO

