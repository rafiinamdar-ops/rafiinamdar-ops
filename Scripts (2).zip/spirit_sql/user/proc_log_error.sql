/*
Usage : This SP is used to load stored procedure log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_log_error')
 DROP PROC [datamart].[proc_log_error]
GO

CREATE PROC [datamart].[proc_log_error] @errorprocedure VARCHAR(50),
								  @errorline INT,
								  @errornumber INT,
								  @errormessage VARCHAR(2048),
								  @errorseverity INT,
								  @errorstate INT
					  
AS
BEGIN
INSERT INTO [datamart].[log_error]
(
[procedure_name]
      ,line_no
      ,[message]
      ,[error_number]
      ,severity
      ,[state]
      ,spid
      ,[user_name]
      ,created_date
	  )
	  VALUES
	  (
	  @errorprocedure
	  ,@errorline
	  ,@errormessage
	  ,@errornumber
	  ,@errorseverity
	  ,@errorstate
	  ,@@SPID
	  ,SYSTEM_USER
	  ,GETDATE()
	  )

	  END


GO


