/*
Usage : This datamrt table is used to populate the data for quality attribute for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_srr_facility'
)

CREATE TABLE datamart.fact_srr_facility
(
nc_key varchar(50)
,dtwritten datetime
,model_ist3 varchar(50)
,unit float
,defect_qty float

,defect_dollars float
,scrap_dollars float
,admin_cost float
,mgcode varchar(50)
,featdef_cd varchar(50)

,feat_decrip varchar(100)
,desc_description varchar(100)
,ncr_type varchar(50)
,value_chain varchar(50)
,parts varchar(100)

,origshop varchar(50)
,reasoncd varchar(50)
,code_set_id varchar(50)
) 

GO



