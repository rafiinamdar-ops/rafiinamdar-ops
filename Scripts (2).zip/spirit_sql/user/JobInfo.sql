SELECT ste.[job_id]
      ,job.[name]
      ,[step_id]
      ,[step_name]
      ,[command]
      ,[server]
      ,[database_name]
      ,[database_user_name]

FROM [msdb].[dbo].[sysjobsteps] AS ste
      INNER JOIN [msdb].dbo.sysjobs AS job
            ON ste.job_id = job.[job_id]