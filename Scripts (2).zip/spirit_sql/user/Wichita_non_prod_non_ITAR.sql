USE [sqldba]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

IF NOT EXISTS (select * from sys.objects
                 where object_id = OBJECT_ID(N'[dbo].[DDBackup_History]')  
                   and type in (N'U')
               )
  BEGIN 
    CREATE TABLE [dbo].[DDBackup_History](	
	    [DATABASE_NAME] [varchar](100) NOT NULL,
	    [SERVER_NAME] [varchar](40) NOT NULL,
	    [START_DATETIME] datetime NOT NULL,
	    [BACKUP_TYPE] [varchar](10) NOT NULL,
	    [LINE_NO] [int] NOT NULL,
	    [MSG_LINE] [varchar](1000) NULL,	
     CONSTRAINT [PK_DDBackup_History] PRIMARY KEY CLUSTERED 
    (
	    [DATABASE_NAME],[SERVER_NAME],[START_DATETIME],[BACKUP_TYPE],[LINE_NO]  ASC
    ) WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON, FILLFACTOR = 10) ON [PRIMARY]
    ) ON [PRIMARY]
  END 

GO

SET ANSI_PADDING OFF
GO



use [sqldba]
go 

delete from dbo.DDBackup_History 

delete from dbo.variable 
where varname in ('DDBackupServer', 'DDDomain', 'DDBackupRetention') 

insert into dbo.variable 
  values('DDBackupServer', 'ddb-ict-mgt.corp.spiritaero.com') 

insert into dbo.variable 
  values('DDDomain', 'corp.spiritaero.com')

insert into dbo.variable 
  values('DDBackupRetention', '15') 


USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_StartBackupDD]    Script Date: 04/03/2015 16:47:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

IF EXISTS (select * from sys.objects where type = 'P' and name = 'proc_StartBackupDD') 
  DROP PROCEDURE proc_StartBackupDD

GO

CREATE   Procedure [dbo].[proc_StartBackupDD] @sBackupType varchar(4)
as
DECLARE dblist CURSOR READ_ONLY FOR 
SELECT distinct sysdb.NAME 
   FROM master.dbo.sysdatabases sysdb
   Where sysdb.name not in (select * from BACKUP_EXCLUSION_LIST)
   and sysdb.name not in ('master', 'msdb')
   and sysdb.name in (select name from sys.databases where state_desc='online')
   order by sysdb.Name
DECLARE @name nvarchar(128)
OPEN dblist
FETCH NEXT FROM dblist INTO @name
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
		exec sqldba..proc_BackupDD @sBackupType, @name
	END
	FETCH NEXT FROM dblist INTO @name
END
CLOSE dblist
DEALLOCATE dblist
/* Backup master and msdb databases last so all other backups are in msdb*/
exec sqldba..proc_BackupDD 'db', 'master'
exec sqldba..proc_BackupDD 'db', 'msdb'




GO

USE [SQLDBA]
GO

/****** Object:  StoredProcedure [dbo].[proc_BackupDD]    Script Date: 04/29/2015 06:57:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO

IF EXISTS (select * from sys.objects where type = 'P' and name = 'proc_BackupDD') 
  DROP PROCEDURE proc_BackupDD

GO

CREATE PROCEDURE [dbo].[proc_BackupDD] @sBackupType varchar(5) = '', @sdbname nvarchar(128) = '' 
as
/* Procedure to back up transaction log. Expects:                           */
/* 	@sBackupType  --> Type of backup, db, diff, or tlog	                    */
/*  @sdbname      --> Name of database to backup   	                        */
/* Written by: 		Clint Richardson (copied from prod_Backup)              */ 					                        
/* Date Written:	02/02/2015			                                    */
/* Revision Log					                                            */


declare @BackupPathLocal varchar(1000)
declare @BackupPath varchar(1000)
declare @BackupServer varchar(50)
declare @sDRPath varchar(1000)
declare @sFullFileName varchar(1000)
declare @sFileName varchar(500)
declare @sDirName varchar(1000)
declare @return_line varchar(1000) 
declare @ErrOccurred bit
declare @iError int
declare @db_backup_finish_date datetime
declare @rc int
declare @sOption as varchar(50)
declare @sql as nvarchar(2000)
declare @cmd as varchar(2000)
declare @Retention as int
declare @dbbackupmode varchar(10)
declare @lastbackupmode varchar(10)
declare @dbcreatedate datetime

declare @saveerror int 
declare @orecipients nvarchar(max)
Set @orecipients = 'Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;Spirit_HP_NEN_SQL_ITAR@groups.ext.hpe.com;SQLServerDBAs@spiritaero.com' 
declare @msgtext nvarchar(max)
declare @osubject nvarchar(255) 
declare @goodbackup as int
declare @linectr as int 
declare @current_datetime datetime  
declare @DDserver varchar(50) 
declare @DDBackupServer varchar(1000) 
declare @DDDomain     varchar(50)
declare @DDBackupDays varchar(10)
declare @DDBackupDaysN int 
declare @DDbackuptype varchar(10)
declare @DDbackuptypO varchar(10)  
declare @DDretention  varchar(25) 
declare @DDdbname     varchar(150) 
declare @DDname       varchar(500) 
declare @DDdesc       varchar(500) 
declare @DDfullparm   varchar(2000) 
declare @DDaparm1     varchar(50)
Set @DDaparm1='NSR_DFA_SI=TRUE'
declare @DDaparm2     varchar(50)
Set @DDaparm2= 'NSR_DFA_SI_USE_DD=TRUE'
declare @DDaparm3     varchar(1050)  
declare @DDaparm3base varchar(25)
Set @DDaparm3base = 'NSR_DFA_SI_DD_HOST='
declare @DDaparm4     varchar(50) 
Set @DDaparm4= 'NSR_DFA_SI_DD_USER=dbauser' 
declare @DDaparm5     varchar(50)   
Set @DDaparm5 = 'NSR_DFA_SI_DEVICE_PATH=/MSSQL'
declare @DDBackupmsg  varchar(200) 
declare @save_log_lsn numeric(25)


DECLARE @cmd_output_tbl table (output varchar(1000))  
DECLARE READ_OUTPUT_CURSOR CURSOR for 
  select output from @cmd_output_tbl 

set @current_datetime = getdate() 

if @sBackupType not in ('db','tlog','diff') 
	or len(@sdbname)     = 0 
	or len(@sBackupType) = 0	
	BEGIN
		print '
/* Procedure to back up transaction log. Expects:                               */
/* 		@sBackupType  --> Type of backup db, diff, or tlog	        	        */
/*      @sdbname      --> Name of database to backup   	                        */ 
/*                                                                              */'
		goto ExitBackup
	END
	
set @ErrOccurred = 0
/* See if database is in read only mode */
Create table #t_options (OptionName varchar(50), CurrentSetting varchar(10))

/* DO BACKUP READ-ONLY DATABASES IN DATA DOMAIN -- So following code is commented out  */  
/*    insert into #t_options  exec sp_dboption @sdbName, 'read only'
   set @sOption = (select CurrentSetting from #t_options where OptionName = 'read only')
if @sOption = 'ON'   /* Can't back database up if its read only, issue alert and abort */
   BEGIN
      print 'Database ' +@sdbName+' is in READ ONLY and cannot be backed up.'
      goto ExitBackup 
   END  */ 


/* Verify Backup Directory exists, if not then create it  */
set @BackupServer = (select VarValue from SQLDBA.dbo.Variable where VarName = 'BackupServer')
set @BackupPathLocal = (select VarValue from SQLDBA.dbo.Variable where VarName = 'BackupPath')
set @BackupPath = @BackupPathLocal
if @BackupServer <> 'Local'
	BEGIN
		set @BackupPath = '\\'+@BackupServer+'\'+@BackupPathLocal 
		set @BackupPathLocal = replace(@BackupPathLocal,'$',':')
	END
print @BackupPath
print 'Backup path = ' + @BackupPath
set @sDirName = (select '\' + @sdbname)
set @sDirName = @BackupPath + @sDirName
print 'Full dirname = ' + @sDirName
if not exists (select * from dbo.sysobjects 
    where id = object_id(N'[dbo].[zLogList]') 
    and OBJECTPROPERTY(id, N'IsUserTable') = 1)
        BEGIN
            CREATE TABLE [dbo].[zLogList] (
            [cmdout] [varchar] (1000) NULL ,
            [f_name] [varchar] (500) NULL ,
            [f_date] [datetime] NULL 
            ) ON [PRIMARY]
        END
truncate table zLogList 
set @cmd = 'exec master..xp_cmdshell ''dir '+@BackupPath+''''
insert into zLogList (cmdout) exec (@cmd)
update zloglist 
    set   f_name = substring(cmdout,40,100)
if (select count(*) from zLogList where upper(f_name) = upper(@sdbname)) < 1
    begin
	/* Create backup directory */
        set @cmd = 'mkdir '+@sDirName
        exec master..xp_cmdshell @cmd
    end
    
RestartBackup:
/* Build Data Domain parameters */

IF ((SELECT SERVERPROPERTY ('InstanceName')) is NULL)
set @DDdbname = 'MSSQL:' + @sdbname 
ELSE
set @DDdbname = 'MSSQL$'+CAST((SELECT SERVERPROPERTY ('InstanceName'))As varchar)+':' + @sdbname 
set @DDbackuptype = case 
                      when @sBackupType = 'db'   then 'full'
                      when @sBackupType = 'diff' then 'diff' 
                      when @sBackupType = 'tlog' then 'incr' 
                      else 'badtype' 
                    end 
set @DDname =  @@servername + '.' + @sdbname + '.' + upper(@DDbackuptype) 
print 'DDbackuptype = ' + @DDbackuptype 
set @DDdesc = upper(@DDbackuptype) + ' backup taken on ' + convert(varchar(20), GETDATE(), 20) 
print 'DDdesc = ' + @DDdesc 
set @DDbackuptypO = @DDbackuptype

/* add -R for incr (tlog) backups so the logfile will not get truncated)   */ 

-- if @DDbackuptype = 'incr' 
--   BEGIN
--     set @DDbackuptype = @DDbackuptype + ' -R'
--   END  
  
set @DDBackupmsg = 'Backing up of ' + @sdbname + ' succeeded' 
set @osubject = 'UNSUCCESSFUL DATA DOMAIN BACKUP on server ' + @@SERVERNAME + ' for DB ' + @sdbname
set @msgtext = 'No successful backup message found for ' + '
    ' + 'Database = ' + @sdbname + '
    ' + 'Server = ' + @@SERVERNAME + '
    ' + 'Backup type = ' + @DDBackuptypO + '
    ' + 'Backup start = ' + CONVERT(varchar, @current_datetime, 120)
 
set @DDDomain = (select VarValue from SQLDBA.dbo.Variable where VarName = 'DDDomain')
if @DDDomain is NULL 
  BEGIN 
    set @msgtext = @msgtext + '
        ' + 'Missing Data Domain Server Domain value in sysdba VARIABLE table -- cannot continue '  
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitBackup;
  END  
    
set @DDserver =  CAST((SELECT SERVERPROPERTY('MachineName')) AS VARCHAR) + '.' + @DDDomain 
print 'DDserver = ' + @DDserver

set @DDBackupDays = (select VarValue from SQLDBA.dbo.Variable where VarName = 'DDBackupRetention')
if @DDBackupDays is NULL 
  BEGIN 
    set @msgtext = @msgtext + '
        ' + 'Missing Data Domain Server Backup Retention Days value in sysdba VARIABLE table -- cannot continue '  
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitBackup;
  END   
print 'DDBackupDays = ' + @DDBackupDays 
set @DDBackupDaysN = CONVERT(INT, @DDBackupDays)   
print 'DDBackupDaysN = ' + CAST(@DDBackupDaysN as varchar(4)) 

set @DDretention = convert(varchar(10),(getdate() + @DDBackupDaysN), 101) + ' 23:59:59' 
print 'DDretention = ' + @DDretention

set @DDBackupServer = (select VarValue from SQLDBA.dbo.Variable where VarName = 'DDBackupServer')
if @DDBackupServer is NULL 
  BEGIN 
    set @msgtext = @msgtext + '
        ' + 'Missing Data Domain Server value in sysdba VARIABLE table -- cannot continue '  
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'        
        goto ExitBackup;
  END 
set @DDaparm3 = @DDaparm3base + @DDBackupServer    
set @DDfullparm = '-q -c ' + 
                  @DDserver     + ' -l '   + 
                  @DDbackuptype + ' -N "'  + 
                  @DDname       + '" -b "' + 
                  @DDdesc       + '" -y "' + 
                  @DDretention  + '" -a "' + 
                  @DDaparm1     + '" -a "' + 
                  @DDaparm2     + '" -a "' + 
                  @DDaparm3     + '" -a "' + 
                  @DDaparm4     + '" -a "' + 
                  @DDaparm5     + '" "' + 
                  @DDdbname     + '"' 
                  
print 'END of DD variables'                
 
--set @BackupPath = (select VarValue from SQLDBA.dbo.Variable where VarName = 'BackupPath')


if @sBackupType <> 'db'
  BEGIN
	/* Check to make sure that db is not set to 'trunc. log on chkpt.' */
	/*  Comment out old technique below   */ 
/* 	Set @sOption = NULL
	truncate table #t_options
	insert into #t_options  exec sp_dboption @sdbName, 'trunc. log on chkpt.'
	set @sOption = (select CurrentSetting from #t_options where OptionName = 'trunc. log on chkpt.')
	drop table #t_options
	if @sOption = 'ON'   /* If so, change backup type to 'db' and restart */
		Begin
			print 'Changing backup type to db due to trunc. log on chkpt. being set...'
			set @sBackupType = 'db'
			goto RestartBackup
		end  */ 
		
    /*  Replace with new technique here    */ 

	set @save_log_lsn = NULL 
	set @save_log_lsn = (select last_log_backup_lsn 
	                       from [master].[sys].[database_recovery_status]
						   where DB_NAME(database_id) = @sdbName
						)	
    if @save_log_lsn is NULL   /* If so, change backup type to 'db' and restart */
		Begin
			print 'Changing backup type to db due to trunc. log on chkpt. being set...'
			set @sBackupType = 'db'
			goto RestartBackup
		end 					 
		
	/* Check to make sure a full backup exists */
	
	select top 1 @db_backup_finish_date = backup_finish_date 
	  from msdb.dbo.backupset 
	  where database_name = @sdbname 
	    and type = 'D' -- Database
	  order by backup_finish_date desc
	set @dbcreatedate = (select create_date from sys.databases where name = @sdbname)
	
	/* If no backup exists, change backup type to 'db' and restart */
	
	if (@db_backup_finish_date is NULL) OR (@db_backup_finish_date < @dbcreatedate) 
	  begin	
		print 'database ' + @sdbname + 
		    ' has no current backup history (either backup not done or msdb data is lost). Changing backup type to db'
		set @sBackupType = 'db'
		goto RestartBackup
	  end
   	set @lastbackupmode = (select top 1 recovery_model 
	                          from msdb.dbo.backupset 
	                         where database_name = @sdbname
	                           and type = 'D'
	                         order by backup_finish_date desc)
	set @dbbackupmode = (select recovery_model_desc from sys.databases where name = @sdbname)
	if  @dbbackupmode <> @lastbackupmode
	  begin
		print 'database ' + @sdbname + ' recovery model and backup recovery model do not match. Changing backup type to db'
		set @sBackupType = 'db'
		goto RestartBackup
	  end
	if  @dbbackupmode = 'SIMPLE'
	  begin
		print 'database ' + @sdbname + ' set to SIMPLE recovery. Changing backup type to db'
		set @sBackupType = 'db'
		goto RestartBackup
	  end
	END
	
	print 'END of BackupType check' 
	

--  Invoke Avomar Data Domain backup here 


print 'Data Domain backup parms=' + @DDfullparm 
    
delete from @cmd_output_tbl 
set @cmd = 'ddbmsqlsv.exe ' + @DDfullparm  /* + ' > ' + @DDFilename  */ 
print ' cmd variable = ' + @cmd 
-- set @cmd = 'exec master.xp_cmdshell ' + 'ddbmsqlsv.exe ' + @DDfullparm   /* + ' > ' + @DDFilename   */ 
print 'BEFORE BACKUP COMMAND ISSUED' 
-- exec @rc = master..xp_cmdshell @cmd 
-- exec master..xp_cmdshell @cmd   
print 'AFTER BACKUP COMMAND ISSUED' 
-- print 'return code = ' + cast(@rc as varchar(10))
-- print 'cmd rc = ' + @rc 
-- exec master..xp_cmdshell @cmd 
-- print ' cmd variable = ' + @cmd 
insert into @cmd_output_tbl  exec master..xp_cmdshell @cmd  
set @rc = (select COUNT(*)from @cmd_output_tbl) 
print 'Rows returned from backup command = ' + cast(@rc as varchar(10))  

set @rc = (select COUNT(*) from 
             (select distinct database_name, server_name, start_datetime
                FROM [sqldba].[dbo].[DDBackup_History] 
             ) as distinctquery
          ) 
print '# distinct backups rows = ' + cast(@rc as varchar(10))

if @rc > 1
  BEGIN 
    delete from [dbo].[DDBackup_History]  
      where database_name = @sdbname
        and server_name = @@servername
        and start_datetime < (GETDATE() - 60) 
  END 
  
set @goodbackup = 0 
set @linectr = 0 

open READ_OUTPUT_CURSOR
fetch next from READ_OUTPUT_CURSOR into @return_line 
while @@FETCH_STATUS = 0 
  BEGIN 
 --   print 'Next return line = ' + @return_line 
    if CHARINDEX(@DDBackupmsg, @return_line, 1)  > 0 
      BEGIN 
        set @goodbackup = 1        
      END 
    set @linectr = @linectr + 1
    insert into [dbo].[DDBackup_History]  
       values (@sdbname, @@SERVERNAME, @current_datetime, @DDBackuptypO, @linectr, @return_line) 
    set @saveerror = @@ERROR
    if @saveerror <> 0 
      BEGIN         
        set @msgtext = @msgtext + '
        ' + 'Bad insert to Backup_History table, error = ' + cast(@saveerror as varchar(10))
        EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
          @subject=@osubject, 
          @body=@msgtext,
          @body_format='TEXT'
        CLOSE READ_OUTPUT_CURSOR
        DEALLOCATE READ_OUTPUT_CURSOR
        goto ExitBackup;               
      END  
    fetch next from READ_OUTPUT_CURSOR into @return_line 
  END 
  
print 'good backup flag = ' + cast(@goodbackup as varchar(2)) 
if @goodbackup = 0 
  BEGIN
    set @msgtext = @msgtext + '    
    ' + '--> Check Backup_History table in sqldba database for detailed output <--'   
    EXEC msdb.dbo.sp_send_dbmail @recipients=@orecipients,
      @subject=@osubject, 
      @body=@msgtext,
      @body_format='TEXT' 
  END  
      
CLOSE READ_OUTPUT_CURSOR
DEALLOCATE READ_OUTPUT_CURSOR     

ExitBackup:
--drop table #t_options












GO


