/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6544)
    Source Database Engine Edition : Microsoft SQL Server Standard Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2012
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [sqldba]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER OFF
GO




--ALTER PROC [dbo].[proc_get_outdated_statistics_lb] @sdays int = NULL
--AS
SET NOCOUNT ON;
DECLARE @dbid int;
DECLARE @dbname VARCHAR(150) -- database name 
DECLARE @sql varchar(max);
DECLARE @uscmd varchar(300);
DECLARE @Days int;
SET @Days=1

CREATE TABLE #Temp (cmd varchar(500) )

		DECLARE db CURSOR FAST_FORWARD FOR SELECT  [name] FROM master.sys.databases 
		where [name]  in ('sqldba','CAI','BAI','CEOActions','ADSS')

		

OPEN db;

/* Get database(s) to be processed */
FETCH NEXT FROM db INTO  @dbname
WHILE (@@fetch_status <> -1)
BEGIN
	IF (@@fetch_status <> -2)
	BEGIN
		set @sql = 'USE ['+@dbname+'] 
				SELECT 
			--  id                    AS [Table ID]
			--, OBJECT_NAME(id)       AS [Table Name]
			--, name                  AS [Index Name]
			--, STATS_DATE(id, indid) AS [LastUpdated]
			--, rowmodctr             AS [Rows Modified]
			''UPDATE STATISTICS ['+@dbname+'].[''+OBJECT_SCHEMA_NAME(id)+''].['' +OBJECT_NAME(id)+''](''+name+'')''+''   WITH FULLSCAN''
			FROM sys.sysindexes 
			WHERE STATS_DATE(id, indid)<=DATEADD(DAY,-1,GETDATE()) 
				AND rowmodctr>10 AND (OBJECTPROPERTY(id,''IsUserTable''))='+CAST(@Days as VARCHAR)

	--print @sql
	--exec (@sql)
	INSERT INTO #Temp exec (@sql)
		
	END
	FETCH NEXT FROM db INTO  @dbname
END

CLOSE db
DEALLOCATE db


DECLARE db_cursor CURSOR FOR  
SELECT cmd
FROM #Temp


OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @uscmd  

WHILE @@FETCH_STATUS = 0  
BEGIN  
      PRINT 'Updating Stats : '+@uscmd 
	  Exec(@uscmd)      

       FETCH NEXT FROM db_cursor INTO @uscmd
END  

CLOSE db_cursor  
DEALLOCATE db_cursor 
--SELECT * FROM #Temp 
DROP TABLE  #Temp



--GO


