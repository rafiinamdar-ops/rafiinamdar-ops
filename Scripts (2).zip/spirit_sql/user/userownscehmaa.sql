use [SpiritDigi]   
go
;with objects_cte as
(
    select
		@@SERVERNAME As ServerName,
		DB_NAME() AS [DatabaseName],
		SCHEMA_NAME(o.schema_id) as schemaname
        ,      case
            when o.principal_id is null then s.principal_id
            else o.principal_id
        end as principal_id
    from sys.objects o

    inner join sys.schemas s
    on o.schema_id = s.schema_id
    where o.is_ms_shipped = 0
    and o.type in ('U', 'FN', 'FS', 'FT', 'IF', 'P', 'PC', 'TA', 'TF', 'TR', 'V')
)
select --distinct
	cte.ServerName,
	cte.[DatabaseName],
	'ALTER AUTHORIZATION ON SCHEMA::['+cte.schemaname+'] TO dbo',
         dp.name As UserName
from objects_cte cte
inner join sys.database_principals dp
on cte.principal_id = dp.principal_id
where dp.name like 'CORP\s%'


SELECT  [object_type]
      ,[object_id]
      ,[principal_id]
      ,[permission_type]
      ,[is_deny]
      ,[grantor_id]
   , 'EXEC catalog.revoke_permission @object_type=' + CAST([object_type] AS VARCHAR)
         + ', @object_id=' + CAST([object_id] AS VARCHAR)
         + ', @principal_id=' + CAST(principal_id AS VARCHAR)
         + ', @permission_type=' + CAST(permission_type AS VARCHAR)
  FROM [SSISDB].[catalog].[explicit_object_permissions]
  WHERE principal_id = USER_ID('CORP\S9038970')


