USE [SpiritDigi] 
GO

/****** Object:  DatabaseRole [db_executor]    Script Date: 2/28/2019 4:52:24 AM ******/
CREATE ROLE [db_executor]
GO


GRANT EXECUTE  TO [db_executor]