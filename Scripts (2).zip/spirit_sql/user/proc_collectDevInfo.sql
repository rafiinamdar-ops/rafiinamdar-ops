USE [SQLDBA]
GO

/****** Object:  StoredProcedure [dbo].[proc_collectDevInfo]    Script Date: 11/22/2017 1:20:13 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[proc_collectDevInfo] (@SrvName varchar(100))
AS

DECLARE @Servername varchar(100)
SET @Servername=@SrvName

--SET @Servername='SQL-FAC-02.FACICT.SPIRITAERO.COM\DEV'
DECLARE @name VARCHAR(100) -- database name  
/****** Object:  Table [dbo].[!DB_Devpr_Info]    Script Date: 6/8/2017 12:29:57 AM ******/
DECLARE @cmd varchar(1000)
DECLARE @objectname varchar(50)

CREATE TABLE #tmpServerList
(Name varchar(100))

SET @cmd='INSERT INTO #tmpServerList select name from ['+@Servername+'].master.sys.databases 
			WHERE name NOT IN (''master'',''msdb'',''tempdb'',''model'',''ReportServer'',''ReportServerTempDB'',''SSISDB'')  and state_desc not in (''OFFLINE'')'
EXEC (@cmd)
SET @cmd='DELETE sqldba.dbo.[DB_Devpr_Info_ALL] WHERE [Server_Name] ='''+@Servername+''''
PRINT @Cmd
EXEC (@cmd)
DECLARE db_cursor CURSOR FOR  

SELECT name from #tmpServerList

OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @name  

WHILE @@FETCH_STATUS = 0  
BEGIN 

SET @cmd='IF EXISTS (select 1 from ['+@Servername+'].['+@name+'].sys.objects where name=''!DB_Devpr_Info'')
			IF (select count(*) from ['+@Servername+'].['+@name+'].[dbo].[!DB_Devpr_Info] )>0
				INSERT INTO sqldba.dbo.[DB_Devpr_Info_ALL] select '''+@Servername+''' ,*,getdate() from ['+@Servername+'].['+@name+'].[dbo].[!DB_Devpr_Info] '
--PRINT @Cmd
EXEC (@cmd)

 FETCH NEXT FROM db_cursor INTO @name  
END  


CLOSE db_cursor  
DEALLOCATE db_cursor 

DROP TABLE #tmpServerList

GO

