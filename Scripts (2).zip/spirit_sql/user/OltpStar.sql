use master
go

if exists (select * from sysdatabases where name='OLTP')
begin
  raiserror('Dropping existing OLTP database ....',0,1)
  DROP database OLTP
end
GO

declare @dbpath varchar(255)
select @dbpath = substring(filename,1,len(filename)-10) from sysdatabases where name = 'master'

exec('CREATE DATABASE OLTP
ON 
( 	NAME=OLTP_dat,
	FILENAME=''' + @dbpath + 'oltp.mdf'',
 	SIZE= 5MB)
  
LOG ON
(	NAME=oltp_log,
 	FILENAME='''+ @dbpath + 'oltp.ldf'',
 	SIZE=5MB)')
GO

set quoted_identifier on
GO

set quoted_identifier on
GO

/****** Object:  Table [OLTP].[dbo].[Order_Details]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Order_Details]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Order_Details]
GO

/****** Object:  Table [OLTP].[dbo].[Payments]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Payments]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Payments]
GO

/****** Object:  Table [OLTP].[dbo].[EmployeeTerritories]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[EmployeeTerritories]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[EmployeeTerritories]
GO

/****** Object:  Table [OLTP].[dbo].[Orders]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Orders]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Orders]
GO

/****** Object:  Table [OLTP].[dbo].[Products]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Products]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Products]
GO

/****** Object:  Table [OLTP].[dbo].[TerritoryRegion]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[TerritoryRegion]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[TerritoryRegion]
GO

/****** Object:  Table [OLTP].[dbo].[Brands]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Brands]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Brands]
GO

/****** Object:  Table [OLTP].[dbo].[Customers]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Customers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Customers]
GO

/****** Object:  Table [OLTP].[dbo].[Employees]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Employees]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Employees]
GO

/****** Object:  Table [OLTP].[dbo].[Payment_Methods]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Payment_Methods]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Payment_Methods]
GO

/****** Object:  Table [OLTP].[dbo].[Region]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Region]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Region]
GO

/****** Object:  Table [OLTP].[dbo].[Shipping_Methods]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Shipping_Methods]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Shipping_Methods]
GO

/****** Object:  Table [OLTP].[dbo].[Territories]    Script Date: 4/3/98 4:18:49 PM ******/
if exists (select * from sysobjects where id = object_id(N'[OLTP].[dbo].[Territories]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [OLTP].[dbo].[Territories]
GO

/****** Object:  Table [OLTP].[dbo].[Brands]    Script Date: 4/3/98 4:18:57 PM ******/
CREATE TABLE [OLTP].[dbo].[Brands] (
	[BrandID] [int] IDENTITY (1, 1) NOT NULL,
	[BrandDescription] [char] (80) NOT NULL ,
	CONSTRAINT [PK_Brands] PRIMARY KEY  NONCLUSTERED 
	(
		[BrandID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[Customers]    Script Date: 4/3/98 4:18:57 PM ******/
CREATE TABLE [OLTP].[dbo].[Customers] (
	[CustomerID] [int] IDENTITY (1, 1) NOT NULL ,
	[CompanyName] [varchar] (50) NULL ,
	[ContactFirstName] [varchar] (30) NULL ,
	[ContactLastName] [varchar] (50) NULL ,
	[BillingAddress] [varchar] (255) NULL ,
	[City] [varchar] (50) NULL ,
	[StateOrProvince] [varchar] (20) NULL ,
	[PostalCode] [varchar] (20) NULL ,
	[Country] [varchar] (50) NULL ,
	[ContactTitle] [varchar] (50) NULL ,
	[PhoneNumber] [varchar] (30) NULL ,
	[FaxNumber] [varchar] (30) NULL ,
	CONSTRAINT [PK_Customers_1__15] PRIMARY KEY  CLUSTERED 
	(
		[CustomerID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[Employees]    Script Date: 4/3/98 4:18:58 PM ******/
CREATE TABLE [OLTP].[dbo].[Employees] (
	[EmployeeID] [int] IDENTITY (1, 1) NOT NULL ,
	[FirstName] [varchar] (50) NULL ,
	[LastName] [varchar] (50) NULL ,
	[Title] [varchar] (50) NULL ,
	[EmailName] [varchar] (50) NULL ,
	[Extension] [varchar] (30) NULL ,
	[WorkPhone] [varchar] (30) NULL ,
	CONSTRAINT [PK_Employees_1__15] PRIMARY KEY  CLUSTERED 
	(
		[EmployeeID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[Payment_Methods]    Script Date: 4/3/98 4:18:59 PM ******/
CREATE TABLE [OLTP].[dbo].[Payment_Methods] (
	[PaymentMethodID] [int] IDENTITY (1, 1) NOT NULL ,
	[PaymentMethod] [varchar] (50) NULL ,
	CONSTRAINT [PK_Payment_Methods_1__15] PRIMARY KEY  CLUSTERED 
	(
		[PaymentMethodID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[Region]    Script Date: 4/3/98 4:18:59 PM ******/
CREATE TABLE [OLTP].[dbo].[Region] (
	[RegionID] [int] IDENTITY (1, 1) NOT NULL ,
	[RegionDescription] [char] (50) NOT NULL ,
	CONSTRAINT [PK_Region] PRIMARY KEY  NONCLUSTERED 
	(
		[RegionID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[Shipping_Methods]    Script Date: 4/3/98 4:19:00 PM ******/
CREATE TABLE [OLTP].[dbo].[Shipping_Methods] (
	[ShippingMethodID] [int] IDENTITY (1, 1) NOT NULL ,
	[ShippingMethod] [varchar] (20) NULL ,
	CONSTRAINT [PK_Shipping_Methods_1__15] PRIMARY KEY  CLUSTERED 
	(
		[ShippingMethodID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[Territories]    Script Date: 4/3/98 4:19:01 PM ******/
CREATE TABLE [OLTP].[dbo].[Territories] (
	[TerritoryID] [varchar] (20) NOT NULL ,
	[TerritoryDescription] [char] (50) NOT NULL ,
	CONSTRAINT [PK_Territories] PRIMARY KEY  NONCLUSTERED 
	(
		[TerritoryID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [OLTP].[dbo].[EmployeeTerritories]    Script Date: 4/3/98 4:19:02 PM ******/
CREATE TABLE [OLTP].[dbo].[EmployeeTerritories] (
	[EmployeeID] [int] NOT NULL ,
	[TerritoryID] [varchar] (20) NOT NULL ,
	CONSTRAINT [PK_EmployeeTerritories] PRIMARY KEY  NONCLUSTERED 
	(
		[EmployeeID],
		[TerritoryID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_EmployeeTerritories_Employees] FOREIGN KEY 
	(
		[EmployeeID]
	) REFERENCES [OLTP].[dbo].[Employees] (
		[EmployeeID]
	),
	CONSTRAINT [FK_EmployeeTerritories_Territories] FOREIGN KEY 
	(
		[TerritoryID]
	) REFERENCES [OLTP].[dbo].[Territories] (
		[TerritoryID]
	)
)
GO

/****** Object:  Table [OLTP].[dbo].[Orders]    Script Date: 4/3/98 4:19:02 PM ******/
CREATE TABLE [OLTP].[dbo].[Orders] (
	[OrderID] [int] IDENTITY (1, 1) NOT NULL ,
	[CustomerID] [int] NOT NULL ,
	[EmployeeID] [int] NOT NULL ,
	[OrderDate] [datetime] NULL ,
	[PurchaseOrdNumber] [varchar] (30) NULL ,
	[ShipName] [varchar] (50) NULL ,
	[ShipAddress] [varchar] (255) NULL ,
	[ShipCity] [varchar] (50) NULL ,
	[ShipState] [varchar] (50) NULL ,
	[ShipPostalCode] [varchar] (20) NULL ,
	[ShipCountry] [varchar] (50) NULL ,
	[ShipPhoneNumber] [varchar] (30) NULL ,
	[ShipDate] [datetime] NULL ,
	[ShippingMethodID] [int] NULL ,
	[FreightCharge] [money] NULL ,
	[SalesTaxRate] [float] NULL ,
	CONSTRAINT [PK_Orders_1__15] PRIMARY KEY  CLUSTERED 
	(
		[OrderID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Orders_Customers] FOREIGN KEY 
	(
		[CustomerID]
	) REFERENCES [OLTP].[dbo].[Customers] (
		[CustomerID]
	),
	CONSTRAINT [FK_Orders_Employees] FOREIGN KEY 
	(
		[EmployeeID]
	) REFERENCES [OLTP].[dbo].[Employees] (
		[EmployeeID]
	),
	CONSTRAINT [FK_Orders_Shipping_Methods] FOREIGN KEY 
	(
		[ShippingMethodID]
	) REFERENCES [OLTP].[dbo].[Shipping_Methods] (
		[ShippingMethodID]
	)
)
GO

/****** Object:  Table [OLTP].[dbo].[Products]    Script Date: 4/3/98 4:19:03 PM ******/
CREATE TABLE [OLTP].[dbo].[Products] (
	[ProductID] [int] IDENTITY (1, 1) NOT NULL ,
	[ProductName] [varchar] (80) NULL ,
	[UnitPrice] [money] NULL ,
	[BrandID] [int] NULL ,
	CONSTRAINT [PK_Products_1__15] PRIMARY KEY  CLUSTERED 
	(
		[ProductID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Products_Brands] FOREIGN KEY 
	(
		[BrandID]
	) REFERENCES [OLTP].[dbo].[Brands] (
		[BrandID]
	)
)
GO

/****** Object:  Table [OLTP].[dbo].[TerritoryRegion]    Script Date: 4/3/98 4:19:04 PM ******/
CREATE TABLE [OLTP].[dbo].[TerritoryRegion] (
	[RegionID] [int] NOT NULL ,
	[TerritoryID] [varchar] (20) NOT NULL ,
	CONSTRAINT [PK_EmployeeRegion] PRIMARY KEY  NONCLUSTERED 
	(
		[RegionID],
		[TerritoryID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_EmployeeRegion_Territories] FOREIGN KEY 
	(
		[TerritoryID]
	) REFERENCES [OLTP].[dbo].[Territories] (
		[TerritoryID]
	),
	CONSTRAINT [FK_TerritoryRegion_Region] FOREIGN KEY 
	(
		[RegionID]
	) REFERENCES [OLTP].[dbo].[Region] (
		[RegionID]
	)
)
GO

/****** Object:  Table [OLTP].[dbo].[Order_Details]    Script Date: 4/3/98 4:19:05 PM ******/
CREATE TABLE [OLTP].[dbo].[Order_Details] (
	[OrderDetailID] [int] IDENTITY (1, 1) NOT NULL ,
	[OrderID] [int] NULL ,
	[ProductID] [int] NULL ,
	[Quantity] [int] NULL ,
	[UnitPrice] [money] NULL ,
	[Discount] [numeric](18, 0) NULL ,
	CONSTRAINT [PK_Order_Details_1__15] PRIMARY KEY  CLUSTERED 
	(
		[OrderDetailID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Order_Details_Orders] FOREIGN KEY 
	(
		[OrderID]
	) REFERENCES [OLTP].[dbo].[Orders] (
		[OrderID]
	),
	CONSTRAINT [FK_Order_Details_Products] FOREIGN KEY 
	(
		[ProductID]
	) REFERENCES [OLTP].[dbo].[Products] (
		[ProductID]
	)
)
GO

/****** Object:  Table [OLTP].[dbo].[Payments]    Script Date: 4/3/98 4:19:06 PM ******/
CREATE TABLE [OLTP].[dbo].[Payments] (
	[PaymentID] [int] IDENTITY (1, 1) NOT NULL ,
	[OrderID] [int] NOT NULL ,
	[PaymentAmount] [money] NULL ,
	[PaymentDate] [datetime] NULL ,
	[CreditCardNumber] [varchar] (30) NULL ,
	[CardholdersName] [varchar] (50) NULL ,
	[CreditCardExpDate] [datetime] NULL ,
	[PaymentMethodID] [int] NULL ,
	CONSTRAINT [PK_Payments_1__15] PRIMARY KEY  CLUSTERED 
	(
		[PaymentID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Payments_Orders] FOREIGN KEY 
	(
		[OrderID]
	) REFERENCES [OLTP].[dbo].[Orders] (
		[OrderID]
	),
	CONSTRAINT [FK_Payments_Payment_Methods] FOREIGN KEY 
	(
		[PaymentMethodID]
	) REFERENCES [OLTP].[dbo].[Payment_Methods] (
		[PaymentMethodID]
	)
)
GO

if exists (select * from sysdatabases where name='Star')
begin
  raiserror('Dropping existing Star database ....',0,1)
  DROP database Star
end
GO


declare @dbpath varchar(255)
select @dbpath = substring(filename,1,len(filename)-10) from sysdatabases where name = 'master'

exec('CREATE DATABASE Star
ON 
( 	NAME=Star_dat,
	FILENAME=''' + @dbpath + 'Star.mdf'',
 	SIZE= 5MB)
  
LOG ON
(	NAME=Star_log,
 	FILENAME='''+ @dbpath + 'Star.ldf'',
 	SIZE=5MB)')
GO


set quoted_identifier on
GO

/****** Object:  Table [Star].[dbo].[Sales]    Script Date: 4/3/98 4:34:38 PM ******/
if exists (select * from sysobjects where id = object_id(N'[Star].[dbo].[Sales]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [Star].[dbo].[Sales]
GO

/****** Object:  Table [Star].[dbo].[Customers]    Script Date: 4/3/98 4:34:38 PM ******/
if exists (select * from sysobjects where id = object_id(N'[Star].[dbo].[Customers]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [Star].[dbo].[Customers]
GO

/****** Object:  Table [Star].[dbo].[Geography]    Script Date: 4/3/98 4:34:38 PM ******/
if exists (select * from sysobjects where id = object_id(N'[Star].[dbo].[Geography]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [Star].[dbo].[Geography]
GO

/****** Object:  Table [Star].[dbo].[Products]    Script Date: 4/3/98 4:34:38 PM ******/
if exists (select * from sysobjects where id = object_id(N'[Star].[dbo].[Products]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [Star].[dbo].[Products]
GO

/****** Object:  Table [Star].[dbo].[Time]    Script Date: 4/3/98 4:34:38 PM ******/
if exists (select * from sysobjects where id = object_id(N'[Star].[dbo].[Time]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [Star].[dbo].[Time]
GO

/****** Object:  Table [Star].[dbo].[Customers]    Script Date: 4/3/98 4:34:38 PM ******/
CREATE TABLE [Star].[dbo].[Customers] (
	[CustomerID] [int] NOT NULL ,
	[CustomerName] [char] (50) NOT NULL ,
	[CustomerTypeID] [int] NOT NULL ,
	[CustomerTypeDescription] [char] (50) NOT NULL ,
	[PostalCode] [char] (10) NOT NULL ,
	[State] [char] (2) NOT NULL ,
	CONSTRAINT [PK_Customers] PRIMARY KEY  NONCLUSTERED 
	(
		[CustomerID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [Star].[dbo].[Geography]    Script Date: 4/3/98 4:34:39 PM ******/
CREATE TABLE [Star].[dbo].[Geography] (
	[PostalCode] [char] (5) NOT NULL ,
	[TerritoryID] [int] NOT NULL ,
	[TerritoryDescription] [char] (50) NOT NULL ,
	[RegionID] [int] NOT NULL ,
	[RegionDescription] [char] (50) NOT NULL ,
	CONSTRAINT [PK_Geography] PRIMARY KEY  NONCLUSTERED 
	(
		[PostalCode]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [Star].[dbo].[Products]    Script Date: 4/3/98 4:34:40 PM ******/
CREATE TABLE [Star].[dbo].[Products] (
	[ProductID] [int] NOT NULL ,
	[ProductName] [char] (50) NOT NULL ,
	[BrandID] [int] NOT NULL ,
	[BrandDescription] [char] (50) NOT NULL ,
	CONSTRAINT [PK_Products] PRIMARY KEY  NONCLUSTERED 
	(
		[ProductID]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [Star].[dbo].[Time]    Script Date: 4/3/98 4:34:40 PM ******/
CREATE TABLE [Star].[dbo].[Time] (
	[Date] [datetime] NOT NULL ,
	[DayOfWeek] [char] (20) NOT NULL ,
	[Month] [int] NOT NULL ,
	[Year] [int] NOT NULL ,
	[Quarter] [int] NOT NULL ,
	[DayOfYear] [int] NOT NULL ,
	[Holiday] [char] (1) NOT NULL ,
	[Weekend] [char] (1) NOT NULL ,
	[YearMonth] [char] (10) NOT NULL ,
	[WeekOfYear] [int] NOT NULL ,
	CONSTRAINT [PK_Time] PRIMARY KEY  NONCLUSTERED 
	(
		[Date]
	)  ON [PRIMARY] 
)
GO

/****** Object:  Table [Star].[dbo].[Sales]    Script Date: 4/3/98 4:34:41 PM ******/
CREATE TABLE [Star].[dbo].[Sales] (
	[OrderID] [int] NOT NULL ,
	[OrderDetailID] [int] NOT NULL ,
	[CustomerID] [int] NOT NULL ,
	[ProductID] [int] NOT NULL ,
	[PostalCode] [char] (5) NOT NULL ,
	[OrderDate] [datetime] NOT NULL ,
	[Quantity] [int] NOT NULL ,
	[UnitPrice] [money] NOT NULL ,
	[Discount] [numeric](18, 0) NOT NULL ,
	CONSTRAINT [PK_Sales] PRIMARY KEY  NONCLUSTERED 
	(
		[OrderID],
		[OrderDetailID]
	)  ON [PRIMARY] ,
	CONSTRAINT [FK_Sales_Customers] FOREIGN KEY 
	(
		[CustomerID]
	) REFERENCES [Star].[dbo].[Customers] (
		[CustomerID]
	),
	CONSTRAINT [FK_Sales_Geography] FOREIGN KEY 
	(
		[PostalCode]
	) REFERENCES [Star].[dbo].[Geography] (
		[PostalCode]
	),
	CONSTRAINT [FK_Sales_Products] FOREIGN KEY 
	(
		[ProductID]
	) REFERENCES [Star].[dbo].[Products] (
		[ProductID]
	),
	CONSTRAINT [FK_Sales_Time] FOREIGN KEY 
	(
		[OrderDate]
	) REFERENCES [Star].[dbo].[Time] (
		[Date]
	)
)
GO
