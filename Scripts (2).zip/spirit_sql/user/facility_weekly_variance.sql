/*
Usage : This table is used to populate the data forr weekly program metric graph for facility 

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'facility_weekly_variance'
)

CREATE TABLE reporting.facility_weekly_variance
(
	business_unit nvarchar(50),
	weekly_scrap_actual float ,
	weekly_rr_actual float ,
	scrap_target_per_unit float ,
	rr_target_per_unit float ,
	
	ytd_scrap_avg_per_unit float,
	ytd_rr_avg_per_unit float ,
	weekly_available float ,
	weekly_clocked float ,
	weekly_noa float ,
	
	ytd_noa float ,
	effective_hours float ,
	weekly_actual_pcg float ,
	weekly_planned_pcg float ,
	ytd_actual_pcg float ,
	
	planned_ot_pcg float ,
	assigned_actuals float ,
	abs_std_pcg float ,
	week_abs_pcg_actual float ,
	ytd_abs_pcg_actual float ,
	
	crit_1_3_asset bigint ,
	crit_1_3_weekly_dt_actuals_per_hrs float ,
	crit_1_3_prior_week_dt_actuals_per_hrs float ,
	crit_1_3_ytd_dt_actuals_per_hrs float ,
	crit_4_assets bigint ,
	
	crit_4_weekly_dt_actuals_per_hrs float ,
	crit_4_prior_week_dt_actuals_per_hrs float ,
	crit_4_ytd_dt_actuals_per_hrs float ,
	crit_5_assets bigint ,
	crit_5_weekly_dt_tgt_hrs float ,
	
	crit_5_weekly_dt_actuals_per_hrs float ,
	crit_5_prior_weekly_dt_actuals_per_hrs float ,
	crit_5_ytd_dt_actuals_per_hrs float ,
	spirit_week int ,
	location nvarchar(100) ,
	
	spirit_year int 
)

GO


