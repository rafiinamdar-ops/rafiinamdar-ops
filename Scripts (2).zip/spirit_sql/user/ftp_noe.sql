/*
Usage : This table is used to load noe data 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_noe'
)

CREATE TABLE [staging].[ftp_noe](
	[load_date] [datetime] NULL CONSTRAINT [DF_ftp_noe_load_date]  DEFAULT (getdate()),
	[#] [float] NULL,
	[ecd] [nvarchar](255) NULL,
	[date] [datetime] NULL,
	[date_closed] [datetime] NULL,
	[noe_sdr_nar_nod] [nvarchar](255) NULL,
	[noe_sdr] [nvarchar](255) NULL,
	[status] [nvarchar](255) NULL,
	[bu_supplier] [nvarchar](255) NULL,
	[customer] [nvarchar](255) NULL,
	[owner] [nvarchar](255) NULL,
	[models] [nvarchar](255) NULL,
	[assigned_to] [nvarchar](255) NULL,
	[description_of_condition] [nvarchar](255) NULL,
	[comments_disposition] [nvarchar](255) NULL,
	[rcca_summary] [nvarchar](max) NULL,
	[previous_occurrence] [nvarchar](255) NULL,
	[units_affected] [nvarchar](max) NULL,
	[rcca_initiated] [nvarchar](255) NULL,
	[rcca_completed] [nvarchar](255) NULL,
	[safety_of_flight] [nvarchar](255) NULL,
	[tracking] [nvarchar](255) NULL,
	[cust_ref] [nvarchar](255) NULL,
	[Z7] [nvarchar](max) NULL,
	[aftermarke_groups_affected] [nvarchar](255) NULL,
	[qn_number] [nvarchar](255) NULL,
	[qn_initiation_date] [datetime] NULL,
	[vendor_code] [nvarchar](255) NULL,
	[pns] [nvarchar](255) NULL,
	[disposition] [nvarchar](255) NULL,
	[boeing_mrb_appendix_C_authority_used] [nvarchar](255) NULL,
	[can] [nvarchar](255) NULL,
	[can_initiated] [nvarchar](255) NULL,
	[can_action_plans_sent] [nvarchar](255) NULL,
	[can_closed] [nvarchar](255) NULL,
	[ecd_of_ca] [nvarchar](255) NULL,
	[z7_close_with_executive_summary] [nvarchar](255) NULL,
	[customer_closure_notice_received] [nvarchar](255) NULL,
	[item_type] [nvarchar](255) NULL,
	[path] [nvarchar](255) NULL
) 

GO


