/*
Usage : This table is used to load untructured data for ceo metrics from Prestwick location

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_prestwick_srr_escape_noe'
)

CREATE TABLE [staging].[ftp_prestwick_srr_escape_noe](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[attribute] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[previousyear_YE] [float] NULL,
	[currentyear_targets] [float] NULL,
	[variance_targets] [float] NULL,
	[weekly_plan] [float] NULL,
	[weekly_actual] [float] NULL,
	[variance_weekly] [float] NULL,
	[ytd_plan] [float] NULL,
	[ytd_actual] [float] NULL,
	[variance_ytd] [float] NULL,
	[spirit_week] [nvarchar](50) NULL,
	[program] [varchar](50) NULL,
 CONSTRAINT [PK__ftp_pres__1543595E26A3750A] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO

