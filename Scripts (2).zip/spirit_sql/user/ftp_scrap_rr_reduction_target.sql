/*
Usage : This datamart table is used to populate the data for quality attribute of reduction target

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_scrap_rr_reduction_target'
)

CREATE TABLE staging.ftp_scrap_rr_reduction_target
(
	scrap_amount_target_per_unit float,
	rr_amount_target_per_unit float,
	scrap_amount_target_pcg float,
	rr_amount_target_pcg float,
	location nvarchar(255),
	
	Spirit_year float,
	program nvarchar(255) 
) 

GO





