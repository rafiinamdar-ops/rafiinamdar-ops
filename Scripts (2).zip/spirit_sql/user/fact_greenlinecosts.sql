
/*
Usage : This table is used to load greenline costs data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/
IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_greenlinecosts'
)


CREATE TABLE [datamart].[fact_greenlinecosts](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[spirit_week] [int] NULL,
	[spirit_year] [int] NULL,
	[weeklyactuals] [float] NULL,
	[headers] [varchar](50) NULL,
	[actualcummulativeytd] [float] NULL,
	[created_date] [datetime] NULL,
	[modified_by] [datetime] NULL DEFAULT (getdate()),
	[modified_date] [varchar](50) NULL DEFAULT (suser_sname())
) 

GO




