use pubs
go

if exists (select * from sysobjects where name = 'AuthorName' and type = 'U')
	drop table AuthorName
go

create table AuthorName
(
  au_lname varchar(40) not null,
  au_fname varchar(20) not null
)
go

select * from AuthorName

