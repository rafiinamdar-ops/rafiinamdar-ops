EXEC msdb.dbo.sp_add_notification @alert_name=N'825 - Read-Retry Required', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'DB Integrity Error Sev. 23', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'DB Process Error Sev. 21', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'Disk Full', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'Fatal Error Sev. 25', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'H/W Error Sev. 24', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'Process Error Sev. 20', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'Resource Limit Reached Sev. 19', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'TB Integrity Error Sev. 22', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'Trans Log Full', @operator_name=N'SQL Server DBA', @notification_method = 1
GO

