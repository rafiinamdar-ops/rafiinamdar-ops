use master
go
IF EXISTS (SELECT * FROM sys.server_triggers
WHERE name = 'ddl_trig_database')
DROP TRIGGER ddl_trig_database
ON ALL SERVER;
GO
CREATE TRIGGER ddl_trig_database 
ON ALL SERVER 
FOR CREATE_DATABASE,DROP_DATABASE
AS 
insert into sqldba.dbo.TrackDBModification(EventType,PostTime,ServerName,LoginName,DatabaseName,Command)
SELECT EVENTDATA().value('(/EVENT_INSTANCE/EventType)[1]','nvarchar(200)'),
 EVENTDATA().value('(/EVENT_INSTANCE/PostTime)[1]','datetime'),
 EVENTDATA().value('(/EVENT_INSTANCE/ServerName)[1]','nvarchar(max)'),
 EVENTDATA().value('(/EVENT_INSTANCE/LoginName)[1]','nvarchar(max)'),
 EVENTDATA().value('(/EVENT_INSTANCE/DatabaseName)[1]','nvarchar(max)'),
 EVENTDATA().value('(/EVENT_INSTANCE/TSQLCommand)[1]','nvarchar(max)')
GO

