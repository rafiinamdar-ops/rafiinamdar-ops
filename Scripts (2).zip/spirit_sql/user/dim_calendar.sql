/*
Usage : To find spirit year & spirit week 

Creator/Editor #Date #Comments
Pratheesh N # 2017-06-01 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_calendar'
)

CREATE TABLE datamart.dim_calendar
(
date_key date not null
,spirit_year int not null
,calendar_year int not null
,fin_year varchar(20) not null
,qtr int not null

,mnth int not null
,mnth_name varchar(20) not null
,spirit_week int not null
,calendar_week int not null
,budget_month_end datetime null

,spirit_mnth int
,spirit_mnth_name varchar(20)
,modified_by varchar(30) not null
,modified_date datetime  default (getdate())
,is_holiday tinyint default (0)

,is_current_week tinyint default(0)

constraint pk__dim_calendar primary key clustered 
(
date_key asc
)with (pad_index = off, statistics_norecompute = off, ignore_dup_key = off, allow_row_locks = on, allow_page_locks = on) 
) 

GO

