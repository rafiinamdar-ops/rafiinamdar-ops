SELECT s.database_name 'Database',
--s.recovery_model 'Recovery Model',
--s.compatibility_level,
s.USER_NAME 'Backup by Username',
CASE s.TYPE
WHEN 'D' THEN 'Full'
WHEN 'I' THEN 'Diff'
WHEN 'L' THEN 'Log'
END 'Backup Type',
s.is_copy_only,
s.backup_start_date 'Backup Started',
CONVERT(VARCHAR(20), s.backup_finish_date, 13) 'Backup Completed',
DATEDIFF(minute, s.backup_start_date, s.backup_finish_date) 'Duration Min',
CAST(ROUND(s.backup_size * 1.0 / ( 1024 * 1024 ), 2) AS NUMERIC(10, 2)) 'Size in MB',
CAST(mf.physical_device_name AS VARCHAR(100)) 'Physical device name'
/*CASE WHEN LEFT(mf.physical_device_name, 1) = '{' THEN 'SQL VSS Writer'
WHEN LEFT(mf.physical_device_name, 3) LIKE '[A-Za-z]:\%' THEN 'SQL Backup'
WHEN LEFT(mf.physical_device_name, 2) LIKE '\\' THEN 'SQL Backup'
ELSE mf.physical_device_name
END 'Backup tool',*/
FROM   msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily mf ON s.media_set_id = mf.media_set_id
WHERE  s.database_name = 'scat' AND  s.type ='d' and LEFT(mf.physical_device_name, 1) not in ('{')  -- remove this condition if you want all DBs
AND s.backup_finish_date =(select max(s.backup_finish_date)  FROM   msdb.dbo.backupset s
INNER JOIN msdb.dbo.backupmediafamily mf ON s.media_set_id = mf.media_set_id
WHERE  s.database_name = 'scat' AND  s.type ='d' and LEFT(mf.physical_device_name, 1) not in ('{') )
--group by s.database_name,s.recovery_model,s.compatibility_level,s.user_name,s.type,mf.physical_device_name,s.backup_start_date,s.backup_finish_date
		--,s.backup_size,is_copy_only
ORDER BY s.backup_finish_date DESC;