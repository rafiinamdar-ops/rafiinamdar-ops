-- Start procedure
DECLARE @Owner varchar(50)
       ,@Email varchar(50)
       ,@HTML nvarchar(max)
	   ,@Sname varchar(100)
	   ,@DBname varchar(100)
	   ,@ApplicationName varchar(150)

-- Create cursor with owners
DECLARE curOwners CURSOR FAST_FORWARD
FOR
    SELECT DISTINCT  [Devpr_Nm], [E_Mail] FROM [SQLDBA].[dbo].[DB_Devpr_Info_ALL] where Server_Name not in ('sql-ent-01','sql-rdu-06')

-- Open cursor and run over them one by one
OPEN curOwners;
FETCH NEXT FROM curOwners INTO @Owner, @Email;
WHILE @@FETCH_STATUS = 0 BEGIN

    -- Create html email header
    SELECT @HTML = N'<!DOCTYPE html>
                        <html>
                        <head lang="en">
                            <title></title>
                            <style type="text/css">
                                html {
                                color: #222;
                                font-size: 1em;
                                -webkit-font-smoothing: antialiased;
                                }

                                body {
                                padding: 0;
                                margin: 0;
                                width: 100%;
                                }

                                #main {
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                margin: 0 auto 100px auto;
                                position: relative;
                                font-weight: 300;
                                }

                                h1 {
                                font-family: "Segoe UI", sans-serif;
                                font-weight: 500;
                                font-size: 18px;
                                margin-bottom: 12px;
                                }

                                h2 {
                                font-family: "Segoe UI", sans-serif;
                                font-weight: 500;
                                font-size: 16px;
                                }

                                table {
                                border-collapse: collapse;
                                border-spacing: 0;
                                padding: 0;
                                margin: 0;
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                }

                                caption { text-align: left; padding: 2px;}
                                thead tr th { background-color:#ddd; }

                                th {
                                background-color: #eee;
                                border: 1px solid #ccc;
                                color: #555;
                                text-align: center;
                                font-weight: 700;
                                padding: 1px 4px;
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                }

                                td {
                                border: 1px solid #ccc;
                                vertical-align: middle;
                                padding: 1px 4px;
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                }

                                th.fix60 { width: 60px; }
                                th.fix90 { width: 90px; }
                                th.fix120 { width: 120px; }
                                th.fix140 { width: 140px; }
                                th.fix180 { width: 180px }

                                .container table {
                                border: 1px solid #e7e7e7;
                                margin: 0 -1px 24px 0;
                                text-align: left;
                                width: 100%;
                                }
                                .container tr { background-color:#fff; }
                            </style>
                        </head>
                        <body>
                            <div id="main">';
    SELECT @HTML = @HTML + N'<p style="font-weight:bold">Hi ' + @Owner + '.</p>';
	  SELECT @HTML = @HTML + N'<p style="font-weight:bold">We (DBAs) are trying to improve tracking of databases, owners and applications. Our records show you�re the last known owner for these databases. Can you please give me an application name for each one, and let me know - if you�re no longer responsible for the database who the next owner is?
We appreciate your prompt reply. .</p>';


    -- Create table header
    SELECT @HTML = @HTML + N'<table><thead><th class="fix140">Server Name</th><th class="fix140">DataBase Name</th><th class="fix140">Application Name</th></thead><tbody>';


    -- Create cursor with tickets of the owner we are working on
    DECLARE owner CURSOR FAST_FORWARD
    FOR
        SELECT  DISTINCT  [Server_Name] ,[DB_Nm],isnull([Application_name],'') AS applicationName FROM [SQLDBA].[dbo].[DB_Devpr_Info_ALL] WHERE [Devpr_Nm] = @Owner and  Server_Name not in ('sql-ent-01','sql-rdu-06');

    -- Open the cursor and run over the tickets one by one and add them to a table row
    OPEN owner;
    FETCH NEXT FROM owner INTO @Sname,@DBname,@ApplicationName;
    WHILE @@FETCH_STATUS = 0 BEGIN

        -- Add row for every ticket
        SELECT @HTML = @HTML + N'<tr><td>' + CAST(@Sname as varchar(50)) + N'</td><td>' + CAST(@DBname as varchar(50)) + N'</td><td>' + CAST(@ApplicationName as varchar(150)) + N'</td></tr>';

        FETCH NEXT FROM owner INTO @Sname,@DBname,@ApplicationName;
    END;
    CLOSE owner;
    DEALLOCATE owner;



    -- Close table
    SELECT @HTML = @HTML + N'</tbody></table>';

    -- Close html
    SELECT @HTML = @HTML + N'</body></html>';

    -- Print html
    SELECT @HTML;

    -- Send mail
    EXEC msdb.dbo.sp_send_dbmail 
        @profile_name='svcsql',
		--@from_address='mahammadrafik.inamdar@spiritaero.com',
		 @recipients=@Email,
		@copy_recipients ='mahammadrafik.inamdar@hpe.com;fredric.w.shope@spiritaero.com',
		@from_address='Shope, Fredric W <fredric.w.shope@spiritaero.com>',
		@reply_to='fredric.w.shope@spiritaero.com',
        @subject = 'Request for Application Names for Each SQL Server Databases',
        @body = @HTML,
        @body_format = 'HTML';
      

    FETCH NEXT FROM curOwners INTO @Owner, @Email;
END;
CLOSE curOwners;
DEALLOCATE curOwners;