/*
Usage : This table is used to load summary report data for Quality

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'quality_srr_escape_noe'
)

CREATE TABLE [reporting].[quality_srr_escape_noe](
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL,
	[date_written] [date] NULL,
	[program] [varchar](30) NULL,
	[location] [varchar](30) NULL,
	[value_chain] [varchar](30) NULL,
	[feature_defect_description] [varchar](100) NULL,
	[srr_qty_actual] [int] NULL,
	[srr_amount_actual] [float] NULL,
	[escapes_amount_actual] [float] NULL,
	[escapes_qty_actual] [int] NULL,
	[noe_actual] [int] NULL,
	[srr_amount_planned] [float] NULL,
	[escapes_amount_planned] [float] NULL,
	[escapes_qty_planned] [float] NULL,
	[noe_planned] [numeric](18, 2) NULL,
	[attribute] [varchar](20) NULL,
	[charge_mgmt_code] [varchar](255) NULL,
	[function] [varchar](50) NULL,
	[noe_description] [varchar](255) NULL,
	[srr_amount_planned_summary] [float] NULL,
	[escapes_qty_planned_summary] [float] NULL
) 

GO




