  
	--Declare variables
	
	DECLARE @FullDate DATETIME
	DECLARE @DiffDate DATETIME
	DECLARE @tlogDate DATETIME
	
	SELECT  *
  FROM [SQLDBA].[dbo].[TLOG_DatabaseBackup]
    where ltrim(rtrim([LastFullBackupDate]))='12/15/2013 07:12:55'
  update [SQLDBA].[dbo].[TLOG_DatabaseBackup]
   set [LastFullBackupDate]='12/09/2013 07:12:55'
   where [LastFullBackupDate]='12/15/2013 07:12:55'

    update [SQLDBA].[dbo].[TLOG_DatabaseBackup]
   set [LastDifferentialBackupDate]='12/16/2013 01:05:30'
   where [LastDifferentialBackupDate]='12/17/2013 01:05:30' 

    update [SQLDBA].[dbo].[TLOG_DatabaseBackup]
   set LastLogBackupDate ='12/16/2013 14:00:28'
   where LastLogBackupDate ='12/16/2013 18:00:28' select getdate()
	--select * from [SQLDBA].[dbo].[TLOG_DatabaseBackup]
-- Set variables

	SET @FullDate = GETDATE()-7
	SET @DiffDate = GETDATE()-1
	SET @tlogDate = GETDATE()-0.5

	 

	SELECT  [SERVERNAME]
      ,[DatabaseName]
      ,[RecoveryModel]
      ,CONVERT(datetime,[LastFullBackupDate],101) AS [LastFullBackupDate]
      ,CONVERT(datetime,[LastDifferentialBackupDate],101) AS [LastDifferentialBackupDate]
      ,CONVERT(datetime,[LastLogBackupDate],101) AS [LastLogBackupDate]
  FROM [SQLDBA].[dbo].[TLOG_DatabaseBackup]
	WHERE  ((([RecoveryModel] in ('Full','Bulk-logged')) and  ((CONVERT(datetime,[LastFullBackupDate],101))<@FullDate OR (CONVERT(datetime,[LastDifferentialBackupDate],101))<@DiffDate
			OR (CONVERT(datetime, [LastLogBackupDate],101))<@tlogDate)))
						OR((([RecoveryModel]='Simple') and  ((CONVERT(datetime,[LastFullBackupDate],101))<@FullDate OR 
						(CONVERT(datetime,[LastDifferentialBackupDate],101))<@DiffDate)))