IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_escape_prestwick'
)

CREATE TABLE [staging].[ftp_escape_prestwick](
	[program] [varchar](50) NULL,
	[value_chain] [varchar](50) NULL,
	[ca_count] [int] NULL,
	[date_written] [date] NULL,
	[escape_amount_actual] [float] NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](255) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime] NULL DEFAULT (getdate()),
	[feature_descrepancy] [varchar](300) NULL
) 

GO



