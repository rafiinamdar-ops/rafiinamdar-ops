
DECLARE @SQL varchar(300)


IF (select DISTINCT Count(*)
from sys.dm_hadr_availability_replica_cluster_nodes n
join sys.dm_hadr_availability_replica_cluster_states cs
on n.replica_server_name = cs.replica_server_name
join sys.dm_hadr_availability_replica_states rs 
on rs.replica_id = cs.replica_id
join sys.dm_hadr_database_replica_states drs
on rs.replica_id=drs.replica_id
where n.replica_server_name=(Select @@servername) and rs.role_desc='Secondary' 
and drs.synchronization_state_desc  in ('SYNCHRONIZED') and drs.synchronization_health_desc  in ('HEALTHY'))>0
Begin
SET @SQL=(SELECT DISTINCT 'ALTER AVAILABILITY GROUP ['+group_name+'] FAILOVER' from sys.dm_hadr_availability_replica_cluster_nodes)
PRINT(@SQL)
EXEC (@SQL)
END

select n.group_name,n.replica_server_name,n.node_name,rs.role_desc,
db_name(drs.database_id) as 'DBName',drs.synchronization_state_desc,drs.synchronization_health_desc
from sys.dm_hadr_availability_replica_cluster_nodes n
join sys.dm_hadr_availability_replica_cluster_states cs
on n.replica_server_name = cs.replica_server_name
join sys.dm_hadr_availability_replica_states rs 
on rs.replica_id = cs.replica_id
join sys.dm_hadr_database_replica_states drs
on rs.replica_id=drs.replica_id
--where n.replica_server_name=(Select @@servername) and rs.role_desc='Primary'
where drs.synchronization_state_desc not in ('SYNCHRONIZED') or drs.synchronization_health_desc not in ('HEALTHY')

--where n.replica_server_name <> @HADRName
--on rs.replica_id=drs.replica_id