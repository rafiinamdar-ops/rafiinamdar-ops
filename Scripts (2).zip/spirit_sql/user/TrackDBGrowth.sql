USE [sqldba]
GO

/****** Object:  Table [dbo].[DBGrowthRate]    Script Date: 08/08/2017 00:39:51 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DBGrowthRate](
	[DBGrowthID] [int] IDENTITY(1,1) NOT NULL,
	[DBName] [varchar](100) NULL,
	[type_desc] [varchar](20) NULL,
	[Lfname] [varchar](100) NULL,
	[physical_name] [varchar](150) NULL,
	[DBID] [int] NULL,
	[NumPages] [int] NULL,
	[OrigSize_In_MB] [decimal](10, 2) NULL,
	[CurSize_In_MB] [decimal](10, 2) NULL,
	[GrowthAmt] [varchar](100) NULL,
	[MetricDate] [datetime] NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

