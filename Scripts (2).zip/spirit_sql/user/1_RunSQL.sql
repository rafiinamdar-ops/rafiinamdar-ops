DECLARE @RC int
EXECUTE @RC = [SQLDBA].[dbo].[proc_SQLErrorLogReport] 
GO