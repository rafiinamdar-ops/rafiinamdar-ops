/*
Usage : To find source data for planned vs reactive maint attribute

Creator/Editor #Date #Comments
Prakhar  # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_manpower_plannedvsreactive_maintenance'
)

CREATE TABLE staging.maximo_manpower_plannedvsreactive_maintenance
(
	wonum nvarchar(20),
	wo_description nvarchar(100),
	actfinish nvarchar(21),
	regularhrs float,
	wo_status nvarchar(16),
	
	busunit nvarchar(10),
	reqpri nvarchar(10),
	assetlocpririty float,
	priority_num float,
	siteid nvarchar(8),
	
	maintgrp nvarchar(10),
	laborhrs varchar(6) 
) 

GO



