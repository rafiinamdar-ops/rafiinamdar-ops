SELECT SPIRIT_YEAR,SPIRIT_WEEK,BUSINESS_UNIT,LOCATION,

sum(crit_1_3_asset) as crit_1_3_asset,
sum(crit_1_3_weekly_dt_actuals_per_hrs) as crit_1_3_weekly_dt_actuals_per_hrs,
sum(crit_1_3_prior_week_dt_actuals_per_hrs) as crit_1_3_prior_week_dt_actuals_per_hrs,
sum(crit_1_3_ytd_dt_actuals_per_hrs) as crit_1_3_ytd_dt_actuals_per_hrs,
sum(crit_4_assets) as crit_4_assets,
sum(crit_4_weekly_dt_actuals_per_hrs) as crit_4_weekly_dt_actuals_per_hrs,
sum(crit_4_prior_week_dt_actuals_per_hrs) as crit_4_prior_week_dt_actuals_per_hrs,
sum(crit_4_ytd_dt_actuals_per_hrs) as crit_4_ytd_dt_actuals_per_hrs,
sum(crit_5_assets) as crit_5_assets,
sum(crit_5_weekly_dt_tgt_hrs) as crit_5_weekly_dt_tgt_hrs,
sum(crit_5_weekly_dt_actuals_per_hrs) as crit_5_weekly_dt_actuals_per_hrs,
sum(crit_5_prior_weekly_dt_actuals_per_hrs) as crit_5_prior_weekly_dt_actuals_per_hrs,
sum(crit_5_ytd_dt_actuals_per_hrs) as crit_5_ytd_dt_actuals_per_hrs
FROM [reporting].[facility_weekly_variance]

where spirit_year=2017 and location='Kinston' and spirit_week=38

group by 

SPIRIT_YEAR,SPIRIT_WEEK,BUSINESS_UNIT,LOCATION



order by 

SPIRIT_YEAR,SPIRIT_WEEK,BUSINESS_UNIT,LOCATION

