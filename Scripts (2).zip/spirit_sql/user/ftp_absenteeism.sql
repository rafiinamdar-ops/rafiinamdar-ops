/*
Usage : To find the source data 

Creator/Editor #Date #Comments
Prakhar  # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name ='ftp_absenteeism'
)

CREATE TABLE staging.ftp_absenteeism
 (
	cost_center nvarchar(255),
	working_level nvarchar(255),
	shifts nvarchar(255),
	period nvarchar(50),
	abs_p float,
	
	abs_up float,
	abs_fmla nvarchar(255),
	countofpaycode int,
	total_abs_hours float,
	std_hours_per_week float,
	
	std_abs_pcg float,
    loaddate datetime 
	
CONSTRAINT DF_ftp_absenteeism_loaddate  DEFAULT (getdate()),
	business_unit nvarchar(255),
	location nvarchar(50)
) 

GO


