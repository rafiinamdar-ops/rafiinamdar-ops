
USE [SQLDBA]
GO
/****** Object:  Table [dbo].[!DB_Devpr_Info_back]    Script Date: 6/13/2017 4:07:16 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_PADDING ON
GO
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[!DB_Devpr_Info_back]') AND type in (N'U'))
BEGIN
CREATE TABLE [dbo].[!DB_Devpr_Info_back](
	[Server_Name] [nvarchar](128) NULL,
	[DB_Nm] [varchar](50) NOT NULL,
	[Devpr_Nm] [varchar](50) NULL,
	[Devpr_Ph] [varchar](20) NULL,
	[Devpr_UID] [varchar](8) NULL,
	[DB_Cr_Dt] [varchar](10) NULL,
	[TRD_PRTY_APP] [char](10) NULL,
	[E_Mail] [varchar](100) NULL
) ON [PRIMARY]
END
GO
SET ANSI_PADDING OFF
GO
use master 
go
DECLARE @name VARCHAR(50) -- database name  
DECLARE @cmd varchar(500)
DECLARE @objectname varchar(50)

DECLARE db_cursor CURSOR FOR  
select name from sys.databases 
WHERE name NOT IN ('master','model','msdb','tempdb')  and state_desc not in ('OFFLINE')

OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @name  

WHILE @@FETCH_STATUS = 0  
BEGIN  

SET @objectname ='['+@name+'].[dbo].[!DB_Devpr_Info]'

IF OBJECT_ID (@objectname, N'U') IS NOT NULL 
  BEGIN
  SET @cmd='INSERT INTO [SQLDBA].[dbo].[!DB_Devpr_Info_back] SELECT @@ServerName AS ServerName
	  ,[DB_Nm]
      ,[Devpr_Nm]
      ,[Devpr_Ph]
      ,[Devpr_UID]
      ,[DB_Cr_Dt]
      ,[TRD_PRTY_APP]
      ,[E_Mail] 
  FROM ['+@name+'].[dbo].[!DB_Devpr_Info]'
  EXEC (@cmd)
  --PRINT(@cmd)
  END
 --END 

  FETCH NEXT FROM db_cursor INTO @name  
END  

CLOSE db_cursor  
DEALLOCATE db_cursor 

select * from sqldba.[dbo].[!DB_Devpr_Info_back]