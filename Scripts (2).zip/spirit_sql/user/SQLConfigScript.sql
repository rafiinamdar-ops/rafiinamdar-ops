--DROP TABLE #Instance 
--DROP TABLE #AuditData 
--DROP TABLE #msver 
--DROP TABLE #WinverSP 
--DROP TABLE #SQL_Server_Settings
 

SET NOCOUNT ON 
 
--setup temp tables and variables 
CREATE TABLE #Instance (value VARCHAR(50),data VARCHAR(50)) 
CREATE  TABLE #AuditData (value VARCHAR(50),data VARCHAR(100)) 
CREATE TABLE #msver (indx INT, name VARCHAR(50), internal_value INT, character_value VARCHAR(255)) 
CREATE TABLE #WinverSP (value    VARCHAR (255),data VARCHAR(255)) 

DECLARE @Instance VARCHAR(50) 
DECLARE @InstanceLoc VARCHAR(50) 
DECLARE @RegKey VARCHAR(255) 
DECLARE @CPUCount INT 
DECLARE @CPUID INT 
DECLARE @AffinityMask INT 
DECLARE @CPUList VARCHAR(100) 
DECLARE @InstCPUCount INT 
DECLARE @sql VARCHAR(255) 
DECLARE @Database VARCHAR(50) 
DECLARE @WINVERSP VARCHAR(255) 

Delete  [sql-ent-85].sqldba.dbo.tblSQLServerConfig  where [servername]=(SELECT @@SERVERNAME )
--> SQL Server Settings <--
PRINT '		** Loading sp_configure details **'
PRINT ' '
EXEC sp_configure 'show advanced options', 1;
RECONFIGURE;
SELECT 
         [name]
		,[value_in_use]
INTO #SQL_Server_Settings
FROM master.sys.configurations  where [value_in_use]<>0;		

EXEC sp_configure 'show advanced options', 0;
RECONFIGURE;
 
INSERT INTO #msver EXEC xp_msver 

--select * from #msver 
 
--get Windows server version and its service pack 
SET @RegKey = 'SOFTWARE\Microsoft\Windows NT\CurrentVersion' 
INSERT INTO #WinverSP EXEC xp_regread 'HKEY_LOCAL_MACHINE',@regkey,'ProductName' 
INSERT INTO #WinverSP EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'CSDVersion' 
 
--PRINT '' 
--PRINT 'Windows Server version and Service pack values' 

--get instance location FROM registry 
SET @RegKey = 'SOFTWARE\Microsoft\Microsoft SQL Server\Instance Names\SQL' 
 
INSERT INTO #Instance EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, @@servicename 
 
SELECT @InstanceLoc=data FROM #Instance WHERE VALUE = @@servicename 
 --SELECT * FROM #Instance
--get audit data FROM registry and insert into #AuditData 
 
SET @RegKey = 'SOFTWARE\Microsoft\Microsoft SQL Server\' + @InstanceLoc + '\Setup' 
 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'Edition' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'SqlCluster' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'SqlProgramDir' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'SQLDataRoot' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'SQLPath' 
 
SET @RegKey = 'SOFTWARE\Microsoft\Microsoft SQL Server\' + @InstanceLoc + '\MSSQLSERVER' 
 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'AuditLevel' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'LoginMode' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'DefaultData' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'DefaultLog' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'BackupDirectory' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'NumErrorLogs' 
 
SET @RegKey = 'SOFTWARE\Microsoft\Microsoft SQL Server\' + @InstanceLoc + '\SQLServerAgent' 
 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'RestartSQLServer' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'RestartServer' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'UseDatabaseMail' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'DatabaseMailProfile' 
 
SET @RegKey = 'SOFTWARE\Microsoft\Microsoft SQL Server\' + @InstanceLoc + '\MSSQLSERVER\SuperSocketNetLib\Tcp\IPAll' 
 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'TcpDynamicPorts' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE', @RegKey, 'TcpPort' 
INSERT INTO #AuditData EXEC xp_regread 'HKEY_LOCAL_MACHINE','SOFTWARE\McAfee\VSCore\On Access Scanner\McShield\Configuration\Default', 'szExcludeExts' 
 
 
UPDATE #AuditData  
   SET value = 'Antivirusprofile' where  value = 'szExcludeExts' 
   
UPDATE #AuditData  
   SET data =   
      CASE  
         WHEN data = 0 THEN 'captures no logins' 
         WHEN data = 1 THEN 'captures only success login attempts' 
         WHEN data = 2 THEN 'captures only failed login attempts' 
         WHEN data = 3 THEN 'captures both success and failed login attempts' 
         ELSE data  
      END 
 WHERE value IN ('AuditLevel') 
 
UPDATE #AuditData  
   SET data =   
      CASE  
         WHEN data = 1 THEN 'Windows Authentication' 
         WHEN data = 2 THEN 'Mixed Mode Authentication' 
         ELSE data  
      END 
 WHERE value IN ('LoginMode') 
 
UPDATE #AuditData  
   SET data =   
      CASE  
         WHEN data = 0 THEN 'FALSE' 
         WHEN data = 1 THEN 'TRUE' 
         ELSE data  
      END 
 WHERE value IN ('RestartServer','RestartSQLServer','SqlCluster','UseDatabaseMail') 

--select * from  #AuditData
INSERT INTO [sql-ent-85].sqldba.dbo.tblSQLServerConfig 
SELECT @@SERVERNAME as [Server Name],'PRODUCT NAME' AS Value,CONVERT(varchar,LEFT(@@version,CHARINDEX('-',@@Version)-1)+')' )
UNION ALL
SELECT @@SERVERNAME as [Server Name],'Product Version' AS Value,CONVERT(varchar, SERVERPROPERTY('productversion'))
UNION  ALL
SELECT @@SERVERNAME as [Server Name] ,'PRODUCT LEVEL' AS Value,CONVERT(varchar, SERVERPROPERTY ('productlevel') )
UNION  ALL
SELECT @@SERVERNAME as [Server Name] ,'EDITION' AS Value ,CONVERT(varchar,SERVERPROPERTY ('edition') )
UNION ALL
 
SELECT @@SERVERNAME as [Server Name],'OS '+CAST(value AS VARCHAR(50)) AS value,  
       CAST(data AS VARCHAR(50)) AS data  
  FROM #WinverSP 
-- UNION ALL
--SELECT @@SERVERNAME as [Server Name],'Instance Name' as [Value],CAST(@@servicename AS VARCHAR(25)) AS instance 
 
--PRINT '' 
--PRINT 'return instance location' 
UNION ALL
SELECT @@SERVERNAME as [Server Name], 'REGISTRY INSTANCE NAME' AS instance,  
       CAST(value AS VARCHAR(25))+' : '+CAST(data AS VARCHAR(25)) AS data 
  FROM #Instance 
 
UNION ALL
SELECT @@SERVERNAME as [Server Name],'OS '+CAST(name AS VARCHAR(50)) AS name,  
       CAST(character_value AS VARCHAR(50)) AS value  
  FROM #msver 
 WHERE name in ('productname','productversion','platform','filedescription') 
 UNION ALL
SELECT @@SERVERNAME as [Server Name],'OS '+CAST(name AS VARCHAR(50)) AS name,  
       CAST(internal_value  AS VARCHAR(50)) AS value  
  FROM #msver 
 WHERE name in ('PhysicalMemory') 
 
UNION ALL
SELECT @@SERVERNAME as [Server Name],CAST(value AS VARCHAR(25)) AS value,  
       CAST(data AS VARCHAR(100)) AS data  
  FROM #AuditData 

UNION ALL

SELECT @@SERVERNAME as [Server Name],'Authentication Mode' AS [Value],CASE SERVERPROPERTY('IsIntegratedSecurityOnly') WHEN 0 THEN 'Mixed Authentication' WHEN 1 THEN 'Windows Authentication' 
END AS [Data]
-- --ORDER BY value 

UNION ALL 

SELECT @@SERVERNAME as [Server Name],'Server_Default_Collation' as Value,CONVERT(varchar,SERVERPROPERTY( 'Collation' )) 

UNION ALL

 --Script to get CPU and Memory Info
SELECT @@SERVERNAME as [Server Name],'Number of Logical CPU' as Value, CONVERT(varchar,cpu_count) FROM sys.dm_os_sys_info 
UNION ALL
SELECT  @@SERVERNAME as [Server Name],'hyperthread_ratio' AS Vaue,CONVERT(varchar,hyperthread_ratio) FROM sys.dm_os_sys_info 
UNION ALL
SELECT @@SERVERNAME as [Server Name],'Number of Physical CPU' AS Value,CONVERT(varchar,cpu_count/hyperthread_ratio) FROM sys.dm_os_sys_info 
--UNION ALL
--SELECT @@SERVERNAME as [Server Name],'TotalPhysicalMemory INMB' AS VALUE,CONVERT(varchar,physical_memory_kb/1024) FROM sys.dm_os_sys_info 

UNION ALL
SELECT @@SERVERNAME as [Server Name],CONVERT(varchar,name),CONVERT(varchar,value_in_use) FROM #SQL_Server_Settings
--SELECT * FROM [sql-ent-85].sqldba.dbo.tblSQLServerConfig 
DROP TABLE #Instance 
DROP TABLE #AuditData 
DROP TABLE #msver 
DROP TABLE #WinverSP 
DROP TABLE #SQL_Server_Settings
 
 

 