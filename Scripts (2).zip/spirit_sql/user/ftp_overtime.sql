IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_overtime'
)

CREATE TABLE staging.ftp_overtime
(
business_unit nvarchar(100) null
,cost_center nvarchar(100) null
,week_end_date datetime null
,actual_regular_hours float null
,actual_overtime_hours float null

,forecast_regular_hours float null
,forecast_overtime_hours float null
,actual_ot_pcg float null
,forecast_ot_pcg float null
,location nvarchar(100) null
)

GO
