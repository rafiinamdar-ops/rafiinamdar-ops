IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'refresh_log'
)

CREATE TABLE reporting.refresh_log
(
report_name nvarchar(255) null
,report_owner_name nvarchar(255) null
,reporting_period nvarchar(255) null
,last_refresh_date_time datetime null
,week_no int null
)

GO

 