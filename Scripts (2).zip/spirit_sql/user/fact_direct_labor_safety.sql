/*
Usage :It is used to keep cleaned data of Genpact DT Labor & Safery 

Creator/Editor #Date #Comments
Pratheesh N # 2017-10-20 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_direct_labor_safety'
)

CREATE TABLE datamart.fact_direct_labor_safety
(
sheet_name varchar(100)
,location varchar (100)
,spirit_year int not null
,spirit_week int not null

,cost_center varchar (100)
,metric_name varchar (100)
,actuals float (53)
,planned float (53)
) 

GO

