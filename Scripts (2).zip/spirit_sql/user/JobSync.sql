-- Start procedure
DECLARE @Owner varchar(50)
       ,@Email varchar(50)
	   ,@subject varchar(100)
       ,@HTML nvarchar(max)
	   ,@Sname varchar(100)
	   ,@DBname varchar(100)
	   ,@PrimaryServer varchar(50)
	   ,@SecondaryServer Varchar(50)
	   
	   DECLARE @name VARCHAR(50) -- Server Name
DECLARE @Role_Desc varchar(25)
DECLARE @cmd nvarchar(max)
DECLARE @temp nvarchar(max)

DECLARE @AGName varchar(25)
SET @AGName=(select name from master.sys.availability_groups)
SET @subject=UPPER(@AGName)+' : AAG Job Sync Status Details'
Create Table #temp
(JobName varchar(100),
SyncComment varchar(25))

-- Pseudo-code - Most Likely won't work as you expect: 
IF sqldba.dbo.fn_hadr_group_is_primary(@AGName) = 1 
BEGIN 
	-- do whatever you were going to do in the Primary:
	SET @PrimaryServer=( select n.replica_server_name from sys.dm_hadr_availability_replica_cluster_nodes n 
							join sys.dm_hadr_availability_replica_cluster_states cs on n.replica_server_name = cs.replica_server_name 
							join sys.dm_hadr_availability_replica_states rs  on rs.replica_id = cs.replica_id 
							WHERE rs.role_desc='PRIMARY')
		SET @SecondaryServer=( select n.replica_server_name from sys.dm_hadr_availability_replica_cluster_nodes n 
							join sys.dm_hadr_availability_replica_cluster_states cs on n.replica_server_name = cs.replica_server_name 
							join sys.dm_hadr_availability_replica_states rs  on rs.replica_id = cs.replica_id 
							WHERE rs.role_desc='SECONDARY')
			SET @cmd=' INSERT INTO #Temp
						SELECT name, ''Not on ['+@PrimaryServer+']'' FROM (
						SELECT name FROM ['+@SecondaryServer+'].msdb.dbo.sysjobs
						EXCEPT 
						SELECT name FROM ['+@PrimaryServer+'].msdb.dbo.sysjobs
						) S1

						UNION

						-- NOT ON SERVER 2
						SELECT name, ''Not on ['+@SecondaryServer+']'' FROM (
						SELECT name FROM ['+@PrimaryServer+'].msdb.dbo.sysjobs
						EXCEPT 
						SELECT name FROM ['+@SecondaryServer+'].msdb.dbo.sysjobs
						) S2'

  END
  EXEC(@cmd)
 



    -- Create html email header
    SELECT @HTML = N'<!DOCTYPE html>
                        <html>
                        <head lang="en">
                            <title></title>
                            <style type="text/css">
                                html {
                                color: #222;
                                font-size: 1em;
                                -webkit-font-smoothing: antialiased;
                                }

                                body {
                                padding: 0;
                                margin: 0;
                                width: 100%;
                                }

                                #main {
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                margin: 0 auto 100px auto;
                                position: relative;
                                font-weight: 300;
                                }

                                h1 {
                                font-family: "Segoe UI", sans-serif;
                                font-weight: 500;
                                font-size: 18px;
                                margin-bottom: 12px;
                                }

                                h2 {
                                font-family: "Segoe UI", sans-serif;
                                font-weight: 500;
                                font-size: 16px;
                                }

                                table {
                                border-collapse: collapse;
                                border-spacing: 0;
                                padding: 0;
                                margin: 0;
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                }

                                caption { text-align: left; padding: 2px;}
                                thead tr th { background-color:#ddd; }

                                th {
                                background-color: #eee;
                                border: 1px solid #ccc;
                                color: #555;
                                text-align: center;
                                font-weight: 700;
                                padding: 1px 4px;
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                }

                                td {
                                border: 1px solid #ccc;
                                vertical-align: middle;
                                padding: 1px 4px;
                                font-family: "Segoe UI", sans-serif;
                                font-size: 12px;
                                }

                                th.fix60 { width: 60px; }
                                th.fix90 { width: 90px; }
                                th.fix120 { width: 120px; }
                                th.fix140 { width: 140px; }
                                th.fix180 { width: 180px }

                                .container table {
                                border: 1px solid #e7e7e7;
                                margin: 0 -1px 24px 0;
                                text-align: left;
                                width: 100%;
                                }
                                .container tr { background-color:#fff; }
                            </style>
                        </head>
                        <body>
                            <div id="main">';
    SELECT @HTML = @HTML + N'<p style="font-weight:bold"> The Jobs sync Status Details.</p>';
	

    -- Create table header
    SELECT @HTML = @HTML + N'<table><thead><th class="fix140">Job Name</th><th class="fix140">Sync Details</th></thead><tbody>';


    -- Create cursor with tickets of the owner we are working on
    DECLARE owner CURSOR FAST_FORWARD
    FOR
        SELECT JobName,synccomment from #temp 

    -- Open the cursor and run over the tickets one by one and add them to a table row
    OPEN owner;
    FETCH NEXT FROM owner INTO @Sname,@DBname;
    WHILE @@FETCH_STATUS = 0 BEGIN

        -- Add row for every ticket
        SELECT @HTML = @HTML + N'<tr><td>' + CAST(@Sname as varchar(50)) + N'</td><td>' + CAST(@DBname as varchar(50)) +  N'</td></tr>';

        FETCH NEXT FROM owner INTO @Sname,@DBname;
    END;
    CLOSE owner;
    DEALLOCATE owner;



    -- Close table
    SELECT @HTML = @HTML + N'</tbody></table>';

    -- Close html
    SELECT @HTML = @HTML + N'</body></html>';

    -- Print html
    --SELECT @HTML;

    -- Send mail
    EXEC msdb.dbo.sp_send_dbmail 
        @profile_name='svcsql',
				 @recipients='SQLServerDBAs@spiritaero.com;Spirit_HP_NEN_SQL@groups.ext.hpe.com',
		 @subject = @subject ,
        @body = @HTML,
        @body_format = 'HTML';


DROP TABLE #temp 