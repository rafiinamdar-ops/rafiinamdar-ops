Set NOCOUNT ON
Declare @sql varchar(max)
DECLARE @servername VARCHAR(1500) -- database servername  
DECLARE @path VARCHAR(1500) -- path for backup files  
DECLARE @fileservername VARCHAR(1500) -- fileservername for backup  
DECLARE @fileDate VARCHAR(1500) -- used for file servername 

--SET ANSI_WARNINGS ON
--SET ANSI_WARNINGS ON

TRUNCATE TABLE sqldba.dbo.[ITAR_DatabaseBackup]
DECLARE db_cursor CURSOR FOR  
SELECT servername 
FROM SQLDBA.dbo.IBackupServers   
order by servername


OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @servername   

WHILE @@FETCH_STATUS = 0   
BEGIN   
        
  set @SQL='
		INSERT INTO sqldba.dbo.[ITAR_DatabaseBackup]
		
		SELECT DISTINCT '''+@ServerName+''' AS ServerName,
				db.name, 
				db.state_desc  AS [State_Desc],
				db.recovery_model_desc  AS [Recovery_Model],		
			LFB.LastFullBackup,
			LD.LastDifferential,
			LL.LastLog
			FROM ['+@ServerName+'].master.sys.databases db 
			LEFT JOIN ['+@ServerName+'].msdb.dbo.backupset bk  ON 
			bk.database_name =db.name 
			OUTER APPLY (SELECT MAX(CASE WHEN bk1.type = '+'''D'''+' THEN bk1.backup_finish_date ELSE NULL END)  AS LastFullBackup
			FROM ['+@ServerName+'].msdb.dbo.backupset bk1
			WHERE bk1.database_name=db.name) AS LFB
			OUTER APPLY (SELECT MAX(CASE WHEN bk1.type = '+'''I'''+' THEN bk1.backup_finish_date ELSE NULL END)  AS LastDifferential
			FROM ['+@ServerName+'].msdb.dbo.backupset bk1
			WHERE bk1.database_name=db.name) AS LD
			OUTER APPLY (SELECT MAX(CASE WHEN bk1.type = '+'''L'''+' THEN bk1.backup_finish_date ELSE NULL END)  AS LastLog
			FROM ['+@ServerName+'].msdb.dbo.backupset bk1
			WHERE bk1.database_name=db.name) AS LL
			WHERE db.name in (SELECT name from ['+@ServerName+'].master.sys.databases where name not in ('+'''tempdb'''+','+'''model'''+'))
			ORDER BY db.name ASC ' 

	Print @SQL
	EXEC (@SQL)
       FETCH NEXT FROM db_cursor INTO @servername   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor 

--select * from sqldba.dbo.[ITAR_DatabaseBackup] 




