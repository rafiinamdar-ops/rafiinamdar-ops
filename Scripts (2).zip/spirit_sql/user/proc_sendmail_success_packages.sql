
IF EXISTS 
(
SELECT name 
from sys.procedures 
where name ='proc_sendmail_success_packages'
)
DROP PROC datamart.proc_sendmail_success_packages
GO

CREATE PROCEDURE datamart.proc_sendmail_success_packages
AS
BEGIN
/*
Usage : To send email alert after successful execution of packages.

Creator/Editor #Date #Comments
Praveen C # 2017-11-28 # Initial creation
*/
SET NOCOUNT ON

DECLARE @xml NVARCHAR(MAX)
,@body NVARCHAR(MAX)
,@mail_recipients VARCHAR(1000)='jeebanjyoti.paramanik@spiritaero.com;pratheesh.n@spiritaero.com;rushendra.sv@spiritaero.com;Kanak.Agrawal@genpact.com;Prakhar.Shrivastava@genpact.com;Mamidala.RamManohar@genpact.com;LAXMI.NARASIMHA@genpact.com;SHAKATH.SK@genpact.com;Naveen.Bandla@genpact.com'
,@total_counts int

DECLARE @SuccessPackages TABLE
(
pk_id INT,
package_name VARCHAR(100),
package_end_time DATETIME,
[error_message] VARCHAR(MAX)
)

Insert INTO @SuccessPackages
SELECT pk_id, package_name, package_end_time, [error_message]
FROM datamart.log_package 
WHERE package_status = 'Success'
AND mail_sent = 0

SELECT @total_counts = COUNT(pk_id)
FROM @SuccessPackages

IF @total_counts > 0
BEGIN

SET @xml = CAST(( SELECT package_name AS 'td', '', package_end_time as 'td'
FROM @SuccessPackages
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

SET @body ='<html><body>
Hi Team,

<H4 style="color:green">Packages ran successfully</H4>
<table border = 1>
<tr>
<th>Package Name</th> <th>Last run Time</th></tr>'    

SET @body = @body + @xml +'</table>

<p></br>Thanks & Regards,</br>
Digi Analytics Admin</p>
</body></html>'

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'Spirit_Digi',
@body = @body,
@body_format ='HTML',
@recipients = @mail_recipients,
@subject = 'Alert - Packages successful' ;

UPDATE L SET mail_sent = 1
From datamart.log_package L
INNER JOIN @SuccessPackages T 
ON T.pk_id = L.pk_id

END

END

GO
