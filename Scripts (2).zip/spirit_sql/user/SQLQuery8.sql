use sqldba
go
UPDATE TestUpdTable SET col1='23' WHERE pk=10
UPDATE TestUpdTable SET col2='25' WHERE pk=10
UPDATE TestUpdTable SET col3='27' WHERE pk=10
UPDATE TestUpdTable SET col6=getdate()-1 WHERE pk=10
UPDATE TestUpdTable SET col7=getdate()-1 WHERE pk=10
UPDATE TestUpdTable SET col8=getdate()-1 WHERE pk=10
UPDATE TestUpdTable SET col11='test23' WHERE pk=10
UPDATE TestUpdTable SET col12='test25' WHERE pk=10
UPDATE TestUpdTable SET col13='test27' WHERE pk=10
GO

UPDATE TestUpdTable
   SET col1='23',col2='25',col3='27',
       col6=getdate()-1,col7=getdate()-1,col8=getdate()-1,
       col11='test23',col12='test25',col13='test27'
 WHERE pk=15
GO