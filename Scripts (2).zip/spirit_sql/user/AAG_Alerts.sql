USE [msdb]
GO

/****** Object:  Alert [AG Data Movement - Resumed]    Script Date: 4/12/2017 1:35:33 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'AG Data Movement - Resumed', 
		@message_id=35265, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [AG Data Movement - Suspended]    Script Date: 4/12/2017 1:35:33 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'AG Data Movement - Suspended', 
		@message_id=35264, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

/****** Object:  Alert [AG Role Change]    Script Date: 4/12/2017 1:35:33 AM ******/
EXEC msdb.dbo.sp_add_alert @name=N'AG Role Change', 
		@message_id=1480, 
		@severity=0, 
		@enabled=1, 
		@delay_between_responses=0, 
		@include_event_description_in=1, 
		@category_name=N'[Uncategorized]', 
		@job_id=N'00000000-0000-0000-0000-000000000000'
GO

