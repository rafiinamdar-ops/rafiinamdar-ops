Select    o.Object_Name                                [Project Name]  
        ,Replace(e.package_name    , '.dtsx', '')        [Package Name]  
        ,o.start_time                                [Start Time]  
        ,o.end_time                                    [End Time]  
        ,e.message_source_name                        [Message Source Name] --[Tool (Step)]  
        ,e.event_name                                [Event Name]                  
        ,e.subcomponent_name                        [SubComponent Name]  
        ,e.message_code                                [Message Cod]  
        ,m.message_time                                [Event Time] --[Error Date]  
        ,m.message                                    [Error Message]  
        ,m.message_time                                [Error Date]  
        ,o.caller_name                                [Caller Name]  
        ,o.Stopped_By_Name                            [Stoped By]  
        ,Row_Number() Over(Partition BY m.operation_id Order By m.message_source_type Desc) [Source Type Order]  
From    SSISDB.internal.operations o  
        Join SSISDB.internal.operation_messages m  
            On    o.operation_id = m.operation_id  
        Join SSISDB.internal.event_messages e  
            On    m.operation_id = e.operation_id  
            And    m.operation_message_id = e.event_message_id  
Where   e.package_name='pkg_boeing_all_targets_weekly.dtsx' --m.message_type = 120  
Order By o.end_time Desc  
        ,o.Object_Name  
        ,[Source Type Order] Asc 