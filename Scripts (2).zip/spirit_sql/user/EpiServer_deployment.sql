/*------------------
Created: FShope 2017-11-17
Purpose: Automate deployment of EpiServer updates
Updated: Fshope 2017-12-05 fixing separation between prod and stage steps
------------------*/

--Place EpiServer backup in \\corp\data\it_sqlbkup\episerver before running
--Modify Restore statements if necessary


USE [master]

--generate name for backup of old database
declare @backupfile nvarchar(300)
set @backupfile = N'J:\SQLBackups\EpiServer_backup_'+convert(varchar,getdate(),112)+left(replace(convert(varchar,getdate(),8),':',''),4)+'.bak'

--backup, check backups
BACKUP DATABASE [EpiServer] TO  DISK = @backupfile WITH NOFORMAT, NOINIT,  NAME = N'EpiServer-Full Database Backup', SKIP, NOREWIND, NOUNLOAD, COMPRESSION,  STATS = 10
exec xp_cmdshell 'dir J:\SQLBackups /O-D'

--delete old version of DB - CHECK BACKUP FIRST
alter database [EpiServer] set single_user with rollback immediate
go
drop database [EpiServer]
go

--if have to bring old DB back (DON'T NORMALLY RUN)
		restore database [EpiServer] from disk = N'J:\SQLBackups\EpiServer_backup_201712060833.bak'
			with file = 1
		go

--retrieve new database
exec xp_cmdshell 'xcopy \\corp\data\public\freddd\Episerver_1-10-2018.bak \\corp\data\it_sqlbkup\episerver\episerver.bak /Y'
--check filename/path for restore first

--restore new database
restore database [EpiServer] from disk = N'\\corp\data\it_sqlbkup\episerver\Episerver.bak'
	with file = 1,
		move N'SpiritAeroDemo' TO N'H:\Data\EpiServer\EpiServer.mdf',
		move N'SpiritAeroDemo_log' TO N'G:\Logs\EpiServer\EpiServer_log.ldf',
		nounload,  STATS = 5
go

--update new DB properties
USE [EpiServer]
go
ALTER DATABASE [EpiServer] MODIFY FILE (NAME=N'SpiritAeroDemo', NEWNAME=N'EpiServer')
go
ALTER DATABASE [EpiServer] MODIFY FILE (NAME=N'SpiritAeroDemo_log', NEWNAME=N'EpiServer_log')
go
USE [master]
go

--set size of DB files
declare @dbsize varchar(8)
declare @logsize varchar(8)
declare @cmd varchar(500)
--set db, log size to next higher 100MB increment
select @dbsize = cast((size/128)-(size/128 % 100)+100 as varchar)+'MB' from [EpiServer].sys.database_files where type = 0
select @logsize = cast((size/128)-(size/128 % 100)+100 as varchar)+'MB' from [EpiServer].sys.database_files where type = 1

select @cmd = 'ALTER DATABASE [EpiServer] MODIFY FILE ( NAME = N''EpiServer'', SIZE = '+@dbsize+' , FILEGROWTH = 100MB )'
exec(@cmd)
select @cmd = 'ALTER DATABASE [EpiServer] MODIFY FILE ( NAME = N''EpiServer_log'', SIZE = '+@logsize+' , FILEGROWTH = 100MB )'
exec(@cmd)
go

--set autoclose off
ALTER DATABASE [EpiServer] SET AUTO_CLOSE OFF

--set SA as DB owner
USE [EpiServer]
go
ALTER AUTHORIZATION ON DATABASE::[EpiServer] TO [sa]
go

--update users and security
USE [EpiServer]
go
DROP USER [spiritaero]
go
CREATE USER [CORP\svcEpi] FOR LOGIN [CORP\svcEpi]
go
ALTER ROLE [db_owner] ADD MEMBER [CORP\svcEpi]
go

--STAGE only
CREATE USER [sql_episerver] FOR LOGIN [sql_episerver]
go
ALTER ROLE [db_owner] ADD MEMBER [sql_episerver]
go


--create owner table
CREATE TABLE [dbo].[!DB_Devpr_Info](
	[DB_Nm] [varchar](100) NOT NULL, [Devpr_Nm] [varchar](50) NULL,
	[Devpr_Ph] [varchar](20) NULL, [Devpr_UID] [varchar](8) NULL,
	[DB_Cr_Dt] [datetime] NULL, [TRD_PRTY_APP] [char](1) NULL,
	[E_Mail] [varchar](100) NULL, [Application_name] [varchar](255) NULL) ON [PRIMARY]
go
INSERT INTO [!DB_Devpr_Info]
	SELECT db_name(), 'Chris Weaver', '523-6369', '1380301', create_date, 'Y', 'christopher.weaver@spiritaero.com', 'EpiServer'
	FROM sys.databases SDB WHERE SDB.name = db_name()

select * from [!db_devpr_info]

--intialize backup of new DB to DataDomain - PROD ONLY
exec sqldba.dbo.proc_BackupDD @sbackuptype = 'db', @sdbname = 'EpiServer'

--notify upon completion
declare @env varchar(10), @msgsubject varchar(100), @msgbody varchar (300)
select @env = case when cast(right(@@SERVERNAME,2) as int) < 60 then 'PROD'
					when cast(right(@@SERVERNAME,2) as int) > 60 then 'STAGE' end
select @msgsubject = @env + ' EpiServer deployment complete'
select @msgbody = 'New EpiServer database has been deployed to ' +@env+ '.'+char(10)+'Please validate.'

EXEC msdb.dbo.sp_send_dbmail @recipients = 'fredric.w.shope@spiritaero.com; christopher.weaver@spiritaero.com; diana.l.tedlock@spiritaero.com'
    , @subject = @msgsubject
    , @body = @msgbody

