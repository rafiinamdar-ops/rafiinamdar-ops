USE [msdb]
GO

/****** Object:  Job [DiskSpaceReports]    Script Date: 09/21/2016 02:22:44 ******/
IF  EXISTS (SELECT job_id FROM msdb.dbo.sysjobs_view WHERE name = N'DiskSpaceReports')
EXEC msdb.dbo.sp_delete_job @job_id=N'3c835b3d-2dc8-4edb-b1a1-e6a8180646a9', @delete_unused_schedule=1
GO

USE [msdb]
GO

/****** Object:  Job [DiskSpaceReports]    Script Date: 09/21/2016 02:22:44 ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]]    Script Date: 09/21/2016 02:22:45 ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'DiskSpaceReports', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'CORP\p9012592', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run Disk Space PS]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Disk Space PS', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'CmdExec', 
		@command=N'powershell.exe  "& ''J:\DBAScript\DiskSpace\DiskSpaceNew.ps1''"', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=0, 
		@proxy_name=N'cmdrun'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [PopulateDiskUtillazationTable]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'PopulateDiskUtillazationTable', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Insert into sqldba..[DiskSpaceUtilization_History]  Select * from sqldba..[DiskSpaceUtilization] 
--select * from sqldba..[DiskSpaceUtilization] 
truncate table sqldba..[DiskSpaceUtilization]
 --select * from [SQLDBA].[dbo].[AllServerDiskUtilization]
truncate table [SQLDBA].[dbo].[AllServerDiskUtilization]
  
BULK INSERT [SQLDBA].[dbo].[AllServerDiskUtilization]
FROM ''J:\DBAScript\AllServerDiskUtilization.csv''
WITH
(
    FIRSTROW = 2,
    FIELDTERMINATOR = ''"\t"'',  --CSV field delimiter
    ROWTERMINATOR = ''"\n'',   --Use to shift the control to next row
    TABLOCK
)

update[SQLDBA].[dbo].[AllServerDiskUtilization]
set [SERVERNAME]=replace([SERVERNAME],''"'',''''),[MountPoint]=replace([MountPoint],''"'',''''),[Label] =replace([Label] ,''"'',''''),[Capacity]=replace([Capacity],''"'',''''),[FreeSpace]=replace([FreeSpace],''"'','''')
,[UsedSpace]=replace([UsedSpace],''"'',''''),[PercentFree]=replace([PercentFree],''"'','''')


INSERT INTO [SQLDBA].[dbo].[DiskSpaceUtilization]
           ([SERVERNAME]
           ,[MountPoint]
           ,[Label] 
           ,[Capacity]
           ,[FreeSpace]
           ,[UsedSpace]
           ,[PercentFree]
           ,[CheckDate])
     SELECT 
           [SERVERNAME]
           ,[MountPoint]
           ,[Label]
           ,[Capacity]            
           ,[FreeSpace]
           ,[UsedSpace]
           ,[PercentFree]
           ,[CheckDate]
    FROM [SQLDBA].[dbo].[AllServerDiskUtilization]

      


', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run PME Space PS]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run PME Space PS', 
		@step_id=3, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [SQL-PIK-71].msdb.dbo.sp_start_job N''DiskSpaceReport'' ;
GO', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check PMEKUL ps job completeion]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check PMEKUL ps job completeion', 
		@step_id=4, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [SQL-PIK-71].sqldba.dbo.proc_Job_Watcher ''DiskSpaceReport'', 0, 1
GO', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Get Space data from PMEKUL Servers]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Get Space data from PMEKUL Servers', 
		@step_id=5, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Insert into sqldba..[DiskSpaceUtilization] Select * from [SQL-PIK-71].sqldba.dbo.[DiskSpaceUtilization]', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run FACICT space PS]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run FACICT space PS', 
		@step_id=6, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [SQL-FAC-02.FACICT.SPIRITAERO.COM\DEV].msdb.dbo.sp_start_job N''DiskSpaceReport'' ;
GO', 
		@database_name=N'master', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Check Facict ps job completeion]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Check Facict ps job completeion', 
		@step_id=7, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'exec [SQL-FAC-02.FACICT.SPIRITAERO.COM\DEV].sqldba.dbo.proc_Job_Watcher ''DiskSpaceReport'', 0, 1
GO', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Get space data from facict servers]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Get space data from facict servers', 
		@step_id=8, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'Insert into sqldba..[DiskSpaceUtilization] Select * from [SQL-FAC-02.FACICT.SPIRITAERO.COM\DEV].sqldba.dbo.[DiskSpaceUtilization] 
go
DELETE sqldba..[DiskSpaceUtilization]  where MountPoint is NULL
go', 
		@database_name=N'master', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run Disk Space Report]    Script Date: 09/21/2016 02:22:45 ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Disk Space Report', 
		@step_id=9, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'EXEC [sql-ent-85].msdb.dbo.sp_start_job @job_name = ''D4CBB9AA-F318-45BD-90F5-E935AF5BA04B''', 
		@database_name=N'msdb', 
		@output_file_name=N'c:\temp\DiskSpacetJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_Disk', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=0, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20160902, 
		@active_end_date=99991231, 
		@active_start_time=230000, 
		@active_end_time=235959, 
		@schedule_uid=N'7bc72f22-d74f-41f2-a04b-fa897862b15a'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

