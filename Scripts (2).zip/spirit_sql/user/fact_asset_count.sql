/*
Usage : This datamart table is used to populate the data for downtime attribute for assetcount

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_asset_count'
)

CREATE TABLE datamart.fact_asset_count
(
	busunit nvarchar(10),
	assetnum nvarchar(25),
	priority float,
	siteid nvarchar(8),
	isrunning float,
	
	installdate date,
	status nvarchar(20),
	statusdate nvarchar(21) 
)

GO


