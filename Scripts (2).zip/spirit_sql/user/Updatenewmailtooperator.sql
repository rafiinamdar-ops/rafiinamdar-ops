use msdb
go
DECLARE @OldEmailAddress      VARCHAR(100)       
DECLARE @NewEmailAddress    VARCHAR(100)
DECLARE @EmailAddress    VARCHAR(100)
select name,email_address  from msdb.dbo.sysoperators
DECLARE db_cursor CURSOR FOR 
select email_address from msdb.dbo.sysoperators


OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @EmailAddress


WHILE @@FETCH_STATUS = 0  
BEGIN  
IF   (@EmailAddress like '%Spirit_HP_NEN_SQL@groups.ext.hpe.com%')
BEGIN
	SET @OldEmailAddress='Spirit_HP_NEN_SQL@groups.ext.hpe.com'
	SET @NewEmailAddress='spiritdxcnensql@dxc.com'
	--select name,email_address,@OldEmailAddress,replace(email_address,@OldEmailAddress,@NewEmailAddress) as new_mail_address from msdb.dbo.sysoperators
	--where email_address like '%'+@OldEmailAddress+'%'

	update msdb.dbo.sysoperators
	set email_address = replace(email_address,@OldEmailAddress,@NewEmailAddress)
	where email_address like '%'+@OldEmailAddress+'%'
END
ELSE IF (@EmailAddress like '%Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com%')
BEGIN
	SET @OldEmailAddress='Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com'
	SET @NewEmailAddress='spiritdxcnensqlnonitar@dxc.com'

	--select name,email_address,@OldEmailAddress,replace(email_address,@OldEmailAddress,@NewEmailAddress) as new_mail_address from msdb.dbo.sysoperators
	--where email_address like '%'+@OldEmailAddress+'%'

--where email_address like '%'+@OldEmailAddress+'%'
	update msdb.dbo.sysoperators
	set email_address = replace(email_address,@OldEmailAddress,@NewEmailAddress)
	where email_address like '%'+@OldEmailAddress+'%'
END

FETCH NEXT FROM db_cursor INTO @EmailAddress 
END 

CLOSE db_cursor  
DEALLOCATE db_cursor 


--IF (@OldEmailAddress  ='Spirit_HP_NEN_SQL@groups.ext.hpe.com')
--SET @NewEmailAddress='spiritdxcnensql@dxc.com'
--Else 

--select name,email_address,replace(email_address,@OldEmailAddress,@NewEmailAddress) as new_mail_address from msdb.dbo.sysoperators
--where email_address like '%'+@OldEmailAddress+'%'

--update msdb.dbo.sysoperators
--set email_address = replace(email_address,@OldEmailAddress,@NewEmailAddress)
--where email_address like '%'+@OldEmailAddress+'%'

--use msdb
--go
select name,email_address  from msdb.dbo.sysoperators
--go
