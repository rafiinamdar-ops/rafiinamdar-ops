USE SCAT
go

-- =============================================
-- Create basic stored procedure template
-- =============================================

-- Drop stored procedure if it already exists
IF EXISTS (
  SELECT * 
    FROM INFORMATION_SCHEMA.ROUTINES 
   WHERE SPECIFIC_SCHEMA = N'dbo'
     AND SPECIFIC_NAME = N'sp_Batch_Processing' 
)
   DROP PROCEDURE dbo.sp_Batch_Processing
GO

CREATE PROCEDURE dbo.sp_Batch_Processing
AS
	
TRUNCATE TABLE [dbo].[Batch_Processing]

INSERT INTO [dbo].[Batch_Processing]
           ([TYP]
           ,[ChangeNo]
           ,[Page]
           ,[Line]
           ,[Grp]
           ,[EventTitle]
           ,[Part_Type]
           ,[StartDate]
           ,[CommitDate]
           ,[ECD]
           ,[CompletionDate]
           ,[PartNo]
           ,[PartName]
           ,[ToolNo]
           ,[ToolCode]
           ,[Model]
           ,[ACC]
           ,[ACCLoadDate]
           ,[PIN]
           ,[ESWR]
           ,[Proj_objnr]
           ,[Wbs_objnr]
           ,[Network_objnr]
           ,[Activity_objnr]
           ,[Line_Unit]
           ,[Plan_No]
           ,[Plan_No_CTR]
           ,[End_Acc_Plan]
           ,[End_Acc_Plan_CTR]
           ,[NAR]
           ,[Workable]
           ,[ProjectModel]
           ,[ProjectProgram]
           ,[ProjectCreatedDate]
           ,[NetworkCreatedDate]
           ,[Company]
           ,[Plant]
           ,[OEM_Release_ID]
           ,[Full_Acc]
           ,[Requisitioner]
           ,[Vendor]
           ,[Data_Load_Date]
           ,[WBS_Element]
           ,[Purchasing_Group]
           ,[Purchasing_Group_Name])
    
SELECT [TYP]
      ,[CHANGE_NO]
      ,[PAGE]
      ,[LINE]
      ,[GRP]
      ,[EVENT_TITLE]
      ,[PART_TYPE]
      ,[START_DATE]
      ,[COMMIT_DATE]
      ,[ECD]
      ,[COMPLETION_DATE]
      ,[PART_NO]
      ,[PART_NAME]
      ,[TOOL_NO]
      ,[TOOL_CODE]
      ,[MODEL]
      ,[ACC]
      ,[ACC_LOAD_DATE]
      ,[PIN]
      ,[ESWR]
      ,[PROJ_OBJNR]
      ,[WBS_OBJNR]
      ,[NETWORK_HDR_OBJNR]
      ,[ACTVTY_OBJNR]
      ,[LINE_UNIT]
      ,[PLAN_NO]
      ,[PLAN_NO_CTR]
      ,[END_ACC_PLAN_NO]
      ,[END_ACC_PLAN_NO_CTR]
      ,[NAR]
      ,[WORKABLE_FLAG]
      ,[PROJECT_MODEL]
      ,[PROJECT_PROGRAM]
      ,[PROJECT_CREATED_DATE]
      ,[NETWORK_CREATED_DATE]
      ,[COMPANY]
      ,[PLANT]
      ,[OEM_RELEASE_ID]
      ,[FULL_ACC]
      ,[REQUISITIONER]
      ,[VENDOR]
      ,[DATA_LOADED_DATE]
      ,[WBS_ELEMENT]
      ,[PURCHASING_GROUP]
      ,[PURCHASING_GROUP_NAME]

  FROM [LXPDW1]..[SCAT].[SCAT_VIEW]
Where ((Change_No  Not like '02%') AND ((NAR <> 'Y') OR (NAR IS NULL))) 
GO


GO

-- =============================================
-- Example to execute the stored procedure
-- =============================================
GRANT EXECUTE  on  sp_Batch_Processing TO  [SCATUsers]
GO
