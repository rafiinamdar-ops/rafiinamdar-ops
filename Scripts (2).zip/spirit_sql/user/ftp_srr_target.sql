/*
Usage : This table is used to load srr targets data 

Creator/Editor #Date #Comments
Rammanohar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_srr_target'
)

CREATE TABLE [staging].[ftp_srr_target](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[load_date] [datetime] NOT NULL CONSTRAINT [DF__ftp_srr_t__load___1C873BEC]  DEFAULT (getdate()),
	[model] [nvarchar](255) NOT NULL,
	[heading] [nvarchar](255) NULL,
	[value_chain] [nvarchar](255) NULL,
	[function] [nvarchar](255) NULL,
	[year] [nvarchar](255) NULL,
	[week] [datetime] NULL,
	[week_no] [int] NULL,
	[weekly_srr_target] [float] NULL,
	[ytd_srr_target] [float] NULL,
	[weekly_gl_target] [float] NULL,
	[ytd_gl_target] [float] NULL,
	[sheet_name] [nvarchar](255) NULL,
	[location] [nvarchar](50) NULL,
 CONSTRAINT [PK__ftp_srr___1543595EAC553A35] PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 

GO


