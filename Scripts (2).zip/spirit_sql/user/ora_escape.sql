/*
Usage : This table is used to load escapes actuals data  
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ora_escape'
)

CREATE TABLE [staging].[ora_escape](
	[load_date] [datetime] NULL CONSTRAINT [DF_ora_escape_load_date]  DEFAULT (getdate()),
	[progam_nm] [varchar](255) NULL,
	[value_chain_cd] [varchar](255) NULL,
	[responsible_mgmt_code] [varchar](255) NULL,
	[feature_description] [varchar](255) NULL,
	[discrepancy_description] [varchar](max) NULL,
	[feature_code] [varchar](255) NULL,
	[ca_count] [float] NULL,
	[ncr_part_no] [varchar](255) NULL,
	[ca_ser_no] [varchar](255) NULL,
	[sum_ncr_cost_amt] [float] NULL,
	[discrepancy_code] [varchar](255) NULL,
	[unit_no] [varchar](50) NULL,
	[date_written] [datetime] NULL CONSTRAINT [DF__ora_escap__date___607251E5]  DEFAULT (getdate()),
	[SNN_suppl_notification_flag] [numeric](10, 0) NULL,
	[dir_title] [varchar](50) NULL,
	[man_name] [varchar](100) NULL,
	[supt_title] [varchar](50) NULL,
	[resp_ca_team] [varchar](50) NULL,
	[location] [varchar](50) NULL
) 

GO




