IF EXISTS
(
SELECT name
FROM sys.views 
WHERE name = 'vw_dim_calendar'
)

DROP VIEW datamart.vw_dim_calendar

GO

CREATE VIEW datamart.vw_dim_calendar
as

SELECT 
spirit_year
,spirit_week
,convert(varchar,spirit_year) +  iif(spirit_week < 10, '0','') + convert(varchar,spirit_week) as period
,max(date_key) as week_end_date
,min(date_key) as week_start_date

,'Week ' + convert(varchar,spirit_week) + ' (' + replace(convert(varchar,min(date_key),102),'.','-') 
 + ' - ' + replace(convert(varchar,max(date_key),102),'.','-') + ')' as week_str
,max(spirit_mnth) as spirit_mnth
,max(spirit_mnth_name) as spirit_mnth_name
,(Count(date_key) - SUM(CASE WHEN DATEPART(dw, date_key) IN (1,7) THEN 1 ELSE 0 END) - sum(is_holiday)) * 7.22 as week_work_hours_1
,(Count(date_key) - SUM(CASE WHEN DATEPART(dw, date_key) IN (1,7) THEN 1 ELSE 0 END) - sum(is_holiday)) * 8 as week_work_hours_2
--,(5 - sum(is_holiday)) * 7.22 as week_work_hours_1
--,(5 - sum(is_holiday)) * 8 as week_work_hours_2

,max(is_current_week) as is_current_week

FROM datamart.dim_calendar

GROUP BY spirit_year,spirit_week


GO