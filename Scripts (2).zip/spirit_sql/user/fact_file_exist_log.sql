/*
Usage : To log the status of input files 

Creator/Editor #Date #Comments
Praveen C # 2017-11-20 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_file_exist_log'
)
CREATE Table datamart.fact_file_exist_log
(
logdate datetime default (getdate()),
file_code varchar(100) NOT NULL,
file_name varchar(500) NOT NULL,
existence varchar(3)  NOT NULL DEFAULT('Yes'),
mail_sent BIT NOT NULL DEFAULT(0)
)
GO
