/*
Usage : This datamart table is used to populate the data for overtime metric for facility

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'fact_overtime'
)

CREATE TABLE datamart.fact_overtime
(
	business_unit nvarchar(50),
	cost_center nvarchar(255),
	week_end_date datetime,
	actual_regular_hours float,
	actual_overtime_hours float,
	
	forecast_regular_hours float,
	forecast_overtime_hours float,
	actual_ot_pcg float,
	forecast_ot_pcg float,
	location nvarchar(50) 
)

GO


