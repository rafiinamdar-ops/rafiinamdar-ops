USE [SSISDB]
GO
/***** Script for SelectTopNRows command from SSMS ******/
SELECT fld.Name as FolderName

,fld.created_By_Name as folderCreatdBy

,fld.Created_time as folderCreateddate
,proj.name projectName
,proj.created_time
,proj.last_deployed_time
,proj.deployed_by_name
,proj.folder_id
,pkg.[project_version_lsn]
,pkg.[name] as Pakagename
,pkg.[description]
,pkg.[package_format_version]
,pkg.[version_major]
,pkg.[version_minor]
,pkg.[version_build]
,pkg.[version_comments]
FROM [SSISDB].[internal].folders fld
left outer join [SSISDB].[internal].[projects] proj on proj.folder_id=fld.folder_id
left outer join [SSISDB].[internal].[packages] pkg on pkg.project_id=pkg.project_id

Where proj.last_deployed_time>'2018-11-29 23:04:49.1106068 -06:00'

select name,last_deployed_time   from [SSISDB].[internal].[projects]


USE [SSISDB];
GO
SELECT 
	pk.project_id, 
	pj.name 'folder', 
	pj.last_deployed_time,
	pk.name
	
FROM
	catalog.packages pk JOIN catalog.projects pj 
	ON (pk.project_id = pj.project_id)
ORDER BY
	folder,
	pk.name