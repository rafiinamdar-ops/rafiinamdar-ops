
/*
Usage : This table is used to map the charge management codes used for different function
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-09	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_a350_mapping'
)


CREATE TABLE [datamart].[dim_a350_mapping](
	[sno] [int] IDENTITY(1,1) NOT NULL,
	[charge_management_code] [varchar](50) NULL,
	[program] [varchar](50) NULL,
	[function] [varchar](50) NULL,
	[load_date] [datetime] NULL DEFAULT (getdate())
) 

GO



