

Declare  @SinceWhen datetime    --  default: the last 3 hours
Declare  @RootPath nvarchar(255) --  default: C:\SQLErrorReport
Declare  @ShowResult bit           --  default: 0 = "No"
SET @RootPath  = null
SET @ShowResult  = null 
SET NOCOUNT ON
SELECT @SinceWhen=(SELECT DATEADD(day,-1,GETDATE()) )
IF @RootPath IS NULL
  SET @RootPath = N'C:\Temp'

IF @ShowResult IS NULL
  SET @ShowResult =1
  
/*  Get the product version  */
DECLARE @Version nchar(2)
SELECT @Version = SUBSTRING(CONVERT(nvarchar(10), SERVERPROPERTY (N'ProductVersion')), 1, 2)
--SELECT  SUBSTRING(CONVERT(nvarchar(10), SERVERPROPERTY (N'ProductVersion')), 1, 2)
/*  In the following section we build a watermark table to remember last log 
check time. For the first time run, or after a SQL service restart, the temp
table is rebuilt from scratch so "12 hour ago" is taken as the last run default  */
DECLARE @LastRunTime datetime
IF OBJECT_ID(N'tempdb.dbo.Tbl_ErrorLogReportLastRun', N'U') IS NULL
  BEGIN
    CREATE TABLE tempdb.dbo.Tbl_ErrorLogReportLastRun (LastRunTime datetime, Version nchar(2))
    IF @SinceWhen IS NULL
      SET @LastRunTime = DATEADD(hh, -12, getdate())
    ELSE
      SET @LastRunTime = @SinceWhen
  END
ELSE
  BEGIN
    IF @SinceWhen IS NULL
      SELECT @LastRunTime = LastRunTime FROM tempdb.dbo.Tbl_ErrorLogReportLastRun
    ELSE
      SELECT @LastRunTime = @SinceWhen
  END
 
/*  Now we build a table to hold the information about error logs  */
IF OBJECT_ID (N'tempdb.dbo.Tbl_SQLErrorLogList', N'U') IS NULL
  CREATE TABLE tempdb.dbo.Tbl_SQLErrorLogList 
  (
    ArchiveNo tinyint, 
    [Date] datetime, 
    LogFileSize int, 
    SQLErrorLogPath nvarchar(255) 
  )
ELSE
  TRUNCATE TABLE tempdb.dbo.Tbl_SQLErrorLogList

INSERT INTO tempdb.dbo.Tbl_SQLErrorLogList (ArchiveNo, [Date], LogFileSize) 
  EXEC (N'master.dbo.sp_enumerrorlogs') 
  
--  Remove unnecessary logs terminated earlier than the interested time frame
DELETE FROM tempdb.dbo.Tbl_SQLErrorLogList WHERE [Date] < @LastRunTime

/*  In this section we build tables to hold searched results  */
IF OBJECT_ID (N'tempdb.dbo.Tbl_SQLErrorLogContents', N'U') IS NULL
  CREATE TABLE tempdb.dbo.Tbl_SQLErrorLogContents 
  (
    Id int identity, 
    LogDate datetime, 
    ProcessInfo nvarchar(25), 
    LogText nvarchar(3984), 
    ContinuationRow int
  )
ELSE
  TRUNCATE TABLE tempdb.dbo.Tbl_SQLErrorLogContents 

--  Read the current log to find out the log path. 
--  Note the error log output formats are different between SS2000 and SS2005  
IF @Version = N'8.'
  INSERT INTO tempdb.dbo.Tbl_SQLErrorLogContents (LogText, ContinuationRow) 
    EXEC(N'master.dbo.sp_readerrorlog') 
ELSE IF @Version = N'9.' OR @Version = N'10' OR @Version = N'11' OR @Version = N'12'
  INSERT INTO tempdb.dbo.Tbl_SQLErrorLogContents (LogDate, ProcessInfo, LogText) 
    EXEC(N'master.dbo.sp_readerrorlog') 

DECLARE @SQLErrorLogPath nvarchar(255), @cmd nvarchar(500)
SELECT @cmd = N'', 
       @SQLErrorLogPath = SUBSTRING(LogText, CHARINDEX(N'''', LogText)+1, 
                          LEN(LogText)-CHARINDEX(N'''', LogText)-2)
  FROM tempdb.dbo.Tbl_SQLErrorLogContents 
  WHERE LogText LIKE N'%Logging SQL Server messages in file%'

--  If our interested interval spans more than the current error log
TRUNCATE TABLE tempdb.dbo.Tbl_SQLErrorLogContents 
UPDATE tempdb.dbo.Tbl_SQLErrorLogList 
  SET SQLErrorLogPath = @SQLErrorLogPath + REPLACE((N'.' + 
                        CAST(ArchiveNo AS nvarchar(100))), N'.0', N'')

--  Loop through target logs and search interested keywords 
--  then save them in the table

DECLARE @ArchiveNo int
SELECT @ArchiveNo = -1, @cmd = N''
WHILE 1 = 1
  BEGIN
    SELECT TOP 1 @ArchiveNo = ArchiveNo, @SQLErrorLogPath = SQLErrorLogPath 
      FROM tempdb.dbo.Tbl_SQLErrorLogList 
      WHERE ArchiveNo > @ArchiveNo 
      ORDER BY ArchiveNo ASC
    IF @@ROWCOUNT = 0
      BREAK  
    --  For SS 2000
    IF @Version = N'8' 
      BEGIN       
        SET @cmd = N'findstr.exe /i /g:' + @RootPath + N'\findstr_incl.txt "' + 
                   @SQLErrorLogPath + N'" | findstr.exe /v /g:' + 
                   @RootPath + N'\findstr_excl.txt '
        SET @cmd = N'master.dbo.xp_cmdshell ''' + @cmd + N''''
        INSERT INTO tempdb.dbo.Tbl_SQLErrorLogContents (LogText) EXEC (@cmd)
      END
    --  For SS 2005
    ELSE IF  @Version = N'9.' OR @Version = N'10' OR @Version = N'11' OR @Version = N'12'
      BEGIN
        SET @cmd = N'master.dbo.sp_readerrorlog ' + CAST(@ArchiveNo AS varchar(3))
        INSERT INTO tempdb.dbo.Tbl_SQLErrorLogContents (LogDate, ProcessInfo, LogText) 
          EXEC (@cmd)
      END
  END

--  Clean up noise entries in the log table
DELETE FROM tempdb.dbo.Tbl_SQLErrorLogContents WHERE LogText IS NULL

IF @Version = N'8'
  BEGIN
    DELETE FROM tempdb.dbo.Tbl_SQLErrorLogContents 
      WHERE LogText NOT LIKE N'[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9] %'
    DELETE FROM tempdb.dbo.Tbl_SQLErrorLogContents 
      WHERE CONVERT(datetime, SUBSTRING(LogText, 1, 19)) < @LastRunTime 
  END
 
--  For SS2005, we can't use findstr to search binary logs. We have to use T-SQL
IF @Version = N'9.' OR @Version = N'10' OR @Version = N'11' OR @Version = N'12'
  BEGIN
    DELETE FROM tempdb.dbo.Tbl_SQLErrorLogContents 
      WHERE CONVERT(datetime, LogDate) < @LastRunTime 
    DECLARE @Tmp TABLE 
    (
      Id int identity, 
      LogDate datetime, 
      ProcessInfo nvarchar(25), 
      LogText nvarchar(3984), 
      ContinuationRow int
    )
    INSERT INTO @Tmp (LogDate, ProcessInfo, LogText)

    SELECT LogDate, ProcessInfo, LogText 
      FROM tempdb.dbo.Tbl_SQLErrorLogContents 
      WHERE 
      (   
         (LogText LIKE N'%broken%')
      OR (LogText LIKE N'%can not%')
      OR (LogText LIKE N'%cannot%')
      OR (LogText LIKE N'%corrupt%')
      OR (LogText LIKE N'%could not%')
      OR (LogText LIKE N'%Starting up databas%')
	  OR (LogText LIKE N'%dead%')
      OR (LogText LIKE N'%degrad%')
      OR (LogText LIKE N'%disabled%' AND 
          LogText NOT LIKE N'%not configured%')
      OR (LogText LIKE N'%does not%')
      OR (LogText LIKE N'%Error%' AND 
          LogText NOT LIKE N'% 0 errors%' AND 
          LogText NOT LIKE N'%error log%' AND 
          LogText NOT LIKE N'%errorlog%')
      OR (LogText LIKE N'%Exceed%')
      OR (LogText LIKE N'%Exception%')
      OR (LogText LIKE N'%Expire%')
      OR (LogText LIKE N'%fail%')
      OR (LogText LIKE N'%fatal%')
      OR (LogText LIKE N'%incompatible%')
      OR (LogText LIKE N'%inconsistent%')
      OR (LogText LIKE N'%incorrect%')
      OR (LogText LIKE N'%insufficient%')
      OR (LogText LIKE N'%invalid%')
      OR (LogText LIKE N'%I/O%')
      OR (LogText LIKE N'%marked%')
      OR (LogText LIKE N'%no memory%')
      OR (LogText LIKE N'%non-yielding%')
      OR (LogText LIKE N'%not allow%')
      OR (LogText LIKE N'%not available%')
      OR (LogText LIKE N'%not complete%')
      OR (LogText LIKE N'%not enough%')
      OR (LogText LIKE N'%not found%')
      OR (LogText LIKE N'%not installed properly%')
      OR (LogText LIKE N'%not match%')
      OR (LogText LIKE N'%not reorganized%')
      OR (LogText LIKE N'%not support%')
      OR (LogText LIKE N'%not valid%')
      OR (LogText LIKE N'%pressure%')
      OR (LogText LIKE N'%problem%')
      OR (LogText LIKE N'%reject%')
      OR (LogText LIKE N'%running low on virtual address%')
      OR (LogText LIKE N'%Stack%')
      OR (LogText LIKE N'%terminat%')
      OR (LogText LIKE N'%time out%')
      OR (LogText LIKE N'%timeout%')
      OR (LogText LIKE N'%torn%')
      OR (LogText LIKE N'%unable%')
      OR (LogText LIKE N'%unavailable%') 
      OR (LogText LIKE N'%unexpect%') 
      OR (LogText LIKE N'%unknown%') 
      OR (LogText LIKE N'%unrecover%') 
      OR (LogText LIKE N'%unsupport%')
      OR (LogText LIKE N'%wrong%') 
      )
      AND LogText NOT LIKE N'%informational message%'

    TRUNCATE TABLE tempdb.dbo.Tbl_SQLErrorLogContents
    INSERT INTO tempdb.dbo.Tbl_SQLErrorLogContents (LogDate, ProcessInfo, LogText) 
      SELECT LogDate, ProcessInfo, LogText FROM @Tmp
  END

--  To update the last run time
IF @SinceWhen IS NULL
  BEGIN
    IF EXISTS (SELECT * FROM tempdb.dbo.Tbl_ErrorLogReportLastRun)
      UPDATE tempdb.dbo.Tbl_ErrorLogReportLastRun 
        SET LastRunTime = getdate(), Version = @Version
    ELSE
      INSERT INTO tempdb.dbo.Tbl_ErrorLogReportLastRun VALUES (getdate(), @Version)
  END

--  To display result
IF @ShowResult = 1
  BEGIN
    IF @Version = N'8'
      SELECT @@SERVERNAME,LogText 
      FROM tempdb.dbo.Tbl_SQLErrorLogContents 
      ORDER BY CONVERT(datetime, SUBSTRING(LogText, 1, 19)) ASC
    ELSE IF @Version = N'9.' OR @Version = N'10' OR @Version = N'11' OR @Version = N'12'
      INSERT  INTO sqldba..tblErrorLog  SELECT @@SERVERNAME AS ServerName, LogDate, ProcessInfo, LogText 
      FROM tempdb.dbo.Tbl_SQLErrorLogContents 
	  ORDER BY CONVERT(datetime, LogDate) ASC
	  
  END



