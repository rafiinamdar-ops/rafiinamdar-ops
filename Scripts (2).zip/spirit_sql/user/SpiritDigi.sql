USE [master]
GO

/****** Object:  Database [SpiritDigi]    Script Date: 12/15/2017 10:39:51 AM ******/
CREATE DATABASE [SpiritDigi]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'SpiritDigi_Data', FILENAME = N'H:\Data\SpiritDigi\SpiritDigi_Data.MDF' , SIZE = 1024MB , MAXSIZE = UNLIMITED )
 LOG ON 
( NAME = N'SpiritDigi_Log', FILENAME = N'G:\Logs\SpiritDigi\SpiritDigi_Log.LDF' , SIZE = 250MB , MAXSIZE = 2048GB  )
GO

USE DBNAME EXEC sp_changedbowner 'sa'

-- Login: CORP\S9038970
CREATE LOGIN [CORP\S9038970] FROM WINDOWS WITH DEFAULT_DATABASE = [SpiritDigi]
/* sp_help_revlogin script 
** Generated Dec 15 2017 10:47AM on SQL-ENT-85 */

-- Login: CORP\S9039875
CREATE LOGIN [CORP\S9039875] FROM WINDOWS WITH DEFAULT_DATABASE = [SpiritDigi]
/* sp_help_revlogin script 
** Generated Dec 15 2017 10:47AM on SQL-ENT-85 */
 
 
-- Login: user_spiritdigi
CREATE LOGIN [user_spiritdigi] WITH PASSWORD = 0x020088BEB8820C3DA02AE28443D3551A065BBAA4D9132EC7DA406432CCC67B9F70A2C1CB4015639408682898D79A01C3CF77370496C149BAAC38F5532635646128DAFD6018E3 HASHED, SID = 0xCCC56439EEA14C4FAFCC61E37AF1695B, DEFAULT_DATABASE = [SpiritDigi_Dev], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
/* sp_help_revlogin script 
** Generated Dec 15 2017 10:47AM on SQL-ENT-85 */


 
 
-- Login: reader_spiritdigi
CREATE LOGIN [reader_spiritdigi] WITH PASSWORD = 0x0200E9C0A590B7087B2FEA3DF45A27ED4167856045F58946A198C733573E654F25BC39579FB271615E238F3E9F9176F8AC058D6670CFD3A5B24851855DEAE620D43E2F5BE3D6 HASHED, SID = 0x56925E17C4980A449A3B9054AA1F7143, DEFAULT_DATABASE = [SpiritDigi_Dev], CHECK_POLICY = OFF, CHECK_EXPIRATION = OFF
/* sp_help_revlogin script 
** Generated Dec 15 2017 10:47AM on SQL-ENT-85 */

EXEC sp_addrolemember @rolename = 'db_datareader', @membername = 'reader_spiritdigi'
 
 



USE [SpiritDigi]
GO
/****** Object:  User [CORP\s9038970]    Script Date: 12/15/2017 10:42:59 AM ******/
CREATE USER [CORP\s9038970] FOR LOGIN [CORP\S9038970] WITH DEFAULT_SCHEMA=[CORP\s9038970]
GO
/****** Object:  User [CORP\s9039875]    Script Date: 12/15/2017 10:42:59 AM ******/
CREATE USER [CORP\s9039875] FOR LOGIN [CORP\S9039875] WITH DEFAULT_SCHEMA=[CORP\s9039875]
GO
/****** Object:  User [user_spiritdigi]    Script Date: 12/15/2017 10:42:59 AM ******/
CREATE USER [user_spiritdigi] FOR LOGIN [user_spiritdigi] WITH DEFAULT_SCHEMA=[dbo]
GO
CREATE USER [reader_spiritdigi] FOR LOGIN [user_spiritdigi] WITH DEFAULT_SCHEMA=[dbo]
GO
ALTER ROLE [db_owner] ADD MEMBER [user_spiritdigi]
GO
ALTER ROLE [db_datareader] ADD MEMBER [user_spiritdigi]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [user_spiritdigi]
GO
ALTER ROLE [db_datareader] ADD MEMBER [reader_spiritdigi]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [CORP\S9039875]
GO
ALTER ROLE [db_datareader] ADD MEMBER [CORP\S9039875]
GO
ALTER ROLE [db_datawriter] ADD MEMBER [CORP\S9038970] 
GO
ALTER ROLE [db_datareader] ADD MEMBER [CORP\S9038970] 
GO

/*    ==Scripting Parameters==

    Source Server Version : SQL Server 2012 (11.0.6544)
    Source Database Engine Edition : Microsoft SQL Server Standard Edition
    Source Database Engine Type : Standalone SQL Server

    Target Server Version : SQL Server 2017
    Target Database Engine Edition : Microsoft SQL Server Standard Edition
    Target Database Engine Type : Standalone SQL Server
*/

USE [SSISDB]
GO
/****** Object:  User [CORP\S9038970]    Script Date: 1/18/2018 4:04:44 AM ******/
CREATE USER [CORP\S9038970] FOR LOGIN [CORP\S9038970] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [CORP\S9039875]    Script Date: 1/18/2018 4:04:44 AM ******/
CREATE USER [CORP\S9039875] FOR LOGIN [CORP\S9039875] WITH DEFAULT_SCHEMA=[dbo]
GO
/****** Object:  User [user_spiritdigi]    Script Date: 1/18/2018 4:04:44 AM ******/
CREATE USER [user_spiritdigi] FOR LOGIN [user_spiritdigi] WITH DEFAULT_SCHEMA=[dbo]
GO


Declare @folder_id bigint
EXEC [SSISDB].[catalog].[create_folder] @folder_name=N'SpiritDigi', @folder_id=@folder_id OUTPUT
Select @folder_id
EXEC [SSISDB].[catalog].[set_folder_description] @folder_name=N'SpiritDigi', @folder_description=N''

GO

GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=1
GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=2
GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=100
GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=102
GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=103
GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=101
GO

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=5, @principal_id=13, @permission_type=104
GO


-- Create a Database Mail account
EXECUTE msdb.dbo.sysmail_add_account_sp
    @account_name = 'Spirit_Digi',
   -- @description = 'Mail account for administrative e-mail.',
    @email_address = 'noreply-digianalytics@spiritaero.com',
    --@replyto_address = 'SQLServerDBAs@spiritaero.com',
    @display_name = 'Spirit_Digi',
    @mailserver_name = 'sec-relay-na.spiritaero.com' ;

-- Create a Database Mail profile
EXECUTE msdb.dbo.sysmail_add_profile_sp
    @profile_name = 'Spirit_Digi'
    --@description = 'Spirit_Digi.' ;
    
    -- Add the account to the profile

EXECUTE msdb.dbo.sysmail_add_profileaccount_sp
    @profile_name = 'Spirit_Digi',
    @account_name = 'Spirit_Digi',
    @sequence_number = 1;

 


-- Grant access to the profile to the public role

EXECUTE msdb.dbo.sysmail_add_principalprofile_sp
    @profile_name = 'Spirit_Digi',
    @principal_name = 'user_spiritdigi',
   @is_default = 0;
GO

