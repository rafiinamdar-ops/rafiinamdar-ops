DECLARE @sql varchar(500)
DECLARE @Info int=9
DECLARE @Warning int=8
DECLARE @Critical int=3
DECLARE @Subject varchar(100)
DECLARE @OutputParameter int
DECLARE @strMsg varchar(4000)
Declare @RCPT VARCHAR(500)
DECLARE @EMAIL varchar(5000)
DECLARE @DBID int
DECLARE @FileID int
SET @RCPT ='Spirit_HP_NEN_SQL_nonITAR@groups.ext.hpe.com;SQLServerDBAs@spiritaero.com' 
--SET @RCPT ='mahammadrafik.inamdar@hpe.com' 
if exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical)
   begin

   SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
		CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
						where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
					and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical
set @sql=(SELECT 'ALTER DATABASE '+DB_NAME(F.database_id )+ ' MODIFY FILE' +'(NAME='+F.name+ ',MAXSIZE='
		+cast((cast(((size*8)/1024) as bigint)+Cast(((growth*8)/1024) as bigint)+1) as Varchar)+'MB)' FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical)
print(@sql)
EXEC (@sql)

		---SELECT @Subject = 'SQL Monitor Disk Free Space Alert: ' + @@servername
		
			EXEC sqldba.dbo.usp_DBGrowth @OutputParameter OUTPUT 
		
			SELECT @strMSG=( SELECT			'DatabaseName : ' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							'DB Current Size : ' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+' MB' + char(10)+CHAR(10)+
							'DB Growth : ' +CAST((CAST((f.growth*8) AS bigint)/1024) AS VARCHAR)  +' MB' + char(10)  +CHAR(10)+
							'DB MaxSize : ' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +' MB' + char(10)  +CHAR(10)+
							'FreeSpace On '+ SUBSTRING(vs.volume_mount_point,1,2)+ ' Drive : ' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +' MB' + char(10) +CHAR(10)+
							'TotalSpace On ' +SUBSTRING(vs.volume_mount_point,1,2)+ '  Drive : '+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +' MB' + char(10) +CHAR(10)+
							'DBA Action : Immediate - Shrink the file, escalate a drive space request, or take other steps to ensure space available for DB to Grow. '+ char(10) +CHAR(10)+
							'Suggested Additional Space Request : '+ (CAST((@OutputParameter*1.5) AS VARCHAR))+' MB'+ char(10) +CHAR(10)+
							convert(char(15),' EventTime: ') + convert(varchar, getdate())
							FROM sys.master_files AS f
					CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
					WHERE f.database_id =@DBID and f.file_id =@fileid)

			SET @EMAIL = 'msdb.dbo.sp_send_dbmail
   @recipients = ''' + @RCPT + ''',
   @body = ''' + @strMSG + ''',
   @subject = '' Critical : Database Grown on ' + @@SERVERNAME + ' !!'''
 EXEC (@EMAIL)
  

--SELECT  'CASE 1', DB_NAME(f.database_id) As DBName,
--		(((f.growth*8)/1024)) AS Growth,
--		((cast(f.max_size as bigint)*8)/1024) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))) As CountS
--		FROM sys.master_files AS f
--	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
--	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
--		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Critical
end
   
   Else IF

   exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning)
   begin

SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
		CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
		where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and  FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning

set @sql=(SELECT 'ALTER DATABASE '+DB_NAME(F.database_id )+ ' MODIFY FILE' +'(NAME='+F.name+ ',MAXSIZE='
		+cast((cast(((size*8)/1024) as bigint)+Cast(((growth*8)/1024) as bigint)+1) as Varchar)+'MB)' FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and  FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning)
print(@sql)
EXEC (@sql)

		---SELECT @Subject = 'SQL Monitor Disk Free Space Alert: ' + @@servername
		
 
			EXEC sqldba.dbo.usp_DBGrowth @OutputParameter OUTPUT 
			SELECT @strMSG=( SELECT			'DatabaseName : ' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							'DB Current Size : ' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+' MB' + char(10)+CHAR(10)+
							'DB Growth : ' +CAST((CAST((f.growth*8) AS bigint)/1024) AS VARCHAR)  +' MB' + char(10)  +CHAR(10)+
							'DB MaxSize : ' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +' MB' + char(10)  +CHAR(10)+
							'FreeSpace On '+ SUBSTRING(vs.volume_mount_point,1,2)+ ' Drive : ' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +' MB' + char(10) +CHAR(10)+
							'TotalSpace On ' +SUBSTRING(vs.volume_mount_point,1,2)+ '  Drive : '+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +' MB' + char(10) +CHAR(10)+
							'DBA Action : Send an SR to SRVWINDOWS for more space. '+ char(10) +CHAR(10)+
							'Suggested Additional Space Request : '+ (CAST(@OutputParameter AS VARCHAR))+' MB'+ char(10) +CHAR(10)+
							convert(char(15),' EventTime: ') + convert(varchar, getdate())
							FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	WHERE f.database_id =@DBID and f.file_id =@fileid)

			SET @EMAIL = 'msdb.dbo.sp_send_dbmail
   @recipients = ''' + @RCPT + ''',
   @body = ''' + @strMSG + ''',
   @subject = ''Warning : Database Grown on ' + @@SERVERNAME + ' !!'''
 EXEC (@EMAIL)
  

--SELECT  'CASE 2',DB_NAME(f.database_id) As DBName,
--		(((f.growth*8)/1024)) AS Growth,
--		((cast(f.max_size as bigint)*8)/1024) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))) As CountS
--		FROM sys.master_files AS f
--	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
--	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
--		and  FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>@Critical and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))<=@Warning
end
  ELSE IF
  
   exists(SELECT F.* FROM sys.master_files AS F
CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
 where ((f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) ) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info)
   begin

SELECT  @DBid=f.database_id,@FileID =f.file_id  
		FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info

set @sql=(SELECT 'ALTER DATABASE '+DB_NAME(F.database_id )+ ' MODIFY FILE' +'(NAME='+F.name+ ',MAXSIZE='
		+cast((cast(((size*8)/1024) as bigint)+Cast(((growth*8)/1024) as bigint)+1) as Varchar)+'MB)' FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info)
print(@sql)
EXEC (@sql)


		---SELECT @Subject = 'SQL Monitor Disk Free Space Alert: ' + @@servername
		
 
		
			SELECT @strMSG=( SELECT			'DatabaseName : ' + DB_NAME(f.database_id) +CHAR(10)+CHAR(10)+
							'DB Current Size : ' +CAST((cast(((size*8)/1024) as bigint)) AS varchar)+' MB' + char(10)+CHAR(10)+
							'DB Growth : ' +CAST((CAST((f.growth*8) AS bigint)/1024) AS VARCHAR)  +' MB' + char(10)  +CHAR(10)+
							'DB MaxSize : ' +CAST(((cast(f.max_size as bigint)*8)/1024) AS VARCHAR)  +' MB' + char(10)  +CHAR(10)+
							'FreeSpace On '+ SUBSTRING(vs.volume_mount_point,1,2)+ ' Drive : ' +CAST(FLOOR((vs.available_bytes/1024/1024)) AS VARCHAR) +' MB' + char(10) +CHAR(10)+
							'TotalSpace On ' +SUBSTRING(vs.volume_mount_point,1,2)+ '  Drive : '+CAST(FLOOR((vs.total_bytes/1024/1024)) AS VARCHAR) +' MB' + char(10) +CHAR(10)+
							'DBA Action : This is an informational message only; no DBA action is required. '+ char(10) +CHAR(10)+
							convert(char(15),' EventTime: ') + convert(varchar, getdate())
							FROM sys.master_files AS f
	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs

	WHERE f.database_id =@DBID and f.file_id =@fileid)
	
			SET @EMAIL = 'msdb.dbo.sp_send_dbmail
   @recipients = ''' + @RCPT + ''',
   @body = ''' + @strMSG + ''',
   @subject = ''Informational : Database Grown on ' + @@SERVERNAME + ' !!'''
 EXEC (@EMAIL)
  

--SELECT  'CASE 3',DB_NAME(f.database_id) As DBName,
--		(((f.growth*8)/1024)) AS Growth,
--		((cast(f.max_size as bigint)*8)/1024) As MaxSize,
--		(vs.available_bytes/1024/1024) As AvailableSpace,
--		(FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))) As CountS
--		FROM sys.master_files AS f
--	CROSS APPLY sys.dm_os_volume_stats(f.database_id, f.file_id) AS vs
--	where (f.is_percent_growth =0 and f.max_size<>-1 and ((cast(((f.size*8)/1024) as bigint)+((f.growth*8)/1024)))>=((cast(f.max_size as bigint)*8)/1024)) 
--		and FLOOR((vs.available_bytes/1024/1024)/(((f.growth*8)/1024)))>=@Info
end  
	 
	--xp_fixeddrives

	--select * FROM sys.master_files