Set NOCOUNT ON
Declare @sql varchar(max)
DECLARE @servername VARCHAR(1500) -- database servername  
DECLARE @path VARCHAR(1500) -- path for backup files  
DECLARE @fileservername VARCHAR(1500) -- fileservername for backup  
DECLARE @fileDate VARCHAR(1500) -- used for file servername 

--SET ANSI_WARNINGS ON
--SET ANSI_WARNINGS ON

TRUNCATE TABLE sqldba.dbo.[ITAR_DatabaseBackup]
DECLARE db_cursor CURSOR FOR  
SELECT servername 
FROM SQLDBA.dbo.IServers   
order by servername


OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @servername   

WHILE @@FETCH_STATUS = 0   
BEGIN   
        
  set @SQL='INSERT INTO sqldba.dbo.[ITAR_DatabaseBackup]
				SELECT '''+@servername+''' AS ServerName,
				bk.database_name, 
				db.state_desc  AS [State_Desc],
				db.recovery_model_desc  AS [Recovery_Model],		
			MAX(CASE WHEN bk.type = '+'''D'''+' THEN bk.backup_finish_date ELSE NULL END)  AS LastFullBackup,
			MAX(CASE WHEN bk.type = '+'''I'''+' THEN bk.backup_finish_date ELSE NULL END) AS LastDifferential,
			MAX(CASE WHEN bk.type = '+'''L'''+' THEN bk.backup_finish_date ELSE NULL END) AS LastLog
			FROM ['+@servername+'].msdb.dbo.backupset bk 
			OUTER JOIN ['+@servername+'].master.sys.databases db ON 
			bk.database_name =db.name 
			WHERE bk.database_name in (SELECT name from ['+@servername+'].master.sys.databases where name not in ('+'''tempdb'''+','+'''model'''+'))
			GROUP BY bk.database_name,db.state_desc,db.recovery_model_desc
			ORDER BY bk.database_name ASC
			
			 ' 
	--Print @SQL
	EXEC (@SQL)
       FETCH NEXT FROM db_cursor INTO @servername   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor 

select * from sqldba.dbo.[ITAR_DatabaseBackup] where DatabaseName ='test'

select name from sys.databases where name='test'



