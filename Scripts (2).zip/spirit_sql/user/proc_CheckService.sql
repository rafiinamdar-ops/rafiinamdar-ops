USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_CheckService]    Script Date: 4/9/2018 8:50:43 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE Procedure [dbo].[proc_CheckService]
@ServerName varchar(50),
@svcStatus varchar(50) output
As
Begin
DECLARE @Service_Name VARCHAR(100) 
--DECLARE @Status varchar(100)
DECLARE @cmd varchar(200)
-- Used as Boolean to trigger a change of the account or password or both 
DECLARE @TSQL VARCHAR(500)  
--DECLARE @ServerName varchar(50)='sql-ent-70a'
CREATE TABLE #MyTempTable 
    ( 
      Big_String NVARCHAR(500) 
    ) 

SET @cmd='EXEC ['+@ServerName+'].master.dbo.xp_cmdshell ''WMIC SERVICE GET Name,state | findstr /I "Report"'''
INSERT  INTO #MyTempTable EXEC (@cmd)
        
SELECT @svcStatus=REPLACE((SUBSTRING(big_string, CASE CHARINDEX(' ', big_string)
            WHEN 0
                THEN LEN(big_string) + 1
            ELSE CHARINDEX(' ', big_string) + 1
            END, 1000)),' ','')  FROM #MyTempTable where Big_String is not null
RETURN
END
GO

