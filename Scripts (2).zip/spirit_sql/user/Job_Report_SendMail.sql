USE msdb
go
DECLARE @tableHTML  NVARCHAR(MAX) ;
DECLARE @subject varchar(100)
DECLARE @recipients varchar(250)
DECLARE @copy_recipients varchar(100)
SET @subject =(SELECT @@SERVERNAME) +' : Job Run Report for All SpiritDigi Packages'
SET @recipients='pratheesh.n@spiritaero.com;kanak.agrawal@spiritaero.com;ram.manohar@spiritaero.com;jeebanjyoti.paramanik@spiritaero.com'
SET @copy_recipients='spirit_hp_nen_sql@groups.ext.hpe.com;fredric.w.shope@spiritaero.com'

SET @tableHTML =
    ----N'<font face="Arial" size="+1" COLOR="#7AA9DD">Job Status Report</font>' +
    N'<table border="0" cellpadding="3">' +
    N'<tr bgcolor=#D9D9D9><th><font face="Arial" size="-1">Job Name</font></th><th><font face="Arial" size="-1">LastRunOutcome</font></th>' +
    N'<th><font face="Arial" size="-1">LastRan_Schedule</font></th>' +
    N'<th><font face="Arial" size="-1">Duration (DD:HH:MM:SS)</font></th><th><font face="Arial" size="-"></font>NextRun_Schedule</th>' +
	N'<th><font face="Arial" size="-1">Message</font>' +
    CAST ( ( 	SELECT td= j.name ,			'',
				td = CASE jh.run_status    WHEN 0 THEN 'Failed'   WHEN 1 THEN 'Succeeded'   WHEN 2 THEN 'Retry'    WHEN 3 THEN 'Canceled'  WHEN 4 THEN 'In progress'   END ,			'',
                 td= cast(dbo.agent_datetime(jh.run_date, jh.run_time) as varchar ) ,				'',  
	td=STUFF(STUFF(STUFF(RIGHT(REPLICATE('0', 8) + CAST(jh.run_duration as varchar(8)), 8), 3, 0, ':'), 6, 0, ':'), 9, 0, ':') ,'',
   td=cast(dbo.agent_datetime(js.next_run_date,js.next_run_time ) as varchar ) ,		''
   ,td=jh.message from sysjobs j
LEFT JOIN sysjobhistory jh
ON j.job_id =jh.job_id 
LEFT JOIN sysjobschedules js
ON jh.job_id =js.job_id 
where j.enabled = 1 --and jh.step_id =0 
AND jh.instance_id IN        (SELECT MAX(h.instance_id)             FROM sysjobhistory h GROUP BY (h.job_id))
		and j.name like '%SpritDigi%'
ORDER BY j.name 
              FOR XML PATH('tr'), TYPE 
    ) AS NVARCHAR(MAX) ) +
    N'</table>' ;

   -- Formatting of table font, size and colour
    SELECT @tableHTML = REPLACE(@tableHTML,'<td>Succeeded</td>','<td bgcolor=#00C957><font face="Arial" size="-1">Succeeded</font></td>')
    SELECT @tableHTML = REPLACE(@tableHTML,'<td>Failed</td>','<td bgcolor=#B0171F><font face="Arial" size="-1">Failed</font></td>')
    SELECT @tableHTML = REPLACE(@tableHTML,'<td>','<td bgcolor=#E8E8E8><font face="Arial" size="-1">')
	    SELECT @tableHTML = REPLACE(@tableHTML,'</td>','</font></td>')
		--PRINT(@tablehtml)
EXEC msdb.dbo.sp_send_dbmail
   @profile_name = 'svcsql',
   @recipients = @recipients,
   @copy_recipients =@copy_recipients,
    @subject = @subject,
    @body = @tableHTML,
    @body_format = 'HTML' ;