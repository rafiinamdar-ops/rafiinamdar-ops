USE [msdb]
GO

/****** Object:  Job [SQLDBA_ITAR_BackupReports]    Script Date: 9/20/2017 4:58:14 AM ******/
BEGIN TRANSACTION
DECLARE @ReturnCode INT
SELECT @ReturnCode = 0
/****** Object:  JobCategory [[Uncategorized (Local)]]    Script Date: 9/20/2017 4:58:14 AM ******/
IF NOT EXISTS (SELECT name FROM msdb.dbo.syscategories WHERE name=N'[Uncategorized (Local)]' AND category_class=1)
BEGIN
EXEC @ReturnCode = msdb.dbo.sp_add_category @class=N'JOB', @type=N'LOCAL', @name=N'[Uncategorized (Local)]'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback

END

DECLARE @jobId BINARY(16)
EXEC @ReturnCode =  msdb.dbo.sp_add_job @job_name=N'SQLDBA_ITAR_BackupReports', 
		@enabled=1, 
		@notify_level_eventlog=0, 
		@notify_level_email=0, 
		@notify_level_netsend=0, 
		@notify_level_page=0, 
		@delete_level=0, 
		@description=N'No description available.', 
		@category_name=N'[Uncategorized (Local)]', 
		@owner_login_name=N'sa', @job_id = @jobId OUTPUT
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Collect the backup data]    Script Date: 9/20/2017 4:58:14 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Collect the backup data', 
		@step_id=1, 
		@cmdexec_success_code=0, 
		@on_success_action=3, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=0, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE SQLDBA
go
Set NOCOUNT ON
Declare @sql varchar(max)
DECLARE @servername VARCHAR(1500) -- database servername  
DECLARE @path VARCHAR(1500) -- path for backup files  
DECLARE @fileservername VARCHAR(1500) -- fileservername for backup  
DECLARE @fileDate VARCHAR(1500) -- used for file servername 

--SET ANSI_WARNINGS ON
--SET ANSI_WARNINGS ON

TRUNCATE TABLE sqldba.dbo.[ITAR_DatabaseBackup]
DECLARE db_cursor CURSOR FOR  
SELECT servername 
FROM SQLDBA.dbo.IBackupServers   
order by servername


OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @servername   

WHILE @@FETCH_STATUS = 0   
BEGIN   
        
  set @SQL=''
		INSERT INTO sqldba.dbo.[ITAR_DatabaseBackup]
		
		SELECT DISTINCT ''''''+@ServerName+'''''' AS ServerName,
				db.name, 
				db.state_desc  AS [State_Desc],
				db.recovery_model_desc  AS [Recovery_Model],		
			LFB.LastFullBackup,
			LD.LastDifferential,
			LL.LastLog
			FROM [''+@ServerName+''].master.sys.databases db 
			LEFT JOIN [''+@ServerName+''].msdb.dbo.backupset bk  ON 
			bk.database_name =db.name 
			OUTER APPLY (SELECT MAX(CASE WHEN bk1.type = ''+''''''D''''''+'' THEN bk1.backup_finish_date ELSE NULL END)  AS LastFullBackup
			FROM [''+@ServerName+''].msdb.dbo.backupset bk1
			WHERE bk1.database_name=db.name) AS LFB
			OUTER APPLY (SELECT MAX(CASE WHEN bk1.type = ''+''''''I''''''+'' THEN bk1.backup_finish_date ELSE NULL END)  AS LastDifferential
			FROM [''+@ServerName+''].msdb.dbo.backupset bk1
			WHERE bk1.database_name=db.name) AS LD
			OUTER APPLY (SELECT MAX(CASE WHEN bk1.type = ''+''''''L''''''+'' THEN bk1.backup_finish_date ELSE NULL END)  AS LastLog
			FROM [''+@ServerName+''].msdb.dbo.backupset bk1
			WHERE bk1.database_name=db.name) AS LL
			WHERE db.name in (SELECT name from [''+@ServerName+''].master.sys.databases where name not in (''+''''''tempdb''''''+'',''+''''''model''''''+''))
			ORDER BY db.name ASC '' 

	---Print @SQL
	EXEC (@SQL)
       FETCH NEXT FROM db_cursor INTO @servername   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor 

--select * from sqldba.dbo.[ITAR_DatabaseBackup] 




', 
		@database_name=N'SQLDBA', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=0
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
/****** Object:  Step [Run Report SQl Backup report]    Script Date: 9/20/2017 4:58:14 AM ******/
EXEC @ReturnCode = msdb.dbo.sp_add_jobstep @job_id=@jobId, @step_name=N'Run Report SQl Backup report', 
		@step_id=2, 
		@cmdexec_success_code=0, 
		@on_success_action=1, 
		@on_success_step_id=0, 
		@on_fail_action=2, 
		@on_fail_step_id=0, 
		@retry_attempts=3, 
		@retry_interval=0, 
		@os_run_priority=0, @subsystem=N'TSQL', 
		@command=N'USE msdb
go
EXEC [sql-ent-85].msdb.dbo.sp_start_job @job_name =''D49AC20F-B7D9-41AD-8978-8C7CD923BCFB''
go
EXEC [sql-ent-85].msdb.dbo.sp_start_job @job_name =''A78C2B0B-7AE6-416A-ADCB-1C22F81D05A2''
go', 
		@database_name=N'msdb', 
		@output_file_name=N'c:\temp\backupreportJobOut.txt', 
		@flags=2
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_update_job @job_id = @jobId, @start_step_id = 1
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobschedule @job_id=@jobId, @name=N'Daily_Backup', 
		@enabled=1, 
		@freq_type=8, 
		@freq_interval=127, 
		@freq_subday_type=1, 
		@freq_subday_interval=30, 
		@freq_relative_interval=0, 
		@freq_recurrence_factor=1, 
		@active_start_date=20140113, 
		@active_end_date=99991231, 
		@active_start_time=70000, 
		@active_end_time=235959, 
		@schedule_uid=N'b6268de5-005f-46f2-ab7a-ebb10e75cbf4'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
EXEC @ReturnCode = msdb.dbo.sp_add_jobserver @job_id = @jobId, @server_name = N'(local)'
IF (@@ERROR <> 0 OR @ReturnCode <> 0) GOTO QuitWithRollback
COMMIT TRANSACTION
GOTO EndSave
QuitWithRollback:
    IF (@@TRANCOUNT > 0) ROLLBACK TRANSACTION
EndSave:

GO

