SET NOCOUNT  ON
DECLARE @name VARCHAR(100) -- database name  
/****** Object:  Table [dbo].[!DB_Devpr_Info]    Script Date: 6/8/2017 12:29:57 AM ******/
	DECLARE @Servername varchar(100)
    DECLARE curAllServers CURSOR  STATIC LOCAL FOR
    SELECT   [Servername]
    FROM     sqldba.[dbo].[IDevServers]
    OPEN curAllServers
	    FETCH NEXT FROM curAllServers
    INTO @Servername
    WHILE (@@FETCH_STATUS = 0) -- Outer cursor loop
		BEGIN      
			EXEC sqldba.dbo.proc_collectDevInfo @Servername
	   FETCH NEXT FROM curAllServers

       INTO @Servername

      END  
    CLOSE curAllServers
    DEALLOCATE curAllServers
	