
IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_facility_downtime_target')
DROP PROC datamart.proc_generate_facility_downtime_target
GO

CREATE PROC datamart.proc_generate_facility_downtime_target
AS
BEGIN

/*
Usage : To find out downtime target for next year from previous year (Facilities)

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-04 # Initial creation
*/


;
WITH cte_downtime_target as
(
SELECT 
cal.spirit_year
,COALESCE(almap.actual_name,dc.busunit) as busunit
,COALESCE(almap2.actual_name,dc.siteid) as location
,CASE WHEN dc.wo_priority < 4 THEN 3 ELSE dc.wo_priority END as priority
,dc.downtime

FROM datamart.fact_downtime_dailyclocking dc

INNER JOIN datamart.dim_calendar cal
 ON cal.date_key = dc.change_date 

LEFT OUTER JOIN datamart.dim_alias_mapping as almap
 ON dc.busunit = almap.alias_name 
 AND almap.category = 'business_unit'

LEFT OUTER JOIN datamart.dim_alias_mapping as almap2
 ON dc.siteid = almap2.alias_name 
 AND almap2.category = 'location'
)

,
cte_downtime_target2 as
(
SELECT
spirit_year
,busunit
,location
,priority
,SUM(downtime) as downtime

FROM cte_downtime_target

GROUP BY
spirit_year
,busunit
,location
,priority
)

-- INSERT INTO datamart.dim_downtime_target
-- (
-- spirit_year
-- ,location
-- ,business_unit
-- ,asset_priority
-- ,total_downtime_previous_year

-- ,improvement_pcg
-- ,downtime_target
-- )

SELECT 

c1.spirit_year + 1
,c1.location
,c1.busunit
,c1.priority
,c1.downtime

,0.05
,(c1.downtime/52) - (c1.downtime/52) * 0.05 as downtime_target_per_week

FROM cte_downtime_target2 c1

END

GO
