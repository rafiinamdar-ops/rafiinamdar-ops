/*
Usage : This table is used to load error data from SP

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
Praveen C		# 2017-11-22	# Added Mail sent column to existing table
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'log_error'
)


CREATE TABLE [datamart].[log_error](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[procedure_name] [varchar](386) NULL,
	[line_no] [int] NULL,
	[message] [varchar](2048) NULL,
	[error_number] [int] NULL,
	[severity] [int] NULL,
	[state] [int] NULL,
	[spid] [int] NULL,
	[user_name] [varchar](300) NULL,
	[created_date] [datetime] NULL,
	[package_guid] [uniqueidentifier] NULL,
	mail_sent bit NOT NULL DEFAULT(0),
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) 
) 
GO


ALTER TABLE datamart.log_error
ADD mail_sent bit NOT NULL DEFAULT(0)
GO
