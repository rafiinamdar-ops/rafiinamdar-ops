/*
Usage : This table is used to load esacpes from Kinston location
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-01-17	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_kinston_escape'
)


CREATE TABLE [staging].[ftp_kinston_escape](
	[date] [datetime] NULL,
	[airbus_escape_number] [nvarchar](255) NULL,
	[panel] [nvarchar](255) NULL,
	[escape_description] [nvarchar](255) NULL,
	[rcca_number] [nvarchar](255) NULL,
	[note] [nvarchar](255) NULL,
	[submission_target] [float] NULL,
	[closure_target] [float] NULL,
	[sari] [nvarchar](255) NULL,
	[escape_supplier_responsible] [nvarchar](255) NULL,
	[f1_containment_implemented_from_msn] [float] NULL,
	[f2_containment_implemented_from_msn] [nvarchar](255) NULL,
	[date_containment_implemented_at_spirit] [datetime] NULL,
	[workdays_defect_contained] [nvarchar](255) NULL,
	[containment_target] [nvarchar](255) NULL,
	[rcca_submisssion_corrective_action_plan_date] [nvarchar](255) NULL,
	[workdays_corrective_action_plan] [nvarchar](255) NULL,
	[workdays_rcca_closure] [nvarchar](255) NULL,
	[noe] [nvarchar](255) NULL,
	[qsr] [nvarchar](255) NULL,
	[program_nm] [varchar](50) NULL,
	[location] [varchar](50) NULL,
	[load_date] [datetime]   DEFAULT getdate()
)


GO