USE [sqldba]
GO

/****** Object:  StoredProcedure [dbo].[proc_CheckService_xp]    Script Date: 3/26/2018 6:26:27 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE Procedure [dbo].[proc_CheckService_xp]
@ServerName varchar(50),
@svcStatus varchar(50) output
As
Begin
DECLARE @cmd varchar(200)
CREATE TABLE #Temp(ServiceStatus varchar(50))
SET @cmd='['+@ServerName+'].[master].[dbo].xp_servicecontrol ''querystate'',''ReportServer'''
INSERT INTO #Temp EXEC (@cmd)
SELECT @svcStatus=ServiceStatus FROM #Temp
RETURN
end;
GO


