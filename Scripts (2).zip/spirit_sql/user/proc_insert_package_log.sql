/*
Usage : This SP is used to load package log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_insert_package_log')
 DROP PROC [datamart].[proc_insert_package_log]
GO



CREATE PROC [datamart].[proc_insert_package_log]
(
@package_name VARCHAR(100),
@process_number UNIQUEIDENTIFIER,
@machine_name VARCHAR(100)
)
AS
BEGIN

/***********************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Inserting LOG on package execution  
************************************************************************************************************/

SET NOCOUNT ON;


INSERT INTO datamart.log_package
(
	   [package_name]
	   ,[process_number]
      ,[package_start_time]
      ,machine_name
	  )
VALUES
(
@package_name,
@process_number,
GETDATE(),
@machine_name
);
END;




GO


