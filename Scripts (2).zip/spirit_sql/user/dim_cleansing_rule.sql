/*
Usage : This table is used to load cleansing rules
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_cleansing_rule'
)

CREATE TABLE [datamart].[dim_cleansing_rule](
	[table_name] [varchar](50) NULL,
	[column_name] [varchar](50) NULL,
	[column_value] [varchar](50) NULL,
	[operation] [varchar](50) NULL
) 


GO