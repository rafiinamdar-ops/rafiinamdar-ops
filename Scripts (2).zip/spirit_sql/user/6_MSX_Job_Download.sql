EXEC master..xp_regwrite @rootkey='HKEY_LOCAL_MACHINE',@key='SOFTWARE\Microsoft\Microsoft SQL Server\MSSQL12.MSSQLSERVER\SQLServerAgent',
@value_name='MsxEncryptChannelOptions',@type='REG_DWORD',@value=0

WaitFor Delay '000:01:00'


/* Enlist Target Server in MSX server sql-ent-21*/
EXEC msdb.dbo.sp_msx_enlist N'sql-ent-21' 

WaitFor Delay '000:00:10'
Declare @serverName varchar(100)
SET @serverName=(SELECT @@ServerName)
--PRINT @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_BackupDD_DB', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_BackupDD_Diff', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_BackupDD_TLogs', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_CycleErrorLog', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_DisasterRecovery', @server_name =@serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_IndexMaint', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_VerifyDBs', @server_name =@serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_BackupDD_Expire', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_Enable_Disable_jobs', @server_name = @serverName
EXEC [sql-ent-21].msdb.dbo.sp_add_jobserver @job_name = 'SQLDBA_AG_Collect_JobStatus', @server_name = @serverName

