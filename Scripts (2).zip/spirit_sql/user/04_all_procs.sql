
IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_fabrication')
 DROP PROC datamart.proc_cleansing_fabrication
GO

CREATE PROCEDURE datamart.proc_cleansing_fabrication
AS

--EXEC [datamart].[proc_cleansing_fabrication]
/******************************************************************************************************************
Created/Modified By		Created/Modified Date	    Purpose
Kanak					2017-Oct-11		    		Cleansing and Inserting data into Datamart table FROM Staging Tables  
******************************************************************************************************************/
BEGIN
SET NOCOUNT ON;

/****************************************************************************************************************
Getting latest reporting week end date
****************************************************************************************************************/
DECLARE @wk_end_date DATE

SELECT 
	@wk_end_date = DATEADD(DD,-7,calv.week_end_date)
FROM 
	[datamart].[dim_calendar] cal
		JOIN [datamart].[vw_dim_calendar] calv
			ON cal.spirit_week = calv.spirit_week
			AND cal.spirit_year = calv.spirit_year
WHERE 
	cal.date_key = CONVERT(DATE,GETDATE())
/****************************************************************************************************************/

/****************************************************************************************************************
SRR Actuals/Planned (Weekly & YTD)
****************************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_quality_srr') IS NOT NULL DROP TABLE #tmp_quality_srr
;WITH cte_srr_actual AS
(
SELECT 	
	calvw.week_end_date,
	srr.supt_title as pwhse_category,
	srr.gen_title as pwhse_sub_category,		
	SUM(srr.[total_srr]) as wkl_srr_actual
FROM 
	[staging].[pwhse_fab_srr] srr
		JOIN [datamart].[dim_calendar] cal
			ON srr.[dtwritten] = cal.date_key
		JOIN [datamart].[vw_dim_calendar] calvw
			ON cal.spirit_year = calvw.spirit_year
			AND cal.spirit_week = calvw.spirit_week
GROUP BY
	calvw.week_end_date,
	srr.supt_title,
	srr.gen_title
)
,
cte_srr_total AS
(
SELECT 
	srr1.week_end_date,
	bu.category,
	bu.sub_category,
	SUM(srr1.wkl_srr_actual) AS wkl_srr_actual
FROM 
	cte_srr_actual srr1
		JOIN [staging].[ftp_fab_business_unit] bu
			ON srr1.pwhse_category = bu.pwhse_category
			AND srr1.pwhse_sub_category = bu.pwhse_sub_category
GROUP BY
	srr1.week_end_date,
	bu.category,
	bu.sub_category
----------------------------------------------------------------
UNION
----------------------------------------------------------------
SELECT 
	srr2.week_end_date,
	bu.category,
	'All' as sub_category,
	SUM(DISTINCT wkl_srr_actual)
FROM
	cte_srr_actual srr2
		JOIN [staging].[ftp_fab_business_unit] bu
			ON srr2.pwhse_category = bu.pwhse_category
WHERE 
	srr2.pwhse_category <> 'CHEMICAL FINISHES'
GROUP BY
	srr2.week_end_date,
	bu.category
----------------------------------------------------------------
UNION
----------------------------------------------------------------
SELECT 
	week_end_date,
	'All' as category,
	'All' as sub_category,
	SUM(wkl_srr_actual)
FROM
	cte_srr_actual
GROUP BY
	week_end_date
)
SELECT 
	st.week_end_date,
	bu.category,
	bu.sub_category,
	(st.wkl_srr_target * st.breakup_pcg) AS wkl_qlty_srr_planned,
	SUM(st.wkl_srr_target * st.breakup_pcg) 
	OVER (PARTITION BY bu.category,bu.sub_category,YEAR(st.week_end_date) ORDER BY st.week_end_date asc) AS ytd_qlty_srr_planned,
	srr.wkl_srr_actual,
	SUM(srr.wkl_srr_actual) 
	OVER (PARTITION BY srr.category,srr.sub_category,YEAR(srr.week_end_date) ORDER BY srr.week_end_date asc) as ytd_srr_actual
INTO 
	#tmp_quality_srr
FROM 
	[staging].[ftp_fab_srr_target] st
		JOIN [staging].[ftp_fab_business_unit] bu
			ON st.fab_category = bu.fab_category
		LEFT JOIN cte_srr_total srr
			ON st.week_end_date = srr.week_end_date
			AND bu.category =srr.category
			AND bu.sub_category = srr.sub_category
ORDER BY
	st.week_end_date
/***************************************************************************************************************/

/****************************************************************************************************************
-- Escapes to Assembly (Actuals & Planned)
****************************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_escapes_assy') IS NOT NULL DROP TABLE #tmp_escapes_assy
IF OBJECT_ID('tempdb..#tmp_escapes_actual') IS NOT NULL DROP TABLE #tmp_escapes_actual

;WITH cte_escapes_actual AS
(
SELECT DISTINCT
	bucal.week_end_date,
	bucal.category,
	bucal.sub_category,
	SUM(CASE WHEN eaa.qn_qty is null then 0 else 1 end) as wkl_escapes_actual 
FROM 
	(
		SELECT 
			calvw.week_end_date,
			cal.date_key,
			cal.spirit_year,
			cal.spirit_week,
			bu.category,
			bu.sub_category,
			bu.pwhse_category,
			bu.pwhse_sub_category
		FROM
			[datamart].[vw_dim_calendar] calvw
				JOIN [datamart].[dim_calendar] cal
					ON cal.spirit_year = calvw.spirit_year
					AND cal.spirit_week = calvw.spirit_week
				CROSS JOIN [staging].[ftp_fab_business_unit] bu
		WHERE 
			bu.sub_category <> 'All'
			AND cal.spirit_year = YEAR(@wk_end_date)
	) bucal
		LEFT JOIN [staging].[pwhse_fab_escape_assy] eaa
			ON eaa.[dtwritten] = bucal.date_key
			AND eaa.supt_title = bucal.pwhse_category
			and eaa.gen_title = bucal.pwhse_sub_category 
GROUP BY
	bucal.week_end_date,
	bucal.category,
	bucal.sub_category
),
cte_escapes_actual_1 AS
(
SELECT 
	week_end_date,
	category,
	sub_category,
	SUM(wkl_escapes_actual)  as wkl_escapes_actual
FROM 
	cte_escapes_actual
GROUP BY
	week_end_date,
	category,
	sub_category
---------------------------------------------------
UNION
---------------------------------------------------
SELECT 
	week_end_date,
	category,
	'All' as sub_category,
	SUM(wkl_escapes_actual) 	
FROM 
	cte_escapes_actual
WHERE 
	category <> 'CFC'
GROUP BY
	week_end_date,
	category
---------------------------------------------------
UNION
---------------------------------------------------
SELECT 
	week_end_date,
	'All' as category,
	'All' as sub_category,
	SUM(wkl_escapes_actual) 	
FROM 
	cte_escapes_actual
GROUP BY
	week_end_date
)

SELECT 
	week_end_date,
	category,
	sub_category,
	wkl_escapes_actual,
	SUM(wkl_escapes_actual) OVER (PARTITION BY category,sub_category,year(week_end_date) ORDER BY week_end_date asc) as ytd_escapes_actual  
INTO 
	#tmp_escapes_actual
FROM 
	cte_escapes_actual_1 
-------------------------------------------------------------------------------------------------------
;WITH cte_escapes_planned AS
(
SELECT 
	eap.spirit_year,
	bu.category,
	bu.sub_category,
	SUM(eap.baseline) as baseline
FROM 
	[staging].[ftp_fab_escapes_assy_plan] eap
		JOIN [staging].[ftp_fab_business_unit] bu
			on eap.fab_category = bu.fab_category
GROUP BY
	eap.spirit_year,
	bu.category,
	bu.sub_category
-----------------------------------------------------
UNION
-----------------------------------------------------
SELECT 
	eap.spirit_year,
	'All' as category,
	'All' as sub_category,
	SUM(eap.baseline)
FROM 
	[staging].[ftp_fab_escapes_assy_plan] eap
		JOIN [staging].[ftp_fab_business_unit] bu	
			ON eap.fab_category = bu.fab_category
WHERE
	bu.sub_category IN ('All','CFC')
GROUP BY
	eap.spirit_year
)
SELECT 
	vcal.week_end_date,
	pln.category,
	pln.sub_category,
	pln.baseline/51 as wkl_escapes_planned,
	(pln.baseline/51) * vcal.spirit_week as ytd_escapes_planned,
	act.wkl_escapes_actual,
	act.ytd_escapes_actual
INTO 
	#tmp_escapes_assy
FROM 
	cte_escapes_planned pln
		JOIN #tmp_escapes_actual act
			on pln.category = act.category
			and pln.sub_category = act.sub_category
		JOIN [datamart].[vw_dim_calendar] vcal
			on pln.spirit_year = vcal.spirit_year
			and act.week_end_date = vcal.week_end_date
/****************************************************************************************************************/

/***************************************************************************************************************
-- Escapes to End Customer (Actuals & Planned)
****************************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_escapes_cust') IS NOT NULL DROP TABLE #tmp_escapes_cust
;WITH cte_escape_cust AS
(
SELECT DISTINCT
	calv.week_end_date,
	bu.category,
	bu.pwhse_category
FROM
	[staging].[ftp_fab_business_unit] bu
		CROSS JOIN [datamart].[vw_dim_calendar] calv
		JOIN [staging].[pwhse_fab_escape_end_cust] eec
			ON calv.spirit_year = year(eec.ncr_written_dt)
WHERE
	bu.pwhse_category is not null
),
cte_escape_cust_1 AS
(
SELECT 
	cte.category,
	cte.week_end_date,
	ISNULL(COUNT([car_ser_no]) + SUM([suppl_notif_flg]),0) as escape_cnt
FROM
	cte_escape_cust cte
		LEFT JOIN [datamart].[vw_dim_calendar] cal
			on cte.week_end_date = cal.week_end_date
		LEFT JOIN [staging].[pwhse_fab_escape_end_cust] eec
			ON eec.ncr_written_dt between cal.week_start_date and cal.week_end_date
			AND eec.supt_title = cte.pwhse_category
GROUP BY
	cte.category,
	cte.week_end_date
),
cte_escape_cust_2 AS
(
SELECT 
	week_end_date,
	category,escape_cnt 
from 
	cte_escape_cust_1
-----------------------------------
UNION
-----------------------------------
SELECT 
	week_end_date,
	'All' as category,
	SUM(escape_cnt) 
from 
	cte_escape_cust_1
GROUP BY 
	week_end_date
),
cte_escape_cust_act AS
(
SELECT 
	week_end_date,
	category,
	escape_cnt as wkl_qlty_escap_to_cust_actual,
	SUM(escape_cnt) OVER (PARTITION BY category,year(week_end_date) ORDER BY week_end_date asc) as ytd_qlty_escap_to_cust_actual
from 
	cte_escape_cust_2
),
cte_escape_cust_plan AS
(
SELECT 
	calv.week_end_date,
	bu.category,
	bu.sub_category,
	(tot_wkl_target * breakup_pcg) as wkl_qlty_escap_to_cust_planned,
	SUM(tot_wkl_target * breakup_pcg) OVER (PARTITION BY bu.category,bu.sub_category,year(calv.week_end_date) ORDER BY calv.week_end_date asc) as ytd_qlty_escap_to_cust_planned
FROM
	[staging].[ftp_fab_escapes_end_cust_plan] eec
		JOIN [staging].[ftp_fab_business_unit] bu
			ON eec.fab_category=bu.fab_category
		JOIN [datamart].[vw_dim_calendar] calv
			ON eec.spirit_year = calv.spirit_year
)
SELECT 
	p.week_end_date,
	p.category,
	p.sub_category,
	p.wkl_qlty_escap_to_cust_planned,
	p.ytd_qlty_escap_to_cust_planned,
	a.wkl_qlty_escap_to_cust_actual,
	a.ytd_qlty_escap_to_cust_actual
INTO 
	#tmp_escapes_cust
FROM 
	cte_escape_cust_plan p
		LEFT JOIN cte_escape_cust_act a
			ON p.week_end_date = a.week_end_date
			AND p.category =a.category
/****************************************************************************************************************/


/***************************************************************************************************************
-- Combining SRR & Escapes
****************************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_fab_srr_escapes') IS NOT NULL DROP TABLE #tmp_fab_srr_escapes
SELECT 
	cc.week_end_date,
	cc.category,
	cc.sub_category,
	srr.wkl_srr_actual as wkl_qlty_srr_act,
	srr.wkl_qlty_srr_planned as wkl_qlty_srr_pln,
	srr.ytd_srr_actual as ytd_qlty_srr_act,
	srr.ytd_qlty_srr_planned as ytd_qlty_srr_pln,
	assy.wkl_escapes_actual as wkl_qlty_esc_assy_act,
	assy.wkl_escapes_planned as wkl_qlty_esc_assy_pln,
	assy.ytd_escapes_actual as ytd_qlty_esc_assy_act,
	assy.ytd_escapes_planned as ytd_qlty_esc_assy_pln,
	cust.wkl_qlty_escap_to_cust_actual as wkl_qlty_esc_cust_act,
	cust.wkl_qlty_escap_to_cust_planned as wkl_qlty_esc_cust_pln,
	cust.ytd_qlty_escap_to_cust_actual as ytd_qlty_esc_cust_act,
	cust.ytd_qlty_escap_to_cust_planned as ytd_qlty_esc_cust_pln
INTO 
	#tmp_fab_srr_escapes
FROM 
	(SELECT 
		calv.week_end_date,
		bu.category,
		bu.sub_category
	FROM
		[datamart].[vw_dim_calendar] calv
		CROSS JOIN [staging].[ftp_fab_business_unit] bu
	WHERE
		calv.spirit_year = year(@wk_end_date)
	) cc
	LEFT JOIN #tmp_quality_srr srr
		ON  srr.week_end_date = cc.week_end_date
		AND srr.category = cc.category
		AND srr.sub_category = cc.sub_category
	LEFT JOIN #tmp_escapes_assy assy
		ON cc.week_end_date = assy.week_end_date
		AND cc.category = assy.category
		AND cc.sub_category = assy.sub_category
	LEFT JOIN #tmp_escapes_cust cust
		ON cc.week_end_date = cust.week_end_date
		AND cc.category = cust.category
		AND cc.sub_category = cust.sub_category
/****************************************************************************************************************/

--Delete any existing record for previous week
DELETE FROM  [datamart].[fact_fab_srr_escapes] WHERE rpt_week_end_dt = @wk_end_date
/****************************************************************************************************************/
INSERT INTO [datamart].[fact_fab_srr_escapes] 
	(
	[rpt_week_end_dt],
	[category],
	[sub_category],
	wkl_qlty_srr_act,
	wkl_qlty_srr_pln,
	ytd_qlty_srr_act,
	ytd_qlty_srr_pln,
	wkl_qlty_esc_assy_act,
	wkl_qlty_esc_assy_pln,
	ytd_qlty_esc_assy_act,
	ytd_qlty_esc_assy_pln,
	wkl_qlty_esc_cust_act,
	wkl_qlty_esc_cust_pln,
	ytd_qlty_esc_cust_act,
	ytd_qlty_esc_cust_pln
	)
SELECT 
	week_end_date,
	category,
	sub_category,
	wkl_qlty_srr_act,
	wkl_qlty_srr_pln,
	ytd_qlty_srr_act,
	ytd_qlty_srr_pln,
	wkl_qlty_esc_assy_act,
	wkl_qlty_esc_assy_pln,
	ytd_qlty_esc_assy_act,
	ytd_qlty_esc_assy_pln,
	wkl_qlty_esc_cust_act,
	wkl_qlty_esc_cust_pln,
	ytd_qlty_esc_cust_act,
	ytd_qlty_esc_cust_pln
FROM 
	#tmp_fab_srr_escapes 
WHERE 
	week_end_date = @wk_end_date
/****************************************************************************************************************/

/***************************************************************************************************************
-- (Standard hours and Behind Schedule)
****************************************************************************************************************/
-- Update Internal rework hours
UPDATE kpi
	SET kpi.int_rwrk_adj_hrs  = iw1.int_rwk_hrs
FROM
	[staging].[hana_fab_wkly_stdhrs_kpis] kpi
		JOIN
			(
			SELECT 
				iw.cost_center,
				iw.prev_week_enddt,
				--sum(iw.SetupHr) + sum(iw.PrcessHr) + sum(iw.AssyHr) as int_rwk_hrs
				sum(iw.CnfSetupHr) + sum(iw.CnfProcessHr) + sum(iw.CnfAssyHr)  as int_rwk_hrs
			FROM 
				(SELECT a.* FROM [staging].[hana_fab_wkly_intopsrwk] a
				EXCEPT
				SELECT a.*
				FROM 
					[staging].[hana_fab_wkly_intopsrwk] a
						JOIN [staging].[pwhse_fab_sap_routing] b
							ON a.mat_act_task = b.mat_act_task
				) iw
			GROUP BY
				iw.cost_center,
				iw.prev_week_enddt 
			) iw1
			ON kpi.cost_center = iw1.cost_center
			AND kpi.prev_week_enddt = iw1.prev_week_enddt 
/***************************************************************************************************************/

/**************************** Weekly Planned hours calculation *************************************************/
IF OBJECT_ID('tempdb..#tmp_standard_hours') IS NOT NULL DROP TABLE #tmp_standard_hours
;WITH cte_std_hrs AS
(
SELECT 
	kpi.prev_week_enddt,
	bu.category,
	bu.sub_category,
	ISNULL(kpi.wkly_hrs_act,0) AS wkly_hrs_act,
	ISNULL(kpi.behind_sch_hrs,0) as currwk_bhnd_sch_hrs,
	ISNULL(ucl.bhnd_sch_ucl,0) as currwk_bhnd_sch_ucl,
	ISNULL(kpi.behind_sch_to_finish_hrs,0) as currwk_bhnd_schtofnsh_hrs,
	ISNULL(ucl.bhnd_sch_to_fnsh_ucl,0) as currwk_bhnd_schtofnsh_ucl,

	CASE WHEN kpi.wkly_hrs_act <	(ISNULL(wkly_hrs_ex_pln,0) + ISNULL(actual_spl_adj_hrs,0) + 
	ISNULL(cycle_adj_hrs,0) + ISNULL(int_rwrk_adj_hrs,0) +
	ISNULL(ext_rwrk_adj_hrs,0) + ISNULL(vendor_assist_adj_hrs,0) +
	ISNULL(behind_sch_adj_hrs,0) + ISNULL(third_party_adj_hrs,0))
	THEN
	(ISNULL(wkly_hrs_ex_pln,0) + ISNULL(actual_spl_adj_hrs,0) + 
	ISNULL(cycle_adj_hrs,0) + ISNULL(int_rwrk_adj_hrs,0) +
	ISNULL(ext_rwrk_adj_hrs,0) + ISNULL(vendor_assist_adj_hrs,0) +
	ISNULL(third_party_adj_hrs,0))
	ELSE
	(ISNULL(wkly_hrs_ex_pln,0) + ISNULL(actual_spl_adj_hrs,0) + 
	ISNULL(cycle_adj_hrs,0) + ISNULL(int_rwrk_adj_hrs,0) +
	ISNULL(ext_rwrk_adj_hrs,0) + ISNULL(vendor_assist_adj_hrs,0) +
	ISNULL(behind_sch_adj_hrs,0) + ISNULL(third_party_adj_hrs,0))
	END as  wkly_hrs_pln
FROM 
	[staging].[hana_fab_wkly_stdhrs_kpis] kpi
		LEFT JOIN  [staging].[ftp_fab_behind_schedule_ucl] ucl
			on kpi.Cost_Center = ucl.cost_center
			AND Year(kpi.prev_week_enddt) = ucl.spirit_year
			AND Month(kpi.prev_week_enddt) = ucl.spirit_month
		JOIN [staging].[ftp_fab_business_unit] bu
			on kpi.cost_center = bu.cost_center
) 
SELECT * INTO #tmp_standard_hours FROM cte_std_hrs
/*************************************************************************************************************/

/************************************************************************************************************/
--Delete any existing record for previous week
DELETE FROM [datamart].[fact_fab_standard_hours] WHERE rpt_week_end_dt in (SELECT DISTINCT prev_week_enddt from #tmp_standard_hours );
/************************************************************************************************************/
INSERT INTO [datamart].[fact_fab_standard_hours]
([rpt_week_end_dt],[category],[sub_category],[wkl_stdhrs_earned_actual],[wkl_bhndsch_hrs],
[wkl_bhndsch_ucl],[wkl_bhndsch_to_fnsh_hrs],[wkl_bhndsch_to_fnsh_ucl],[wkl_stdhrs_earned_planned])

SELECT * FROM #tmp_standard_hours
/***********************************************************************************************************/

/************************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_planned_hours') IS NOT NULL DROP TABLE #tmp_planned_hours
SELECT 
	kpi.prev_week_enddt,
	bu.category,
	bu.sub_category,
	ISNULL(wkly_hrs_ex_pln,0) AS wkl_stdhrs_ex_pln,
	ISNULL(actual_spl_adj_hrs,0) AS adj_actual_spl_hrs,
	ISNULL(cycle_adj_hrs,0) AS adj_cycle_hrs,
	ISNULL(int_rwrk_adj_hrs,0) AS adj_int_rwrk_hrs,
	ISNULL(ext_rwrk_adj_hrs,0) AS adj_ext_rwrk_hrs,
	ISNULL(vendor_assist_adj_hrs,0) AS adj_vendor_assist_hrs,
	ISNULL(behind_sch_adj_hrs,0) AS adj_behind_sch_hrs,
	ISNULL(third_party_adj_hrs,0) AS adj_third_party_hrs
INTO 
	#tmp_planned_hours
FROM 
	[staging].[hana_fab_wkly_stdhrs_kpis] kpi
		JOIN [staging].[ftp_fab_business_unit] bu
			ON kpi.cost_center = bu.cost_center
/*************************************************************************************************************/

/************************************************************************************************************/
--Delete any existing record for previous week
DELETE FROM [datamart].[fact_fab_planned_hours] WHERE rpt_week_end_dt in (SELECT DISTINCT prev_week_enddt from #tmp_planned_hours);
/************************************************************************************************************/

INSERT INTO [datamart].[fact_fab_planned_hours]
([rpt_week_end_dt],[category],[sub_category],[wkl_stdhrs_ex_pln],[adj_actual_spl_hrs],[adj_cycle_hrs],
[adj_int_rwrk_hrs],[adj_ext_rwrk_hrs],[adj_vendor_assist_hrs],[adj_behind_sch_hrs],[adj_third_party_hrs])
-------------------------------------------------------------------------------------------------------------
SELECT * FROM #tmp_planned_hours
/************************************************************************************************************/

/************************************************************************************************************
Labor Hours, OT , DOI
************************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_labor_hours') IS NOT NULL DROP TABLE #tmp_labor_hours
;WITH cte_labor_hrs AS
(
SELECT  
	a.cost_center,
	a.emp_id,
	a.emp_name,
	a.gl_acc_code,
	a.gl_acc_desc,
	CONVERT(float,a.labor_hrs) as labor_hrs,
	CONVERT(date,a.labor_worked_dt) as labor_worked_dt,
	CONVERT(date,a.posting_dt) as posting_dt
FROM
	[staging].[ftp_fab_adp_hours] a
WHERE
	LTRIM(RTRIM(a.posting_dt)) NOT IN ('','Posting Date')
	AND CONVERT(NVARCHAR(50),CONVERT(bigint,LTRIM(RTRIM(a.[emp_id])))) 
		NOT IN (SELECT m.emp_id 
					from [staging].[ftp_fab_m08_list] m
				WHERE a.cost_center = m.cost_center)
),
cte_labor_hrs_1 AS
(
SELECT 
	CONVERT(date,lbr.posting_dt) as week_end_date,
	bu.category,
	bu.sub_category,
	SUM(CASE WHEN lbr.gl_acc_code IN ('611000','611080') THEN lbr.labor_hrs END) as wkl_labor_hrs,
	SUM(CASE WHEN lbr.gl_acc_code = '611005' THEN lbr.labor_hrs END) as wkl_ot_hrs,
	SUM(CASE WHEN lbr.gl_acc_code NOT IN ('611000','611005') THEN lbr.labor_hrs END) as wkl_doi_chgs
FROM
	cte_labor_hrs lbr
		JOIN [staging].[ftp_fab_business_unit] bu
			on lbr.cost_center = bu.cost_center
GROUP BY
	lbr.posting_dt,
	bu.category,
	bu.sub_category
)
---------------------------------------------------------------------------------------------------------
SELECT * INTO #tmp_labor_hours FROM cte_labor_hrs_1
---------------------------------------------------------------------------------------------------------
UPDATE fs
	SET fs.[wkl_labor_hrs_actual] = lbr.wkl_labor_hrs,
	fs.[wkl_overtime_hrs_actual] = lbr.wkl_ot_hrs,
	fs.[wkl_doi_chgs_actual] = lbr.wkl_doi_chgs
FROM
	[datamart].[fact_fab_standard_hours] fs
		JOIN #tmp_labor_hours lbr
			on fs.rpt_week_end_dt = lbr.week_end_date
			and fs.category = lbr.category
			and fs.sub_category = lbr.sub_category
/**********************************************************************************************************/


/**********************************************************************************************************
Absenteeism hours
**********************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_abs_hours') IS NOT NULL DROP TABLE #tmp_abs_hours
SELECT 
	calv.week_end_date,
	bu.category,
	bu.sub_category,
	sum(work_hours) as wkl_abs_hrs
INTO 
	#tmp_abs_hours
FROM 
	[staging].[ftp_fab_absenteeism] ab
		JOIN [staging].[ftp_fab_business_unit] bu
			ON ab.cost_center = bu.cost_center
		JOIN [datamart].[vw_dim_calendar] calv
			ON ab.period = calv.period
GROUP BY
	calv.week_end_date,
	bu.category,
	bu.sub_category

-------------------------------------------------------------------------------------------------------
UPDATE fs
SET 
	fs.[wkl_abs_hrs] = ab.wkl_abs_hrs
FROM
	[datamart].[fact_fab_standard_hours] fs
		JOIN #tmp_abs_hours ab
			on fs.rpt_week_end_dt = ab.week_end_date
			and fs.category = ab.category
			and fs.sub_category = ab.sub_category
/**********************************************************************************************************/


/**********************************************************************************************************
Total hours with YTD computation
**********************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_total_hours') IS NOT NULL DROP TABLE #tmp_total_hours
;WITH cte_total_hours AS
(
SELECT 
	rpt_week_end_dt as week_end_date,
	category,
	sub_category,
	ISNULL(wkl_stdhrs_earned_actual,0) AS wkl_stdhrs_earned_actual,
	SUM(ISNULL(wkl_stdhrs_earned_actual,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc) AS ytd_stdhrs_earned_actual,
	ISNULL(wkl_stdhrs_earned_planned,0) AS wkl_stdhrs_earned_planned,
	SUM(ISNULL(wkl_stdhrs_earned_planned,0) ) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc) AS ytd_stdhrs_earned_planned,
	ISNULL(wkl_bhndsch_hrs,0) AS wkl_bhndsch_hrs,
	ISNULL(wkl_bhndsch_ucl,0) AS wkl_bhndsch_ucl,
	ISNULL(wkl_bhndsch_to_fnsh_hrs,0) AS wkl_bhndsch_to_fnsh_hrs,
	ISNULL(wkl_bhndsch_to_fnsh_ucl,0) AS wkl_bhndsch_to_fnsh_ucl,
	ISNULL(wkl_labor_hrs_actual,0) as wkl_labor_hrs_actual,
	SUM(ISNULL(wkl_labor_hrs_actual,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc) AS ytd_labor_hrs_actual,
	ISNULL(wkl_overtime_hrs_actual,0) as wkl_overtime_hrs_actual,
	SUM(ISNULL(wkl_overtime_hrs_actual,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc) AS ytd_overtime_hrs_actual,
	ISNULL(wkl_doi_chgs_actual,0) AS wkl_doi_chgs_actual,
	SUM(ISNULL(wkl_doi_chgs_actual,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc) AS ytd_doi_chgs_actual,
	(ISNULL(wkl_labor_hrs_actual,0) + ISNULL(wkl_overtime_hrs_actual,0)) AS wkl_total_hrs_actual,
	(SUM(ISNULL(wkl_labor_hrs_actual,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc)  +
	SUM(ISNULL(wkl_overtime_hrs_actual,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc)) AS ytd_total_hrs_actual,
	ISNULL(wkl_abs_hrs,0) AS wkl_abs_hrs,
	SUM(ISNULL(wkl_abs_hrs,0)) OVER (PARTITION BY category,sub_category,YEAR(rpt_week_end_dt) ORDER BY rpt_week_end_dt asc) AS ytd_abs_hrs
FROM 
	[datamart].[fact_fab_standard_hours] 
)

SELECT * 
INTO 
	#tmp_total_hours 
FROM 
	cte_total_hours 
-----------------------------
UNION
-----------------------------
SELECT 
	week_end_date,
	category,
	'All' AS sub_category,
	SUM(wkl_stdhrs_earned_actual),
	SUM(ytd_stdhrs_earned_actual),
	SUM(wkl_stdhrs_earned_planned),
	SUM(ytd_stdhrs_earned_planned),
	SUM(wkl_bhndsch_hrs),
	SUM(wkl_bhndsch_ucl),
	SUM(wkl_bhndsch_to_fnsh_hrs),
	SUM(wkl_bhndsch_to_fnsh_ucl),
	SUM(wkl_labor_hrs_actual),
	SUM(ytd_labor_hrs_actual),
	SUM(wkl_overtime_hrs_actual),
	SUM(ytd_overtime_hrs_actual),
	SUM(wkl_doi_chgs_actual),
	SUM(ytd_doi_chgs_actual),
	SUM(wkl_total_hrs_actual),
	SUM(ytd_total_hrs_actual),
	SUM(wkl_abs_hrs),
	SUM(ytd_abs_hrs)
FROM
	cte_total_hours
WHERE 
	category <> 'CFC'
	--AND week_end_date = @wk_end_date
GROUP BY
	week_end_date,
	category
-----------------------------
UNION
-----------------------------
SELECT 
	week_end_date,
	'All' AS category,
	'All' AS sub_category,
	SUM(wkl_stdhrs_earned_actual),
	SUM(ytd_stdhrs_earned_actual),
	SUM(wkl_stdhrs_earned_planned),
	SUM(ytd_stdhrs_earned_planned),
	SUM(wkl_bhndsch_hrs),
	SUM(wkl_bhndsch_ucl),
	SUM(wkl_bhndsch_to_fnsh_hrs),
	SUM(wkl_bhndsch_to_fnsh_ucl),
	SUM(wkl_labor_hrs_actual),
	SUM(ytd_labor_hrs_actual),
	SUM(wkl_overtime_hrs_actual),
	SUM(ytd_overtime_hrs_actual),
	SUM(wkl_doi_chgs_actual),
	SUM(ytd_doi_chgs_actual),
	SUM(wkl_total_hrs_actual),
	SUM(ytd_total_hrs_actual),
	SUM(wkl_abs_hrs),
	SUM(ytd_abs_hrs)
FROM
	cte_total_hours
--WHERE
--	week_end_date = @wk_end_date
GROUP BY
	week_end_date
/**********************************************************************************************************/

/**********************************************************************************************************
Kit Fill Rate
**********************************************************************************************************/

IF OBJECT_ID('tempdb..#tmp_KFR') IS NOT NULL DROP TABLE #tmp_KFR
SELECT 
	a.row_num,
	a.week_end_dt,
	ISNULL(CASE WHEN CHARINDEX('%',a.lsn,1) > 0 THEN CONVERT(float,replace(a.lsn,'%',''))/100 ELSE CONVERT(float,a.lsn) END,0.0) as lsn,
	ISNULL(CASE WHEN CHARINDEX('%',a.cmcs_mach,1) > 0 THEN CONVERT(float,replace(a.cmcs_mach,'%',''))/100 ELSE CONVERT(float,a.cmcs_mach) END,0.0) as cmcs_mach,
	ISNULL(CASE WHEN CHARINDEX('%',a.cmcs_wtw,1) > 0 THEN CONVERT(float,replace(a.cmcs_wtw,'%',''))/100 ELSE CONVERT(float,a.cmcs_wtw) END,0.0) as cmcs_wtw,
	ISNULL(CASE WHEN CHARINDEX('%',a.lss,1) > 0 THEN CONVERT(float,replace(a.lss,'%',''))/100 ELSE CONVERT(float,a.lss) END,0.0) as lss,
	ISNULL(CASE WHEN CHARINDEX('%',a.smc,1) > 0 THEN CONVERT(float,replace(a.smc,'%',''))/100 ELSE CONVERT(float,a.smc) END,0.0) as smc,
	ISNULL(CASE WHEN CHARINDEX('%',a.cmce,1) > 0 THEN CONVERT(float,replace(a.cmce,'%',''))/100 ELSE CONVERT(float,a.cmce) END,0.0) as cmce,
	ISNULL(CASE WHEN CHARINDEX('%',a.cfc,1) > 0 THEN CONVERT(float,replace(a.cfc,'%',''))/100 ELSE CONVERT(float,a.cfc) END,0.0) as cfc,
	ISNULL(CASE WHEN CHARINDEX('%',a.cmcw,1) > 0 THEN CONVERT(float,replace(a.cmcw,'%',''))/100 ELSE CONVERT(float,a.cmcw) END,0.0) as cmcw,
	ISNULL(CASE WHEN CHARINDEX('%',a.skin_fab_1,1) > 0 THEN CONVERT(float,replace(a.skin_fab_1,'%',''))/100 ELSE CONVERT(float,a.skin_fab_1) END,0.0) as skin_fab_1 ,
	ISNULL(CASE WHEN CHARINDEX('%',a.machine_fab,1) > 0 THEN CONVERT(float,replace(a.machine_fab,'%',''))/100 ELSE CONVERT(float,a.machine_fab) END,0.0) as machine_fab,
	ISNULL(CASE WHEN CHARINDEX('%',a.sheet_metal,1) > 0 THEN CONVERT(float,replace(a.sheet_metal,'%',''))/100 ELSE CONVERT(float,a.sheet_metal) END,0.0) as sheet_metal,
	ISNULL(CASE WHEN CHARINDEX('%',a.skin_fab,1) > 0 THEN CONVERT(float,replace(a.skin_fab,'%',''))/100 ELSE CONVERT(float,a.skin_fab) END,0.0) as skin_fab,
	ISNULL(CASE WHEN CHARINDEX('%',a.cfc_1,1) > 0 THEN CONVERT(float,replace(a.cfc_1,'%',''))/100 ELSE CONVERT(float,a.cfc_1) END,0.0) as cfc_1,
	ISNULL(CASE WHEN CHARINDEX('%',a.total_fab,1) > 0 THEN CONVERT(float,replace(a.total_fab,'%',''))/100 ELSE CONVERT(float,a.total_fab) END,0.0) as total_fab
INTO 
	#tmp_KFR
FROM
	(SELECT *
	from 
		[staging].[ftp_fab_kit_fill_rate]
	where 
		total_fab is not null
	) a
-------------------------------------------------------------------------------------------------------------------------------
IF OBJECT_ID('tempdb..#tmp_kit_fill_rate') IS NOT NULL DROP TABLE #tmp_kit_fill_rate

;WITH cte_kfr AS
(
SELECT 
	ROW_NUMBER() OVER (ORDER BY row_num desc) AS Row_ID,
	row_num,
	week_end_dt as week_end_date,
	lsn,
	cmcs_mach,
	cmcs_wtw,
	lss,
	smc,
	cmce,
	cfc,
	cmcw,
	skin_fab_1,
	machine_fab,
	sheet_metal,
	skin_fab,
	cfc_1,
	total_fab 
FROM 
	#tmp_KFR
),
cte_kfr_1 AS
(
SELECT 
	Row_ID,
	week_end_date,
	category,
	kfr_actual 
FROM 
	cte_kfr  
	UNPIVOT (kfr_actual for category in 
					(lsn,cmcs_mach,cmcs_wtw,lss,smc,cmce,cfc,
					cmcw,skin_fab_1,machine_fab,sheet_metal,skin_fab,cfc_1,total_fab)
) q
),
cte_kfr_2 AS
(
SELECT 
	category,
	week_end_date,
	MAX(CASE WHEN Row_ID NOT IN (1,2) THEN kfr_actual END) as kfr_actual,
	MAX(CASE WHEN Row_ID = 1 THEN kfr_actual END) as kfr_ytd_target,
	MAX(CASE WHEN Row_ID = 2 THEN kfr_actual END) as kfr_ytd_actual
FROM 
	cte_kfr_1
GROUP BY 
	week_end_date,
	category
),
cte_kfr_3 AS
(
SELECT 
	a.week_end_date,
	a.category,
	a.kfr_actual,
	b.kfr_ytd_actual,
	b.kfr_ytd_target
FROM 
	cte_kfr_2 a
		JOIN cte_kfr_2 b
			on a.category	=b.category
WHERE
	YEAR(a.week_end_date) = YEAR(GETDATE())
	AND b.kfr_ytd_actual is not null
),
cte_final AS
(
SELECT 
	f.week_end_date,
	'All' as category,
	'All' as sub_category,
	f.kfr_actual,
	f.kfr_ytd_actual,
	f.kfr_ytd_target
FROM 
	cte_kfr_3 f
Where 
	f.category = 'total_fab'

UNION

SELECT 
	f.week_end_date,
	bu.category,
	'All',
	f.kfr_actual,
	f.kfr_ytd_actual,
	f.kfr_ytd_target
FROM 
	[staging].[ftp_fab_business_unit] bu
		LEFT JOIN cte_kfr_3 f
			ON bu.category = REPLACE(f.category,'_',' ') 
WHERE 
	f.category in ('skin_fab','machine_fab','sheet_metal')

UNION

SELECT 
	f.week_end_date,
	bu.category,
	bu.sub_category,
	f.kfr_actual,
	f.kfr_ytd_actual,
	f.kfr_ytd_target
FROM 
	[staging].[ftp_fab_business_unit] bu
		JOIN cte_kfr_3 f
			ON bu.sub_category = REPLACE(f.category,'_',' ') 

UNION
	
SELECT 
	f.week_end_date,
	'Skin Fab' as category,
	bu.sub_category,
	1-(((1-f.kfr_actual)*2)/3) as kfr_actual,f.kfr_ytd_actual,f.kfr_ytd_target
FROM 
	cte_kfr_3 f
		CROSS JOIN [staging].[ftp_fab_business_unit] bu
Where 
	f.category = 'skin_fab_1'
	AND bu.sub_category IN ('MCC','Skin Proc','Skin T&D' )
)

SELECT 
	f.week_end_date,
	f.category,
	f.sub_category,
	f.kfr_actual as wkl_kfr_actual,
	0.98 as wkl_kfr_planned,
	--1 as wkl_kfr_planned,
	f.kfr_ytd_actual as ytd_kfr_actual,
	f.kfr_ytd_target as ytd_kfr_planned
INTO 
	#tmp_kit_fill_rate
FROM 
	cte_final f

UNION

SELECT 
	f.week_end_date,
	'Skin Fab' as category,
	'Master Model' as sub_category,
	1 as wkl_kfr_actual,
	0.98 as wkl_kfr_planned,
	--1 as wkl_kfr_planned,
	1 as ytd_kfr_actual,
	1 as ytd_kfr_planned
FROM 
	cte_final f

UNION

SELECT 
	f.week_end_date,
	'Skin Fab' as category,
	'Panelization' as sub_category,
	1 as wkl_kfr_actual,
	0.98 as wkl_kfr_planned,
	--1 as wkl_kfr_planned,
	1 as ytd_kfr_actual,
	1 as ytd_kfr_planned
FROM 
	cte_final f
/**********************************************************************************************************/


/**********************************************************************************************************
Headcount
**********************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_headcount') IS NOT NULL DROP TABLE #tmp_headcount
;WITH cte_hcnt AS
(
SELECT 
	calv.week_end_date,
	bu.category,
	bu.sub_category,
	lbr.actuals as wkl_headcount_act,
	SUM(lbr.actuals) OVER (PARTITION BY bu.category,bu.sub_category,year(calv.week_end_date) ORDER BY calv.week_end_date asc) as ytd_headcount_act,
	lbr.planned as wkl_headcount_pln,
	SUM(lbr.planned) OVER (PARTITION BY bu.category,bu.sub_category,year(calv.week_end_date) ORDER BY calv.week_end_date asc) as ytd_headcount_pln,
	(lbr.actuals * calv.week_work_hours_2) as wkl_tot_hc_act,
	SUM((lbr.actuals * calv.week_work_hours_2)) OVER (PARTITION BY bu.category,bu.sub_category,year(calv.week_end_date) ORDER BY calv.week_end_date asc) as ytd_tot_hc_act
FROM 
	[datamart].[fact_direct_labor_safety] lbr
		JOIN [staging].[ftp_fab_business_unit] bu
			ON lbr.cost_center = bu.cost_center
		JOIN [datamart].[vw_dim_calendar] calv
			ON lbr.spirit_week = calv.spirit_week
			AND lbr.spirit_year = calv.spirit_year
WHERE 
	lbr.metric_name = 'Hdct'
)
SELECT * 
INTO 
	#tmp_headcount 
FROM 
	cte_hcnt

UNION

SELECT
	week_end_date,
	category,
	'All' as sub_category,
	SUM(wkl_headcount_act) as wkl_headcount_act,
	SUM(ytd_headcount_act) as ytd_headcount_act,
	SUM(wkl_headcount_pln)  as wkl_headcount_pln,
	SUM(ytd_headcount_pln)  as ytd_headcount_pln,
	SUM(wkl_tot_hc_act) as wkl_tot_hc_act,
	SUM(ytd_tot_hc_act) as ytd_tot_hc_act
FROM
	cte_hcnt
WHERE
	category <> 'CFC'
GROUP BY
	week_end_date,
	category

UNION

SELECT
	week_end_date,
	'All' as category,
	'All' as sub_category,
	SUM(wkl_headcount_act) as wkl_headcount_act,
	SUM(ytd_headcount_act) as ytd_headcount_act,
	SUM(wkl_headcount_pln)  as wkl_headcount_pln,
	SUM(ytd_headcount_pln)  as ytd_headcount_pln,
	SUM(wkl_tot_hc_act) as wkl_tot_hc_act,
	SUM(ytd_tot_hc_act) as ytd_tot_hc_act
FROM
	cte_hcnt
GROUP BY
	week_end_date
/**********************************************************************************************************/


/**********************************************************************************************************
Targets for current year
**********************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_fab_tgts') IS NOT NULL DROP TABLE #tmp_fab_tgts
SELECT DISTINCT
	bu.week_end_date,
	bu.category,
	bu.sub_category,
	aop.aop_ot_pcg,
	rlzn.wkl_rlzn_target_pcg,
	saop.wkl_staffing_aop,
	doi.doi_tgt_pcg as wkl_hc_doi_pcg_planned,
	doi.doi_tgt_pcg as ytd_hc_doi_pcg_planned,
	ab.wkl_std_abs_pcg,
	srrtgt.srr_touch_to_plan_pcg
INTO 
	#tmp_fab_tgts
FROM 
	(
	SELECT 
		calv.week_end_date,
		calv.spirit_year,
		bu.fab_category,
		bu.category,
		bu.sub_category
	FROM
		[datamart].[vw_dim_calendar] calv
			CROSS JOIN [staging].[ftp_fab_business_unit] bu
	) bu
		LEFT JOIN [staging].[ftp_fab_aop_ot_pcg] aop
			on aop.fab_category = bu.fab_category
			AND aop.week_end_date = bu.week_end_date
		LEFT JOIN [staging].[ftp_fab_realization_pcg_plan] rlzn
			on rlzn.fab_category = bu.fab_category
			AND rlzn.week_end_date = bu.week_end_date
		LEFT JOIN [staging].[ftp_fab_staffing_aop] saop	
			ON saop.fab_category = bu.fab_category
			AND saop.week_end_date = bu.week_end_date
		LEFT JOIN [staging].[ftp_fab_doi_tgt_pcg] doi
			ON doi.fab_category = bu.fab_category
			AND doi.spirit_year = bu.spirit_year
		LEFT JOIN [staging].[ftp_fab_standard_abs_pcg] ab
			on ab.fab_category = bu.fab_category
			AND ab.spirit_year = bu.spirit_year
		LEFT JOIN [staging].[ftp_fab_srr_touch_to_plan_pcg] srrtgt
			on srrtgt.fab_category = bu.fab_category
			AND srrtgt.spirit_year = bu.spirit_year
WHERE
	bu.spirit_year = year(@wk_end_date)
ORDER BY
	bu.week_end_date

-------------------------------------------------------------------------------------------
UPDATE ftgt
SET 
	ftgt.wkl_rlzn_target_pcg = tgt1.wkl_rlzn_target_pcg,
	ftgt.wkl_staffing_aop = tgt1.wkl_staffing_aop
FROM
	#tmp_fab_tgts ftgt
		JOIN
			(SELECT 
				tgt.week_end_date,
				tgt.category,
				AVG(tgt.wkl_rlzn_target_pcg) AS wkl_rlzn_target_pcg,
				SUM(tgt.wkl_staffing_aop) AS wkl_staffing_aop
			FROM 
				#tmp_fab_tgts tgt
			WHERE
				tgt.sub_category <> 'All'
			GROUP BY
				tgt.week_end_date,
				tgt.category
			) tgt1
			ON ftgt.week_end_date =  tgt1.week_end_date
			AND ftgt.category = tgt1.category
			AND ftgt.sub_category = 'All'

-------------------------------------------------------------------------------------------
UPDATE ftgt
SET 
	ftgt.wkl_rlzn_target_pcg = tgt1.wkl_rlzn_target_pcg,
	ftgt.wkl_staffing_aop = tgt1.wkl_staffing_aop
FROM
	#tmp_fab_tgts ftgt
		JOIN
			(SELECT 
				tgt.week_end_date,
				AVG(tgt.wkl_rlzn_target_pcg) AS wkl_rlzn_target_pcg,
				SUM(tgt.wkl_staffing_aop) AS wkl_staffing_aop
			FROM 
				#tmp_fab_tgts tgt
			WHERE
				tgt.sub_category <> 'All'
			GROUP BY
				tgt.week_end_date
			) tgt1
			ON ftgt.week_end_date =  tgt1.week_end_date
			AND ftgt.category = 'All'
			AND ftgt.sub_category = 'All'	
/**********************************************************************************************************/


/**********************************************************************************************************
All KPI's
**********************************************************************************************************/
IF OBJECT_ID('tempdb..#tmp_fab_kpis') IS NOT NULL DROP TABLE #tmp_fab_kpis
;WITH cte_fab_kpis AS 
(
SELECT 
	cc.week_end_date,
	cc.spirit_year,
	cc.spirit_week,
	cc.week_work_hours_1,
	cc.week_work_hours_2,
	1 AS flg_curr_week,
	cc.category,
	cc.sub_category,
	th.wkl_stdhrs_earned_actual,
	th.ytd_stdhrs_earned_actual,
	th.wkl_stdhrs_earned_planned,
	th.ytd_stdhrs_earned_planned,
	th.wkl_bhndsch_hrs,
	th.wkl_bhndsch_ucl,
	th.wkl_bhndsch_to_fnsh_hrs,
	th.wkl_bhndsch_to_fnsh_ucl,
	th.wkl_labor_hrs_actual,
	th.ytd_labor_hrs_actual,
	th.wkl_overtime_hrs_actual,
	th.ytd_overtime_hrs_actual,
	th.wkl_doi_chgs_actual,
	th.ytd_doi_chgs_actual,
	th.wkl_total_hrs_actual,
	th.ytd_total_hrs_actual,
	th.wkl_abs_hrs,
	th.ytd_abs_hrs,
	thc.wkl_headcount_act as wkl_hc_assigned_actual,
	thc.ytd_headcount_act as ytd_hc_assigned_actual,
	thc.wkl_headcount_pln,
	thc.ytd_headcount_pln,
	thc.wkl_tot_hc_act as wkl_total_headhours,
	thc.ytd_tot_hc_act as ytd_total_headhours,
	ftgt.wkl_hc_doi_pcg_planned,
	ftgt.ytd_hc_doi_pcg_planned,
	ftgt.wkl_rlzn_target_pcg,
	ftgt.aop_ot_pcg,
	ftgt.wkl_staffing_aop,
	ftgt.wkl_std_abs_pcg,
	ftgt.srr_touch_to_plan_pcg,
	--(th.wkl_total_hrs_actual * ftgt.wkl_rlzn_target_pcg) as wkl_total_hrs_planned,
	(th.wkl_stdhrs_earned_planned / ftgt.wkl_rlzn_target_pcg) as wkl_total_hrs_planned,
	
	--((th.wkl_total_hrs_actual * ftgt.wkl_rlzn_target_pcg) * ftgt.aop_ot_pcg) as wkl_overtime_hrs_planned,
	((th.wkl_stdhrs_earned_planned  / ftgt.wkl_rlzn_target_pcg) * ftgt.aop_ot_pcg) as wkl_overtime_hrs_planned,
	--((th.wkl_total_hrs_actual * ftgt.wkl_rlzn_target_pcg) - ((th.wkl_total_hrs_actual * ftgt.wkl_rlzn_target_pcg) * ftgt.aop_ot_pcg)) as wkl_labor_hrs_planned,
	((th.wkl_stdhrs_earned_planned  / ftgt.wkl_rlzn_target_pcg) - ((th.wkl_stdhrs_earned_planned  / ftgt.wkl_rlzn_target_pcg) * ftgt.aop_ot_pcg)) as wkl_labor_hrs_planned,
	CASE WHEN th.wkl_labor_hrs_actual > 0 THEN th.wkl_overtime_hrs_actual/th.wkl_labor_hrs_actual END as wkl_ot_pcg_actual,
	CASE WHEN th.ytd_labor_hrs_actual > 0 THEN th.ytd_overtime_hrs_actual/th.ytd_labor_hrs_actual END as ytd_ot_pcg_actual,
	CASE WHEN th.wkl_total_hrs_actual > 0 THEN (th.wkl_stdhrs_earned_actual/th.wkl_total_hrs_actual) END AS wkl_rlzn_pcg_actual,
	CASE WHEN th.ytd_total_hrs_actual > 0 THEN (th.ytd_stdhrs_earned_actual/th.ytd_total_hrs_actual) END AS ytd_rlzn_pcg_actual,
	CASE WHEN thc.wkl_tot_hc_act > 0 THEN th.wkl_doi_chgs_actual/thc.wkl_tot_hc_act END as wkl_hc_doi_pcg_actual,
	CASE WHEN thc.ytd_tot_hc_act > 0 THEN th.ytd_doi_chgs_actual/thc.ytd_tot_hc_act END as ytd_hc_doi_pcg_actual,
	CASE WHEN thc.wkl_tot_hc_act > 0 THEN th.wkl_abs_hrs / thc.wkl_tot_hc_act END as wkl_hc_abs_pcg_actual,
	CASE WHEN thc.ytd_tot_hc_act > 0 THEN th.ytd_abs_hrs / thc.ytd_tot_hc_act END as ytd_hc_abs_pcg_actual,
	kfr.wkl_kfr_actual,
	kfr.wkl_kfr_planned,
	kfr.ytd_kfr_actual,
	kfr.ytd_kfr_planned,
	srresc.wkl_qlty_srr_act,
	srresc.wkl_qlty_srr_pln,
	srresc.ytd_qlty_srr_act,
	srresc.ytd_qlty_srr_pln,
	srresc.wkl_qlty_esc_assy_act,
	srresc.wkl_qlty_esc_assy_pln,
	srresc.ytd_qlty_esc_assy_act,
	srresc.ytd_qlty_esc_assy_pln,
	srresc.wkl_qlty_esc_cust_act,
	srresc.wkl_qlty_esc_cust_pln,
	srresc.ytd_qlty_esc_cust_act,
	srresc.ytd_qlty_esc_cust_pln
FROM 
	(SELECT 
		calv.week_end_date,
		calv.spirit_year,
		calv.spirit_week,
		calv.week_work_hours_1,
		calv.week_work_hours_2,
		bu.category,
		bu.sub_category
	FROM
		[datamart].[vw_dim_calendar] calv
			CROSS JOIN [staging].[ftp_fab_business_unit] bu
	WHERE
		calv.spirit_year = year(@wk_end_date)
	) cc
		LEFT JOIN #tmp_total_hours th
			ON th.week_end_date = cc.week_end_date
			AND th.category = cc.category
			AND th.sub_category = cc.sub_category	
		LEFT JOIN #tmp_headcount thc
			ON cc.week_end_date = thc.week_end_date
			AND cc.category = thc.category
			AND cc.sub_category = thc.sub_category
		LEFT JOIN #tmp_fab_tgts ftgt
			ON cc.week_end_date = ftgt.week_end_date
			AND cc.category = ftgt.category
			AND cc.sub_category = ftgt.sub_category
		LEFT JOIN #tmp_kit_fill_rate kfr
			ON cc.week_end_date = kfr.week_end_date
			AND cc.category = kfr.category
			AND cc.sub_category = kfr.sub_category
		--LEFT JOIN #tmp_fab_srr_escapes srresc
		--	ON cc.week_end_date = srresc.week_end_date
		--	AND cc.category = srresc.category
		--	AND cc.sub_category = srresc.sub_category
		LEFT JOIN [datamart].[fact_fab_srr_escapes] srresc
			ON cc.week_end_date = srresc.rpt_week_end_dt
			AND cc.category = srresc.category
			AND cc.sub_category = srresc.sub_category
where 
	th.wkl_stdhrs_earned_actual is not null
),
cte_fab_kpis_1 AS (
SELECT 
	*,
	SUM(wkl_total_hrs_planned) OVER(PARTITION BY category,sub_category,year(week_end_date) ORDER BY week_end_date asc) as ytd_total_hrs_planned,
	SUM(wkl_overtime_hrs_planned)  OVER(PARTITION BY category,sub_category,year(week_end_date) ORDER BY week_end_date asc) as ytd_overtime_hrs_planned,
	SUM(wkl_labor_hrs_planned)  OVER(PARTITION BY category,sub_category,year(week_end_date) ORDER BY week_end_date asc) as ytd_labor_hrs_planned
FROM 
	cte_fab_kpis
)
SELECT 
	*,
	CASE WHEN ytd_total_hrs_planned > 0 THEN ytd_stdhrs_earned_planned / ytd_total_hrs_planned END as ytd_rlzn_pcg_planned,
	CASE WHEN wkl_labor_hrs_planned > 0 THEN wkl_overtime_hrs_planned/wkl_labor_hrs_planned END as wkl_ot_pcg_planned
INTO 
	#tmp_fab_kpis
FROM
	cte_fab_kpis_1
-----------------------------------------------------------------------------------------------------------------------------
update #tmp_fab_kpis 
set 
	flg_curr_week = 2
WHERE 
	week_end_date IN (SELECT max(week_end_date) from #tmp_fab_kpis)
-------------------------------------------------------------------------------------------------------------------------------

/**********************************************************************************************************/

/**********************************************************************************************************
Final load to datamart [fact_fab_summary]
**********************************************************************************************************/
DELETE FROM  [datamart].[fact_fab_summary] WHERE year([rpt_week_end_dt]) = year(@wk_end_date)
-------------------------------------------------------------------------------------------------------------------------------
INSERT INTO [datamart].[fact_fab_summary]
	(
	[rpt_week_end_dt],	[rpt_year],	[rpt_week],	[category],	[sub_category],	[flg_curr_week],[wkl_qlty_srr_actual],	[wkl_qlty_srr_planned],	[ytd_qlty_srr_actual],
	[ytd_qlty_srr_planned],	[wkl_qlty_srr_touch_pcg_actual],[wkl_qlty_srr_touch_pcg_planned],	[ytd_qlty_srr_touch_pcg_actual],	[ytd_qlty_srr_touch_pcg_planned],
	[wkl_qlty_escap_to_assy_actual],	[wkl_qlty_escap_to_assy_planned],	[ytd_qlty_escap_to_assy_actual],	[ytd_qlty_escap_to_assy_planned],	[wkl_qlty_escap_to_cust_actual],
	[wkl_qlty_escap_to_cust_planned],	[ytd_qlty_escap_to_cust_actual],	[ytd_qlty_escap_to_cust_planned],	[wkl_rlzn_pcg_actual],	[wkl_rlzn_pcg_planned],	[ytd_rlzn_pcg_actual],
	[ytd_rlzn_pcg_planned],	[wkl_stdhrs_earned_actual],	[wkl_stdhrs_earned_planned],	[ytd_stdhrs_earned_actual],	[ytd_stdhrs_earned_planned],	[wkl_dlvry_kfr_pcg_actual],
	[wkl_dlvry_kfr_pcg_planned],	[ytd_dlvry_kfr_pcg_actual],	[ytd_dlvry_kfr_pcg_planned],	[wkl_ot_pcg_actual],	[wkl_ot_pcg_planned],	[ytd_ot_pcg_actual],[aop_ot_pcg],
	[wkl_hc_assigned_actual],[wkl_hc_assigned_planned],	[ytd_hc_assigned_actual],	[ytd_hc_assigned_planned],	[wkl_hc_doi_pcg_actual],	[wkl_hc_doi_pcg_planned],	[ytd_hc_doi_pcg_actual],
	[ytd_hc_doi_pcg_planned],	[hc_std_abs_pcg],	[wkl_hc_abs_pcg_actual],	[ytd_hc_abs_pcg_actual],	[wkl_bhndsch_hrs],	[wkl_bhndsch_ucl],	[wkl_bhndsch_to_fnsh_hrs],
	[wkl_bhndsch_to_fnsh_ucl],	[wkl_hc_effective_actual],	[wkl_hc_demand],	[ytd_hc_effective_actual],	[ytd_hc_demand],	[wkl_stfg_aop_planned]
	)

SELECT 
	week_end_date,
	spirit_year,
	spirit_week,
	category,
	sub_category,
	flg_curr_week,
	wkl_qlty_srr_act,
	wkl_qlty_srr_pln,
	ytd_qlty_srr_act,
	ytd_qlty_srr_pln,
	CASE WHEN wkl_total_hrs_actual > 0 THEN (wkl_qlty_srr_act / wkl_total_hrs_actual) /100	END AS wkl_qlty_srr_touch_pcg_actual,
	srr_touch_to_plan_pcg	 AS wkl_qlty_srr_touch_pcg_planned,
	CASE WHEN ytd_total_hrs_actual > 0 THEN (ytd_qlty_srr_act / (ytd_total_hrs_actual * 93.31)) 	END AS ytd_qlty_srr_touch_pcg_actual,
	srr_touch_to_plan_pcg AS ytd_qlty_srr_touch_pcg_planned,
	wkl_qlty_esc_assy_act,
	wkl_qlty_esc_assy_pln,
	ytd_qlty_esc_assy_act,
	ytd_qlty_esc_assy_pln,
	wkl_qlty_esc_cust_act,
	wkl_qlty_esc_cust_pln,
	ytd_qlty_esc_cust_act,
	ytd_qlty_esc_cust_pln,
	wkl_rlzn_pcg_actual,
	wkl_rlzn_target_pcg,
	ytd_rlzn_pcg_actual,
	CASE WHEN ytd_total_hrs_planned > 0 THEN ytd_stdhrs_earned_planned / ytd_total_hrs_planned END as ytd_rlzn_pcg_planned,
	wkl_stdhrs_earned_actual,
	wkl_stdhrs_earned_planned,
	ytd_stdhrs_earned_actual,
	ytd_stdhrs_earned_planned,
	wkl_kfr_actual,
	wkl_kfr_planned,
	ytd_kfr_actual,
	ytd_kfr_planned,
	wkl_ot_pcg_actual,
	CASE WHEN wkl_labor_hrs_planned > 0 THEN wkl_overtime_hrs_planned/wkl_labor_hrs_planned END as wkl_ot_pcg_planned,
	ytd_ot_pcg_actual,
	aop_ot_pcg,
	wkl_hc_assigned_actual,
	wkl_headcount_pln,
	ytd_hc_assigned_actual,
	ytd_headcount_pln,
	wkl_hc_doi_pcg_actual,
	wkl_hc_doi_pcg_planned,
	ytd_hc_doi_pcg_actual,
	ytd_hc_doi_pcg_planned,
	wkl_std_abs_pcg,
	wkl_hc_abs_pcg_actual,
	ytd_hc_abs_pcg_actual,
	wkl_bhndsch_hrs,
	wkl_bhndsch_ucl,
	wkl_bhndsch_to_fnsh_hrs,
	wkl_bhndsch_to_fnsh_ucl,
	CASE WHEN week_work_hours_1 > 0 THEN wkl_labor_hrs_actual/week_work_hours_1 END as wkl_hc_effective_actual,
	CASE WHEN wkl_rlzn_pcg_actual > 0 THEN (wkl_stdhrs_earned_planned / wkl_rlzn_pcg_actual) / week_work_hours_1 / ( 1 + aop_ot_pcg) END as wkl_hc_demand,
	----The below calc require clarification and not used in dashboard.
	CASE WHEN week_work_hours_1 > 0 THEN ytd_labor_hrs_actual / week_work_hours_1 END as ytd_hc_effective_actual,
	CASE WHEN week_work_hours_1 > 0 THEN ytd_labor_hrs_planned / week_work_hours_1 END as ytd_hc_demand,
	wkl_staffing_aop
FROM 
	#tmp_fab_kpis

END
GO

IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_facility')
 DROP PROC datamart.proc_cleansing_facility
GO

CREATE PROC datamart.proc_cleansing_facility
as

/*
Usage : Cleansing facilities related data from Staging & Loading to Datamart

Creator/Editor #Date #Comments
Prakhar Shrivastava # 2017-06-21 # Initial creation
Pratheesh N # 2017-10-20 # added overtime cleansing & corrected logical errors
*/

BEGIN

SET NOCOUNT ON;

--BEGIN TRAN trn_main_facility_processing;

DECLARE 
@errorline int -- used to call raiseerror
,@errornumber int -- used to call raiseerror
,@errorseverity int -- used to call raiseerror
,@errorstate int -- used to call raiseerror
,@errormessage varchar(2048) -- used to call raiseerror

,@errorflag bit
,@week int
,@installdate datetime
,@errorprocedure varchar(50)
,@max_date date

,@workdate date
,@report_date date
,@spirit_year int;

--BEGIN TRY;

--Truncating Full-Loading tables
TRUNCATE TABLE datamart.fact_srr_facility
TRUNCATE TABLE datamart.fact_asset_cost
TRUNCATE TABLE datamart.fact_downtime_dailyclocking
TRUNCATE TABLE datamart.fact_manpower_utilization
TRUNCATE TABLE datamart.fact_manpower_utilization_noa

TRUNCATE TABLE datamart.fact_manpower_plannedvsreactive_maintenance
TRUNCATE TABLE datamart.fact_asset_count

--Deleting records which are already exist on Periodical-Loading tables
SET @spirit_year = year(getdate())

DELETE FROM datamart.fact_units_facility
WHERE weekenddate in
(
SELECT distinct weekenddate
FROM staging.ftp_units_facility
UNION ALL
SELECT '2000-01-01'
)
 
DELETE FROM datamart.dim_scrap_rr_reduction_target
WHERE convert(varchar,spirit_year,102) + location in
(
SELECT distinct convert(varchar,spirit_year,102) + location
FROM staging.ftp_scrap_rr_reduction_target
UNION ALL
SELECT '2000Wichita'
)
 
DELETE FROM datamart.fact_absenteeism
WHERE period in 
(
SELECT distinct period
FROM staging.ftp_absenteeism
UNION ALL
SELECT '200011'
)
 
SELECT @max_date = MAX(week_end_date) 
FROM datamart.vw_dim_calendar 
WHERE week_end_date < getdate()

--starts Cleansing for ora_srr_facility

INSERT INTO datamart.fact_srr_facility
(
nc_key
,dtwritten
,model_ist3
,unit
,defect_qty

,defect_dollars
,scrap_dollars
,admin_cost
,mgcode
,featdef_cd

,feat_decrip
,desc_description
,ncr_type
,value_chain
,parts

,origshop
,reasoncd
)

SELECT 
t1.nc_key
,t1.dtwritten
,coalesce(t2.actual_name,t1.model_ist3)
,t1.unit
,t1.defect_qty

,t1.defect_dollars
,t1.scrap_dollars
,t1.admin_cost
,t1.mgcode
,t1.featdef_cd

,t1.feat_descrip
,t1.desc_description
,t1.ncr_type
,t1.value_chain
,t1.parts

,t1.origshop
,t1.reasoncd
  
FROM staging.ora_srr_facility t1

LEFT OUTER JOIN datamart.dim_alias_mapping  t2
 ON COALESCE(t1.code_set_id,t1.model_ist3) =  t2.alias_name
 AND t2.category = 'model_facilities'

WHERE model_ist3 is not null 

and  dtwritten <=@max_date

--End Cleansing for ora_srr_facility

-- Start Cleansing for Quality Units---

INSERT INTO datamart.fact_units_facility
(
Location
,Program
,weekenddate
,Units
)

SELECT 
coalesce(t3.actual_name,t1.location) as location
,coalesce(t2.actual_name,t1.program) as program
,t1.weekenddate
,t1.units
FROM staging.ftp_units_facility t1

LEFT OUTER JOIN datamart.dim_alias_mapping t2
 ON t1.program = t2.alias_name
 AND t2.category = 'model_facilities'
 
LEFT OUTER JOIN datamart.dim_alias_mapping t3
 ON t1.location = t3.alias_name
 AND t3.category = 'location'

WHERE location IN ('Wichita','Oklahoma','Tulsa')

/*AND PROGRAM IN

(
'737'
,'747'
,'767'
,'777'
,'787'

,'bd-'
,'br7'
,'br725'
,'c-series'
,'37m'

,'max'
,'p8a'
,'p-8a'
,'g280'
,'g650'
)*/

and weekenddate <= @max_date

--Starts Cleansing  of maximo_asset_cost--

INSERT INTO datamart.fact_Asset_Cost
(
startdate,
wonum,
wo_description,
reportdate,
actfinish,

busunit,
reqpri,
assetlocpriority,
wo_type,
assetnum,

labor_hrs,
labor_cost,
cause,
failuremark_desc,
problemcode,

wo_priority,
siteid,
maintgrp,
stock_cost,
nonstock_cost

)

SELECT 
startdate
,wonum
,[description]
,reportdate
,actfinish

,busunit
,reqpri
,assetlocpriority
,wo_type
,assetnum

,labor_hrs
,labor_cost
,cause
,failuremark_desc
,problemcode

,wo_priority
,siteid
,maintgrp
,stockcost
,nonstock_cost
  
FROM staging.maximo_asset_cost

where wo_priority is not null

and SITEID IN ('ICT','ISO','TUL')

and busunit in

(
'787'
,'COMPF'
,'FUSESA'
,'FUSETA'      
,'SIKORSKY'

,'NACL'
,'TOOL'

,'FABR'
,'CFC'
,'LIGHT'
,'SFP'

,'MFGOP'       

,'A350C'
,'ASSY'
,'GMF'
,'QA' 
,'S15'
,'SPAR'

)

--Ends cleansing of maximo_asset_cost--

--Starts cleansing of Maximo_Downtime_DailyClocking--

INSERT INTO datamart.fact_downtime_dailyclocking
(
 assetnum
,change_date
,wo_num
,downtime
,assetdept

,wo_description
,location
,wo_priority
,busunit
,wo_status

,siteid
,shopid
,report_date
,actfinish
,leadcraft

,maintgrp
,reqpri
,amflag
,workorder_desc
,failure_desc

,work_type
)

SELECT 

 assetnum
,change_date
,wo_num
,downtime
,assetdept

,wo_description
,location
,wo_priority
,busunit
,wo_status

,siteid
,shopid
,report_date
,actfinish
,leadcraft

,maintgrp
,reqpri
,amflag
,workorder_desc
,failure_desc

,work_type

FROM staging.maximo_downtime_dailyclocking 

where siteid IN ('ICT','TUL','ISO')

and wo_priority is not null 

and report_date <= @max_date

--------Asset count for downtime----------

INSERT INTO datamart.fact_asset_count
(
busunit
,assetnum
,[priority]
,siteid
,isrunning

,installdate
,[status]
,statusdate

)

SELECT 

busunit
,assetnum
,[priority]
,siteid
,isrunning

,installdate
,[status]
,statusdate

FROM  staging.maximo_asset_count

WHERE SITEID IN ('ICT','ISO','TUL')


------------------

--Ends cleansing of Maximo_Downtime_DailyClocking--

--Starts cleansing of maximo_manpower_plannedvsreactive_maintenance--

INSERT INTO datamart.fact_manpower_plannedvsreactive_maintenance
(

 wonum
,wo_description
,actfinish
,regularhrs
,wo_status

,busunit
,reqpri
,assetlocpriority
,priority_num
,siteid

,maintgrp
,laborhrs
)

SELECT
 
 wonum
,wo_description
,actfinish
,regularhrs
,wo_status

,busunit
,reqpri
,assetlocpririty
,priority_num
,siteid

,maintgrp
,laborhrs 

FROM staging.maximo_manpower_plannedvsreactive_maintenance 

WHERE actfinish <=@max_date

--Ends cleansing of maximo_manpower_plannedvsreactive_maintenance--

--Starts cleansing of maximo_manpower_utilization--

INSERT INTO datamart.fact_manpower_utilization
(

personid
,shiftnum
,workdate
,availablehrs
,modhrs

,regularhrs
,siteid
,displayname
,costcenter
,supervisor

,department
,super_name
,sec_personid
,sec_level_mgr
,craft

,qualificationid
)

SELECT 
 personid
,shiftnum
,workdate
,availablehrs
,modhrs

,regularhrs
,siteid
,displayname
,costcenter
,supervisor

,department
,super_name
,sec_personid
,sec_level_mgr
,craft

,qualificationid

FROM staging.maximo_manpower_utilization  

WHERE workdate < = @max_date

--Ends cleansing of maximo_manpower_utilization--

--Starts cleansing of maximo_manpower_utilization_noa--

INSERT INTO datamart.fact_manpower_utilization_noa
(
personid
,shiftnum
,workdate
,availablehrs
,regularhrs

,siteid
,displayname
,costcenter
,supervisor
,department

,super_name
,sec_personid
,sec_level_mgr
,craft
,qualificationid
)

SELECT 

 personid
,shiftnum
,workdate
,availablehrs
,regularhrs

,siteid
,displayname
,costcenter
,supervisor
,department

,super_name
,sec_personid
,sec_level_mgr
,craft
,qualificationid

FROM staging.maximo_manpower_utilization_noa 

WHERE workdate <= @max_date

---Start Cleansing for Head Count-----

INSERT INTO datamart.fact_absenteeism
(
cost_center
,working_level
,shifts
,period
,abs_p

,abs_up
,abs_fmla
,countofpaycode
,total_abs_hours
,std_hours_per_week

,std_abs_pcg
,business_unit
,location
)

SELECT
cost_center
,working_level
,shifts
,period
,abs_p

,abs_up
,abs_fmla
,countofpaycode
,total_abs_hours
,std_hours_per_week

,std_abs_pcg
,business_unit
,location

FROM staging.ftp_absenteeism

where cost_center not like '%-%'

--and period <=@max_date 

--Ends cleansing of HeadCount---

--Call cleansing of overtime
exec datamart.proc_cleansing_facility_overtime

--Start Cleansing for Reduction Target--
INSERT INTO datamart.dim_scrap_rr_reduction_target
(
scrap_amount_target_per_unit
,rr_amount_target_per_unit
,scrap_amount_target_pcg
,rr_amount_target_pcg
,location
,Spirit_year
,program
)

SELECT
scrap_amount_target_per_unit
,rr_amount_target_per_unit
,scrap_amount_target_pcg
,rr_amount_target_pcg
,location
,Spirit_year
,program

FROM staging.ftp_scrap_rr_reduction_target

--End Cleansing For Reduction Target--

--COMMIT TRAN trn_main_facility_processing;

--END TRY

--BEGIN CATCH;

--ROLLBACK TRAN trn_main_facility_processing

--SELECT @errorprocedure='[datamart].[proc_cleansing_quality]', 
--       @errorline=ERROR_LINE(),
--       @errornumber=ERROR_NUMBER(),
--	   @errorseverity=ERROR_SEVERITY(),
--	   @errorstate=CASE WHEN ERROR_STATE()=0 THEN 1 ELSE ERROR_STATE() END,
--       @errormessage=ERROR_MESSAGE();


--EXECUTE datamart.proc_log_error
--                                  @errorprocedure=@errorprocedure,
--								  @errorline=@errorline,
--								  @errornumber=@errornumber,
--								  @errormessage=@errormessage,
--								  @errorseverity=@errorseverity,
--								  @errorstate=@errorstate
					  
					  
--RETURN -1;
--END CATCH;
--RETURN 0;


END

GO

IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_facility_overtime')
 DROP PROC datamart.proc_cleansing_facility_overtime
GO

CREATE PROC datamart.proc_cleansing_facility_overtime
as

/*
Usage : Cleansing overtime data for factilities & fabrication from Staging & Loading to Datamart

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-05 # Initial Creation
*/

BEGIN

SET NOCOUNT ON;
DECLARE @spirit_year int;

SELECT @spirit_year = MAX(spirit_year)
FROM datamart.vw_dim_calendar
WHERE is_current_week = 1
--week_end_date < getdate() 

IF -- delete data for the current year if we have some data in the staging table
(
SELECT count(week_no) as cnt
FROM staging.ftp_direct_labor_safety
) > 10

DELETE FROM datamart.fact_direct_labor_safety
WHERE spirit_year = @spirit_year

--Starts cleansing of Overtime # Updating cost_center for merged rows (only for week_no = 1)

;
WITH cte1 as
(
SELECT
srno
,cost_center
,sheet_name

FROM staging.ftp_direct_labor_safety

WHERE cost_center is not null
 AND week_no = 1
)

,
cte2 as
(
SELECT
t1.srno
,t1.sheet_name
,max(c1.srno) as srno_cc

FROM staging.ftp_direct_labor_safety t1
INNER JOIN cte1 c1 
 ON t1.sheet_name = c1.sheet_name

WHERE t1.cost_center is null
 AND t1.week_no = 1
 AND t1.srno > c1.srno
 
GROUP BY
t1.srno
,t1.sheet_name
)

,
cte3 as
(
SELECT
c2.srno as sn
,c2.sheet_name as ss
,c1.cost_center as cc

FROM cte2 c2
INNER JOIN cte1 c1 
 ON c2.srno_cc = c1.srno
 AND c2.sheet_name = c1.sheet_name
)
 
UPDATE staging.ftp_direct_labor_safety
SET cost_center = cc

FROM cte3
WHERE srno = sn
 AND sheet_name = ss

--Ends cleansing of Overtime # Updating cost_center for merged rows (only for week_no = 1)
 
--Starts cleansing of Overtime # Updating metric_name for null rows (week_no 2 onwards)
;
WITH cte1 as
(
SELECT
srno as sn
,sheet_name as ss
,cost_center as cc
,metric_name as mn
,row_number () over (partition by sheet_name,week_no order by srno) as wsn

FROM staging.ftp_direct_labor_safety
WHERE week_no = 1
)

,
cte2 as
(
SELECT
srno
,sheet_name
,cost_center
,metric_name
,row_number () over (partition by sheet_name,week_no order by srno) as week_wise_srno

FROM staging.ftp_direct_labor_safety
WHERE week_no > 1
)

UPDATE cte2
SET cost_center = cc
 ,metric_name = mn

FROM cte1
WHERE sheet_name = ss
 AND week_wise_srno = wsn

--Ends cleansing of Overtime # Updating metric_name for null rows (week_no 2 onwards)


--Starts cleansing of Overtime # Inserting into datamart table
;
WITH cte_location as
(
SELECT DISTINCT
sheet_name
,location

FROM datamart.dim_cellrange_dynamic_excel_cols
)

INSERT INTO datamart.fact_direct_labor_safety
(
sheet_name
,location
,spirit_year
,spirit_week
,cost_center

,metric_name
,actuals
,planned
)

SELECT
t1.sheet_name
,c1.location
,@spirit_year
,t1.week_no
,coalesce(t2.actual_name, rtrim(ltrim(t1.cost_center))) as cost_center

,rtrim(ltrim(t1.metric_name)) as metric_name
,t1.actuals
,t1.planned

FROM staging.ftp_direct_labor_safety t1

LEFT OUTER JOIN cte_location c1 
 ON t1.sheet_name = c1.sheet_name

LEFT OUTER JOIN datamart.dim_alias_mapping t2 
 ON rtrim(ltrim(t1.cost_center)) = t2.alias_name
 AND t2.category = 'cost_center'

--Ends cleansing of Overtime # Inserting into datamart table

END

GO
/*
Usage : This SP is used to load data from staging to datamart after cleansing

Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_quality')
 DROP PROC [datamart].[proc_cleansing_quality]
GO



CREATE PROC [datamart].[proc_cleansing_quality]
AS
BEGIN
/*************************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Cleansing and Inserting data into Datamart tables from Staging  
**************************************************************************************************************/

SET NOCOUNT ON;

BEGIN TRAN datamart_quality
DECLARE @errorprocedure VARCHAR(50), --used to store procedure name
		@errorline INT, -- used to call RAISEERROR
		@errornumber INT, -- used to call RAISEERROR
		@errorseverity INT, -- used to call RAISEERROR
		@errorstate INT,  -- used to call RAISEERROR
		@errormessage VARCHAR(2048),  -- used to call RAISEERROR
		@run_date datetime, -- used to hold the bad record loading datetime of datamart tables
		@bad_records XML, -- used to capture bad records
		@week int,		--To load the current spirit week
		@spirit_year int, --To load the current spirit year
		@max_date date,  --To load the last week maximum date
		@date_written date; -- To load lastweek end date
		

BEGIN TRY;


SELECT @week=spirit_week FROM [datamart].[dim_calendar] WHERE date_key=CONVERT(DATE,GETDATE());
SET @spirit_year=(SELECT CASE WHEN (@week>=50 AND MONTH(GETDATE()-1)=1) THEN YEAR(GETDATE()-1)-1 ELSE YEAR(GETDATE()-1) END)
SELECT @max_date=MAX(date_key) FROM [datamart].[dim_calendar] WHERE spirit_week=(@week-1) AND spirit_year=@spirit_year;

TRUNCATE TABLE [datamart].[fact_srr_fuselage];
TRUNCATE TABLE datamart.fact_escape;
TRUNCATE TABLE [datamart].[fact_noe];
DELETE FROM [datamart].[dim_srr_target] WHERE [year]=@spirit_year;
DELETE FROM [datamart].[dim_escape_target] WHERE [year]=@spirit_year;

DELETE FROM [datamart].[fact_srr_prestwick] WHERE spirit_year=@spirit_year;
DELETE FROM [datamart].[fact_escape_prestwick] WHERE spirit_year=@spirit_year;
DELETE FROM [datamart].[fact_escape_kinsnz]  WHERE YEAR(date_written)=@spirit_year;

--Start inserting [datamart].[fact_srr_fuselage]
INSERT INTO [datamart].[fact_srr_fuselage](
[date_written]
,[ncr_type]
,[model]
,[unit]
,[feature_defect_code]

,[feature_description]
,[discrepancy_description]
,[value_chain]
,[charge_mgmt_code]
,[defect_qty]

,[defect_dollars]
,[scrap_dollars]
,[admin_cost]
,[total_srr_dollar]
,[location]
,[created_date]
)
SELECT 
CONVERT(DATE,[date_written]) as [date_written]
,[ncr_type]
,COALESCE(modelmapping.actual_name,srr.[model]) as [model]
,[unit]
,[feature_defect_code]

,[feature_description]
,[discrepancy_description]
,COALESCE(aliasmapping.actual_name,srr.value_chain) as [value_chain]
,srr.[charge_mgmt_code]
,[defect_qty]

,[defect_dollars]
,[scrap_dollars]
,[admin_cost]
,[total_srr_dollar]
,[location]
,[load_date]
FROM [staging].[ora_srr_fuselage] srr
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping 
 ON srr.value_chain = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
LEFT OUTER JOIN datamart.dim_alias_mapping modelmapping
 ON srr.model = modelmapping.alias_name and modelmapping.category = 'model'
WHERE srr.model NOT IN 
  (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_srr_fuselage]' and column_name='model' AND operation='In')
AND
srr.value_chain NOT IN  
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_srr_fuselage]' and column_name='value_chain' AND operation='In')
AND
CONVERT(DATE,[date_written])<=@max_date;
  --AND  (COALESCE(defect_dollars,0)<>0 AND COALESCE(scrap_dollars,0)<>0)
--Ends inserting [datamart].[fact_srr_fuselage]

--Bad records inserting start 
SET @run_date=GETDATE();
SET @bad_records=(SELECT 
CONVERT(DATE,[date_written]) as [date_written]
,[ncr_type]
,COALESCE(modelmapping.actual_name,srr.[model]) as [model]
,[unit]
,[feature_defect_code]

,[feature_description]
,[discrepancy_description]
,COALESCE(aliasmapping.actual_name,srr.value_chain) as [value_chain]
,srr.[charge_mgmt_code]
,[defect_qty]

,[defect_dollars]
,[scrap_dollars]
,[admin_cost]
,[total_srr_dollar]
,[location]
,[load_date]
FROM [staging].[ora_srr_fuselage] srr
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping
 ON value_chain = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
LEFT OUTER JOIN datamart.dim_alias_mapping modelmapping
 ON model = modelmapping.alias_name and modelmapping.category = 'model'
WHERE (srr.model IS NULL OR srr.model IN
  (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_srr_fuselage]' and column_name='model' AND operation='In'))
OR (srr.value_chain IS NULL OR srr.value_chain IN  
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_srr_fuselage]' and column_name='value_chain' AND operation='In'))
OR
 (CONVERT(DATE,[date_written])>@max_date)
 FOR XML PATH('node'), ROOT ('datamart.fact_srr_fuselage'));
INSERT INTO [datamart].[bad_table]
(
table_name
,run_date
,records
)
VALUES
(
'datamart.fact_srr_fuselage'
,@run_date
,@bad_records
)
--Bad records inserting end

--Start inserting [datamart].[fact_escape]
INSERT INTO datamart.fact_escape(

      
[program_nm]
,[value_chain_cd]
,[responsible_mgmt_code]
,[feature_description]
,[discrepancy_description]

,[feature_code]
,[ca_count]
,[ncr_part_no]
,[ca_ser_no]
,[sum_ncr_cost_amt]

,[discrepancy_code]
,[unit_no]
,[created_date]
,[location]
,[date_written]
)
SELECT COALESCE(modelmapping.actual_name,[progam_nm]) as [progam_nm]
,COALESCE(aliasmapping.actual_name,value_chain_cd) as [value_chain_cd]
,[responsible_mgmt_code]
,[feature_description]
,[discrepancy_description]

,[feature_code]
,[ca_count]
,[ncr_part_no]
,[ca_ser_no]
,[sum_ncr_cost_amt]

,[discrepancy_code]
,TRY_CONVERT(FLOAT,REPLACE([unit_no],'',NULL))
,[load_date]
,[location]
,CONVERT(DATE,[date_written])
FROM [staging].[ora_escape]
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping
 ON value_chain_cd = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
LEFT OUTER JOIN datamart.dim_alias_mapping modelmapping
 ON [progam_nm] = modelmapping.alias_name and modelmapping.category = 'model'
WHERE [progam_nm] NOT IN 
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_escape]' AND column_name='program_nm' AND operation='In')
AND [value_chain_cd] NOT IN 
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_escape]' AND column_name='value_chain_cd'  AND operation='In')
AND
CONVERT(DATE,[date_written])<=@max_date ;

INSERT INTO [datamart].[fact_escape_kinsnz](
      
[program_nm]
,[value_chain_cd]
,[feature_description]
,[ca_count]
,[created_date]

,[location]
,[date_written]
)
SELECT [program_nm]
	  ,'fuselage' AS [value_chain_cd]
	  ,[escape_description]
      ,1 AS [count]
	  ,[load_date]

	  ,[location]
	  ,[date]
FROM [staging].[ftp_kinston_escape]
WHERE  CONVERT(DATE,[date])<=@max_date;

--Ends inserting [datamart].[fact_escape]

--Bad records inserting start
SET @run_date=GETDATE();
SET @bad_records=(SELECT COALESCE(modelmapping.actual_name,[progam_nm]) as [progam_nm]
,COALESCE(aliasmapping.actual_name,value_chain_cd) as [value_chain_cd]
,[responsible_mgmt_code]
,[feature_description]
,[discrepancy_description]

,[feature_code]
,[ca_count]
,[ncr_part_no]
,[ca_ser_no]
,[sum_ncr_cost_amt]

,[discrepancy_code]
,TRY_CONVERT(FLOAT,REPLACE([unit_no],'',NULL))
,[load_date]
,[location]
,CONVERT(DATE,[date_written])
FROM [staging].[ora_escape]
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping
 ON value_chain_cd = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
LEFT OUTER JOIN datamart.dim_alias_mapping modelmapping
 ON [progam_nm] = modelmapping.alias_name and modelmapping.category = 'model'
WHERE 
([progam_nm] IS NULL OR [progam_nm] IN 
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_escape]' AND column_name='program_nm' AND operation='In'))
OR ([value_chain_cd] IS NULL OR [value_chain_cd] IN 
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ora_escape]' AND column_name='value_chain_cd'  AND operation='In'))
OR
(CONVERT(DATE,[date_written])>@max_date)
 FOR XML PATH('node'), ROOT ('datamart.fact_escape'));
 
INSERT INTO [datamart].[bad_table]
(
table_name
,run_date
,records
)
VALUES
(
'datamart.fact_escape'
,@run_date
,@bad_records);
 --Bad records inserting end

--Start inserting [datamart].[fact_noe]
INSERT INTO [datamart].[fact_noe]
(
[ecd]
,[date_written]
,[date_closed]
,[noe_sdr_nar_nod]
,[noe_sdr]

,[status]
,[bu_supplier]
,[customer]
,[owner]
,[assigned_to]

,[description_of_condition]
,[comments_disposition]
,[rcca_summary]
,[previous_occurrence]
,[units_affected]

,[rcca_initiated]
,[rcca_completed]
,[safety_of_flight]
,[tracking]
,[cust_ref]

,[Z7]
,[aftermarke_groups_affected]
,[qn_number]
,[qn_initiation_date]
,[vendor_code]

,[pns]
,[disposition]
,[boeing_mrb_appendix_C_authority_used]
,[can]
,[can_initiated]

,[can_action_plans_sent]
,[can_closed]
,[ecd_of_ca]
,[z7_close_with_executive_summary]
,[customer_closure_notice_received]

,[item_type]
,[path]
,[models]
,[created_date]
)
SELECT A.[ecd]
,CONVERT(DATE,A.[date])
,A.[date_closed]
,A.[noe_sdr_nar_nod]
,A.[noe_sdr]

,A.[status]
,A.[bu_supplier]
,A.[customer]
,A.[owner]
,A.[assigned_to]

,A.[description_of_condition]
,A.[comments_disposition]
,A.[rcca_summary]
,A.[previous_occurrence]
,A.[units_affected]

,A.[rcca_initiated]
,A.[rcca_completed]
,A.[safety_of_flight]
,A.[tracking]
,A.[cust_ref]

,A.[Z7]
,A.[aftermarke_groups_affected]
,A.[qn_number]
,A.[qn_initiation_date]
,A.[vendor_code]

,A.[pns]
,A.[disposition]
,A.[boeing_mrb_appendix_C_authority_used]
,A.[can]
,A.[can_initiated]

,A.[can_action_plans_sent]
,A.[can_closed]
,A.[ecd_of_ca]
,A.[z7_close_with_executive_summary]
,A.[customer_closure_notice_received]

,A.[item_type]
,A.[path]
,Split.a.value('.', 'VARCHAR(50)') AS String  
,A.[load_date]
FROM  (SELECT 
[ecd]
,[date]
,[date_closed]
,[noe_sdr_nar_nod]
,[noe_sdr]

,[status]
,[bu_supplier]
,[customer]
,[owner]
,[assigned_to]

,[description_of_condition]
,[comments_disposition]
,[rcca_summary]
,[previous_occurrence]
,[units_affected]

,[rcca_initiated]
,[rcca_completed]
,[safety_of_flight]
,[tracking]
,[cust_ref]

,[Z7]
,[aftermarke_groups_affected]
,[qn_number]
,[qn_initiation_date]
,[vendor_code]

,[pns]
,[disposition]
,[boeing_mrb_appendix_C_authority_used]
,[can]
,[can_initiated]

,[can_action_plans_sent]
,[can_closed]
,[ecd_of_ca]
,[z7_close_with_executive_summary]
,[customer_closure_notice_received]

,[item_type]
,[path]
,CAST ('<M>' + REPLACE(COALESCE(aliasprogram.actual_name,noe.[models]), ';#', '</M><M>') + '</M>' AS XML) AS String  
,[load_date]
FROM  staging.ftp_noe noe 
INNER JOIN datamart.dim_calendar cal 
 ON noe.[date]=cal.date_key
LEFT OUTER JOIN datamart.dim_alias_mapping aliasprogram
 ON noe.[models] = aliasprogram.alias_name AND aliasprogram.category = 'model'
WHERE models NOT IN
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ftp_noe]' AND column_name='models' AND operation='In')
 AND ([date]>=DATEADD(yy,-1,DATEADD(yy,DATEDIFF(yy,0,GETDATE()),0)) AND CONVERT(DATE,[date])<=@max_date)
) AS A CROSS APPLY String.nodes ('/M') AS Split(a); 
--Ends inserting [datamart].[fact_noe]

--Bad records inserting start
SET @run_date=GETDATE();
SET @bad_records=(SELECT [load_date]
    
      ,[ecd]
      ,[date]
      ,[date_closed]
      ,[noe_sdr_nar_nod]
      ,[noe_sdr]
      ,[status]
      ,[bu_supplier]
      ,[customer]
      ,[owner]
      ,[models]
      ,[assigned_to]
      ,[description_of_condition]
      ,[comments_disposition]
      ,[rcca_summary]
      ,[previous_occurrence]
      ,[units_affected]
      ,[rcca_initiated]
      ,[rcca_completed]
      ,[safety_of_flight]
      ,[tracking]
      ,[cust_ref]
      ,[Z7]
      ,[aftermarke_groups_affected]
      ,[qn_number]
      ,[qn_initiation_date]
      ,[vendor_code]
      ,[pns]
      ,[disposition]
      ,[boeing_mrb_appendix_C_authority_used]
      ,[can]
      ,[can_initiated]
      ,[can_action_plans_sent]
      ,[can_closed]
      ,[ecd_of_ca]
      ,[z7_close_with_executive_summary]
      ,[customer_closure_notice_received]
      ,[item_type]
      ,[path] FROM staging.ftp_noe noe 
INNER JOIN datamart.dim_calendar cal 
 ON noe.[date]=cal.date_key
WHERE (models IS NULL OR models IN
 (SELECT distinct column_value FROM [datamart].[dim_cleansing_rule] WHERE table_name='[staging].[ftp_noe]' AND column_name='models' AND operation='In'))
 OR CONVERT(DATE,[date])>@max_date
FOR XML PATH('node'), ROOT ('datamart.fact_noe'))

INSERT INTO [datamart].[bad_table]
(
table_name
,run_date
,records
)
VALUES
(
'datamart.fact_noe'
,@run_date
,@bad_records
);
--Bad records inserting end

--Start inserting [datamart].[dim_srr_target]
INSERT INTO [datamart].[dim_srr_target]( 
[model]
,[heading]
,[value_chain]
,[function]
,[year]
,[date_written]
,[week_no]

,[weekly_srr_target]
,[ytd_srr_target]
,[weekly_gl_target]
,[ytd_gl_target]
,[location]
,[createddate]
      
) 
SELECT COALESCE(aliasprogram.actual_name,[model]) as [model]
,[heading]
,[value_chain]
,[function]
,CONVERT(INT,[year])
,CONVERT(DATE,[week])
,[week_no]

,[weekly_srr_target]
,[ytd_srr_target]
,[weekly_gl_target]
,[ytd_gl_target]
,[location]
,[load_date]
FROM [staging].[ftp_srr_target] srr  
INNER JOIN datamart.dim_calendar cal 
 ON srr.[week]=cal.date_key
LEFT OUTER JOIN datamart.dim_alias_mapping aliasprogram
 ON srr.model = aliasprogram.alias_name AND aliasprogram.category = 'model_target'
WHERE heading<>'Total'
--Ends inserting [datamart].[dim_srr_target]

--Start inserting [datamart].[dim_escape_target]
INSERT INTO datamart.dim_escape_target(
[model]
,[heading]
,[value_chain]
,[function]
,[year]
,[date_written]
,[week_no]

,[weekly_escape_target]
,[ytd_escape_target]
,[location]
,[createddate]
)
SELECT COALESCE(aliasprogram.actual_name,[model]) as [model]
,[heading]
,[value_chain]
,[function]
,CONVERT(INT,[year])
,CONVERT(DATE,[week])
,[week_no]

,[weekly_escape_target]
,[ytd_escape_target]
,[location]
,[load_date]
FROM [staging].[ftp_escape_target] esc 
INNER JOIN datamart.dim_calendar cal
 ON esc.[week]=cal.date_key
LEFT OUTER JOIN datamart.dim_alias_mapping aliasprogram
 ON esc.[model] = aliasprogram.alias_name and aliasprogram.category = 'model_target'
WHERE heading<>'Total';

--Ends inserting [datamart].[dim_escape_target]



--Start Prestwick SRR YTD(For Top Drivers) insert
INSERT INTO  [datamart].[fact_srr_prestwick]
(
       [program]
      ,[value_chain]
      ,[spirit_week]
      ,[location]
      ,[date_written]

      ,[created_date]
      ,[feature_descrepancy]
	  ,[total_srr_dollar]
	  ,[spirit_year]
)
SELECT [program]
      ,[value_chain]
	  ,cal.[spirit_week]
      ,[location]
      ,[date_written]
	  
      ,[load_date]
      ,REPLACE(LTRIM(RTRIM([feature_descrepancy])),'-','')
      ,[total_srr_dollar]
	  ,cal.[spirit_year]

  FROM [staging].[ftp_srr_prestwick] srr
 INNER JOIN datamart.dim_calendar cal ON srr.date_written=cal.date_key
 WHERE CONVERT(DATE,[date_written])<=@max_date
--End Prestwick SRR YTD(For Top Drivers) insert  

--Start Prestwick escapes YTD(For Top Drivers) insert 
INSERT INTO [datamart].[fact_escape_prestwick]
(	   [program]
      ,[value_chain]
      ,[ca_count]
      ,[date_written]
      ,[escape_amount_actual]

      ,[feature_description]
      ,[discrepancy_description]
      ,[location]
      ,[load_date]
      ,[feature_descrepancy]

	  ,[spirit_year]
	  ,[spirit_week]
)
SELECT [program]
      ,[value_chain]
      ,[ca_count]
      ,[date_written]
      ,[escape_amount_actual]

      ,[feature_description]
      ,[discrepancy_description]
      ,[location]
      ,[load_date]
	  ,REPLACE(LTRIM(RTRIM([feature_descrepancy])),'-','')
      
	  ,cal.[spirit_year]
	  ,cal.[spirit_week]
  FROM [staging].[ftp_escape_prestwick] esc
  INNER JOIN datamart.dim_calendar cal ON esc.date_written=cal.date_key
 WHERE CONVERT(DATE,[date_written])<=@max_date
--End Prestwick escapes YTD(For Top Drivers) insert 

COMMIT TRAN datamart_quality;
END TRY
BEGIN CATCH;


ROLLBACK TRAN datamart_quality


SELECT  
	@errorprocedure='[datamart].[proc_cleansing_quality]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate

RETURN -1;
END CATCH;
RETURN 0;

END



GO


/*
Usage : This SP is used to load data from unstructured format table to structured format table of greenline costs data
Creator/Editor  #Date			#Comments
Rammanohar	# 2017-10-23		# Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_quality_greenlinecosts')
 DROP PROC [datamart].[proc_cleansing_quality_greenlinecosts]
GO


CREATE PROC [datamart].[proc_cleansing_quality_greenlinecosts]
AS
BEGIN
/****************************************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Cleansing and Inserting Greenlinecosts data into actual staging tables from Staging  
******************************************************************************************************************************/

SET NOCOUNT ON;

BEGIN TRAN datamart_quality
DECLARE @errorprocedure VARCHAR(50), --used to store procedure name
		@errorline INT, -- used to call RAISEERROR
		@errornumber INT, -- used to call RAISEERROR
		@errorseverity INT, -- used to call RAISEERROR
		@errorstate INT,  -- used to call RAISEERROR
		@errormessage VARCHAR(2048),  -- used to call RAISEERROR
		@source_load_date DATE,  --used to load file placed date
		@spirit_week INT,  --used to load spirit_week
		@run_date DATETIME, -- used to hold the bad record loading datetime of datamart tables
		@spirit_year INT; -- used to load year

BEGIN TRY;



SELECT @source_load_date=DATEADD(DD,-1,[week_date]) FROM [staging].[ftp_greenlinecosts];
SELECT @spirit_week=spirit_week FROM datamart.dim_calendar WHERE date_key=@source_load_date;
SET @spirit_year= YEAR(@source_load_date) ;

UPDATE staging.ftp_total_srr_rollup SET spirit_week_no=@spirit_week,yr=@spirit_year;

DELETE FROM [datamart].[fact_greenlinecosts] 
WHERE spirit_week=@spirit_week AND spirit_year=@spirit_year;


--Start inserting datamart.fact_greenlinecosts
INSERT INTO [datamart].[fact_greenlinecosts]
(	   [program]
      ,[value_chain]
      ,[spirit_week]
      ,[spirit_year]
      ,[weeklyactuals]

      ,[headers]
      ,[actualcummulativeytd]
      ,[created_date]
      )
SELECT program
,value_chain
,@spirit_week AS spirit_week
,@spirit_year AS spirit_year
,0 AS weeklyactuals

,'Greenline costs' AS headers
,ISNULL(SUM(gl_dollar),0) AS actualcummulativeytd
,ISNULL(load_date,getdate()) AS [created_date]
FROM staging.ftp_total_srr_rollup(NOLOCK) 
--INNER JOIN datamart.dim_calendar cal ON spirit_week_no=cal.spirit_week AND yr=cal.spirit_year
GROUP BY program
,value_chain
,load_date

--Ends inserting datamart.fact_greenlinecosts
--Start updating datamart.fact_greenlinecosts current week weeklyactuals
;WITH cte1 AS
(
SELECT program prg,value_chain vc,actualcummulativeytd acytd
FROM [datamart].[fact_greenlinecosts] 
WHERE
spirit_year = (SELECT TOP 1 yr FROM staging.ftp_total_srr_rollup)
and spirit_week = (SELECT TOP 1 spirit_week_no FROM staging.ftp_total_srr_rollup) - 1
)


UPDATE [datamart].[fact_greenlinecosts] 
SET weeklyactuals = actualcummulativeytd - acytd
FROM cte1
WHERE 
 program = prg
and value_chain = vc
and spirit_year = (SELECT TOP 1 yr FROM staging.ftp_total_srr_rollup)
and spirit_week = (SELECT TOP 1 spirit_week_no FROM staging.ftp_total_srr_rollup)

--Ends updating datamart.fact_greenlinecosts current week weeklyactuals

COMMIT TRAN datamart_quality;
END TRY
BEGIN CATCH;

--PRINT 'Unexpected error occurred!'
ROLLBACK TRAN datamart_quality
--RETURN 1


SELECT  
	@errorprocedure='[datamart].[proc_cleansing_quality_greenlinecosts]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
----RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0;

END



GO


/*
Usage : This SP is used to load data from unstructured format table to structured format table of Malaysia data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_quality_malaysia')
 DROP PROC [datamart].[proc_cleansing_quality_malaysia]
GO

CREATE PROC [datamart].[proc_cleansing_quality_malaysia]
AS
BEGIN
/****************************************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Cleansing and Inserting Malaysia data into actual staging tables from Staging  
******************************************************************************************************************************/

SET NOCOUNT ON;

BEGIN TRAN datamart_quality
DECLARE @errorprocedure VARCHAR(50), --used to store procedure name
		@errorline INT, -- used to call RAISEERROR
		@errornumber INT, -- used to call RAISEERROR
		@errorseverity INT, -- used to call RAISEERROR
		@errorstate INT,  -- used to call RAISEERROR
		@errormessage VARCHAR(2048),  -- used to call RAISEERROR
		@date_written DATE, --To load last week max date
		@spirit_week INT, --To load spirit week
		@spirit_year INT; --To load spirit year

SET @spirit_week=(SELECT DISTINCT spirit_week FROM staging.ftp_malaysia_srr_escape_noe(NOLOCK));
SET @spirit_year=(SELECT CASE WHEN (@spirit_week>=50 AND MONTH(GETDATE()-1)=1) THEN YEAR(GETDATE()-1)-1 ELSE YEAR(GETDATE()-1) END)
SELECT @date_written=MAX(date_key) FROM datamart.dim_calendar(NOLOCK) WHERE spirit_week=@spirit_week AND spirit_year=@spirit_year;

BEGIN TRY;

DELETE FROM [datamart].[fact_malaysia_ceo_metrics_master] WHERE spirit_week=@spirit_week AND spirit_year=@spirit_year;

;WITH CTE1 AS
(
SELECT DISTINCT @spirit_week AS spirit_week
,@spirit_year AS spirit_year
,dim.program AS model 
,COALESCE(aliasmapping.actual_name,mal.value_chain) as [value_chain_cd]
,mal.weekly_actual AS defect_quantiy
,REPLACE(mal.attribute,'Total Defect Count','srr')  AS attribute 
FROM staging.ftp_malaysia_srr_escape_noe(NOLOCK) mal 
INNER JOIN [datamart].[dim_sno_program_mapping_malaysia](NOLOCK) dim ON mal.pk_id=dim.sno
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping 
 ON mal.value_chain = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
WHERE attribute = 'Total Defect Count' AND dim.program IS NOT NULL
),
CTE2 AS
(
SELECT DISTINCT @date_written AS date_written
,'Malaysia' AS location
,@spirit_week AS spirit_week
,@spirit_year AS spirit_year
,dim.program

,COALESCE(aliasmapping.actual_name,mal.value_chain) as [value_chain]
,mal.weekly_actual AS metric_value
,(CASE WHEN mal.attribute='Total SRR $$' THEN 'srr'
WHEN mal.attribute='Total Events' THEN 'escape'
WHEN mal.attribute='Total NoE''s' THEN 'noe'
END) AS attribute 
FROM staging.ftp_malaysia_srr_escape_noe(NOLOCK) mal 
INNER JOIN [datamart].[dim_sno_program_mapping_malaysia](NOLOCK) dim ON mal.pk_id=dim.sno
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping 
 ON mal.value_chain = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
WHERE attribute IN('Total SRR $$','Total Events','Total NoE''s') AND dim.program IS NOT NULL
)
INSERT INTO [datamart].[fact_malaysia_ceo_metrics_master]
(
date_written
,location
,spirit_week
,spirit_year
,program

,value_chain
,metric_value
,attribute
,defect_qty
)
SELECT DISTINCT  CTE2.date_written
,CTE2.location
,CTE2.spirit_week
,CTE2.spirit_year
,CTE2.program

,CTE2.[value_chain]
,CTE2.metric_value
,CTE2.attribute
,ISNULL(CTE1.defect_quantiy,0) AS defect_quantiy

FROM CTE2 LEFT JOIN CTE1 
ON  CTE2.program=CTE1.model AND CTE2.spirit_week=CTE1.spirit_week 
AND CTE2.spirit_year=CTE1.spirit_year AND CTE2.attribute=CTE1.attribute


COMMIT TRAN datamart_quality;
END TRY
BEGIN CATCH;

--PRINT 'Unexpected error occurred!'
ROLLBACK TRAN datamart_quality
--RETURN 1


SELECT  
	@errorprocedure='[datamart].[proc_cleansing_quality_malaysia]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
----RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0;

END



GO


/*
Usage : This SP is used to load data from unstructured format table to structured format table of Prestwick data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_cleansing_quality_prestwick')
 DROP PROC [datamart].[proc_cleansing_quality_prestwick]
GO


CREATE PROC [datamart].[proc_cleansing_quality_prestwick]
AS
BEGIN
/*************************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Cleansing and Inserting data into Datamart tables from Staging  
**************************************************************************************************************/

SET NOCOUNT ON;

BEGIN TRAN datamart_quality
DECLARE @errorprocedure VARCHAR(50), --used to store procedure name
		@errorline INT, -- used to call RAISEERROR
		@errornumber INT, -- used to call RAISEERROR
		@errorseverity INT, -- used to call RAISEERROR
		@errorstate INT,  -- used to call RAISEERROR
		@errormessage VARCHAR(2048),  -- used to call RAISEERROR
		@run_date datetime, -- used to hold the bad record loading datetime of datamart tables
		@bad_records XML, -- used to capture bad records
		@week int,		--To load the current spirit week
		@spirit_year int, --To load the current spirit year
		@max_date date,  --To load the last week maximum date
		@date_written date; -- To load lastweek end date
		

BEGIN TRY;


--Prestwick load starts
SET @week=(SELECT DISTINCT spirit_week FROM staging.ftp_prestwick_srr_escape_noe(NOLOCK));
SET @spirit_year=(SELECT CASE WHEN (@week>=50 AND MONTH(GETDATE()-1)=1) THEN YEAR(GETDATE()-1)-1 ELSE YEAR(GETDATE()-1) END)
SELECT @date_written=MAX(date_key) FROM datamart.dim_calendar(NOLOCK) WHERE spirit_week=@week AND spirit_year=@spirit_year;

DELETE FROM datamart.fact_prestwick_ceo_metrics_master WHERE spirit_week=@week AND spirit_year=@spirit_year;

;WITH CTE1 AS
(
SELECT DISTINCT @week AS spirit_week
,@spirit_year AS spirit_year
,dim.program AS model 
,COALESCE(aliasmapping.actual_name,mal.value_chain) as [value_chain_cd]
,mal.weekly_actual AS defect_quantiy
,REPLACE(mal.attribute,'Total Defect Count','srr')  AS attribute 
FROM staging.ftp_prestwick_srr_escape_noe(NOLOCK) mal 
INNER JOIN [datamart].[dim_sno_program_mapping_prestwick](NOLOCK) dim ON mal.pk_id=dim.sno
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping 
 ON mal.value_chain = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
WHERE attribute = 'Total Defect Count' AND dim.program IS NOT NULL
),
CTE2 AS
(
SELECT DISTINCT @date_written AS date_written
,'Prestwick' AS location
,@week AS spirit_week
,@spirit_year AS spirit_year
,dim.program

,COALESCE(aliasmapping.actual_name,mal.value_chain) as [value_chain]
,mal.weekly_actual AS metric_value
,(CASE WHEN mal.attribute='Total SRR $$' THEN 'srr'
WHEN mal.attribute='Total Events' THEN 'escape'
WHEN mal.attribute='Total NoE''s' THEN 'noe'
END) AS attribute 
FROM staging.ftp_prestwick_srr_escape_noe(NOLOCK) mal 
INNER JOIN [datamart].[dim_sno_program_mapping_prestwick](NOLOCK) dim ON mal.pk_id=dim.sno
LEFT OUTER JOIN datamart.dim_alias_mapping aliasmapping 
 ON mal.value_chain = aliasmapping.alias_name and aliasmapping.category = 'valuechain'
WHERE attribute IN('Total SRR $$','Total Events','Total NoE''s') AND dim.program IS NOT NULL
)
INSERT INTO datamart.fact_prestwick_ceo_metrics_master
(
date_written
,location
,spirit_week
,spirit_year
,program

,value_chain
,metric_value
,attribute
,defect_qty
)
SELECT DISTINCT  CTE2.date_written
,CTE2.location
,CTE2.spirit_week
,CTE2.spirit_year
,CTE2.program

,CTE2.[value_chain]
,CTE2.metric_value
,CTE2.attribute
,ISNULL(CTE1.defect_quantiy,0) AS defect_quantiy

FROM CTE2 LEFT JOIN CTE1 
ON  CTE2.program=CTE1.model AND CTE2.spirit_week=CTE1.spirit_week 
AND CTE2.spirit_year=CTE1.spirit_year AND CTE2.attribute=CTE1.attribute

--Prestwick load ends

COMMIT TRAN datamart_quality;
END TRY
BEGIN CATCH;

--PRINT 'Unexpected error occurred!'
ROLLBACK TRAN datamart_quality
--RETURN 1


SELECT  
	@errorprocedure='[datamart].[proc_cleansing_quality_prestwick]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
----RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0;

END



GO



IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_fabrication_summary')
 DROP PROC datamart.proc_generate_fabrication_summary
GO

CREATE PROC [datamart].[proc_generate_fabrication_summary]
AS

--EXEC [datamart].[proc_generate_fabrication_summary]
/******************************************************************************************************************
Created/Modified By		Created/Modified Date	    Purpose
Kanak					2017-Oct-11		    		 Loading reporting tables
******************************************************************************************************************/
BEGIN
SET NOCOUNT ON;


TRUNCATE TABLE [reporting].[fabrication_summary]
TRUNCATE TABLE [reporting].[fabrication_staffing_summary]


INSERT INTO [reporting].[fabrication_summary]
	(
		rpt_week_end_dt, rpt_year, rpt_week, category, sub_category, flg_curr_week, wkl_qlty_srr_actual, wkl_qlty_srr_planned, wkl_qlty_srr_variance, 
		ytd_qlty_srr_actual, ytd_qlty_srr_planned, ytd_qlty_srr_variance, wkl_qlty_srr_touch_pcg_actual, wkl_qlty_srr_touch_pcg_planned, 
		wkl_qlty_srr_touch_pcg_variance, ytd_qlty_srr_touch_pcg_actual, ytd_qlty_srr_touch_pcg_planned, ytd_qlty_srr_touch_pcg_variance, 
		wkl_qlty_escap_to_assy_actual, wkl_qlty_escap_to_assy_planned, wkl_qlty_escap_to_assy_variance, ytd_qlty_escap_to_assy_actual, 
		ytd_qlty_escap_to_assy_planned, ytd_qlty_escap_to_assy_variance, wkl_qlty_escap_to_cust_actual, wkl_qlty_escap_to_cust_planned, 
		wkl_qlty_escap_to_cust_variance, ytd_qlty_escap_to_cust_actual, ytd_qlty_escap_to_cust_planned, ytd_qlty_escap_to_cust_variance, 
		wkl_rlzn_pcg_actual, wkl_rlzn_pcg_planned, wkl_rlzn_pcg_variance, ytd_rlzn_pcg_actual, ytd_rlzn_pcg_planned, ytd_rlzn_pcg_variance, 
		wkl_stdhrs_earned_actual, wkl_stdhrs_earned_planned, wkl_stdhrs_earned_variance, ytd_stdhrs_earned_actual, ytd_stdhrs_earned_planned, 
		ytd_stdhrs_earned_variance, wkl_dlvry_kfr_pcg_actual, wkl_dlvry_kfr_pcg_planned, wkl_dlvry_kfr_pcg_variance, ytd_dlvry_kfr_pcg_actual, 
		ytd_dlvry_kfr_pcg_planned, ytd_dlvry_kfr_pcg_variance, wkl_ot_pcg_actual, wkl_ot_pcg_planned, wkl_ot_pcg_variance, ytd_ot_pcg_actual, 
		ytd_ot_pcg_variance, aop_ot_pcg, wkl_hc_assigned_actual, wkl_hc_assigned_planned, wkl_hc_assigned_variance, ytd_hc_assigned_actual, 
		ytd_hc_assigned_planned, ytd_hc_assigned_variance, wkl_hc_doi_pcg_actual, wkl_hc_doi_pcg_planned, wkl_hc_doi_pcg_variance, 
		ytd_hc_doi_pcg_actual, ytd_hc_doi_pcg_planned, ytd_hc_doi_pcg_variance, hc_std_abs_pcg, wkl_hc_abs_pcg_actual, wkl_hc_abs_pcg_variance, 
		ytd_hc_abs_pcg_actual, ytd_hc_abs_pcg_variance, wkl_bhndsch_hrs, wkl_bhndsch_ucl, wkl_bhndsch_to_fnsh_hrs, wkl_bhndsch_to_fnsh_ucl, 
		wkl_hc_effective_actual, wkl_hc_demand, wkl_hc_eff_vs_demand_variance, ytd_hc_effective_actual, ytd_hc_demand, ytd_hc_eff_vs_demand_variance, 
		wkl_stfg_aop_planned
	)
SELECT 
	rpt_week_end_dt ,
	rpt_year ,
	rpt_week ,
	category ,
	sub_category ,
	flg_curr_week ,
	wkl_qlty_srr_actual ,
	wkl_qlty_srr_planned ,
	wkl_qlty_srr_variance = wkl_qlty_srr_actual - wkl_qlty_srr_planned,
	ytd_qlty_srr_actual ,
	ytd_qlty_srr_planned ,
	ytd_qlty_srr_variance = ytd_qlty_srr_actual - ytd_qlty_srr_planned,
	wkl_qlty_srr_touch_pcg_actual ,
	wkl_qlty_srr_touch_pcg_planned ,
	wkl_qlty_srr_touch_pcg_variance =wkl_qlty_srr_touch_pcg_actual - wkl_qlty_srr_touch_pcg_planned,
	ytd_qlty_srr_touch_pcg_actual ,
	ytd_qlty_srr_touch_pcg_planned ,
	ytd_qlty_srr_touch_pcg_variance = ytd_qlty_srr_touch_pcg_actual - ytd_qlty_srr_touch_pcg_planned,
	wkl_qlty_escap_to_assy_actual ,
	wkl_qlty_escap_to_assy_planned ,
	wkl_qlty_escap_to_assy_variance =wkl_qlty_escap_to_assy_actual - wkl_qlty_escap_to_assy_planned,
	ytd_qlty_escap_to_assy_actual ,
	ytd_qlty_escap_to_assy_planned ,
	ytd_qlty_escap_to_assy_variance =ytd_qlty_escap_to_assy_actual - ytd_qlty_escap_to_assy_planned,
	wkl_qlty_escap_to_cust_actual ,
	wkl_qlty_escap_to_cust_planned ,
	wkl_qlty_escap_to_cust_variance =wkl_qlty_escap_to_cust_actual - wkl_qlty_escap_to_cust_planned,
	ytd_qlty_escap_to_cust_actual ,
	ytd_qlty_escap_to_cust_planned ,
	ytd_qlty_escap_to_cust_variance =ytd_qlty_escap_to_cust_actual - ytd_qlty_escap_to_cust_planned,
	wkl_rlzn_pcg_actual ,
	wkl_rlzn_pcg_planned ,
	wkl_rlzn_pcg_variance = wkl_rlzn_pcg_actual - wkl_rlzn_pcg_planned,
	ytd_rlzn_pcg_actual ,
	ytd_rlzn_pcg_planned ,
	ytd_rlzn_pcg_variance = ytd_rlzn_pcg_actual - ytd_rlzn_pcg_planned,
	wkl_stdhrs_earned_actual ,
	wkl_stdhrs_earned_planned ,
	wkl_stdhrs_earned_variance = wkl_stdhrs_earned_actual - wkl_stdhrs_earned_planned,
	ytd_stdhrs_earned_actual ,
	ytd_stdhrs_earned_planned ,
	ytd_stdhrs_earned_variance = ytd_stdhrs_earned_actual - ytd_stdhrs_earned_planned,
	wkl_dlvry_kfr_pcg_actual ,
	wkl_dlvry_kfr_pcg_planned ,
	--wkl_dlvry_kfr_pcg_variance = wkl_dlvry_kfr_pcg_actual - wkl_dlvry_kfr_pcg_planned,
	wkl_dlvry_kfr_pcg_variance = 1 - wkl_dlvry_kfr_pcg_actual,
	ytd_dlvry_kfr_pcg_actual ,
	ytd_dlvry_kfr_pcg_planned ,
	--ytd_dlvry_kfr_pcg_variance = ytd_dlvry_kfr_pcg_actual - ytd_dlvry_kfr_pcg_planned,
	ytd_dlvry_kfr_pcg_variance = ytd_dlvry_kfr_pcg_planned - ytd_dlvry_kfr_pcg_actual,
	wkl_ot_pcg_actual ,
	wkl_ot_pcg_planned ,
	wkl_ot_pcg_variance = wkl_ot_pcg_actual - wkl_ot_pcg_planned,
	ytd_ot_pcg_actual ,
	ytd_ot_pcg_variance = ytd_ot_pcg_actual - aop_ot_pcg ,
	aop_ot_pcg ,
	wkl_hc_assigned_actual ,
	wkl_hc_assigned_planned ,
	wkl_hc_assigned_variance = wkl_hc_assigned_actual - wkl_hc_assigned_planned,
	ytd_hc_assigned_actual ,
	ytd_hc_assigned_planned ,
	ytd_hc_assigned_variance = ytd_hc_assigned_actual - ytd_hc_assigned_planned,
	wkl_hc_doi_pcg_actual ,
	wkl_hc_doi_pcg_planned ,
	wkl_hc_doi_pcg_variance = wkl_hc_doi_pcg_actual - wkl_hc_doi_pcg_planned,
	ytd_hc_doi_pcg_actual ,
	ytd_hc_doi_pcg_planned ,
	ytd_hc_doi_pcg_variance =ytd_hc_doi_pcg_actual - ytd_hc_doi_pcg_planned,
	hc_std_abs_pcg ,
	wkl_hc_abs_pcg_actual ,
	wkl_hc_abs_pcg_variance =wkl_hc_abs_pcg_actual - hc_std_abs_pcg,
	ytd_hc_abs_pcg_actual ,
	ytd_hc_abs_pcg_variance = ytd_hc_abs_pcg_actual - hc_std_abs_pcg,
	wkl_bhndsch_hrs ,
	wkl_bhndsch_ucl ,
	wkl_bhndsch_to_fnsh_hrs ,
	wkl_bhndsch_to_fnsh_ucl ,
	wkl_hc_effective_actual ,
	wkl_hc_demand ,
	wkl_hc_eff_vs_demand_variance = wkl_hc_demand - wkl_hc_effective_actual,
	ytd_hc_effective_actual ,
	ytd_hc_demand ,
	--ytd_hc_eff_vs_demand_variance = ytd_hc_demand - ytd_hc_effective_actual ,
	NULL,
	wkl_stfg_aop_planned
FROM  
	[datamart].[fact_fab_summary]

----------------------------------------------------------------------------------------------

INSERT INTO [reporting].[fabrication_staffing_summary]
SELECT 
	rpt_week_end_dt,
	rpt_year,
	rpt_week,
	category,
	sub_category,
	flg_curr_week,
	wkl_hc_assigned_actual,
	wkl_hc_demand,
	wkl_hc_effective_actual,

	-- Fabrication Scheduled Hours
	wkl_stdhrs_earned_actual ,
	wkl_stdhrs_earned_planned,

	-- Fabrication Internal Behind schedules
	wkl_bhndsch_hrs ,
	wkl_bhndsch_ucl ,
	wkl_bhndsch_to_fnsh_hrs ,
	wkl_bhndsch_to_fnsh_ucl ,
 
	-- Fabrication Realization & SRR% Touch
	wkl_rlzn_pcg_actual ,
	wkl_rlzn_pcg_planned ,
	ytd_rlzn_pcg_actual ,
	ytd_qlty_srr_touch_pcg_actual ,
	ytd_qlty_srr_touch_pcg_planned ,

	wkl_stfg_aop_planned,
	'Actual' as OT_Metrics,
	wkl_ot_pcg_actual as OT_Values
FROM 
	reporting.fabrication_summary

UNION

SELECT 
	rpt_week_end_dt,
	rpt_year,
	rpt_week,
	category,
	sub_category,
	flg_curr_week,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	'Planned' as OT_Metrics,
	aop_ot_pcg as OT_Values
FROM 
	reporting.fabrication_summary



UPDATE reporting.refresh_log
SET 
	reporting_period = week_str,
	last_refresh_date_time = GETDATE() ,
	week_no = spirit_week
FROM
	datamart.vw_dim_calendar
WHERE 
	is_current_week = 1
	and report_name = 'Fabrication'

END

GO

IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_facility_downtime_target')
DROP PROC datamart.proc_generate_facility_downtime_target
GO

CREATE PROC datamart.proc_generate_facility_downtime_target
AS
BEGIN

/*
Usage : To find out downtime target for next year from previous year (Facilities)

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-04 # Initial creation
*/


;
WITH cte_downtime_target as
(
SELECT 
cal.spirit_year
,COALESCE(almap.actual_name,dc.busunit) as busunit
,COALESCE(almap2.actual_name,dc.siteid) as location
,CASE WHEN dc.wo_priority < 4 THEN 3 ELSE dc.wo_priority END as priority
,dc.downtime

FROM datamart.fact_downtime_dailyclocking dc

INNER JOIN datamart.dim_calendar cal
 ON cal.date_key = dc.change_date 

LEFT OUTER JOIN datamart.dim_alias_mapping as almap
 ON dc.busunit = almap.alias_name 
 AND almap.category = 'business_unit'

LEFT OUTER JOIN datamart.dim_alias_mapping as almap2
 ON dc.siteid = almap2.alias_name 
 AND almap2.category = 'location'
)

,
cte_downtime_target2 as
(
SELECT
spirit_year
,busunit
,location
,priority
,SUM(downtime) as downtime

FROM cte_downtime_target

GROUP BY
spirit_year
,busunit
,location
,priority
)

-- INSERT INTO datamart.dim_downtime_target
-- (
-- spirit_year
-- ,location
-- ,business_unit
-- ,asset_priority
-- ,total_downtime_previous_year

-- ,improvement_pcg
-- ,downtime_target
-- )

SELECT 

c1.spirit_year + 1
,c1.location
,c1.busunit
,c1.priority
,c1.downtime

,0.05
,(c1.downtime/52) - (c1.downtime/52) * 0.05 as downtime_target_per_week

FROM cte_downtime_target2 c1

END

GO

IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_facility_summary')
DROP PROC datamart.proc_generate_facility_summary
GO

CREATE PROC datamart.proc_generate_facility_summary
AS
BEGIN

/*
Usage : Loading reporting table for facilities from all datamart tables

Creator/Editor #Date #Comments
Prakhar Shrivastava # 2017-06-21 # Initial creation
Pratheesh N # 2017-10-20 # added overtime changes with new table
*/

SET NOCOUNT ON;

--BEGIN TRAN trn_generate_facility_summary;

DECLARE 

@errorline INT --used to call RAISEERROR
,@errornumber INT --used to call RAISEERROR
,@errorseverity INT --used to call RAISEERROR
,@errorstate INT  --used to call RAISEERROR
,@errormessage VARCHAR(2048) --used to call RAISEERROR

,@errorflag BIT
,@startdate DATE
,@maxdate DATE

--BEGIN TRY;

TRUNCATE TABLE reporting.facility_summary

SELECT @maxdate = max(week_end_date)
FROM datamart.vw_dim_calendar
WHERE week_end_date < getdate ()
 AND is_current_week = 1

-- Starts insert of quality attribute # scrap/rr

INSERT INTO reporting.facility_summary
(
 spirit_year
,spirit_week
,date_written
,program
,location

,rr_amount_actual
,scrap_amount_actual
,attribute
,value_chain
,month_no

,month_name
,week_str
)

SELECT
 cal.spirit_year 
,cal.spirit_week
,srr.dtwritten
,srr.model_ist3
,loc.location_name

,defect_dollars as rr_amount_actual
,scrap_dollars as scrap_amount_actual
,'quality'  as attribute
,srr.value_chain
,cal.spirit_mnth

,Left(cal.spirit_mnth_name,3)
,v1.week_str

FROM datamart.fact_srr_facility srr
 
INNER JOIN datamart.dim_calendar cal
 ON cal.date_key = srr.dtwritten
 
INNER JOIN datamart.vw_dim_calendar v1
 ON cal.spirit_week = v1.spirit_week
 AND cal.spirit_year = v1.spirit_year

LEFT OUTER JOIN datamart.dim_location loc
 ON left(srr.mgcode,2) = loc.code

-- Ends insert of quality attribute # scrap/rr

-- Starts insert of quality attribute # reduction target

INSERT INTO reporting.facility_summary
(

spirit_year
,spirit_week
,date_written
,location
,rr_amount_target

,scrap_amount_target
,rr_reduction_target_pcg
,scrap_reduction_target_pcg
,attribute
,program

,month_no
,month_name
,week_str
)


SELECT
 rt.spirit_year
,cal.spirit_week
,cal.week_end_date
,rt.location
,rt.rr_amount_target_per_unit

,rt.scrap_amount_target_per_unit
,rt.rr_amount_target_pcg
,rt.scrap_amount_target_pcg
,'Quality' as attribute
,rt.program

,cal.spirit_mnth
,Left(cal.spirit_mnth_name,3)
,cal.week_str
 
FROM datamart.dim_scrap_rr_reduction_target as rt

INNER  JOIN datamart.vw_dim_calendar  cal
 ON cal.spirit_year = rt.spirit_year 
 
WHERE cal.week_end_date <= @maxdate

-- Ends insert of quality attribute # reduction target


-- Starts insert of quality attribute # unit

;
WITH cte1 as
(
SELECT 
t1.location
,t1.program
--finding mid of the month to avoid spirit year change for Jan & Dec
,dateadd(day,14,t1.weekenddate) as month_mid_date
,t1.units

FROM datamart.fact_units_facility t1
)

,
cte2 as
(
SELECT 
c1.location
,c1.program
,c1.units
,c1.month_mid_date
,t1.spirit_year

,t1.spirit_week
,t1.spirit_mnth
,left(t1.spirit_mnth_name,3) spirit_mnth_name
,v1.week_str

FROM cte1 c1

INNER JOIN datamart.dim_calendar t1
 ON c1.month_mid_date = t1.date_key
 
INNER JOIN datamart.vw_dim_calendar v1
 ON t1.spirit_week = v1.spirit_week
 AND t1.spirit_year = v1.spirit_year
)

INSERT INTO reporting.facility_summary
(
spirit_year
,spirit_week
,date_written
,unit
,attribute

,program
,location
,month_no
,month_name
,week_str
)

SELECT
 c2.spirit_year
,c2.spirit_week
,c2.month_mid_date
,c2.units
,'quality'

,c2.program
,COALESCE(a.actual_name, c2.location)
,c2.spirit_mnth
,Left(c2.spirit_mnth_name,3)
,c2.week_str

FROM cte2 c2
LEFT OUTER JOIN datamart.dim_alias_mapping a 
 ON c2.location = a.alias_name 
 AND a.category = 'location'

-- Ends insert of quality attribute # unit



-- Starts insert of quality attribute # monthly $ per unit

DELETE FROM reporting.facility_summary
WHERE date_written > @maxdate

;
WITH cte1 as
(
SELECT
t1.location
,t1.program
,t1.spirit_year
,t1.month_no
,t1.month_name

,MAX(t1.date_written) as max_date_written
,MAX(t1.spirit_week) as max_spirit_week
,SUM(t1.scrap_amount_actual) monthly_scrap
,SUM(t1.rr_amount_actual) monthly_rr
,SUM(t1.unit) monthly_unit

FROM reporting.facility_summary t1

WHERE t1.attribute = 'quality'

GROUP BY 
t1.location
,t1.program
,t1.spirit_year
,t1.month_no
,t1.month_name
)

INSERT INTO reporting.facility_summary
(
attribute
,spirit_year
,spirit_week
,month_no
,month_name

,date_written
,week_str	
,program
,location
,monthly_rr_per_unit

,monthly_scrap_per_unit
)

SELECT
'quality'
,c1.spirit_year
,c1.max_spirit_week
,c1.month_no
,c1.month_name

,c1.max_date_written
,v1.week_str
,c1.program
,c1.location
,isnull(c1.monthly_rr,0) / nullif(c1.monthly_unit,0) as monthly_rr_per_unit

,isnull(c1.monthly_scrap,0) / nullif(c1.monthly_unit,0) as monthly_scrap_per_unit

FROM cte1 c1

INNER JOIN datamart.vw_dim_calendar v1
 ON c1.spirit_year = v1.spirit_year
 AND c1.max_spirit_week = v1.spirit_week

-- Ends insert of quality attribute # monthly $ per unit


-- Starts insert of utilization attribute # QUAL

INSERT INTO reporting.facility_summary
(
 spirit_year
,spirit_week
,date_written
,manpower_available
,manpower_clocked

,attribute
,business_unit
,effective_hours
,location
,month_no

,month_name
,week_str
)

SELECT
 cal.spirit_year as spirit_year
,cal.spirit_week as spirit_week
,qual.workdate as date_written
,isnull(availablehrs,0) -isnull(modhrs,0) as man_power_available
,regularhrs as man_power_clocked

,'utilization' as attribute
,COALESCE(almap2.actual_name,qual.qualificationid) as  business_unit
,regularhrs/availablehrs *100  AS effectivehours
,COALESCE(almap.actual_name,qual.siteid) as location
,cal.spirit_mnth

,Left(cal.spirit_mnth_name,3)
,v1.week_str

FROM datamart.fact_manpower_utilization qual 

INNER JOIN datamart.dim_calendar cal
 ON cal.date_key = qual.workdate
 
INNER JOIN datamart.vw_dim_calendar v1
 ON cal.spirit_week = v1.spirit_week
 AND cal.spirit_year = v1.spirit_year

LEFT OUTER JOIN datamart.dim_alias_mapping almap
 ON qual.siteid = almap.alias_name
 AND almap.category = 'location'

LEFT OUTER JOIN datamart.dim_alias_mapping almap2
 ON qual.qualificationid = almap2.alias_name
 AND almap2.category = 'business_unit'
 
-- Ends insert of utilization attribute # QUAL


-- Starts insert of utilization attribute # NOA

INSERT INTO reporting.facility_summary
(
 spirit_year
,spirit_week
,date_written
,manpower_clocked_noa
,attribute

,business_unit
,location
,month_no
,month_name
,week_str
)

SELECT  
 cal.spirit_year as spirit_year
,cal.spirit_week as spirit_week
,noa.workdate as date_written
,ISNULL(regularhrs,0) as man_power_noa
,'utilization' as attribute

,COALESCE(almap2.actual_name,noa.qualificationid) as  business_unit
,COALESCE(almap.actual_name,noa.siteid) as location
,cal.spirit_mnth
,Left(cal.spirit_mnth_name,3)
,v1.week_str

FROM  datamart.fact_manpower_utilization_noa noa 

INNER JOIN datamart.dim_calendar cal
 ON cal.date_key = noa.workdate

INNER JOIN datamart.vw_dim_calendar v1
 ON cal.spirit_week = v1.spirit_week
 AND cal.spirit_year = v1.spirit_year

LEFT OUTER JOIN datamart.dim_alias_mapping almap
 ON noa.siteid = almap.alias_name
 AND almap.category = 'location' 

LEFT OUTER JOIN datamart.dim_alias_mapping almap2
 ON noa.qualificationid = almap2.alias_name
 AND almap2.category = 'business_unit'

-- Ends insert of utilization attribute # NOA


--Starts insert of downtime attribute # downtime actual

INSERT INTO reporting.facility_summary
(

spirit_year
,spirit_week
,date_written
,criticality
,attribute

,business_unit
,location
,priority
,downtime_actual
,assetnum

,month_no
,month_name
,week_str
)

SELECT
 cal.spirit_year as spirit_year
,cal.spirit_week as spirit_week
,dc.change_date as date_written
,(CASE WHEN wo_Priority in (1,2,3) then 'Critical 1-3' 
 WHEN wo_priority = 4 then 'Critical 4'
 WHEN wo_priority = 5 then 'Critical 5'
 ELSE NULL END) as criticality,
'downtime' AS attribute

,COALESCE(almap2.actual_name,dc.busunit) as businessunit
,COALESCE(almap.actual_name,dc.siteid) as location
,dc.wo_priority
,dc.downtime
,dc.assetnum

,cal.spirit_mnth
,Left(cal.spirit_mnth_name,3)
,v1.week_str

FROM datamart.fact_downtime_dailyclocking dc  

INNER JOIN datamart.dim_calendar cal
 ON cal.date_key = dc.change_date

INNER JOIN datamart.vw_dim_calendar v1
 ON cal.spirit_week = v1.spirit_week
 AND cal.spirit_year = v1.spirit_year

LEFT OUTER JOIN datamart.dim_alias_mapping almap
 ON dc.siteid = almap.alias_name 
 AND almap.category = 'location'

LEFT OUTER JOIN datamart.dim_alias_mapping as almap2
 ON dc.busunit = almap2.alias_name 
 AND almap2.category = 'business_unit'

--Ends insert of downtime attribute # downtime actual

--Starts insert of downtime attribute # downtime target

INSERT INTO reporting.facility_summary
(
spirit_year
,spirit_week
,date_written
,month_name
,month_no

,week_str
,business_unit
,location
,priority
,criticality

,downtime_target
,attribute
)

SELECT 
c1.spirit_year
,c2.spirit_week
,c2.week_end_date
,Left(c2.spirit_mnth_name,3)
,c2.spirit_mnth

,c2.week_str
,c1.business_unit
,c1.location
,c1.asset_priority
,CASE WHEN c1.asset_priority in (1,2,3) then 'Critical 1-3' 
 WHEN c1.asset_priority = 4 then 'Critical 4'
 WHEN c1.asset_priority = 5 then 'Critical 5'
 ELSE null End as criticality

,downtime_target
,'downtime'

FROM datamart.dim_downtime_target c1

INNER JOIN datamart.vw_dim_calendar c2
 ON c1.spirit_year  = c2.spirit_year

--Ends insert of downtime attribute # downtime target


--Starts insert of downtime attribute # asset count
;
WITH cte_asset as
(
SELECT
COALESCE(dc.installdate,'2000-01-01') as date_written
,COALESCE(almap2.actual_name,dc.busunit) as business_unit
,COALESCE(almap.actual_name,dc.siteid) as location
,dc.assetnum
,(CASE WHEN dc.priority in (1,2,3) then 'Critical 1-3' 
 WHEN dc.priority = 4 then 'Critical 4'
 WHEN dc.priority = 5 then 'Critical 5'
 ELSE NULL END) as criticality

FROM datamart.fact_asset_count dc  

LEFT OUTER JOIN datamart.dim_alias_mapping almap
 ON dc.siteid = almap.alias_name 
 AND almap.category = 'location'
  
LEFT OUTER JOIN datamart.dim_alias_mapping as almap2
 ON dc.busunit = almap2.alias_name 
 AND almap2.category = 'business_unit'
)
,

cte_asset_week_wise as
(
SELECT
c1.date_written
,c1.business_unit
,c1.location
,c1.assetnum
,c1.criticality

,v1.spirit_year
,v1.spirit_week
,v1.week_end_date
,v1.spirit_mnth
,Left(v1.spirit_mnth_name,3) spirit_mnth_name

,v1.week_str

FROM cte_asset c1

INNER JOIN datamart.vw_dim_calendar v1
 ON c1.date_written <= v1.week_end_date
)

INSERT INTO reporting.facility_summary
( 
 spirit_year
,spirit_week
,date_written
,attribute
,business_unit

,location
,criticality
,asset_count
,month_no
,month_name

,week_str
)

SELECT 	
spirit_year
,spirit_week
,week_end_date
,'downtime'
,business_unit

,location
,criticality
,count(distinct assetnum) as asset_count
,spirit_mnth
,spirit_mnth_name

,week_str

FROM cte_asset_week_wise

GROUP BY 
business_unit
,location
,criticality
,week_end_date
,spirit_year

,spirit_week
,spirit_mnth
,spirit_mnth_name
,week_str

--Ends insert of downtime attribute # asset count

--Starts insert of headcount attribute 

INSERT INTO  reporting.facility_summary
(
 spirit_year
,spirit_week
,date_written
,headcount_actuals
,abs_std_pcg

,total_abs_hours
,std_hours_per_week
,business_unit
,location
,attribute

,month_no
,month_name
,week_str
)

SELECT
 vwcal.spirit_year as spirit_year
,vwcal.spirit_week as spirit_week
,vwcal.week_end_date as date_written
,countofpaycode as head_count_actuals
,t3.standard_abs_pcg as abs_std_pcg

,total_abs_hours
,std_hours_per_week
,ccbm.business_unit as business_unit
,ccbm.location as location
,'headcount' as attribute

,vwcal.spirit_mnth
,Left(vwcal.spirit_mnth_name,3)
,vwcal.week_str

FROM  datamart.fact_absenteeism abst 

INNER JOIN datamart.vw_dim_calendar vwcal
 ON vwcal.period = abst.period

INNER JOIN datamart.dim_cost_center_businessunit_mapping ccbm
 ON abst.cost_center = ccbm.cost_center

INNER JOIN datamart.dim_standard_abs_pcg t3
 ON ccbm.location = t3.location
 AND ccbm.business_unit = t3.business_unit
 AND vwcal.spirit_year = t3.spirit_year

 
--Ends insert of headcount attribute

--Starts insert of overtime attribute
;
WITH cte1 as
(
SELECT
location
,spirit_year
,spirit_week
,cost_center
,actuals as actual_regular_hours

,planned as forecast_regular_hours

FROM datamart.fact_direct_labor_safety
WHERE metric_name = 'Reg Hrs'
)

,
cte2 as
(
SELECT
location
,spirit_year
,spirit_week
,cost_center
,actuals as actual_overtime_hours

,planned as forecast_overtime_hours

FROM datamart.fact_direct_labor_safety
WHERE metric_name = 'OT Hrs'
)

,
cte3 as
(
SELECT
location
,spirit_year
,spirit_week
,cost_center
,actuals as actual_overtime_pcg

,planned as forecast_overtime_pcg

FROM datamart.fact_direct_labor_safety
WHERE metric_name = 'OT%'
)

,
cte4 as
(
SELECT
c1.location
,c1.spirit_year
,c1.spirit_week
,c1.cost_center
,c1.actual_regular_hours

,c1.forecast_regular_hours
,c2.actual_overtime_hours
,c2.forecast_overtime_hours
,c3.actual_overtime_pcg
,c3.forecast_overtime_pcg

FROM cte1 c1

LEFT OUTER JOIN cte2 c2
 ON c1.location = c2.location
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.cost_center = c2.cost_center

LEFT OUTER JOIN cte3 c3
 ON c1.location = c3.location
 AND c1.spirit_year = c3.spirit_year
 AND c1.spirit_week = c3.spirit_week
 AND c1.cost_center = c3.cost_center
)


INSERT INTO reporting.facility_summary
(
spirit_year
,spirit_week
,date_written
,business_unit
,location

,actual_regular_hours
,actual_over_time_hours
,forecast_regular_hours
,forecast_over_time_hours
,attribute

,month_no
,month_name
,week_str
)

SELECT
 ot.spirit_year
,ot.spirit_week
,cal.week_end_date as date_written
,cm.business_unit
,ot.location

,ot.actual_regular_hours
,ot.actual_overtime_hours
,ot.forecast_regular_hours
,ot.forecast_overtime_hours
,'overtime' as attribute

,cal.spirit_mnth
,Left(cal.spirit_mnth_name,3)
,cal.week_str

FROM cte4 ot 

INNER JOIN datamart.vw_dim_calendar cal
 ON ot.spirit_year = cal.spirit_year
 AND ot.spirit_week = cal.spirit_week

INNER JOIN datamart.dim_cost_center_businessunit_mapping cm
 ON ot.cost_center = cm.cost_center

WHERE cm.business_unit in
 (
 '787'
 ,'COMPF'
 ,'Equipment'
 ,'FAB'
 ,'FUSEASSM'
 ,'Legacy'
 ,'STRUT/NACL'
 )

--Ends insert of overtime attribute

--Starts insert of asset attribute # top 10 asset
 
 INSERT INTO reporting.facility_summary
(
 spirit_year
,spirit_week
,date_written
,location
,business_unit

,laborcost
,matlcost
,nonstockcost
,assetnum
,priority

,criticality
,attribute
,month_no
,month_name
,week_str
)

SELECT  
 cal.spirit_year
,cal.spirit_week
,dc.startdate
,COALESCE(almap.actual_name,dc.siteid) as location
,COALESCE(almap2.actual_name,dc.busunit) as busunit


,dc.labor_cost
,dc.stock_cost
,dc.nonstock_cost
,assetnum
,wo_priority

,(CASE WHEN wo_priority in (1,2,3) then 'Critical 1-3' 
 WHEN wo_priority = 4 then 'Critical 4'
 WHEN wo_priority = 5 then 'Critical 5'
 ELSE NULL END) as criticality
,'asset' as attribute
,cal.spirit_mnth
,Left(cal.spirit_mnth_name,3)
,v1.week_str

FROM datamart.fact_asset_cost dc

INNER JOIN datamart.dim_calendar cal
 ON dc.startdate = cal.date_key

INNER JOIN datamart.vw_dim_calendar v1
 ON cal.spirit_year = v1.spirit_year
 AND cal.spirit_week = v1.spirit_week
 
LEFT OUTER JOIN datamart.dim_alias_mapping as almap
 ON dc.siteid = almap.alias_name 
 AND almap.category = 'location'

LEFT OUTER JOIN datamart.dim_alias_mapping as almap2
 ON dc.busunit = almap2.alias_name 
 AND almap2.category = 'business_unit'

--Ends Insert of asset attribute # top 10 asset

--Starts Insert of planned vs reactive attribute

INSERT INTO reporting.facility_summary
(
spirit_year
,spirit_week
,date_written
,business_unit
,location

,planned_maint
,reactive_maint
,target_maint
,reqpri
,attribute

,month_no
,month_name
,week_str
)

SELECT 
cal.spirit_year
,cal.spirit_week
,dc.actfinish
,COALESCE(almap.actual_name,dc.busunit) as busunit
,COALESCE(almap2.actual_name,dc.siteid) as location

,dc.regularhrs as planned_maint
,100 - dc.regularhrs as reactive_maint
,50 as target_maint
,dc.reqpri
,'planned vs reactive' as attribute

,cal.spirit_mnth
,Left(cal.spirit_mnth_name,3)
,v1.week_str

FROM datamart.fact_manpower_plannedvsreactive_maintenance dc

INNER JOIN datamart.dim_calendar cal
 ON dc.actfinish = cal.date_key

INNER JOIN datamart.vw_dim_calendar v1
 ON cal.spirit_year = v1.spirit_year
 AND cal.spirit_week = v1.spirit_week

LEFT OUTER JOIN datamart.dim_alias_mapping as almap
 ON dc.busunit = almap.alias_name 
 AND almap.category = 'business_unit'

LEFT OUTER JOIN datamart.dim_alias_mapping as almap2
 ON dc.siteid = almap2.alias_name 
 AND almap2.category = 'location' 

--Ends Insert of planned vs reactive attribute

--Starts cleaning reporting table as per facility reporting

DELETE FROM reporting.facility_summary
WHERE Location ='Wichita'
AND business_unit NOT IN 
(
'787'
,'COMPF'
,'FAB'
,'FUSEASSM'
,'STRUT/NACL'
)
AND attribute <> 'quality'

DELETE FROM reporting.facility_summary
WHERE Location ='Tulsa'
AND business_unit NOT IN 
(
'787'
,'Legacy'
)
AND attribute <> 'quality'

DELETE FROM reporting.facility_summary
WHERE Location ='Kinston'
AND business_unit NOT IN 
(
'Equipment'
)


DELETE FROM reporting.facility_summary
WHERE date_written > @maxdate

--Ends cleaning reporting table as per facility reporting

--COMMIT TRAN trn_generate_facility_summary;

--END TRY

--BEGIN CATCH;

--ROLLBACK TRAN trn_generate_facility_summary;

--SELECT  @errorline=ERROR_LINE(),
--		@errornumber=ERROR_NUMBER(),
--		@errorseverity=ERROR_SEVERITY(),
--		@errorstate=ERROR_STATE(),
--		@errormessage=ERROR_MESSAGE();
	
--EXECUTE datamart.proc_log_error @errorprocedure='proc_generate_facility_summary',
--								  @errorline=@errorline,
--								  @errornumber=@errornumber,
--								  @errormessage=@errormessage,
--								  @errorseverity=@errorseverity,
--								  @errorstate=@errorstate
		

--RETURN -1;
--END CATCH;
--RETURN 0;

END

GO


IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_facility_weekly_variance')
DROP PROC datamart.proc_generate_facility_weekly_variance
GO

CREATE PROC datamart.proc_generate_facility_weekly_variance
AS
BEGIN

/*
Usage : To populate Facility Weekly Varinace report in the same reporting format

Creator/Editor #Date #Comments
Pratheesh N # 2017-09-22 # Initial creation
*/

SET NOCOUNT ON;

--BEGIN TRAN datamart_facility

DECLARE 
@errorprocedure VARCHAR(50) --used to store procedure name
,@errorline INT --used to call RAISEERROR
,@errornumber INT --used to call RAISEERROR
,@errorseverity INT --used to call RAISEERROR
,@errorstate INT  --used to call RAISEERROR
,@errormessage VARCHAR(2048);  --used to call RAISEERROR

--BEGIN TRY;

TRUNCATE TABLE reporting.facility_weekly_variance

--Starts Insert of template data
;
WITH cte1 as
(
SELECT distinct spirit_year,spirit_week
FROM reporting.facility_summary

WHERE spirit_year > 2016
)
,

cte2 as
(
SELECT distinct location,business_unit
FROM reporting.facility_summary
)

INSERT INTO reporting.facility_weekly_variance
(
spirit_year
,spirit_week
,business_unit
,location
)

SELECT
spirit_year
,spirit_week
,business_unit
,location

FROM cte1, cte2
;
--Ends Insert of template data


--Starts Update of quality summary # All except $ per unit
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,SUM(scrap_amount_actual) as weekly_scrap_actual

,SUM(rr_amount_actual) as weekly_rr_actual
,MAX(scrap_amount_target) as scrap_target_per_unit
,MAX(rr_amount_target) as rr_target_per_unit

FROM reporting.facility_summary

WHERE attribute = 'quality'

GROUP BY
spirit_year
,spirit_week
,location
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,SUM(c2.weekly_scrap_actual) as ytd_scrap_actual
,SUM(c2.weekly_rr_actual) as ytd_rr_actual

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.weekly_scrap_actual
,c1.weekly_rr_actual

,c1.scrap_target_per_unit
,c1.rr_target_per_unit
,c2.ytd_scrap_actual
,c2.ytd_rr_actual

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
)

UPDATE reporting.facility_weekly_variance
SET weekly_scrap_actual = isnull(cte3.weekly_scrap_actual,0)
 ,weekly_rr_actual = isnull(cte3.weekly_rr_actual,0)
 ,scrap_target_per_unit = isnull(cte3.scrap_target_per_unit,0)
 ,rr_target_per_unit = isnull(cte3.rr_target_per_unit,0)

FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit is null
   
--Ends Update of quality summary # All except $ per unit

--Starts Update of quality summary # $ per unit
;
WITH cte1 as
(
SELECT
t1.spirit_year
,t1.spirit_week
,t1.location
,t1.program
,t1.month_no

,SUM(t1.rr_amount_actual) as weekly_rr
,SUM(t1.scrap_amount_actual) as weekly_scrap

FROM reporting.facility_summary t1

WHERE t1.attribute = 'quality'
  
GROUP BY
t1.spirit_year
,t1.spirit_week
,t1.location
,t1.program

,t1.month_no
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.month_no
,c1.location
,c1.program

,SUM(c2.weekly_rr) as mtd_rr
,SUM(c2.weekly_scrap) as mtd_scrap

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.program = c2. program
 AND c1.spirit_year = c2.spirit_year
 AND c1.month_no = c2.month_no
 AND c1.spirit_week >= c2.spirit_week
 
GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.month_no
,c1.location
,c1.program
)

,
cte3 as
(
SELECT
t1.location
,t1.program
,t1.spirit_year
,t1.month_no
,SUM(t1.scrap_amount_actual) / NULLIF(SUM(t1.unit),0) monthly_scrap_per_unit

,SUM(t1.rr_amount_actual) / NULLIF(SUM(t1.unit),0) monthly_rr_per_unit
,SUM(t1.unit) monthly_unit

FROM reporting.facility_summary t1

WHERE t1.attribute = 'quality'

GROUP BY 
t1.location
,t1.program
,t1.spirit_year
,t1.month_no
)

,
cte4 as
(
SELECT
c2.spirit_year
,c2.spirit_week
,c2.month_no
,c2.location
,c2.program

,c2.mtd_rr / NULLIF(c3.monthly_unit,0) mtd_rr_per_unit
,c2.mtd_scrap / NULLIF(c3.monthly_unit,0) mtd_scrap_per_unit

FROM cte2 c2

INNER JOIN cte3 c3
 ON c2.spirit_year = c3.spirit_year
 AND c2.month_no = c3.month_no
 AND c2.location = c3.location
 AND c2.program = c3.program
)

,
cte5 as
(
SELECT
c3.location
,c3.spirit_year
,c3.month_no
,SUM(c3.monthly_scrap_per_unit) as monthly_scrap_per_unit

,SUM(c3.monthly_rr_per_unit) as monthly_rr_per_unit

FROM cte3 c3

GROUP BY
c3.location
,c3.spirit_year
,c3.month_no
)

,
cte6 as
(
SELECT
c4.location
,c4.spirit_year
,c4.spirit_week
,c4.month_no
,SUM(c4.mtd_rr_per_unit) as mtd_rr_per_unit

,SUM(c4.mtd_scrap_per_unit) as mtd_scrap_per_unit
,ROW_NUMBER () OVER (partition by c4.location,c4.spirit_year,c4.spirit_week  order by c4.month_no desc) as rno

FROM cte4 c4

GROUP BY
c4.location
,c4.spirit_year
,c4.spirit_week
,c4.month_no
)

,

cte7 as
(
SELECT 
c6.location
,c6.spirit_year
,c6.spirit_week
,c6.month_no
,c6.mtd_rr_per_unit

,c6.mtd_scrap_per_unit
,SUM(c5.monthly_rr_per_unit) as ytd_rr_per_unit
,SUM(c5.monthly_scrap_per_unit) as ytd_scrap_per_unit

FROM cte6 c6

LEFT OUTER JOIN cte5 c5
 ON c6.location = c5.location
 AND c6.spirit_year = c5.spirit_year
 AND c6.month_no > c5.month_no

WHERE c6.rno = 1

GROUP BY
c6.location
,c6.spirit_year
,c6.spirit_week
,c6.month_no
,c6.mtd_rr_per_unit

,c6.mtd_scrap_per_unit
)

UPDATE reporting.facility_weekly_variance
SET ytd_scrap_avg_per_unit = (isnull(cte7.mtd_scrap_per_unit,0) + isnull(cte7.ytd_scrap_per_unit,0)) / nullif(cte7.month_no,0)
 ,ytd_rr_avg_per_unit = (isnull(cte7.mtd_rr_per_unit,0) + isnull(cte7.ytd_rr_per_unit,0)) / nullif(cte7.month_no,0)

FROM cte7

WHERE reporting.facility_weekly_variance.spirit_year = cte7.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte7.spirit_week
 AND reporting.facility_weekly_variance.location = cte7.location
 AND reporting.facility_weekly_variance.business_unit is null

--Ends Update of quality summary # $ per unit


--Starts Update of utilization summary
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(manpower_available) as weekly_available

,SUM(manpower_clocked) as weekly_clocked
,SUM(manpower_clocked_noa) as weekly_noa

FROM reporting.facility_summary

WHERE attribute = 'utilization'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_noa) as ytd_noa

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.weekly_available
,c1.weekly_clocked

,c1.weekly_noa
,c2.ytd_noa

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit
)

UPDATE reporting.facility_weekly_variance
SET weekly_available = isnull(cte3.weekly_available,0)
 ,weekly_clocked = isnull(cte3.weekly_clocked,0) - isnull(cte3.weekly_noa,0)
 ,weekly_noa = isnull(cte3.weekly_noa,0)
 ,ytd_noa = isnull(cte3.ytd_noa,0)
 ,effective_hours = ((isnull(cte3.weekly_clocked,0) - isnull(cte3.weekly_noa,0)) / nullif(cte3.weekly_available,0)) --* 100

FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit = cte3.business_unit
 
--Ends Update of utilization summary


--Starts Update of overtime summary
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(actual_regular_hours) as weekly_actual_regular_hours

,SUM(actual_over_time_hours) as weekly_actual_over_time_hours
,SUM(forecast_regular_hours) as weekly_forecast_regular_hours
,SUM(forecast_over_time_hours) as weekly_forecast_over_time_hours

FROM reporting.facility_summary

WHERE attribute = 'overtime'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_actual_regular_hours) as ytd_actual_regular_hours

,SUM(c2.weekly_actual_over_time_hours) as ytd_actual_over_time_hours
,SUM(c2.weekly_forecast_regular_hours) as ytd_forecast_regular_hours
,SUM(c2.weekly_forecast_over_time_hours) as ytd_forecast_over_time_hours

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.weekly_actual_regular_hours

,c1.weekly_actual_over_time_hours
,c1.weekly_forecast_regular_hours
,c1.weekly_forecast_over_time_hours
,c2.ytd_actual_regular_hours
,c2.ytd_actual_over_time_hours

,c2.ytd_forecast_regular_hours
,c2.ytd_forecast_over_time_hours

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit
)

UPDATE reporting.facility_weekly_variance
SET weekly_actual_pcg = isnull((cte3.weekly_actual_over_time_hours/nullif(cte3.weekly_actual_regular_hours,0)),0)
 ,weekly_planned_pcg = isnull((cte3.weekly_forecast_over_time_hours/nullif(cte3.weekly_forecast_regular_hours,0)),0)
 ,ytd_actual_pcg = isnull((cte3.ytd_actual_over_time_hours/nullif(cte3.ytd_actual_regular_hours,0)),0)
 ,planned_ot_pcg = isnull((cte3.ytd_forecast_over_time_hours/nullif(cte3.ytd_forecast_regular_hours,0)),0)
 
FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit = cte3.business_unit
 
--Ends Update of overtime summary


--Starts Update of headcount summary
;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(headcount_actuals) as weekly_headcount_actuals

,MAX(abs_std_pcg) as abs_std_pcg
,SUM(total_abs_hours) as weekly_total_abs_hours
,SUM(std_hours_per_week) as weekly_std_hours_per_week

FROM reporting.facility_summary

WHERE attribute = 'headcount'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_total_abs_hours) as ytd_total_abs_hours

,SUM(c2.weekly_std_hours_per_week) as ytd_std_hours_per_week

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.weekly_headcount_actuals

,c1.abs_std_pcg
,c1.weekly_total_abs_hours
,c1.weekly_std_hours_per_week
,c2.ytd_total_abs_hours
,c2.ytd_std_hours_per_week

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit
)

UPDATE reporting.facility_weekly_variance
SET assigned_actuals = isnull(cte3.weekly_headcount_actuals,0)
 ,abs_std_pcg = isnull(cte3.abs_std_pcg,0)
 ,week_abs_pcg_actual = isnull((cte3.weekly_total_abs_hours/nullif(cte3.weekly_std_hours_per_week,0)),0)
 ,ytd_abs_pcg_actual = isnull((cte3.ytd_total_abs_hours/nullif(cte3.ytd_std_hours_per_week,0)),0)
 
FROM cte3

WHERE reporting.facility_weekly_variance.spirit_year = cte3.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte3.spirit_week
 AND reporting.facility_weekly_variance.location = cte3.location
 AND reporting.facility_weekly_variance.business_unit = cte3.business_unit
 
--Ends Update of headcount summary


--Starts Update of downtime summary

;
WITH cte1 as
(
SELECT
spirit_year
,spirit_week
,location
,business_unit
,SUM(case when criticality = 'Critical 1-3' then asset_count else 0 end) as asset_count_critical_1_3

,SUM(case when criticality = 'Critical 4' then asset_count else 0 end) as asset_count_critical_4
,SUM(case when criticality = 'Critical 5' then asset_count else 0 end) as asset_count_critical_5
,SUM(case when criticality = 'Critical 1-3' then downtime_actual else 0 end) as weekly_downtime_actual_critical_1_3
,SUM(case when criticality = 'Critical 4' then downtime_actual else 0 end) as weekly_downtime_actual_critical_4
,SUM(case when criticality = 'Critical 5' then downtime_actual else 0 end) as weekly_downtime_actual_critical_5

,SUM(case when criticality = 'Critical 5' then downtime_target else 0 end) as weekly_downtime_target_critical_5

FROM reporting.facility_summary

WHERE attribute = 'downtime'

GROUP BY
spirit_year
,spirit_week
,location
,business_unit
)

,
cte2 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,SUM(c2.weekly_downtime_actual_critical_1_3) as ytd_downtime_actual_critical_1_3

,SUM(c2.weekly_downtime_actual_critical_4) as ytd_downtime_actual_critical_4
,SUM(c2.weekly_downtime_actual_critical_5) as ytd_downtime_actual_critical_5

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week >= c2.spirit_week

GROUP BY
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
)

,
cte3 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c2.weekly_downtime_actual_critical_1_3 as prior_weekly_downtime_actual_critical_1_3

,c2.weekly_downtime_actual_critical_4 as prior_weekly_downtime_actual_critical_4
,c2.weekly_downtime_actual_critical_5 as prior_weekly_downtime_actual_critical_5

FROM cte1 c1

INNER JOIN cte1 c2
 ON c1.location = c2.location
 AND c1.business_unit = c2.business_unit
 AND c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week + 1
)


,
cte4 as
(
SELECT
c1.spirit_year
,c1.spirit_week
,c1.location
,c1.business_unit
,c1.asset_count_critical_1_3

,c1.asset_count_critical_4
,c1.asset_count_critical_5
,c1.weekly_downtime_actual_critical_1_3
,c1.weekly_downtime_actual_critical_4
,c1.weekly_downtime_actual_critical_5

,c1.weekly_downtime_target_critical_5
,c2.ytd_downtime_actual_critical_1_3
,c2.ytd_downtime_actual_critical_4
,c2.ytd_downtime_actual_critical_5
,c3.prior_weekly_downtime_actual_critical_1_3

,c3.prior_weekly_downtime_actual_critical_4
,c3.prior_weekly_downtime_actual_critical_5

FROM cte1 c1

INNER JOIN cte2 c2
 ON c1.spirit_year = c2.spirit_year
 AND c1.spirit_week = c2.spirit_week
 AND c1.location = c2.location
 AND c1.business_unit = c2.business_unit

LEFT OUTER JOIN cte3 c3
 ON c1.spirit_year = c3.spirit_year
 AND c1.spirit_week = c3.spirit_week
 AND c1.location = c3.location
 AND c1.business_unit = c3.business_unit 
 
)

UPDATE reporting.facility_weekly_variance
SET crit_1_3_asset = isnull(cte4.asset_count_critical_1_3,0)
 ,crit_1_3_weekly_dt_actuals_per_hrs = isnull(cte4.weekly_downtime_actual_critical_1_3,0)
 ,crit_1_3_prior_week_dt_actuals_per_hrs = isnull(cte4.prior_weekly_downtime_actual_critical_1_3,0)
 ,crit_1_3_ytd_dt_actuals_per_hrs = isnull(cte4.ytd_downtime_actual_critical_1_3,0)
 
 ,crit_4_assets = isnull(cte4.asset_count_critical_4,0)
 ,crit_4_weekly_dt_actuals_per_hrs = isnull(cte4.weekly_downtime_actual_critical_4,0)
 ,crit_4_prior_week_dt_actuals_per_hrs = isnull(cte4.prior_weekly_downtime_actual_critical_4,0)
 ,crit_4_ytd_dt_actuals_per_hrs = isnull(cte4.ytd_downtime_actual_critical_4,0)
 
 ,crit_5_assets = isnull(cte4.asset_count_critical_5,0)
 ,crit_5_weekly_dt_actuals_per_hrs = isnull(cte4.weekly_downtime_actual_critical_5,0)
 ,crit_5_prior_weekly_dt_actuals_per_hrs = isnull(cte4.prior_weekly_downtime_actual_critical_5,0)
 ,crit_5_ytd_dt_actuals_per_hrs = isnull(cte4.ytd_downtime_actual_critical_5,0)
 ,crit_5_weekly_dt_tgt_hrs = isnull(cte4.weekly_downtime_target_critical_5,0)
  
FROM cte4

WHERE reporting.facility_weekly_variance.spirit_year = cte4.spirit_year
 AND reporting.facility_weekly_variance.spirit_week = cte4.spirit_week
 AND reporting.facility_weekly_variance.location = cte4.location
 AND reporting.facility_weekly_variance.business_unit = cte4.business_unit
 
--Ends Update of downtime summary

--Starts Update of nulls with 0

UPDATE reporting.facility_weekly_variance

SET weekly_scrap_actual = isnull(weekly_scrap_actual,0)
 ,weekly_rr_actual = isnull(weekly_rr_actual,0)
 ,scrap_target_per_unit = isnull(scrap_target_per_unit,0)
 ,rr_target_per_unit = isnull(rr_target_per_unit,0)
 ,ytd_scrap_avg_per_unit = isnull(ytd_scrap_avg_per_unit,0)
 
 ,ytd_rr_avg_per_unit = isnull(ytd_rr_avg_per_unit,0)
 ,weekly_available = isnull(weekly_available,0)
 ,weekly_clocked = isnull(weekly_clocked,0)
 ,weekly_noa = isnull(weekly_noa,0)
 ,ytd_noa = isnull(ytd_noa,0)
 
 ,effective_hours = isnull(effective_hours,0)
 ,weekly_actual_pcg = isnull(weekly_actual_pcg,0)
 ,weekly_planned_pcg = isnull(weekly_planned_pcg,0)
 ,ytd_actual_pcg = isnull(ytd_actual_pcg,0)
 ,planned_ot_pcg = isnull(planned_ot_pcg,0)

 ,assigned_actuals = isnull(assigned_actuals,0)
 ,abs_std_pcg = isnull(abs_std_pcg,0)
 ,week_abs_pcg_actual = isnull(week_abs_pcg_actual,0)
 ,ytd_abs_pcg_actual = isnull(ytd_abs_pcg_actual,0)
 ,crit_1_3_asset = isnull(crit_1_3_asset,0)
 
 ,crit_1_3_weekly_dt_actuals_per_hrs = isnull(crit_1_3_weekly_dt_actuals_per_hrs,0)
 ,crit_1_3_prior_week_dt_actuals_per_hrs = isnull(crit_1_3_prior_week_dt_actuals_per_hrs,0)
 ,crit_1_3_ytd_dt_actuals_per_hrs = isnull(crit_1_3_ytd_dt_actuals_per_hrs,0)
 ,crit_4_assets = isnull(crit_4_assets,0)
 ,crit_4_weekly_dt_actuals_per_hrs = isnull(crit_4_weekly_dt_actuals_per_hrs,0)
 
 ,crit_4_prior_week_dt_actuals_per_hrs = isnull(crit_4_prior_week_dt_actuals_per_hrs,0)
 ,crit_4_ytd_dt_actuals_per_hrs = isnull(crit_4_ytd_dt_actuals_per_hrs,0)
 ,crit_5_assets = isnull(crit_5_assets,0)
 ,crit_5_weekly_dt_tgt_hrs = isnull(crit_5_weekly_dt_tgt_hrs,0)
 ,crit_5_weekly_dt_actuals_per_hrs = isnull(crit_5_weekly_dt_actuals_per_hrs,0)
 
 ,crit_5_prior_weekly_dt_actuals_per_hrs = isnull(crit_5_prior_weekly_dt_actuals_per_hrs,0)
 ,crit_5_ytd_dt_actuals_per_hrs = isnull(crit_5_ytd_dt_actuals_per_hrs,0)
 
update SpiritDigi_Test.reporting.refresh_log
set reporting_period = week_str
,last_refresh_date_time = getdate() 
,week_no = spirit_week

from datamart.vw_dim_calendar
where is_current_week = 1

and report_name = 'Facility'

--Ends Update of nulls with 0

--COMMIT TRAN datamart_facility;

--END TRY

--BEGIN CATCH;

--PRINT 'Unexpected error occurred!'
--ROLLBACK TRAN datamart_facility
--RETURN 1


/* SELECT  
	@errorprocedure='[datamart].[proc_generate_facility_weekly_program_metrics]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
----RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0; */



END

GO
/*
Usage : This SP is used to load data from datamart table to summary report table for Quality
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_quality_srr_escape_noe')
 DROP PROC [datamart].[proc_generate_quality_srr_escape_noe]
GO



CREATE PROC [datamart].[proc_generate_quality_srr_escape_noe]
AS
BEGIN
/*******************************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			2017-Jun-21				Processing & generating reporting data for quality metrics (tableau) 
********************************************************************************************************************/

SET NOCOUNT ON;

BEGIN TRAN quality_reporting

DECLARE 
		@errorline INT, -- used to call RAISEERROR
		@errornumber INT, -- used to call RAISEERROR
		@errorseverity INT, -- used to call RAISEERROR
		@errorstate INT,  -- used to call RAISEERROR
		@errormessage VARCHAR(2048),  -- used to call RAISEERROR
		@date_srr DATE,  --used to get the maximum date from srr fact table
		@date_escape DATE, --used to get the maximum date from escape fact table
		@week_srr INT,	--used to get the maximum week to load srr target
		@week_escape INT,	--used to get the maximum week to load escape target
		@week INT,		--To load the current spirit week
		@max_date DATE,  --To load the last week maximum date
		@prv_start_date DATE; --To load previous year starting date

BEGIN TRY;

TRUNCATE TABLE [reporting].[quality_srr_escape_noe];

SELECT @week=spirit_week FROM [datamart].[dim_calendar] WHERE date_key=CONVERT(DATE,GETDATE());
SELECT @max_date=MAX(date_key) FROM [datamart].[dim_calendar] WHERE spirit_week=(@week-1) AND spirit_year=DATEPART(YY,GETDATE());
SET @prv_start_date=(SELECT DATEADD(yy,-1,DATEADD(yy,DATEDIFF(yy,0,GETDATE()),0)));

--Starts Inserting SRR
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[feature_defect_description]
,[location]
,[program]
,[spirit_week]

,[spirit_year]
,[srr_amount_actual]
,[srr_qty_actual]
,[value_chain]
,[function]
,[charge_mgmt_code]
,[attribute]
)

SELECT  
[date_written]
,([discrepancy_description]+' '+[feature_description]) as feature_defect_description
,location
,srr.model as program
,cal.spirit_week as spirit_week

,cal.spirit_year as spirit_year
,total_srr_dollar as srr_amount_actual
,[defect_qty] as srr_qty_actual
,srr.[value_chain]
,chargemgmt.[functions]

,[charge_mgmt_code]
,'srr'

FROM [datamart].[fact_srr_fuselage] srr (NOLOCK)
INNER JOIN [datamart].dim_calendar cal (NOLOCK)
  ON cal.date_key=srr.date_written
LEFT JOIN [datamart].[dim_charge_management_code_function] chargemgmt (NOLOCK)
 ON  srr.[charge_mgmt_code]=chargemgmt.management_code 
--Ends Inserting SRR



SELECT @date_srr=MAX(date_written) FROM [datamart].[fact_srr_fuselage] (NOLOCK); 
SELECT @week_srr=spirit_week FROM [datamart].[dim_calendar] (NOLOCK) WHERE date_key=@date_srr;

--Starts Inserting ESCAPE
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[escapes_amount_actual]
,[escapes_qty_actual]
,[feature_defect_description]
,[program]

,[spirit_week]
,[spirit_year]
,[value_chain]
,[function]
,[charge_mgmt_code]

,[location]
,[attribute]
)


SELECT 
date_written
,[sum_ncr_cost_amt] as escapes_amount_actual
,[ca_count] as escapes_qty_actual
,([discrepancy_description]+' '+[feature_description]) as feature_defect_description
,[program_nm] as program

,cal.spirit_week as spirit_week
,cal.spirit_year as spirit_year
,[value_chain_cd] 
,(CASE WHEN esc.responsible_mgmt_code IS NULL THEN 'Misc'
ELSE chargemgmt.[functions] END) AS [function]
,[responsible_mgmt_code]

,[location]
,'escape'

FROM [datamart].[fact_escape] esc (NOLOCK)
INNER JOIN [datamart].dim_calendar cal (NOLOCK)
 ON cal.date_key=esc.date_written
LEFT JOIN [datamart].[dim_charge_management_code_function] chargemgmt (NOLOCK)
 ON  esc.responsible_mgmt_code=chargemgmt.management_code 
 --Ends Inserting ESCAPE

 
--Starts Inserting KINSTON & SNZ escapes
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[escapes_qty_actual]
,[feature_defect_description]
,[program]
,[spirit_week]

,[spirit_year]
,[value_chain]
,[function]
,[location]
,[attribute]
)


SELECT 
date_written
,[ca_count] as escapes_qty_actual
,[feature_description] as feature_defect_description
,[program_nm] as program
,cal.spirit_week as spirit_week

,cal.spirit_year as spirit_year
,[value_chain_cd] 
,'Misc' AS [function]
,[location]
,'escape'

FROM [datamart].[fact_escape_kinsnz] esc (NOLOCK)
INNER JOIN [datamart].dim_calendar cal (NOLOCK)
 ON cal.date_key=esc.date_written
WHERE esc.date_written>=@prv_start_date;

 --Ends Inserting KINSTON & SNZ escapes
  
SELECT @date_escape=MAX(date_written) FROM  [datamart].[fact_escape] (NOLOCK); 
SELECT @week_escape=spirit_week FROM [datamart].[dim_calendar] (NOLOCK) WHERE date_key=@date_escape
--print @date_escape

 --Starts Inserting NOE
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[noe_actual]
,[program]
,[spirit_week]
,[spirit_year]

,[value_chain]
,[noe_description]
,[attribute]
)

SELECT 
noe.date_written
,1 as noe_actual
,COALESCE(modelmapping.actual_name,noe.[models]) as  program
,cal.spirit_week as spirit_week
,cal.spirit_year as spirit_year

,null AS [value_chain]
,noe.[description_of_condition]
,'noe'

FROM [datamart].[fact_noe] noe (NOLOCK)
INNER JOIN [datamart].dim_calendar cal (NOLOCK)
 ON cal.date_key=date_written
LEFT OUTER JOIN datamart.dim_alias_mapping modelmapping
 ON noe.models = modelmapping.alias_name and modelmapping.category = 'model'
WHERE date_written<=@max_date;
 --Ends Inserting NOE


 --Starts Inserting SRR_TARGET
 INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[program]
,[spirit_week]
,[spirit_year]
,[srr_amount_planned]

,[value_chain]
,[function]
,[location]
,[attribute]
)

SELECT 
date_written
,[model] as program
,[spirit_week]
,[spirit_year]
,[weekly_srr_target] as [srr_amount_planned]

,[value_chain]
,[function]
,[location]
,'srr'

FROM datamart.[dim_srr_target] (NOLOCK)
INNER JOIN [datamart].dim_calendar cal (NOLOCK)
 ON cal.date_key=date_written
WHERE date_written>=@prv_start_date AND cal.spirit_week<=@week_srr;
--Ends Inserting SRR_TARGET


--Starts Inserting ESCAPE_TARGET
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[escapes_amount_planned]
,[escapes_qty_planned]
,[program]
,[spirit_week]

,[spirit_year]
,[value_chain]
,[function]
,[location]
,[attribute]
)
SELECT 
date_written
,0 as [escapes_amount_planned]
,[weekly_escape_target]
,[model] as program
,[spirit_week]

,[spirit_year]
,[value_chain]
,[function]
,[location]
,'escape'

FROM [datamart].[dim_escape_target]  (NOLOCK)
INNER JOIN [datamart].dim_calendar cal (NOLOCK)
 ON cal.date_key=date_written
WHERE date_written>=@prv_start_date AND cal.spirit_week<=@week_escape;
--Ends Inserting ESCAPE_TARGET

--Start Inserting Malysia SRR
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[location]
,[program]
,[spirit_week]
,[spirit_year]

,[srr_amount_actual]
,[value_chain]
,[srr_qty_actual]
,[attribute]
)
SELECT mal.[date_written]
      ,mal.[location]
	  ,mal.[program]
      ,mal.[spirit_week]
      ,mal.[spirit_year]
      
      ,mal.[metric_value] AS [srr_amount_actual]
	  ,mal.[value_chain]
	  ,[defect_qty] as srr_qty_actual
      ,mal.[attribute]

 FROM [datamart].[fact_malaysia_ceo_metrics_master](NOLOCK) mal
  INNER JOIN [datamart].dim_calendar cal (NOLOCK)
 ON cal.date_key=mal.date_written
  WHERE mal.date_written>=@prv_start_date AND mal.attribute='srr'
--End Inserting Malaysia SRR

--Start Inserting Malaysia Escape
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[escapes_qty_actual]
,[program]
,[spirit_week]
,[spirit_year]

,[value_chain]
,[location]
,[attribute]
)
SELECT mal.[date_written]
	  ,mal.[metric_value] AS [escapes_qty_actual]
      ,mal.[program]
      ,mal.[spirit_week]
      ,mal.[spirit_year]
      
      
	  ,mal.[value_chain]
	  ,mal.[location]
      ,mal.[attribute]

FROM [datamart].[fact_malaysia_ceo_metrics_master](NOLOCK) mal
 INNER JOIN [datamart].dim_calendar cal (NOLOCK)
ON cal.date_key=mal.date_written
 WHERE mal.date_written>=@prv_start_date AND mal.attribute='escape'

--End Inserting Malaysia Escape

--Start Inserting Malaysia noe
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[noe_actual]
,[program]
,[spirit_week]
,[spirit_year]

,[value_chain]
,[location]
,[attribute]
)
SELECT mal.[date_written]
	  ,mal.[metric_value] AS [noe_actual]
      ,mal.[program]
      ,mal.[spirit_week]
      ,mal.[spirit_year]
      
      
	  ,mal.[value_chain]
	  ,mal.[location]
      ,mal.[attribute]
FROM [datamart].[fact_malaysia_ceo_metrics_master](NOLOCK) mal 
 INNER JOIN [datamart].dim_calendar cal (NOLOCK)
  ON cal.date_key=mal.date_written
 WHERE mal.date_written>=@prv_start_date AND mal.attribute='noe'

--End Inserting Malaysia noe


--Start Inserting Prestwick SRR Quantity
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[location]
,[program]
,[spirit_week]
,[spirit_year]

,[value_chain]
,[srr_qty_actual]
,[attribute]
)
SELECT pstwk.[date_written]
      ,pstwk.[location]
	  ,pstwk.[program]
      ,pstwk.[spirit_week]
      ,pstwk.[spirit_year]
      
      ,pstwk.[value_chain]
	  ,pstwk.[defect_qty] AS srr_qty_actual
      ,pstwk.[attribute]

FROM [datamart].[fact_prestwick_ceo_metrics_master](NOLOCK) pstwk
 INNER JOIN [datamart].dim_calendar cal (NOLOCK)
  ON cal.date_key=pstwk.date_written
 WHERE pstwk.date_written>=@prv_start_date AND pstwk.attribute='srr'
--End Inserting Prestwick SRR Quantity

--Start Inserting Prestwick SRR 
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[location]
,[program]
,[spirit_week]
,[spirit_year]

,[feature_defect_description]
,[srr_amount_actual]
,[value_chain]
,[attribute]
)
SELECT [date_written]
	  ,[location]
	  ,[program]
	  ,pstsrr.[spirit_week]
	  ,pstsrr.[spirit_year]

      ,[feature_descrepancy] AS feature_defect_description
	  ,[total_srr_dollar]
	  ,[value_chain]
      ,'srr' AS attribute
	           
FROM [datamart].[fact_srr_prestwick] pstsrr (NOLOCK)
 INNER JOIN [datamart].dim_calendar cal (NOLOCK)
  ON cal.date_key=pstsrr.date_written
WHERE pstsrr.date_written>=@prv_start_date 
--End Inserting Prestwick SRR 


--Start Inserting Prestwick Escape
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[escapes_qty_actual]
,[program]
,[spirit_week]
,[spirit_year]

,[escapes_amount_actual]
,[value_chain]
,feature_defect_description
,[location]
,[attribute]
)
SELECT [date_written]
	  ,[ca_count]
	  ,[program]
	  ,pstwk.[spirit_week]
	  ,pstwk.[spirit_year]

	  ,[escape_amount_actual]
	  ,[value_chain]
	  ,[feature_descrepancy] AS feature_defect_description
	  ,[location]
	  ,'escape' AS attribute

FROM [datamart].[fact_escape_prestwick](NOLOCK) pstwk
 INNER JOIN [datamart].dim_calendar cal (NOLOCK)
  ON cal.date_key=pstwk.date_written
WHERE pstwk.date_written>=@prv_start_date 

--End Inserting Prestwick Escape

--Start Inserting pstwkaysia noe
INSERT INTO  [reporting].[quality_srr_escape_noe]
(
[date_written]
,[noe_actual]
,[program]
,[spirit_week]
,[spirit_year]

,[value_chain]
,[location]
,[attribute]
)
SELECT pstwk.[date_written]
	  ,pstwk.[metric_value] AS [noe_actual]
      ,pstwk.[program]
      ,pstwk.[spirit_week]
      ,pstwk.[spirit_year]
      
      
	  ,pstwk.[value_chain]
	  ,pstwk.[location]
      ,pstwk.[attribute]
FROM [datamart].[fact_prestwick_ceo_metrics_master](NOLOCK) pstwk 
 INNER JOIN [datamart].dim_calendar cal (NOLOCK)
  ON cal.date_key=pstwk.date_written
 WHERE pstwk.date_written>=@prv_start_date AND pstwk.attribute='noe'

--End Inserting pstwkaysia noe


--For Update SNZ,Kinston etc functions as NULL
UPDATE  reporting.quality_srr_escape_noe SET [function]=NULL WHERE [function] IN('MALAYSIA','OKLAHOMA','SNZ','KINSTON');
UPDATE  reporting.quality_srr_escape_noe SET [function]='ASSY' WHERE [function] IN('SNZ ASSY','OKLAHOMA ASSY');

--For Update Planned values for summery report(exclude function values)
UPDATE reporting.quality_srr_escape_noe SET srr_amount_planned_summary=srr_amount_planned,escapes_qty_planned_summary=escapes_qty_planned FROM reporting.quality_srr_escape_noe;
UPDATE reporting.quality_srr_escape_noe SET srr_amount_planned_summary=0,escapes_qty_planned_summary=0 WHERE [function] IS NOT NULL;

--For Escapes Actuals, location should be updated as Misc where the charge management code is NULL
UPDATE reporting.quality_srr_escape_noe SET location='Misc' WHERE location is null and escapes_qty_actual is not null ;

COMMIT TRAN quality_reporting;

END TRY

BEGIN CATCH;

ROLLBACK TRAN quality_reporting;

SELECT  @errorline=ERROR_LINE(),
		@errornumber=ERROR_NUMBER(),
		@errorseverity=ERROR_SEVERITY(),
		@errorstate=ERROR_STATE(),
		@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure='datamart.proc_generate_quality_srr_escape_noe',
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
--RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0;

END




GO


/*
Usage : This SP is used to load weekly program metrics data
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_generate_quality_weekly_program_metrics')
 DROP PROC [datamart].[proc_generate_quality_weekly_program_metrics]
GO

CREATE PROC [datamart].[proc_generate_quality_weekly_program_metrics]
AS
BEGIN

/*************************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Inserting data into weekly program metrics reporting table  
**************************************************************************************************************/

SET NOCOUNT ON;

BEGIN TRAN datamart_quality

DECLARE 
		@errorprocedure VARCHAR(50), --used to store procedure name
		@errorline INT, -- used to call RAISEERROR
		@errornumber INT, -- used to call RAISEERROR
		@errorseverity INT, -- used to call RAISEERROR
		@errorstate INT,  -- used to call RAISEERROR
		@errormessage VARCHAR(2048),  -- used to call RAISEERROR
		@week int,		--To load the current spirit week
		@spirit_year int;  --To load the year

BEGIN TRY;

TRUNCATE TABLE [reporting].[quality_weekly_program_metrics];

SELECT @week=spirit_week FROM [datamart].[dim_calendar] WHERE date_key=CONVERT(DATE,GETDATE());
SET @spirit_year=(SELECT CASE WHEN (@week>=50 AND MONTH(GETDATE()-1)=1) THEN YEAR(GETDATE()-1)-1 ELSE YEAR(GETDATE()-1) END)

DECLARE @matched_mgcode TABLE(program VARCHAR(50),value_chain VARCHAR(50),charge_mgmt_code varchar(50),[function] VARCHAR(50));

;WITH CTE1 as
(SELECT DISTINCT program,[function],mgcode_like,mgcode_notlike,business_unit FROM datamart.dim_quality_prg_metrics_mapping
WHERE program NOT IN(SELECT DISTINCT program FROM reporting.quality_srr_escape_noe))
,CTE2 as(SELECT DISTINCT b.program ,b.value_chain ,b.charge_mgmt_code,a.program AS [function] 
FROM CTE1 a INNER JOIN reporting.quality_srr_escape_noe B ON a.[function]=b.attribute AND b.charge_mgmt_code LIKE a.mgcode_like+'%') 
,CTE3 AS
(
SELECT DISTINCT a.program ,a.value_chain ,a.charge_mgmt_code ,b.[function] 
FROM reporting.quality_srr_escape_noe a
INNER JOIN datamart.dim_quality_prg_metrics_mapping b ON a.program=b.program AND a.value_chain=b.business_unit 
AND  a.charge_mgmt_code like b.mgcode_like+'%'--3141
UNION
SELECT program,value_chain,charge_mgmt_code,[function] FROM CTE2
)
,CTE4 as(SELECT DISTINCT b.program ,b.value_chain ,b.charge_mgmt_code,a.program AS [function]  
FROM CTE1 a INNER JOIN reporting.quality_srr_escape_noe B ON a.[function]=b.attribute AND b.charge_mgmt_code LIKE a.mgcode_notlike+'%')
,CTE5 AS
(
SELECT DISTINCT a.program ,a.value_chain ,a.charge_mgmt_code ,b.[function] 
FROM reporting.quality_srr_escape_noe a
INNER JOIN datamart.dim_quality_prg_metrics_mapping b ON a.program=b.program AND a.value_chain=b.business_unit 
AND  a.charge_mgmt_code like b.mgcode_notlike+'%'
UNION
SELECT program,value_chain,charge_mgmt_code,[function] FROM CTE4 
)

INSERT INTO @matched_mgcode
			
SELECT program,value_chain,charge_mgmt_code,[function] FROM CTE3  B
WHERE NOT EXISTS
(SELECT program,value_chain,charge_mgmt_code,[function] FROM CTE5
WHERE  program=b.program 
and value_chain=b.value_chain
and charge_mgmt_code like b.charge_mgmt_code
AND [function]=B.[function]);
--SELECT * FROM @matched_mgcode
			
IF OBJECT_ID('tempdb..#tmp_quality_weekly_program_matrix') IS NOT NULL 
DROP Table #tmp_quality_weekly_program_matrix;
CREATE TABLE #tmp_quality_weekly_program_matrix(
	[spirit_year] [int] NULL,
	[spirit_week] [int] NULL,
	[program] [varchar](30) NULL,
	[business_units] [varchar](30) NULL,
	[headers] [varchar](255) NULL,
	[weeklyactuals] [float] NULL,
	[weeklyplanned] [float] NULL,
	[weekly_variance] [float] NULL,
	[variance_planned] [float] NULL,
	[escape_weekly$_actuals] [float] NULL,
	[actualcumulativeytd] [float] NULL,
	[plannedcumulativeytd] [float] NULL
)


INSERT INTO #tmp_quality_weekly_program_matrix
(
[spirit_year]
      ,[spirit_week]
      ,[program]
      ,[business_units]
      ,[headers]
	  
      ,[weeklyactuals]
      ,[weeklyplanned]
      ,[weekly_variance]
      ,[variance_planned]
      ,[escape_weekly$_actuals]
)

SELECT 
spirit_year
,spirit_week
,program
,business_units
,headers

,ISNULL(weekly_actuals,0)
,ISNULL(weekly_planned,0)
,ISNULL(weekly_variance,0)
,ISNULL(variance_planned,0)
,CAST(escapeweekly$actuals AS INT) AS Escape_weekly$_actuals
FROM
  (SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals
					
			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='SRR' AND srr_amount_planned IS NULL AND attribute = 'SRR' 
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  value_chain IS NOT NULL  
			 AND [function] IS NULL 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location NOT IN('Malaysia','Prestwick')
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year AND actualsrr.spirit_week=plannedsrr.spirit_week
			AND 
			actualsrr.program = plannedsrr.program 
			AND 
			actualsrr.business_units = plannedsrr.business_units
  --------------------------------------------------------------------
   UNION --- Escapes Data
  ----------------------------------------------------------------------
	SELECT	 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,program 
					,LOWER(value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK)
			  WHERE value_chain IS NOT NULL AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) AND escapes_qty_planned IS NULL AND attribute = 'escape' 
			  AND location NOT IN('Malaysia','Prestwick')
			  GROUP  BY program,value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain IS NOT NULL  AND [function] IS NULL  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) 
			  AND escapes_qty_actual IS NULL AND attribute = 'escape' 
			  AND location NOT IN('Malaysia','Prestwick')
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 


  -------------------------------------
  UNION --- Assembly SRR Data
  -------------------------------------
  SELECT	 COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
		    ,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
		    ,2 as seq
			,COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units

			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekl_actuals
			,ISNULL(plannedsrr.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned
			 
			,null as escapeweekly$actuals
	FROM   
			(SELECT		 spirit_week
						,spirit_year
						,rep.program  
						,LOWER(rep.value_chain) AS business_units 
						,'Assembly SRR $'  AS Headers
						 
						,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='Assembly SRR' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

     FULL OUTER JOIN 

			(SELECT		 spirit_week
						,spirit_year
                        ,program
                        ,Lower(value_chain)      AS business_units 
                        ,'Assembly SRR $'                AS Headers 
                        ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

             FROM   reporting.quality_srr_escape_noe (NOLOCK)

             WHERE  value_chain IS NOT NULL AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
             AND attribute = 'SRR' and [function]='ASSY' AND value_chain<>'Wings'
             GROUP  BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 
     ON		 actualsrr.spirit_year = plannedsrr.spirit_year
	     AND actualsrr.spirit_week = plannedsrr.spirit_week 
         AND actualsrr.program = plannedsrr.program 
         AND actualsrr.business_units = plannedsrr.business_units 
  )  weeklyprogrammatrix  order by spirit_week,business_units,program,seq asc;



  INSERT INTO #tmp_quality_weekly_program_matrix
(
[spirit_year]
      ,[spirit_week]
      ,[program]
      ,[business_units]
      ,[headers]
	  
      ,[weeklyactuals]
      ,[weeklyplanned]
      ,[weekly_variance]
      ,[variance_planned]
      ,[escape_weekly$_actuals]
)

SELECT 
spirit_year
,spirit_week
,program
,business_units
,headers

,ISNULL(weekly_actuals,0)
,ISNULL(weekly_planned,0)
,ISNULL(weekly_variance,0)
,ISNULL(variance_planned,0)
,CAST(escapeweekly$actuals AS INT) AS Escape_weekly$_actuals
FROM
  (
  /*============================CMF==============================================*/
  
  --CMF SRR 

  SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,'CMF '+COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='CMF' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned
					  
			 FROM   reporting.quality_srr_escape_noe (NOLOCK)
			 WHERE  (value_chain IS NOT NULL AND value_chain<>'wings') 
			 AND [function] ='CMF' 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location<>'Malaysia'
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--181-06092017
--------------------------
UNION
--------------------------

SELECT	 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'CMF '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='CMF' AND escapes_qty_planned IS NULL AND attribute = 'escape' 
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
			  WHERE  (value_chain IS NOT NULL AND value_chain<>'wings') AND [function]='CMF'  
			  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) 
			  AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 
UNION 
/*========================================GEN Fab==============================================*/

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,'Gen Fab '+COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='GEN FAB' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 
			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  (value_chain IS NOT NULL  AND value_chain<>'Wings')
			 AND [function] IN ('Fabrication' ,'FAB')
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location<>'Malaysia'
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT	     COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'Gen Fab '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='GEN FAB' AND escapes_qty_planned IS NULL AND attribute = 'escape' 
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  (value_chain IS NOT NULL AND value_chain<>'Wings') AND [function] IN('Fabrication','FAB')  
			  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) 
			  AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION 
/*==============================================GPE========================================================*/

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,'GPE '+COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='GPE' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned
					  
			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  (value_chain IS NOT NULL)
			 AND [function] ='GPE' 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location<>'Malaysia'
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT	 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'GPE '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='GPE' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain IS NOT NULL  AND [function]='GPE'  
			  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) 
			  AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION
/*=====================================IPB4 Fab==============================================*/

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,'IPB4 Fab '+COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='IPB4' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  (value_chain IS NOT NULL  AND value_chain<>'wings')
			AND [function] ='IPB4' 
			AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			AND srr_amount_actual IS NULL 
			AND attribute = 'SRR' 
			AND location<>'Malaysia'
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT	     COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'IPB4 Fab '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='IPB4' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals
              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  (value_chain IS NOT NULL  AND value_chain<>'wings') AND [function]='IPB4'  
			  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION
/*========================================SCM=====================================================================*/
SELECT		 COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,3 as seq
			,'SCM '+COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units

			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualsrr.escapeweekly$actuals,0)
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='SCM' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 
			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE (value_chain IS NOT NULL AND value_chain<>'Wings')
			AND [function] ='SCM' 
			AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK))
			AND srr_amount_actual IS NULL 
			AND attribute = 'SRR' 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
      AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units
		
UNION

SELECT	 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'SCM '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			 FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			 INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			 AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			 AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			 WHERE  mgc.[function]='SCM' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			 GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals
              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  (value_chain IS NOT NULL  AND value_chain<>'wings') AND [function]='SCM'  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) 
			  AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 
		AND actualescape.spirit_year=plannedescape.spirit_year


UNION
/*======================================Eng========================================================================*/


SELECT       COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,'Eng '+COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='ENG' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  value_chain IS NOT NULL 
			AND [function] ='ENG' 
			AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			AND srr_amount_actual IS NULL 
			AND attribute = 'SRR' 
			AND location NOT IN('Malaysia','Prestwick')
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units
	  AND actualsrr.spirit_year=plannedsrr.spirit_year

--------------------------
UNION
--------------------------

SELECT	     COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'Eng '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='ENG' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
			  WHERE  value_chain IS NOT NULL  AND [function]='ENG'  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK))
			  AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

/*================================================Escapes Assy==================================*/
--------------------------
UNION
--------------------------

SELECT	     COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,'Assy '+COALESCE(actualescape.program,plannedescape.program) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='Assembly SRR' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  (value_chain IS NOT NULL AND value_chain<>'wings')  AND [function]='ASSY' 
			  AND program IN (SELECT NAME FROM   datamart.dim_model(NOLOCK)) AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

			ON  actualescape.spirit_year=plannedescape.spirit_year 
			AND actualescape.spirit_week=plannedescape.spirit_week 
            AND actualescape.program = plannedescape.program 
            AND actualescape.business_units = plannedescape.business_units 


/*=========================================Kinston A350 Assy===============================================================*/


UNION

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,('Kinston '+COALESCE(SUBSTRING(actualsrr.program,1,4),SUBSTRING(plannedsrr.program,1,4))+' Assy') AS program
			,'' AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,srr.program  AS program
					,''  AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) srr
			INNER JOIN datamart.dim_a350_mapping (NOLOCK) alis ON srr.charge_mgmt_code=alis.charge_management_code
			WHERE   srr.program='A350 Kinston' AND alis.[function]='Assy'
			AND srr_amount_planned IS NULL AND attribute = 'SRR' 
			
 			GROUP  BY srr.program,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,''  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] ='ASSY' 
			 AND program='A350 Kinston'
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location='Kinston'
			GROUP BY program,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

UNION

/*=========================================Kinston A350 Fab===============================================================*/

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,('Kinston '+COALESCE(SUBSTRING(actualsrr.program,1,4),SUBSTRING(plannedsrr.program,1,4))+' Fab') AS program
			,'' AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,srr.program  AS program
					,''  AS business_units 
					,'SRR [$]'  AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) srr
			INNER JOIN datamart.dim_a350_mapping (NOLOCK) alis ON srr.charge_mgmt_code=alis.charge_management_code
			WHERE   srr.program='A350 Kinston' AND alis.[function] IN('Fab','Fabrication')
			AND srr_amount_planned IS NULL AND attribute = 'SRR' 
			GROUP  BY srr.program,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,''  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] IN ('Fab','Fabrication') 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location='Kinston'
			GROUP BY program,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

UNION
/*=========================================Kinston A350 Spar===============================================================*/
			
SELECT		 COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,('Kinston '+COALESCE(SUBSTRING(actualsrr.program,1,4),SUBSTRING(plannedsrr.program,1,4))+' Spar') AS program
			,'' AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,srr.program   AS program
					,''   AS business_units 
					,'SRR [$]' AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) srr
			INNER JOIN datamart.dim_a350_mapping (NOLOCK) alis ON srr.charge_mgmt_code=alis.charge_management_code
			WHERE   srr.program='A350 Kinston' AND alis.[function]='Spar'
			AND srr_amount_planned IS NULL AND attribute = 'SRR' 
			GROUP  BY srr.program,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,''  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] ='Spars' 
			 AND program='A350 Kinston'
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location='Kinston'
			GROUP BY program,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units
			
UNION
/*========================SNZ A350 Assy=========================================================================*/

SELECT		 COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,('SNZ '+COALESCE(SUBSTRING(actualsrr.program,1,4),SUBSTRING(plannedsrr.program,1,4))+' Assy') AS program
			,'' AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

			,actualsrr.escapeweekly$actuals

   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,''     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			--AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='SNZ Assy' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,'' AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] ='ASSY' 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location='SNZ'
			GROUP BY program,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

UNION			
/*=====================SNZ A350 SCM=============================================================*/

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,('SNZ '+COALESCE(SUBSTRING(actualsrr.program,1,4),SUBSTRING(plannedsrr.program,1,4))+' SCM') AS program 
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,''     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			--AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='SNZ SCM' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,''  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] ='SCM' 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location='SNZ'
			GROUP BY program,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units
UNION			
/*==========================================SNA A350 QA============================================*/

SELECT       COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,('SNZ '+COALESCE(SUBSTRING(actualsrr.program,1,4),SUBSTRING(plannedsrr.program,1,4))+' QA') AS program 
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,''     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			--AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='SNZ QA' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,''  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 
			FROM   reporting.quality_srr_escape_noe (NOLOCK)

			WHERE  [function] ='QA' 
			 AND program IN (SELECT NAME FROM datamart.dim_model(NOLOCK)) 
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 AND location='SNZ'
			GROUP BY program,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

UNION			
/*==================================787 Composites===========================================================*/

SELECT       COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,(COALESCE(actualsrr.program,plannedsrr.program)+' Composites') AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

			,actualsrr.escapeweekly$actuals

   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='Comp Assy' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			 FROM   reporting.quality_srr_escape_noe (NOLOCK)
			 WHERE  [function] ='COMP FAB' 
			 AND program ='787' AND value_chain='fuselage'
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT	     COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,(COALESCE(actualescape.program,plannedescape.program)+' Composites ') AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='Comp Assy' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			  
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain='fuselage'  AND [function]='COMP FAB'  
			  AND program ='787' AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION
/*=============================787 Systems=========================================================================*/

SELECT       COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,(COALESCE(actualsrr.program,plannedsrr.program)+' Systems') AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='Fuse Systems' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] ='Systems' 
			AND program ='787' AND value_chain='fuselage'
			AND srr_amount_actual IS NULL 
			AND attribute = 'SRR' 
			 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT	     COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,(COALESCE(actualescape.program,plannedescape.program)+' Systems') AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='Fuse Systems' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain='fuselage'  AND [function]='Systems'  
			  AND program ='787' AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
		AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION

/*==================787 Structures===========================================================================*/

SELECT		 COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,(COALESCE(actualsrr.program,plannedsrr.program)+' Structures') AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='Fuse Structures' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 
			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] ='Structures' 
			 AND program='787' AND value_chain='fuselage'
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT		 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,(COALESCE(actualescape.program,plannedescape.program)+' Structures') AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='Fuse Structures' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain='fuselage'  AND [function]='Structures'  
			  AND program='787' AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION
/*=================================787 Nose Wheel Well==========================================================================*/

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,(COALESCE(actualsrr.program,plannedsrr.program)+' Nose Wheel Well') AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='Nose Wheel' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [function] =' Nose Wheel Well' 
			 AND program='787' AND value_chain='fuselage'
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT		 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,(COALESCE(actualescape.program,plannedescape.program)+' Nose Wheel Well') AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,rep.program 
					,LOWER(rep.value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			  INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			  AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			  AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			  WHERE  mgc.[function]='Nose Wheel' AND escapes_qty_planned IS NULL AND attribute = 'escape'
			  GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain='fuselage'  AND [function]=' Nose Wheel Well'  
			  AND program='787' AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

UNION
/*=================================================C-Series======================================================*/

SELECT   	DISTINCT COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

	   ,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,program                AS program
					,LOWER(value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals
			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE   program='C-Series' AND value_chain='Strut'
			AND srr_amount_planned IS NULL AND attribute = 'SRR' 
			
 			GROUP  BY program,value_chain,spirit_week,spirit_year
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'SRR [$]'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 
			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [value_chain]='strut' 
			 AND program='C-Series' AND [function] IS NULL
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

--------------------------
UNION
--------------------------

SELECT		 COALESCE(actualescape.spirit_week,plannedescape.spirit_week) AS spirit_week
			,COALESCE(actualescape.spirit_year,plannedescape.spirit_year) AS spirit_year
			,3 as seq
			,(COALESCE(actualescape.program,plannedescape.program)) AS program
			,COALESCE(actualescape.business_units,plannedescape.business_units) AS business_units

			,COALESCE(actualescape.headers,plannedescape.headers) AS headers
			,ISNULL(actualescape.weeklyactuals,0) AS weekly_actuals
			,ISNULL(plannedescape.weeklyplanned,0) AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0) AS weekly_variance 
			,(CASE WHEN ISNULL(plannedescape.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS variance_planned 

			,ISNULL(actualescape.escapeweekly$actuals,0)
	FROM   
			( SELECT spirit_week
					,spirit_year
					,program 
					,LOWER(value_chain)     AS business_units 
					,'Quality escapes at delivery [#]'    AS Headers
			    
					,ISNULL(SUM(escapes_qty_actual),0) AS weeklyactuals 
					,SUM(escapes_amount_actual) as escapeweekly$actuals

			  FROM   reporting.quality_srr_escape_noe (NOLOCK)
			  WHERE program='C-Series' AND value_chain='Strut' 
			  AND escapes_qty_planned IS NULL AND attribute='escape'
			  GROUP  BY program,value_chain,spirit_week,spirit_year
			) actualescape

       FULL OUTER JOIN 

			(SELECT   spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units 
                     ,'Quality escapes at delivery [#]'  AS Headers
					  
                     ,ISNULL(SUM(escapes_qty_planned),0) AS weeklyplanned 
					 ,SUM(escapes_amount_planned) as escapeweekly$actuals

              FROM   reporting.quality_srr_escape_noe (NOLOCK)
              WHERE  value_chain='Strut' AND [function] IS NULL
			  AND program='C-Series' AND escapes_qty_actual IS NULL AND attribute = 'escape' 
              GROUP  BY program,value_chain,spirit_week,spirit_year
			  ) plannedescape

        ON actualescape.spirit_year=plannedescape.spirit_year 
		AND actualescape.spirit_week=plannedescape.spirit_week 
        AND actualescape.program = plannedescape.program 
        AND actualescape.business_units = plannedescape.business_units 

--------------------------
UNION
--------------------------

SELECT   COALESCE(actualsrr.spirit_week,plannedsrr.spirit_week) AS spirit_week
			,COALESCE(actualsrr.spirit_year,plannedsrr.spirit_year) AS spirit_year
			,1 as seq
			,COALESCE(actualsrr.program,plannedsrr.program) AS program
			,COALESCE(actualsrr.business_units,plannedsrr.business_units) AS business_units
			 
			,COALESCE(actualsrr.headers,plannedsrr.headers) AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,ISNULL(plannedsrr.weeklyplanned,0)  AS weekly_planned
			,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
			,(CASE WHEN ISNULL(plannedsrr.weeklyplanned,0)=0 THEN 0
			ELSE ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / weeklyplanned ),0) END) AS  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'Assembly SRR $'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.program=mgc.program 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.charge_mgmt_code=mgc.charge_mgmt_code
			WHERE  mgc.[function]='C-Series Assy' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year 
			
			) actualsrr 

	   FULL OUTER JOIN 

			(SELECT	  spirit_week
					 ,spirit_year
                     ,program AS program 
                     ,LOWER(value_chain)  AS business_units
                     ,'Assembly SRR $'  AS Headers

                     ,ISNULL(SUM(srr_amount_planned),0) AS weeklyplanned 

			FROM   reporting.quality_srr_escape_noe (NOLOCK)
			WHERE  [value_chain]='strut' 
			 AND program='C-Series' AND [function]='ASSY'
			 AND srr_amount_actual IS NULL 
			 AND attribute = 'SRR' 
			 
			GROUP BY program,value_chain,spirit_week,spirit_year
			) plannedsrr 

      ON actualsrr.spirit_year=plannedsrr.spirit_year 
	  AND actualsrr.spirit_week=plannedsrr.spirit_week
	  AND actualsrr.program = plannedsrr.program 
	  AND actualsrr.business_units = plannedsrr.business_units

UNION

/*=================================================Brotje===========================================================*/


SELECT		actualsrr.spirit_week AS spirit_week
			,actualsrr.spirit_year AS spirit_year
			,1 as seq
			,'Brotje' AS program
			,'' AS business_units
			 
			,actualsrr.headers AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,0  AS weekly_planned
			,0 AS weekly_variance
			,0  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK) rep
			INNER JOIN @matched_mgcode mgc ON rep.charge_mgmt_code=mgc.charge_mgmt_code 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.program=mgc.program
			WHERE  mgc.[function]='Brotje' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			
			) actualsrr 

UNION
/*================================================Camo 2==========================================================*/

SELECT		actualsrr.spirit_week AS spirit_week
			,actualsrr.spirit_year AS spirit_year
			,1 as seq
			,'Camo 2' AS program
			,'' AS business_units
			 
			,actualsrr.headers AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,0  AS weekly_planned
			,0 AS weekly_variance
			,0  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM   reporting.quality_srr_escape_noe (NOLOCK)  rep
			INNER JOIN @matched_mgcode mgc ON rep.charge_mgmt_code=mgc.charge_mgmt_code 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.program=mgc.program
			WHERE  mgc.[function]='Camo2' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year
			) actualsrr 

UNION
/*===========================================Camo 3===========================================*/

SELECT		actualsrr.spirit_week AS spirit_week
			,actualsrr.spirit_year AS spirit_year
			,1 as seq
			,'Camo 3' AS program
			,'' AS business_units
			 
			,actualsrr.headers AS headers
			,ISNULL(actualsrr.weeklyactuals,0)  AS weekly_actuals
			,0  AS weekly_planned
			,0 AS weekly_variance
			,0  variance_planned

			,actualsrr.escapeweekly$actuals
   FROM  
			(
			SELECT  spirit_week
					,spirit_year
					,rep.program                AS program
					,LOWER(rep.value_chain)     AS business_units 
					,'SRR [$]'               AS Headers 

					,ISNULL(SUM(srr_amount_actual),0) AS weeklyactuals 
					,null as escapeweekly$actuals

			FROM reporting.quality_srr_escape_noe (NOLOCK)rep
			INNER JOIN @matched_mgcode mgc ON rep.charge_mgmt_code=mgc.charge_mgmt_code 
			AND ISNULL(rep.value_chain,'')=ISNULL(mgc.value_chain,'')
			AND rep.program=mgc.program
			WHERE  mgc.[function]='Camo3' AND srr_amount_planned IS NULL AND attribute = 'SRR'
			GROUP  BY rep.program,rep.value_chain,spirit_week,spirit_year

			) actualsrr 



) weeklyprogrammatrix  order by spirit_week,business_units,program,seq asc


--select * from #tmp_quality_weekly_program_matrix

--Updating Cummulative YTD Starts
;WITH CTE1 AS
(
 SELECT 
  A.spirit_year
 ,A.spirit_week
 ,A.program
 ,ISNULL(A.business_units,'') AS business_units
 ,A.headers

 ,ISNULL(A.weeklyactuals,0) AS weeklyactuals
 ,ISNULL(A.weeklyplanned,0) AS weeklyplanned
 ,ISNULL(A.variance_planned,0) AS variance_planned
 ,ISNULL(A.weekly_variance,0) AS weekly_variance
 ,ISNULL(escape_weekly$_actuals,0) AS escape_weekly$_actuals

 ,0 AS actualcumulativeytd 
 ,0 AS plannedcumulativeytd

 FROM  #tmp_quality_weekly_program_matrix A WHERE headers NOT IN('Greenline costs','NOEs [#]')
 ),
CTE2 AS
(
SELECT DISTINCT program,ISNULL(business_unit,'') AS business_unit,header,spirit_week,spirit_year FROM datamart.dim_quality_metric_structure,datamart.dim_calendar 
),
CTE3 AS
(
SELECT DISTINCT
 cte2.program
,cte2.business_unit AS business_units
,cte2.spirit_year
,cte2.spirit_week
,cte2.header as headers

,cte1.weeklyactuals
,cte1.weeklyplanned
,cte1.variance_planned
,cte1.weekly_variance
,cte1.escape_weekly$_actuals

,cte1.actualcumulativeytd
,cte1.plannedcumulativeytd

FROM cte2 LEFT OUTER JOIN CTE1 
		ON cte2.program=CTE1.program
		AND ISNULL(cte2.business_unit,'')=ISNULL(CTE1.business_units,'')
		AND ISNULL(cte2.header,'')=ISNULL(CTE1.headers,'')
		AND cte2.spirit_year=CTE1.spirit_year
		AND cte2.spirit_week=CTE1.spirit_week
)
,CTE4 AS
(
SELECT DISTINCT
A.spirit_year
,A.spirit_week
,A.program
,A.business_units
,A.headers

,ISNULL(A.weeklyactuals,0) AS weeklyactuals
,ISNULL(A.weeklyplanned,0) AS weeklyplanned
,ISNULL(A.weekly_variance,0) AS weekly_variance
,ISNULL(A.variance_planned,0) AS variance_planned
,(SELECT SUM(B.weeklyactuals) AS CUM FROM  cte3 AS B 
 WHERE B.spirit_week<=A.spirit_week AND B.program=A.program AND B.headers=A.headers and B.business_units=A.business_units AND B.spirit_year=A.spirit_year)actualcumulativeytd 

,(SELECT SUM(B.weeklyplanned) AS CUM FROM  cte3 AS B 
 WHERE B.spirit_week<=A.spirit_week AND B.program=A.program AND B.headers=A.headers and B.business_units=A.business_units AND B.spirit_year=A.spirit_year)plannedcumulativeytd
,ISNULL(A.escape_weekly$_actuals,0) AS escape_weekly$_actuals

 FROM cte3 as A)
 
 INSERT INTO [reporting].[quality_weekly_program_metrics]
(	   [spirit_year]
      ,[spirit_week]
      ,[program]
      ,[business_units]
      ,[headers]

      ,[weeklyactuals]
      ,[weeklyplanned]
      ,[weekly_variance]
      ,[variance_planned]
      ,[escape_weekly$_actuals]

      ,[actualcumulativeytd]
      ,[plannedcumulativeytd]
)


SELECT 
	   [spirit_year]
      ,[spirit_week]
      ,[program]
      ,[business_units]
      ,[headers]

      ,ISNULL([weeklyactuals],0)
      ,ISNULL([weeklyplanned],0)
      ,ISNULL([weekly_variance],0)
      ,ISNULL([variance_planned],0)
      ,ISNULL([escape_weekly$_actuals],0)

      ,ISNULL([actualcumulativeytd],0)
      ,ISNULL([plannedcumulativeytd],0)

FROM cte4 --WHERE spirit_year=@spirit_year ;
 --Updated Cumulative YTD Ends

 
--Inserting Greenline costs 
INSERT INTO [reporting].[quality_weekly_program_metrics]
(
[spirit_year]
      ,[spirit_week]
      ,[program]
      ,[business_units]
      ,[headers]
      ,[weeklyactuals]

      ,[actualcumulativeytd]
	  ,[plannedcumulativeytd]
	  ,[weeklyplanned]
      ,[weekly_variance]
      ,[variance_planned]
      ,[escape_weekly$_actuals]
)
SELECT DISTINCT  actualgcost.spirit_year
		 ,actualgcost.spirit_week
		 ,actualgcost.program
		 ,actualgcost.business_units
		 ,COALESCE(actualgcost.headers,plannedgcost.headers) AS headers
		 ,ISNULL(actualgcost.weeklyactuals,0)  AS weekly_actuals
		 
		 ,ISNULL(actualgcost.actualcummulativeytd,0) AS actualcummulativeytd
		 ,ISNULL(plannedgcost.plannedcumulativeytd,0) AS plannedcumulativeytd
		 ,ISNULL(plannedgcost.weeklyplanned,0)  AS weekly_planned
		 ,ISNULL(( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ),0)  AS weekly_variance
		 ,ISNULL(( ( ISNULL(weeklyactuals,0) - ISNULL(weeklyplanned, 0) ) / nullif(weeklyplanned,0) ),0) AS  variance_planned
		 ,ISNULL(actualgcost.escapeweekly$actuals,0)
   FROM 
(SELECT   program
		,LOWER(value_chain)     AS business_units 
		,Headers 
		,spirit_week
		,spirit_year

		,weeklyactuals 
		,actualcummulativeytd
		,0 AS escapeweekly$actuals

FROM datamart.fact_greenlinecosts(NOLOCK) WHERE spirit_year>=YEAR(GETDATE())-1 )actualgcost

FULL OUTER JOIN

(SELECT   [model] AS program
		,LOWER(value_chain)     AS business_units
        ,'Greenline costs' AS Headers
        ,[week_no] AS spirit_week
        ,[year] AS spirit_year

        ,[weekly_gl_target] AS [weeklyplanned]
		,[ytd_gl_target] AS plannedcumulativeytd
      
FROM [datamart].[dim_srr_target] WHERE value_chain IS NOT NULL AND [function] IS NULL AND [year]>=YEAR(GETDATE())-1)plannedgcost

ON			actualgcost.spirit_year = plannedgcost.spirit_year
			AND
			actualgcost.spirit_week = plannedgcost.spirit_week 
			AND 
			actualgcost.program = plannedgcost.program 
			AND 
			actualgcost.business_units = plannedgcost.business_units
			

--Ends inserting Greenlinecosts

--Inseerting NOE data
INSERT INTO [reporting].[quality_weekly_program_metrics]
(
[spirit_year]
      ,[spirit_week]
      ,[program]
      ,[business_units]
      ,[headers]
      ,[weeklyactuals]

      ,[actualcumulativeytd]
	  ,[plannedcumulativeytd]
	  ,[weeklyplanned]
      ,[weekly_variance]
      ,[variance_planned]
      ,[escape_weekly$_actuals]
)
SELECT 	  A.spirit_year
		 ,A.spirit_week
		 ,A.program   AS program 
         ,''  AS business_units
		 ,'NOEs [#]'   AS Headers 
         ,ISNULL(SUM(noe_actual),0) AS weekly_actuals

		 ,(SELECT SUM(B.noe_actual) AS CUM FROM  reporting.quality_srr_escape_noe B 
		   WHERE B.spirit_week<=A.spirit_week AND B.program=A.program 
		   AND B.spirit_year=A.spirit_year)actualcumulativeytd
		    
		 ,(SELECT SUM(B.noe_actual) AS CUM FROM  reporting.quality_srr_escape_noe B 
		   WHERE B.spirit_week<=A.spirit_week AND B.program=A.program 
		   AND B.spirit_year=A.spirit_year)Plannedcumulativeytd

		 ,0 AS weekly_planned
		 ,SUM(noe_actual) AS weekly_variance
		 ,0 AS variance_planned
		 ,0 AS escapeweekly$actuals

FROM reporting.quality_srr_escape_noe A

WHERE A.attribute = 'noe' AND A.location IS NULL 
GROUP BY A.program,A.spirit_week,A.spirit_year

DELETE FROM reporting.quality_weekly_program_metrics 
WHERE spirit_week>=@week AND spirit_year=@spirit_year;

UPDATE reporting.refresh_log
SET reporting_period = week_str
,last_refresh_date_time = GETDATE()
,week_no = spirit_week
FROM datamart.vw_dim_calendar
WHERE is_current_week = 1 AND report_name='Quality';

COMMIT TRAN datamart_quality;
END TRY
BEGIN CATCH;

--PRINT 'Unexpected error occurred!'
ROLLBACK TRAN datamart_quality
--RETURN 1


SELECT  
	@errorprocedure='[datamart].[proc_generate_quality_weekly_program_metrics]',
	@errorline=ERROR_LINE(),
	@errornumber=ERROR_NUMBER(),
	@errorseverity=ERROR_SEVERITY(),
	@errorstate=ERROR_STATE(),
	@errormessage=ERROR_MESSAGE();
EXECUTE datamart.proc_log_error   @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
----RAISEERROR(@errormessage,@errorseverity,@errorstate);
RETURN -1;
END CATCH;
RETURN 0;

END

GO


/*
Usage : This SP is used to load package log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_insert_package_log')
 DROP PROC [datamart].[proc_insert_package_log]
GO



CREATE PROC [datamart].[proc_insert_package_log]
(
@package_name VARCHAR(100),
@process_number UNIQUEIDENTIFIER,
@machine_name VARCHAR(100)
)
AS
BEGIN

/***********************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Inserting LOG on package execution  
************************************************************************************************************/

SET NOCOUNT ON;


INSERT INTO datamart.log_package
(
	   [package_name]
	   ,[process_number]
      ,[package_start_time]
      ,machine_name
	  )
VALUES
(
@package_name,
@process_number,
GETDATE(),
@machine_name
);
END;




GO


/*
Usage : This SP is used to load stored procedure log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_log_error')
 DROP PROC [datamart].[proc_log_error]
GO

CREATE PROC [datamart].[proc_log_error] @errorprocedure VARCHAR(50),
								  @errorline INT,
								  @errornumber INT,
								  @errormessage VARCHAR(2048),
								  @errorseverity INT,
								  @errorstate INT
					  
AS
BEGIN
INSERT INTO [datamart].[log_error]
(
[procedure_name]
      ,line_no
      ,[message]
      ,[error_number]
      ,severity
      ,[state]
      ,spid
      ,[user_name]
      ,created_date
	  )
	  VALUES
	  (
	  @errorprocedure
	  ,@errorline
	  ,@errormessage
	  ,@errornumber
	  ,@errorseverity
	  ,@errorstate
	  ,@@SPID
	  ,SYSTEM_USER
	  ,GETDATE()
	  )

	  END


GO



IF EXISTS (SELECT name from sys.procedures where name ='proc_processall_facility')
 DROP PROC datamart.proc_processall_facility
GO

CREATE PROC datamart.proc_processall_facility
as

/*
Usage : Process all facilities related data 

Creator/Editor #Date #Comments
Pratheesh N # 2018-01-30 # Initial Creation
*/

BEGIN

SET NOCOUNT ON;

BEGIN TRAN process_facility;

DECLARE 
@errorline int -- used to call raiseerror
,@errornumber int -- used to call raiseerror
,@errorseverity int -- used to call raiseerror
,@errorstate int -- used to call raiseerror
,@errormessage varchar(2048) -- used to call raiseerror

,@errorprocedure varchar(50)


BEGIN TRY;

execute datamart.proc_cleansing_facility
execute datamart.proc_generate_facility_summary
execute datamart.proc_generate_facility_weekly_variance


COMMIT TRAN process_facility;

END TRY

BEGIN CATCH;

ROLLBACK TRAN process_facility

SELECT @errorprocedure='[datamart].[proc_cleansing_quality]', 
      @errorline=ERROR_LINE(),
      @errornumber=ERROR_NUMBER(),
	   @errorseverity=ERROR_SEVERITY(),
	   @errorstate=CASE WHEN ERROR_STATE()=0 THEN 1 ELSE ERROR_STATE() END,
      @errormessage=ERROR_MESSAGE();


EXECUTE datamart.proc_log_error
                                 @errorprocedure=@errorprocedure,
								  @errorline=@errorline,
								  @errornumber=@errornumber,
								  @errormessage=@errormessage,
								  @errorseverity=@errorseverity,
								  @errorstate=@errorstate
					  
					  
RETURN -1;
END CATCH;
RETURN 0;


END

GO

IF EXISTS (
SELECT name 
from sys.procedures 
where name ='proc_sendmailreminder_missingfiles'
)
DROP PROC datamart.proc_sendmailreminder_missingfiles
GO


CREATE Procedure [datamart].[proc_sendmailreminder_missingfiles]
As 
BEGIN
/*
Usage : To find missing input file AND send notification to respactive biz users.

Creator/Editor #Date #Comments
Praveen C # 2017-11-22 # Initial creation
Praveen C # 2018-01-31 # Modified the logic to exclude already processed files for current week from sending mail 
*/

SET NOCOUNT ON;

DECLARE @errorprocedure VARCHAR(50), --used to store procedure name
@errorline INT, -- used to call RAISEERROR
@errornumber INT, -- used to call RAISEERROR
@errorseverity INT, -- used to call RAISEERROR
@errorstate INT,  -- used to call RAISEERROR
@errormessage VARCHAR(2048)  -- used to call RAISEERROR

Declare @SeqNo int = 1, @NoOfRows int

Declare @File_Code varchar(100)
,@msg_unavailable varchar(MAX)
,@msg_subject varchar(100)
,@mailgroup_user varchar(MAX)
,@mailgroup_dev varchar(MAX)
,@file_description varchar(150)

BEGIN TRY;

Declare @LogDate datetime , @start_date date
SELECT @LogDate = MAX(logdate) 
From datamart.fact_file_exist_log

Select @start_date = MAX(week_start_date)
From datamart.vw_dim_calendar 
Where week_start_date <= @LogDate

-- Update the file_code into log files
;WITH msgCTE AS
(
SELECT @LogDate logdate
,file_code
,file_location+CHAR(92)+file_name file_name
from datamart.dim_mail_messages
)
Update L Set L.file_code = Msg.file_code
From msgCTE Msg
Inner Join datamart.fact_file_exist_log L 
 On L.file_name Like msg.file_name 
 AND L.logdate = @LogDate
Where L.file_code = ''

-- Insert missing log files with status 'NO'
;WITH msgCTE AS
(
SELECT @LogDate logdate
,file_code
,file_location+CHAR(92)+file_name file_name
from datamart.dim_mail_messages
)
, cte_exising_files AS
(
SELECT DISTINCT file_code 
from datamart.fact_file_exist_log l
Where logdate >= @start_date
AND existence = 'Yes'
)

Insert Into datamart.fact_file_exist_log
SELECT Msg.logdate, Msg.file_code, Msg.file_name, 'No', 0 
From msgCTE Msg
Left  Join datamart.fact_file_exist_log L 
 On L.file_name Like msg.file_name 
 AND L.logdate = @LogDate
WHERE L.existence is Null
AND Msg.file_code NOT IN (Select file_code from cte_exising_files)

-- Send mail to biz users or dev
DECLARE db_cursor CURSOR FOR  
SELECT Msg.file_code
,Msg.msg_unavailable
,Msg.mailgroup_user
,Msg.mailgroup_dev
,Msg.msg_subject
From datamart.dim_mail_messages Msg
Inner Join datamart.fact_file_exist_log L 
On L.file_name Like file_location+CHAR(92)+Msg.file_name 
AND L.logdate = @LogDate 
AND L.existence = 'No'
AND L.mail_sent = 0

OPEN db_cursor   
FETCH NEXT FROM db_cursor 
INTO @File_Code, @msg_unavailable, @mailgroup_user, @mailgroup_dev,@msg_subject

WHILE @@FETCH_STATUS = 0   
BEGIN   

If (@mailgroup_user IS NOT Null)
Begin
EXEC msdb.dbo.sp_send_dbmail @profile_name='Spirit_Digi'
,@recipients=@mailgroup_user
,@copy_recipients=@mailgroup_dev
,@subject=@msg_subject
,@body=@msg_unavailable

UPDATE datamart.fact_file_exist_log SET mail_sent =1
WHERE logdate = @logdate 
 AND file_code = @file_code
 
End
FETCH NEXT FROM db_cursor 
INTO @File_Code, @msg_unavailable, @mailgroup_user, @mailgroup_dev,@msg_subject
END   

CLOSE db_cursor   
DEALLOCATE db_cursor

END TRY
BEGIN CATCH;

SELECT @errorprocedure='[datamart].[proc_sendmailreminder_missingfiles]',
@errorline=ERROR_LINE(),
@errornumber=ERROR_NUMBER(),
@errorseverity=ERROR_SEVERITY(),
@errorstate=ERROR_STATE(),
@errormessage=ERROR_MESSAGE();

EXECUTE datamart.proc_log_error   
@errorprocedure=@errorprocedure,
@errorline=@errorline,
@errornumber=@errornumber,
@errormessage=@errormessage,
@errorseverity=@errorseverity,
@errorstate=@errorstate

RETURN -1;
END CATCH;
RETURN 0;
End

GO

IF EXISTS 
(
SELECT name 
from sys.procedures 
where name ='proc_sendmail_failed_packages'
)
DROP PROC datamart.proc_sendmail_failed_packages
GO

CREATE PROCEDURE datamart.proc_sendmail_failed_packages
AS
BEGIN
/*
Usage : To send email alert if any package is failed.

Creator/Editor #Date #Comments
Praveen C # 2017-11-28 # Initial creation
*/
SET NOCOUNT ON

DECLARE @xml NVARCHAR(MAX)
,@body NVARCHAR(MAX)
,@mail_recipients VARCHAR(1000)='praveen.d@genpact.com'
,@total_counts int
,@failed_counts int 

DECLARE @FailedPackages TABLE
(
pk_id INT,
package_name VARCHAR(100),
package_end_time DATETIME,
[error_message] VARCHAR(MAX),
package_status VARCHAR(50)
)

Insert INTO @FailedPackages
SELECT pk_id, package_name, package_end_time, [error_message],package_status
FROM datamart.log_package 
WHERE package_status = 'fail'
AND mail_sent = 0

SELECT @total_counts = COUNT(pk_id)
FROM @FailedPackages

SELECT @failed_counts = COUNT(pk_id)
FROM @FailedPackages
WHERE package_status = 'fail'

IF @failed_counts > 0
BEGIN

SET @xml = CAST(( SELECT package_name AS 'td', '', package_end_time as 'td','',[error_message] AS 'td'
FROM @FailedPackages 
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

SET @body ='<html><body>
Hi Team,
<p>Below packages are failed while processing data, please look into it ASAP.</p>
<H4 style="color:red">Failed packages Info</H4>
<table border = 1> 
<tr>
<th>Package Name</th> <th>Last run Time</th> <th>Error Message</th></tr>'    

SET @body = @body + @xml +'</table>

<p></br>Thanks & Regards,</br>
Digi Analytics Admin</p>
</body></html>'

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'Spirit_Digi',
@body = @body,
@body_format ='HTML',
@recipients = @mail_recipients,
@subject = 'Alert - Packages failed';

UPDATE L SET mail_sent = 1
From datamart.log_package L
INNER JOIN @FailedPackages T 
ON T.pk_id = L.pk_id

--Print @body
END

IF (@failed_counts=0 AND @total_counts=0)
BEGIN

SET @body = '<html><body>
Hi Team,
<p style="color:red">There are no logs found, please check all packages ran correctly?</p>

<p></br>Thanks & Regards,</br>
Digi Analytics Admin</p>
</body></html>'  

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'Spirit_Digi',
@body = @body,
@body_format ='HTML',
@recipients = @mail_recipients,
@subject = 'Alert - Packages are not ran';

END

END

GO

IF EXISTS 
(
SELECT name 
from sys.procedures 
where name ='proc_sendmail_success_packages'
)
DROP PROC datamart.proc_sendmail_success_packages
GO

CREATE PROCEDURE datamart.proc_sendmail_success_packages
AS
BEGIN
/*
Usage : To send email alert after successful execution of packages.

Creator/Editor #Date #Comments
Praveen C # 2017-11-28 # Initial creation
*/
SET NOCOUNT ON

DECLARE @xml NVARCHAR(MAX)
,@body NVARCHAR(MAX)
,@mail_recipients VARCHAR(1000)='jeebanjyoti.paramanik@spiritaero.com;pratheesh.n@spiritaero.com;rushendra.sv@spiritaero.com;Kanak.Agrawal@genpact.com;Prakhar.Shrivastava@genpact.com;Mamidala.RamManohar@genpact.com;LAXMI.NARASIMHA@genpact.com;SHAKATH.SK@genpact.com;Naveen.Bandla@genpact.com'
,@total_counts int

DECLARE @SuccessPackages TABLE
(
pk_id INT,
package_name VARCHAR(100),
package_end_time DATETIME,
[error_message] VARCHAR(MAX)
)

Insert INTO @SuccessPackages
SELECT pk_id, package_name, package_end_time, [error_message]
FROM datamart.log_package 
WHERE package_status = 'Success'
AND mail_sent = 0

SELECT @total_counts = COUNT(pk_id)
FROM @SuccessPackages

IF @total_counts > 0
BEGIN

SET @xml = CAST(( SELECT package_name AS 'td', '', package_end_time as 'td'
FROM @SuccessPackages
FOR XML PATH('tr'), ELEMENTS ) AS NVARCHAR(MAX))

SET @body ='<html><body>
Hi Team,

<H4 style="color:green">Packages ran successfully</H4>
<table border = 1>
<tr>
<th>Package Name</th> <th>Last run Time</th></tr>'    

SET @body = @body + @xml +'</table>

<p></br>Thanks & Regards,</br>
Digi Analytics Admin</p>
</body></html>'

EXEC msdb.dbo.sp_send_dbmail
@profile_name = 'Spirit_Digi',
@body = @body,
@body_format ='HTML',
@recipients = @mail_recipients,
@subject = 'Alert - Packages successful' ;

UPDATE L SET mail_sent = 1
From datamart.log_package L
INNER JOIN @SuccessPackages T 
ON T.pk_id = L.pk_id

END

END

GO
/*
Usage : This SP is used to load stored procedure log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_update_location')
 DROP PROC [staging].[proc_update_location]
GO

CREATE PROC [staging].[proc_update_location]
AS
BEGIN
--For SRR Actual for Wichita,Tulsa,Kinston,SNZ locations
UPDATE staging.ora_srr_fuselage SET location=
(CASE WHEN SUBSTRING(charge_mgmt_code,1,2)='36' THEN 'Wichita'
WHEN SUBSTRING(charge_mgmt_code,1,2)='40' then 'Tulsa'
WHEN SUBSTRING(charge_mgmt_code,1,2)='45' then 'Kinston'
WHEN SUBSTRING(charge_mgmt_code,1,2)='46' then 'SNZ'
END) WHERE location IS NULL


--For Escapes Actual for Wichita,Tulsa,Kinston,SNZ locations
UPDATE staging.ora_escape SET location=
(CASE WHEN SUBSTRING(responsible_mgmt_code,1,2)='36' THEN 'Wichita'
WHEN SUBSTRING(responsible_mgmt_code,1,2)='40' then 'Tulsa'
WHEN SUBSTRING(responsible_mgmt_code,1,2)='45' then 'Kinston'
WHEN SUBSTRING(responsible_mgmt_code,1,2)='46' then 'SNZ'
END) WHERE location IS NULL

--For SRR Targets
UPDATE staging.ftp_srr_target SET location=
(
CASE WHEN sheet_name IN ('737 All Models','747','767','777') AND value_chain IN('Nacelles','Strut','Fuselage') THEN 'Wichita'
WHEN sheet_name='787' AND value_chain IN('Fuselage','Strut') THEN 'Wichita'
WHEN sheet_name='A350 Kinston_SNZ' AND heading IN('SNZ','SNZ-Assembly') THEN 'SNZ'
WHEN sheet_name='A350 Kinston_SNZ' AND heading NOT IN('SNZ','SNZ-Assembly') THEN 'Kinston'
WHEN sheet_name='Malaysia - Airbus Programs' THEN 'Malaysia'
WHEN sheet_name='Prestwick - Airbus Programs' THEN 'Prestwick'
END
) WHERE location IS NULL

--For Escape Targets
UPDATE staging.ftp_escape_target SET location=
(
CASE WHEN sheet_name IN ('737 All Models','747','767','777') AND value_chain IN('Nacelles','Strut','Fuselage') THEN 'Wichita'
WHEN sheet_name='787' AND value_chain IN('Fuselage','Strut') THEN 'Wichita'
WHEN sheet_name='A350 Kinston_SNZ' AND heading IN ('SNZ','SNZ-Assembly') THEN 'SNZ'
WHEN sheet_name='A350 Kinston_SNZ' AND heading NOT  IN ('SNZ','SNZ-Assembly') THEN 'Kinston'
WHEN sheet_name='Prestwick - Airbus Programs' THEN 'Prestwick'
WHEN sheet_name='Malaysia - Airbus Programs' THEN 'Malaysia'
END
) WHERE location IS NULL

--For Escape Actual
UPDATE staging.ora_escape SET location='Wichita' 
WHERE progam_nm in ('737','747','767','777','787','BR725','BR 725','C-Series Pylon','C Series') AND  value_chain_cd in ('Fuselage','Strut','Nacelles','Structures') 
AND location is null;


UPDATE staging.ora_escape SET location='Tulsa' where value_chain_cd IN('TUL-STRUCTURES','TUL-STRUCTURES','TUL/MIL-STRUCTU','MIL-STRUCTURES') AND location IS NULL
AND responsible_mgmt_code IS NULL

--For SRR Targets
UPDATE staging.ftp_srr_target SET location='Wichita'  
WHERE model IN ('737','747','767','777','787','BR725','BR 725','C-Series Pylon','C Series') AND  value_chain IN ('Fuselage','Strut','Nacelles','Structures')
AND location IS NULL
UPDATE staging.ftp_srr_target SET location='Tulsa' WHERE model IN ('737','747','777') AND  value_chain IN ('Wings')  AND location IS NULL
UPDATE  staging.ftp_srr_target SET location='Tulsa' where model in('787')  and location is null AND value_chain='wings' and ([function]<>'MALAYSIA' OR [function] IS NULL)
UPDATE  staging.ftp_srr_target SET location='Malaysia' where model in('787')  and location is null AND value_chain='wings' and [function]='MALAYSIA'
UPDATE staging.ftp_srr_target SET location='Prestwick' WHERE model='767' AND value_chain='Wings' AND location is null
UPDATE  staging.ftp_srr_target SET location='Wichita' where model in('C Series')    and [function] in('ASSY','FAB','MISC') and location is null
UPDATE staging.ftp_srr_target SET location='Wichita' WHERE model='787' AND [function] in('COMP FAB','SYSTEMS') AND location is null


--For Escape Targets
UPDATE staging.ftp_escape_target SET location='Wichita'  
WHERE model IN ('737','747','767','777','787','BR725','BR 725','C-Series Pylon','C Series') AND  value_chain IN ('Fuselage','Strut','Nacelles','Structures')
AND location IS NULL
UPDATE staging.ftp_escape_target SET location='Tulsa' WHERE model IN ('737','747','777') AND  value_chain IN ('Wings')  AND location IS NULL
UPDATE staging.ftp_escape_target SET location='Tulsa' where [function] like 'okla%' AND location is null
UPDATE staging.ftp_escape_target SET location='Tulsa' WHERE [heading] IN ('Oklahoma','Oklahoma-Assembly','Oklahoma-Fabrication','Oklahoma-Misc')
--UPDATE  staging.ftp_escape_target SET location='Tulsa' where model in('787')  and location is null AND value_chain='wings' and ([function]<>'MALAYSIA' OR [function] IS NULL)--208
UPDATE  staging.ftp_escape_target SET location='Malaysia' where model in('787')  and location is null AND value_chain='wings' and [function]='MALAYSIA'
UPDATE staging.ftp_escape_target SET location='Prestwick' WHERE model='767' AND value_chain='Wings' AND location is null
--Check about C-Series sheet with value chain then update
UPDATE  staging.ftp_escape_target SET location='Wichita' where model in('C Series')    and [function] in('ASSY','FAB','MISC') and location is null
UPDATE staging.ftp_escape_target SET location='Wichita' WHERE model='787' AND [function] in('COMP FAB','SYSTEMS') AND location is null
--For Update value_chain as Fuselage for Kinston and SNZ location
UPDATE staging.ora_srr_fuselage SET value_chain='Fuselage' WHERE value_chain IS NULL and location IN('Kinston','SNZ')
UPDATE staging.ora_escape SET value_chain_cd='Fuselage' WHERE value_chain_cd IS NULL and location IN('Kinston','SNZ')
UPDATE staging.ftp_srr_target SET value_chain='Fuselage' WHERE value_chain IS NULL and location IN('Kinston','SNZ')
UPDATE staging.ftp_escape_target SET value_chain='Fuselage' WHERE value_chain IS NULL and location IN('Kinston','SNZ')



--For Update model name for Kinston and Sr.Nazaire locations in SRR Actual
UPDATE staging.ora_srr_fuselage SET model=
(CASE WHEN SUBSTRING(charge_mgmt_code,1,2)='45' THEN 'A350 Kinston'
WHEN SUBSTRING(charge_mgmt_code,1,2)='46' THEN 'A350 St.Nazaire' ELSE model END)
WHERE model='A35'


END

GO


/*
Usage : This SP is used to load stored procedure log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_update_package_error')
 DROP PROC [datamart].[proc_update_package_error]
GO




CREATE PROC [datamart].[proc_update_package_error]
(
@package_name VARCHAR(100),
@process_number UNIQUEIDENTIFIER,
@package_status VARCHAR(20),
@error_message VARCHAR(max)
)
AS
BEGIN

/***********************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Inserting LOG on package execution  
************************************************************************************************************/
SET NOCOUNT ON;

UPDATE datamart.log_package
SET 
[package_end_time]=getdate(),
package_status=@package_status,
[error_message]=@error_message
WHERE [package_name]=@package_name
and process_number=@process_number
END



GO


/*
Usage : This SP is used to load stored procedure log information
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	#Initial creation
*/

IF EXISTS (SELECT name from sys.procedures where name ='proc_update_package_success')
 DROP PROC [datamart].[proc_update_package_success]
GO


CREATE PROC [datamart].[proc_update_package_success]
(
@package_name VARCHAR(100),
@process_number  UNIQUEIDENTIFIER,
@package_status VARCHAR(20)

)
AS
BEGIN


/***********************************************************************************************************
Created By/Modified By	Created/Modified Date	Purpose
Rammanohar M			6/12/2017				Inserting LOG on package execution  
************************************************************************************************************/

SET NOCOUNT ON;
UPDATE datamart.log_package
SET [package_end_time]=GETDATE(),
package_status=@package_status
WHERE [package_name]=@package_name
AND process_number=@process_number
END




GO



IF EXISTS (SELECT name from sys.procedures where name ='proc_update_status_pre_execution')
 DROP PROC datamart.proc_update_status_pre_execution
GO

CREATE PROC datamart.proc_update_status_pre_execution
as

/*
Usage : Update status in dimension tables pre execution of packages

Creator/Editor #Date #Comments
Pratheesh N # 2018-01-30 # Initial Creation
*/

BEGIN

SET NOCOUNT ON;

UPDATE datamart.dim_calendar
SET is_current_week = 0
WHERE is_current_week = 1

;
WITH cte1 as
(
SELECT TOP 2
spirit_year as syear
,spirit_week as sweek
,week_start_date sdate
,ROW_NUMBER () over (order by week_start_date desc) as rno

FROM datamart.vw_dim_calendar

WHERE week_start_date <= GETDATE()
ORDER BY week_start_date desc
)


UPDATE datamart.dim_calendar
SET is_current_week = 1
FROM cte1
WHERE spirit_year = syear
AND spirit_week = sweek
AND rno = 2


END

GO
