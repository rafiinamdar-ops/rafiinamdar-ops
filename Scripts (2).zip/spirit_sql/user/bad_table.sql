/*
Usage : This table is used to load data which doesnot obey cleansing rules
Creator/Editor  #Date			#Comments
Rammanohar		# 2017-10-23	# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'bad_table'
)

CREATE TABLE [datamart].[bad_table](
	[pk_id] [int] IDENTITY(1,1) NOT NULL,
	[table_name] [varchar](50) NULL,
	[run_date] [datetime] NULL,
	[records] [xml] NULL,
PRIMARY KEY CLUSTERED 
(
	[pk_id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
) 

GO




