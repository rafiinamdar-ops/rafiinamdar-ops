
DECLARE @name VARCHAR(1500) -- database name  
DECLARE @dbname VARCHAR(1500) -- database name
Declare @sql varchar(max)

DECLARE db_cursor CURSOR FOR  
SELECT name 
FROM master.sys.databases  
WHERE name NOT IN ('master','model','msdb','tempdb','sqldba')  
order by name


OPEN db_cursor   
FETCH NEXT FROM db_cursor INTO @name   

WHILE @@FETCH_STATUS = 0   
BEGIN
SET @sql='USE ['+@name+']' +'  
		declare @PageSize float
		select @PageSize=v.low/1024.0 from master.dbo.spt_values v where v.number=1 and v.type='''+'E'+''' 
	INSERT INTO SQLDBA.dbo.TableSpace ([DatabaseName],[SchemaName],TableName, NumRows, Reserved, DataUsed, IndexUsed, Unused) 
	SELECT 
			db_name() as DatabaseName
			,SCHEMA_NAME(t.schema_id) AS SchemaName 
			,object_Name(i.object_id) as [name]
		,p.rows
		,Convert(varchar(50),@PageSize * SUM(total_pages))  as [reserved]
		,Convert(varchar(50),@PageSize * SUM(CASE WHEN a.type <> 1 THEN a.used_pages WHEN p.index_id < 2 THEN a.data_pages ELSE 0 END))  as [data]
		,Convert(varchar(50),@PageSize * SUM(a.used_pages - CASE WHEN a.type <> 1 THEN a.used_pages WHEN p.index_id < 2 THEN a.data_pages ELSE 0 END))  as [index_size]
		,Convert(varchar(50),@PageSize * SUM(total_pages-used_pages)) as [unused]
FROM sys.indexes as i
JOIN sys.partitions as p ON p.object_id = i.object_id and p.index_id = i.index_id
JOIN sys.allocation_units as a ON a.container_id = p.partition_id
JOIN sys.tables t ON i.object_id=t.object_id
Where i.type<=1 and a.type=1
and
t.type='''+'U'+''' and is_ms_shipped=0
Group By i.object_id,p.rows,t.schema_id'
--PRINT (@sql)
 EXEC (@sql)

       FETCH NEXT FROM db_cursor INTO @name   
END   

CLOSE db_cursor   
DEALLOCATE db_cursor 
--Select all records so we can use the reults
SELECT * 
FROM  SQLDBA.dbo.TableSpace