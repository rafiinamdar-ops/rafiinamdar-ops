SELECT TOP 500  TextData,StartTime, EndTime, ObjectName,RowCounts 
FROM fn_trace_gettable('F:\Rafik\Ektron\Ektronsync_07312017.trc', default) Trace
INNER JOIN sys.trace_events Events
ON Trace.EventClass = Events.trace_event_id
where TextData is not null
ORDER BY StartTime desc
