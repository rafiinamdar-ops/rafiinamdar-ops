/*
Usage : To find source data for utilization attribute for noa site

Creator/Editor #Date #Comments
Prakhar # 2017-10-17 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'maximo_manpower_utilization_noa'
)
CREATE TABLE staging.maximo_manpower_utilization_noa
(
	personid nvarchar(30),
	shiftnum nvarchar(8),
	workdate date,
	availablehrs float,
	regularhrs float,
	
	siteid nvarchar(8),
	displayname nvarchar(62),
	costcenter nvarchar(20),
	supervisor nvarchar(30),
	department nvarchar(30),
	
	super_name nvarchar(62),
	sec_personid nvarchar(30),
	sec_level_mgr nvarchar(62),
	craft nvarchar(8),
	qualificationid nvarchar(8) 
)

GO


