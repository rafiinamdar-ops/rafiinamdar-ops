USE [SQLDBA]
GO

/****** Object:  Table [dbo].[DB_Devpr_Info_ALL]    Script Date: 11/20/2017 12:24:19 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[DB_Devpr_Info_ALL](
	[Server_Name] [nvarchar](128) NULL,
	[DB_Nm] [varchar](100) NULL,
	[Devpr_Nm] [varchar](50) NULL,
	[Devpr_Ph] [varchar](20) NULL,
	[Devpr_UID] [varchar](8) NULL,
	[DB_Cr_Dt] [varchar](30) NULL,
	[TRD_PRTY_APP] [char](10) NULL,
	[E_Mail] [varchar](100) NULL,
	[Application_name] [varchar](255) NULL,
	[CheckDate] [datetime] NOT NULL CONSTRAINT [DF_DB_Devpr_Info_ALL_CheckDate]  DEFAULT (getdate())
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

