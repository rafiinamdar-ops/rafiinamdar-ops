/*
Usage : To find standard abs % for facilities (headcount)

Creator/Editor #Date #Comments
Pratheesh N # 2017-12-07 # Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'dim_standard_abs_pcg'
)

CREATE TABLE datamart.dim_standard_abs_pcg
(
spirit_year int
,location varchar(100)
,business_unit varchar(100)
,standard_abs_pcg float
)

GO

