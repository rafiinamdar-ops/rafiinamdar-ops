EXEC msdb.dbo.sp_add_notification @alert_name=N'AG Data Movement - Resumed', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'AG Data Movement - Suspended', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
EXEC msdb.dbo.sp_add_notification @alert_name=N'AG Role Change', @operator_name=N'SQL Server DBA', @notification_method = 1
GO
