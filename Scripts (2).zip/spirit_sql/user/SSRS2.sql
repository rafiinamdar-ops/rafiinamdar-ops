DECLARE @Service_Name VARCHAR(100) 
DECLARE @Status varchar(100)
-- Used as Boolean to trigger a change of the account or password or both 
DECLARE @TSQL VARCHAR(500)  

CREATE TABLE #MyTempTable 
    ( 
      Big_String NVARCHAR(500) 
    ) 


INSERT  INTO #MyTempTable 
        EXEC master..xp_cmdshell 
                       'WMIC SERVICE GET Name,state | findstr /I "Report"' 

SELECT @Service_Name=SUBSTRING(big_string, 1, CASE CHARINDEX(' ', big_string)
            WHEN 0
                THEN LEN(big_string)
            ELSE CHARINDEX(' ', big_string) - 1
            END)     
			,@Status=REPLACE((SUBSTRING(big_string, CASE CHARINDEX(' ', big_string)
            WHEN 0
                THEN LEN(big_string) + 1
            ELSE CHARINDEX(' ', big_string) + 1
            END, 1000)),' ','')  FROM #MyTempTable where Big_String is not null

--SELECT @Service_Name ,@Status 

					
		SET @tsql = 'xp_cmdshell "sc stop ' + @Service_Name+'"'
		PRINT (@tsql)
		PRINT 'TIMEOUT 5'

		SET @tsql = 'xp_cmdshell "sc start ' + @Service_Name+'"'
		PRINT (@tsql)
		PRINT 'TIMEOUT 5'
		

		DROP TABLE #MyTempTable 

		