use sqldba
go
create procedure porc_SSRSRestart
AS
DECLARE @PrimaryServer varchar(50)
DECLARE @SecondaryServer varchar(50)
DECLARE @TSQL VARCHAR(500) 
DECLARE @Role_Desc varchar(50)
DECLARE @Service_Name varchar(50)='ReportServer'
DECLARE @SvcStatus varchar(50)
DECLARE @msg as varchar(500)
DECLARE @to as varchar(100)
DECLARE @subject as sysname
CREATE TABLE #MyTempTable 
    ( 
      Big_String NVARCHAR(500) 
    ) 


INSERT  INTO #MyTempTable 
        EXEC master..xp_cmdshell 
                       'WMIC SERVICE GET Name | findstr /I "Report"' 
IF EXISTS (SELECT * FROM #MyTempTable where Big_String is not null and Big_String like '%ReportServer%')
IF (select rs.role_desc from sys.dm_hadr_availability_replica_cluster_nodes n 
	join sys.dm_hadr_availability_replica_cluster_states cs 
	on n.replica_server_name = cs.replica_server_name 
		join sys.dm_hadr_availability_replica_states rs  
		on rs.replica_id = cs.replica_id 
	Where node_name =(@@SERVERNAME) )='PRIMARY'
		Begin
BEGIN
Q:
select @PrimaryServer=n.replica_server_name from sys.dm_hadr_availability_replica_cluster_nodes n 
	join sys.dm_hadr_availability_replica_cluster_states cs 
	on n.replica_server_name = cs.replica_server_name 
		join sys.dm_hadr_availability_replica_states rs  
		on rs.replica_id = cs.replica_id where rs.role_desc ='Primary'
select @SecondaryServer=n.replica_server_name from sys.dm_hadr_availability_replica_cluster_nodes n 
	join sys.dm_hadr_availability_replica_cluster_states cs 
	on n.replica_server_name = cs.replica_server_name 
		join sys.dm_hadr_availability_replica_states rs  
		on rs.replica_id = cs.replica_id where rs.role_desc ='Secondary'

IF @PrimaryServer is null and @SecondaryServer is null
		Begin
               WaitFor Delay '000:00:10'
			   GOTO Q
              End
	ELSE
	BEGIN 

		EXEC sqldba.dbo.proc_CheckService @SecondaryServer,@SvcStatus=@SvcStatus output 
		IF (SELECT @SvcStatus )<>'Stopped'
		BEGIN
		SET @tsql = 'xp_cmdshell "sc \\'+@SecondaryServer+' stop ' + @Service_Name+'"'
		PRINT (@tsql)
		EXEC (@tsql)
		END
		EXEC sqldba.dbo.proc_CheckService @PrimaryServer,@SvcStatus=@SvcStatus output 
		IF (SELECT @SvcStatus )<>'Stopped'
		BEGIN
		SET @tsql = 'xp_cmdshell "sc \\'+@PrimaryServer+' stop ' + @Service_Name+'"'
		PRINT (@tsql)
		EXEC (@tsql)
		END
		EXEC sqldba.dbo.proc_CheckService @PrimaryServer,@SvcStatus=@SvcStatus output 
		IF (SELECT @SvcStatus )<>'Stopped'
		BEGIN
		WaitFor Delay '000:00:10'
		SET @tsql = 'xp_cmdshell "sc \\'+@PrimaryServer+' start ' + @Service_Name+'"'
		PRINT (@tsql)
		EXEC (@tsql)
		END
		ELSE 
		BEGIN
		SET @tsql = 'xp_cmdshell "sc \\'+@PrimaryServer+' start ' + @Service_Name+'"'
		PRINT (@tsql)
		EXEC (@tsql)
		END
		EXEC sqldba.dbo.proc_CheckService @SecondaryServer,@SvcStatus=@SvcStatus output 
		IF (SELECT @SvcStatus )<>'Stopped'
		BEGIN
		WaitFor Delay '000:00:10'
		SET @tsql = 'xp_cmdshell "sc \\'+@SecondaryServer+' start ' + @Service_Name+'"'
		PRINT (@tsql)
		EXEC (@tsql)
		END
		ELSE
		BEGIN
		SET @tsql = 'xp_cmdshell "sc \\'+@SecondaryServer+' start ' + @Service_Name+'"'
		PRINT (@tsql)
		EXEC (@tsql)
		END
	END
WaitFor Delay '000:00:10'
 SET @to = (select email_address from msdb..sysoperators where name = 'SQL Server DBA')

 set @msg = 'The Report Server Service is not running on '+@PrimaryServer+'. Please check'
EXEC sqldba.dbo.proc_CheckService @PrimaryServer,@SvcStatus=@SvcStatus output 
--SELECT @SvcStatus,@PrimaryServer
		IF (SELECT @SvcStatus )='Stopped'
		     BEGIN
				    SET @to = (select email_address from msdb..sysoperators where name = 'SQL Server DBA')
				    SET @subject = 'ALERT: Report Server Service Stopped -- '+@PrimaryServer
					exec msdb.dbo.sp_send_dbmail @recipients = @to
						, @subject = @subject
						, @body = @msg
               END		
 set @msg = 'The Report Server Service is not running on '+@SecondaryServer+'. Please check'
 --SELECT @SvcStatus,@SecondaryServer
EXEC sqldba.dbo.proc_CheckService @SecondaryServer,@SvcStatus=@SvcStatus output 
		IF (SELECT @SvcStatus )='Stopped'
		     BEGIN
				    SET @to = (select email_address from msdb..sysoperators where name = 'SQL Server DBA')
				    SET @subject = 'ALERT: Report Server Service Stopped -- '+@SecondaryServer
					exec msdb.dbo.sp_send_dbmail @recipients = @to
						, @subject = @subject
						, @body = @msg
               END		
END
END
DROP TABLE #MyTempTable

