 use reportserver
go
SELECT
     S.ScheduleID AS SQLAgent_Job_Name
     ,SUB.Description AS Sub_Desc
     ,SUB.DeliveryExtension AS Sub_Del_Extension
     ,C.Name AS ReportName
     ,C.Path AS ReportPath
	 ,REPLACE(REPLACE(CAST(SUB.Parameters as NVARCHAR(MAX)),'<ParameterValues><ParameterValue><Name>ServerName</Name><Value>','')
	 ,'</Value></ParameterValue></ParameterValues>','') AS ServerSchedule

FROM ReportSchedule RS
     INNER JOIN Schedule S ON (RS.ScheduleID = S.ScheduleID)
     INNER JOIN Subscriptions SUB ON (RS.SubscriptionID = SUB.SubscriptionID)
     INNER JOIN [Catalog] C ON (RS.ReportID = C.ItemID AND SUB.Report_OID = C.ItemID)
WHERE
     C.Name LIKE '%table%' and SUB.Parameters like '%sql%'

	 USE msdb
go
EXEC [sql-ent-85].msdb.dbo.sp_start_job @job_name ='B3699BCF-97EA-41E8-8675-0E0524741ED7'
go
EXEC [sql-ent-85].msdb.dbo.sp_start_job @job_name ='B7FF10B4-A516-477F-B8B2-4A02DD470BAF'
go

select * from ReportSchedule
select * from Subscriptions


