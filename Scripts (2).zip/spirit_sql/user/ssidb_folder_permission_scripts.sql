
USE [master]
GO
CREATE LOGIN [CORP\GenPactSQLIS] FROM WINDOWS WITH DEFAULT_DATABASE=[SSISDB]
GO
USE [SSISDB]
GO
CREATE USER [CORP\GenPactSQLIS] FOR LOGIN [CORP\GenPactSQLIS]
GO
use ssisdb
go
declare @pid as int
Declare @folderid as int

SET @pid=(SELECT DATABASE_PRINCIPAL_ID('CORP\GenPactSQLIS') )
SET @folderid=(SELECT [folder_id] FROM [SSISDB].[internal].[folders] where [name]='SpiritDigi')

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=@folderid, @principal_id=@pid, @permission_type=1

EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=@folderid, @principal_id= @pid, @permission_type=100


EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=@folderid, @principal_id=@pid, @permission_type=102


EXEC [SSISDB].[catalog].[grant_permission] @object_type=1, @object_id=@folderid, @principal_id=@pid, @permission_type=101

 SELECT * FROM [SSISDB].[internal].[folders]


 EXEC [SSISDB].[catalog].[grant_permission] @object_type=2, @object_id=26, @principal_id=14, @permission_type=3
GO




