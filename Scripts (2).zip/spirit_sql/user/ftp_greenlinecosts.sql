/*
Usage : This table is used to load unstructured data for greenlinecost 

Creator/Editor #Date            #Comments
Rammanohar     # 2017-10-17		# Initial creation
*/

IF NOT EXISTS
(
SELECT name
FROM sys.tables 
WHERE name = 'ftp_greenlinecosts'
)

CREATE TABLE [staging].[ftp_greenlinecosts](
	[week_date] [date] NULL,
	[737NG_gl] [float] NULL,
	[737MAX_gl] [float] NULL,
	[P8A_gl] [float] NULL,
	[747_gl] [float] NULL,
	[767_gl] [float] NULL,
	[777_gl] [float] NULL,
	[787_GL] [float] NULL,
	[C-Series_gl] [float] NULL,
	[br725_gl] [float] NULL,
	[value_chain] [nvarchar](50) NULL,
	[load_date] [datetime] DEFAULT (getdate())
) 

GO




