SELECT @@ServerName AS ServerName, q.duration,q.cpu_time,q.physical_reads,q.logical_reads,q.writes,statement--,event_data_XML,statement,timestamp
FROM   (
       SELECT  duration=e.event_data_XML.value('(//data[@name="duration"]/value)[1]','int')
       ,       cpu_time=e.event_data_XML.value('(//data[@name="cpu_time"]/value)[1]','int')
       ,       physical_reads=e.event_data_XML.value('(//data[@name="physical_reads"]/value)[1]','int')
       ,       logical_reads=e.event_data_XML.value('(//data[@name="logical_reads"]/value)[1]','int')
       ,       writes=e.event_data_XML.value('(//data[@name="writes"]/value)[1]','int')
       ,       statement=e.event_data_XML.value('(//data[@name="statement"]/value)[1]','nvarchar(max)')
       ,       TIMESTAMP=e.event_data_XML.value('(//@timestamp)[1]','datetime2(7)')
       ,       *
       FROM    (
               SELECT CAST(event_data AS XML) AS event_data_XML
               FROM sys.fn_xe_file_target_read_file('J:\temp\queryperf*.xel', NULL, NULL, NULL)
               )e
       )q
--WHERE  q.[statement] LIKE 'select @salesTally = count(*)%' --Filters out all the detritus that we're not interested in!
ORDER  BY q.[timestamp] ASC 