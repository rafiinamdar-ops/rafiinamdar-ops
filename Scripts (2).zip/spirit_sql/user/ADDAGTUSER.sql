


--SET @Servername='SQL-FAC-02.FACICT.SPIRITAERO.COM\DEV'
DECLARE @name VARCHAR(100) -- database name  
/****** Object:  Table [dbo].[!DB_Devpr_Info]    Script Date: 6/8/2017 12:29:57 AM ******/
DECLARE @cmd varchar(1000)
DECLARE @objectname varchar(50)



DECLARE db_cursor CURSOR FOR  

select name from master.sys.databases 
			WHERE name NOT IN ('master','msdb','tempdb','model','ReportServer','ReportServerTempDB')  and state_desc not in ('OFFLINE')

OPEN db_cursor  
FETCH NEXT FROM db_cursor INTO @name  

WHILE @@FETCH_STATUS = 0  
BEGIN 

SET @cmd='USE ['+@name+']
	
	CREATE USER [CORP\svcsqlagt] FOR LOGIN [CORP\svcsqlagt]



GRANT SELECT ON [dbo].[!DB_Devpr_Info] TO [CORP\svcsqlagt]
'
--PRINT @Cmd
EXEC (@cmd)

 FETCH NEXT FROM db_cursor INTO @name  
END  


CLOSE db_cursor  
DEALLOCATE db_cursor 


GO