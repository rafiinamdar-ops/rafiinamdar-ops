CREATE SCHEMA staging
GO

CREATE SCHEMA datamart
GO

CREATE SCHEMA reporting
GO
