USE master
GO
SELECT e.name as EndpointName,
sp.name AS EndpointOwner,
et.PayloadType,
e.state_desc
FROM sys.endpoints e
INNER JOIN sys.server_principals sp
ON e.principal_id = sp.principal_id
RIGHT OUTER JOIN ( VALUES ( 2, 'TSQL'),
( 3, 'SERVICE_BROKER'), ( 4, 'DATABASE_MIRRORING') )
AS et ( typeid, PayloadType )
ON et.typeid = e.type
where e.name in ('Hadr_endpoint')
USE master
GO
ALTER AUTHORIZATION ON ENDPOINT::Hadr_endpoint TO sa

USE master
GO
SELECT e.name as EndpointName,
sp.name AS EndpointOwner,
et.PayloadType,
e.state_desc
FROM sys.endpoints e
INNER JOIN sys.server_principals sp
ON e.principal_id = sp.principal_id
RIGHT OUTER JOIN ( VALUES ( 2, 'TSQL'),
( 3, 'SERVICE_BROKER'), ( 4, 'DATABASE_MIRRORING') )
AS et ( typeid, PayloadType )
ON et.typeid = e.type
where e.name in ('Hadr_endpoint')

USE [master]
GO
SELECT pm.class, pm.class_desc, pm.major_id, pm.minor_id, 
   pm.grantee_principal_id, pm.grantor_principal_id, 
   pm.[type], pm.[permission_name], pm.[state],pm.state_desc, 
   pr.[name] AS [owner], gr.[name] AS grantee
FROM sys.server_permissions pm 
   JOIN sys.server_principals pr ON pm.grantor_principal_id = pr.principal_id
   JOIN sys.server_principals gr ON pm.grantee_principal_id = gr.principal_id
WHERE pr.[name] in (N'corp\p9012592',N'corp\s9012592')


USE [master]
GO
SELECT pm.class, pm.class_desc, pm.major_id, pm.minor_id, 
   pm.grantee_principal_id, pm.grantor_principal_id, 
   pm.[type], pm.[permission_name], pm.[state],pm.state_desc, 
   pr.[name] AS [owner], gr.[name] AS grantee, e.[name] AS endpoint_name
FROM sys.server_permissions pm 
   JOIN sys.server_principals pr ON pm.grantor_principal_id = pr.principal_id
   JOIN sys.server_principals gr ON pm.grantee_principal_id = gr.principal_id
   JOIN sys.endpoints e ON pm.grantor_principal_id = e.principal_id 
        AND pm.major_id = e.endpoint_id
--WHERE pr.[name]  in () (N'corp\p9012592',N'corp\s9012592')


----list of Availability Groups owned by the login

USE [master]
GO
SELECT ag.[name] AS AG_name, ag.group_id, r.replica_id, r.owner_sid, p.[name] as owner_name 
FROM sys.availability_groups ag 
   JOIN sys.availability_replicas r ON ag.group_id = r.group_id
   JOIN sys.server_principals p ON r.owner_sid = p.[sid]
WHERE p.[name] = N'sa'
GO  

---Now we will re-assign the AG's ownership to the renamed "sa" login:
SELECT 'ALTER AUTHORIZATION ON AVAILABILITY GROUP::['+ag.[name]+'] to [sa]'
FROM sys.availability_groups ag 
   JOIN sys.availability_replicas r ON ag.group_id = r.group_id
   JOIN sys.server_principals p ON r.owner_sid = p.[sid]
WHERE p.[name]  in (N'corp\p9012592',N'corp\s9012592')

ALTER AUTHORIZATION ON AVAILABILITY GROUP::[SQL-ICT-01-AAG] to [sa]
--ALTER AUTHORIZATION ON AVAILABILITY GROUP::TESTAG to [sa]
--When we've tried to drop the login on the secondary replica we get another error:
ALTER AUTHORIZATION ON AVAILABILITY GROUP::[sql-ict-03-aag] to [sa]
USE [master]
GO
DROP LOGIN [CORP\p9012592]
GO

USE [master]
GO
SELECT 'EXEC ['+[name]+']..sp_changedbowner ''sa''' AS dbname FROM sys.databases WHERE SUSER_SNAME(owner_sid) = N'CORP\p9012592'
GO
----To Change job owner to sa

 select 'EXEC msdb.dbo.sp_update_job @job_id=N'''+cast(job_id as varchar(max))+''', @owner_login_name=N''sa''' from msdb..sysjobs WHERE SUSER_SNAME(owner_sid) = N'CORP\p9012592'

 SELECT agr.replica_server_name, 
   agr.[endpoint_url],
   agrs.connected_state_desc, 
   agrs.last_connect_error_description, 
   agrs.last_connect_error_number, 
   agrs.last_connect_error_timestamp 
FROM sys.dm_hadr_availability_replica_states agrs 
JOIN sys.availability_replicas agr ON agrs.replica_id = agr.replica_id
WHERE agrs.is_local = 1


USE [master]
GO
GRANT CONNECT ON ENDPOINT::Hadr_endpoint TO [corp\svcsqlss];
GO
