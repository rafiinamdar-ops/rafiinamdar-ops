USE [SQLDBA]
GO
/****** Object:  Table [dbo].[GrowthTable]    Script Date: 6/21/2017 3:42:24 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[GrowthTable](
	[ServerName] [nvarchar](50) NULL,
	[RunDate] [datetime] NULL,
	[DatabaseName] [nvarchar](128) NULL,
	[SchemaName] [nvarchar](128) NULL,
	[TableName] [nvarchar](128) NULL,
	[NumRows] [int] NULL,
	[ReservedInKB] [int] NULL,
	[DataUsedInKB] [int] NULL,
	[IndexUsedInKB] [int] NULL,
	[RowNum] [tinyint] NULL
) ON [PRIMARY]

GO
/****** Object:  Table [dbo].[TableSpace]    Script Date: 6/21/2017 3:42:24 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[TableSpace](
	[ServerName] [nvarchar](50) NULL,
	[RunDate] [datetime] NOT NULL CONSTRAINT [DF_TableSpace_RunDate]  DEFAULT (getdate()),
	[DatabaseName] [nvarchar](128) NULL,
	[SchemaName] [nvarchar](128) NULL,
	[TableName] [nvarchar](128) NOT NULL,
	[NumRows] [int] NOT NULL,
	[Reserved] [nchar](16) NOT NULL,
	[DataUsed] [nchar](16) NOT NULL,
	[IndexUsed] [nchar](16) NOT NULL,
	[Unused] [nchar](16) NOT NULL
) ON [PRIMARY]

GO
